# InputTags

### *class* sklearn.utils.InputTags(one_d_array: [bool](https://docs.python.org/3/library/functions.html#bool) = False, two_d_array: [bool](https://docs.python.org/3/library/functions.html#bool) = True, three_d_array: [bool](https://docs.python.org/3/library/functions.html#bool) = False, sparse: [bool](https://docs.python.org/3/library/functions.html#bool) = False, categorical: [bool](https://docs.python.org/3/library/functions.html#bool) = False, string: [bool](https://docs.python.org/3/library/functions.html#bool) = False, dict: [bool](https://docs.python.org/3/library/functions.html#bool) = False, positive_only: [bool](https://docs.python.org/3/library/functions.html#bool) = False, allow_nan: [bool](https://docs.python.org/3/library/functions.html#bool) = False, pairwise: [bool](https://docs.python.org/3/library/functions.html#bool) = False)

Tags for the input data.

* **Parameters:**
  **one_d_array**
  : Whether the input can be a 1D array.

  **two_d_array**
  : Whether the input can be a 2D array. Note that most common
    tests currently run only if this flag is set to `True`.

  **three_d_array**
  : Whether the input can be a 3D array.

  **sparse**
  : Whether the input can be a sparse matrix.

  **categorical**
  : Whether the input can be categorical.

  **string**
  : Whether the input can be an array-like of strings.

  **dict**
  : Whether the input can be a dictionary.

  **positive_only**
  : Whether the estimator requires positive X.

  **allow_nan**
  : Whether the estimator supports data with missing values encoded as `np.nan`.

  **pairwise**
  : This boolean attribute indicates whether the data (`X`),
    [fit](../../glossary.md#term-fit) and similar methods consists of pairwise measures
    over samples rather than a feature representation for each
    sample.  It is usually `True` where an estimator has a
    `metric` or `affinity` or `kernel` parameter with value
    ‘precomputed’. Its primary purpose is to support a
    [meta-estimator](../../glossary.md#term-meta-estimator) or a cross validation procedure that
    extracts a sub-sample of data intended for a pairwise
    estimator, where the data needs to be indexed on both axes.
    Specifically, this tag is used by
    `sklearn.utils.metaestimators._safe_split` to slice rows and
    columns.
    <br/>
    Note that if setting this tag to `True` means the estimator can take only
    positive values, the `positive_only` tag must reflect it and also be set to
    `True`.

<!-- !! processed by numpydoc !! -->
