# fetch_covtype

### sklearn.datasets.fetch_covtype(\*, data_home=None, download_if_missing=True, random_state=None, shuffle=False, return_X_y=False, as_frame=False, n_retries=3, delay=1.0)

Load the covertype dataset (classification).

Download it if necessary.

| Classes        | 7      |
|----------------|--------|
| Samples total  | 581012 |
| Dimensionality | 54     |
| Features       | int    |

Read more in the [User Guide](../../datasets/real_world.md#covtype-dataset).

* **Parameters:**
  **data_home**
  : Specify another download and cache folder for the datasets. By default
    all scikit-learn data is stored in ‘~/scikit_learn_data’ subfolders.

  **download_if_missing**
  : If False, raise an OSError if the data is not locally available
    instead of trying to download the data from the source site.

  **random_state**
  : Determines random number generation for dataset shuffling. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **shuffle**
  : Whether to shuffle dataset.

  **return_X_y**
  : If True, returns `(data.data, data.target)` instead of a Bunch
    object.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **as_frame**
  : If True, the data is a pandas DataFrame including columns with
    appropriate dtypes (numeric). The target is a pandas DataFrame or
    Series depending on the number of target columns. If `return_X_y` is
    True, then (`data`, `target`) will be pandas DataFrames or Series as
    described below.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **n_retries**
  : Number of retries when HTTP errors are encountered.
    <br/>
    #### Versionadded
    Added in version 1.5.

  **delay**
  : Number of seconds between retries.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **dataset**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : Each row corresponds to the 54 features in the dataset.
    <br/>
    target
    : Each value corresponds to one of
      the 7 forest covertypes with values
      ranging between 1 to 7.
    <br/>
    frame
    : Only present when `as_frame=True`. Contains `data` and `target`.
    <br/>
    DESCR
    : Description of the forest covertype dataset.
    <br/>
    feature_names
    : The names of the dataset columns.
    <br/>
    target_names: list
    : The names of the target columns.

  **(data, target)**
  : A tuple of two ndarray. The first containing a 2D array of
    shape (n_samples, n_features) with each row representing one
    sample and each column representing the features. The second
    ndarray of shape (n_samples,) containing the target samples.
    <br/>
    #### Versionadded
    Added in version 0.20.

### Examples

```pycon
>>> from sklearn.datasets import fetch_covtype
>>> cov_type = fetch_covtype()
>>> cov_type.data.shape
(581012, 54)
>>> cov_type.target.shape
(581012,)
>>> # Let's check the 4 first feature names
>>> cov_type.feature_names[:4]
['Elevation', 'Aspect', 'Slope', 'Horizontal_Distance_To_Hydrology']
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of PolynomialCountSketch to efficiently generate polynomial kernel feature-space approximations. This is used to train linear classifiers that approximate the accuracy of kernelized ones.">  <div class="sphx-glr-thumbnail-title">Scalable learning with polynomial kernel approximation</div>
</div>
* [Scalable learning with polynomial kernel approximation](../../auto_examples/kernel_approximation/plot_scalable_poly_kernels.md#sphx-glr-auto-examples-kernel-approximation-plot-scalable-poly-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
