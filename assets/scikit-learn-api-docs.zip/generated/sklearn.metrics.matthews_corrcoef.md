# matthews_corrcoef

### sklearn.metrics.matthews_corrcoef(y_true, y_pred, \*, sample_weight=None)

Compute the Matthews correlation coefficient (MCC).

The Matthews correlation coefficient is used in machine learning as a
measure of the quality of binary and multiclass classifications. It takes
into account true and false positives and negatives and is generally
regarded as a balanced measure which can be used even if the classes are of
very different sizes. The MCC is in essence a correlation coefficient value
between -1 and +1. A coefficient of +1 represents a perfect prediction, 0
an average random prediction and -1 an inverse prediction.  The statistic
is also known as the phi coefficient. [source: Wikipedia]

Binary and multiclass labels are supported.  Only in the binary case does
this relate to information about true and false positives and negatives.
See references below.

Read more in the [User Guide](../model_evaluation.md#matthews-corrcoef).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated targets as returned by a classifier.

  **sample_weight**
  : Sample weights.
    <br/>
    #### Versionadded
    Added in version 0.18.
* **Returns:**
  **mcc**
  : The Matthews correlation coefficient (+1 represents a perfect
    prediction, 0 an average random prediction and -1 and inverse
    prediction).

### References

### Examples

```pycon
>>> from sklearn.metrics import matthews_corrcoef
>>> y_true = [+1, +1, +1, -1]
>>> y_pred = [+1, -1, +1, +1]
>>> matthews_corrcoef(y_true, y_pred)
np.float64(-0.33...)
```

<!-- !! processed by numpydoc !! -->
