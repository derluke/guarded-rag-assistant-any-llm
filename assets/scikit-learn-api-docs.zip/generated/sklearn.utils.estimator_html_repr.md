# estimator_html_repr

### sklearn.utils.estimator_html_repr(estimator)

Build a HTML representation of an estimator.

Read more in the [User Guide](../compose.md#visualizing-composite-estimators).

* **Parameters:**
  **estimator**
  : The estimator to visualize.
* **Returns:**
  html: str
  : HTML representation of estimator.

### Examples

```pycon
>>> from sklearn.utils._estimator_html_repr import estimator_html_repr
>>> from sklearn.linear_model import LogisticRegression
>>> estimator_html_repr(LogisticRegression())
'<style>...</div>'
```

<!-- !! processed by numpydoc !! -->
