# RegressorChain

### *class* sklearn.multioutput.RegressorChain(base_estimator, \*, order=None, cv=None, random_state=None, verbose=False)

A multi-label model that arranges regressions into a chain.

Each model makes a prediction in the order specified by the chain using
all of the available features provided to the model plus the predictions
of models that are earlier in the chain.

Read more in the [User Guide](../multiclass.md#regressorchain).

#### Versionadded
Added in version 0.20.

* **Parameters:**
  **base_estimator**
  : The base estimator from which the regressor chain is built.

  **order**
  : If `None`, the order will be determined by the order of columns in
    the label matrix Y.:
    ```default
    order = [0, 1, 2, ..., Y.shape[1] - 1]
    ```
    <br/>
    The order of the chain can be explicitly set by providing a list of
    integers. For example, for a chain of length 5.:
    ```default
    order = [1, 3, 2, 4, 0]
    ```
    <br/>
    means that the first model in the chain will make predictions for
    column 1 in the Y matrix, the second model will make predictions
    for column 3, etc.
    <br/>
    If order is ‘random’ a random ordering will be used.

  **cv**
  : Determines whether to use cross validated predictions or true
    labels for the results of previous estimators in the chain.
    Possible inputs for cv are:
    - None, to use true labels when fitting,
    - integer, to specify the number of folds in a (Stratified)KFold,
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.

  **random_state**
  : If `order='random'`, determines random number generation for the
    chain order.
    In addition, it controls the random seed given at each `base_estimator`
    at each chaining iteration. Thus, it is only used when `base_estimator`
    exposes a `random_state`.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **verbose**
  : If True, chain progress is output as each model is completed.
    <br/>
    #### Versionadded
    Added in version 1.2.
* **Attributes:**
  **estimators_**
  : A list of clones of base_estimator.

  **order_**
  : The order of labels in the classifier chain.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying `base_estimator` exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`ClassifierChain`](sklearn.multioutput.ClassifierChain.md#sklearn.multioutput.ClassifierChain)
: Equivalent for classification.

[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)
: Learns each output independently rather than chaining.

### Examples

```pycon
>>> from sklearn.multioutput import RegressorChain
>>> from sklearn.linear_model import LogisticRegression
>>> logreg = LogisticRegression(solver='lbfgs')
>>> X, Y = [[1, 0], [0, 1], [1, 1]], [[0, 2], [1, 1], [2, 0]]
>>> chain = RegressorChain(base_estimator=logreg, order=[0, 1]).fit(X, Y)
>>> chain.predict(X)
array([[0., 2.],
       [1., 1.],
       [2., 0.]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, Y, \*\*fit_params)

Fit the model to data matrix X and targets Y.

* **Parameters:**
  **X**
  : The input data.

  **Y**
  : The target values.

  **\*\*fit_params**
  : Parameters passed to the `fit` method at each step
    of the regressor chain.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **self**
  : Returns a fitted instance.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.3.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict on the data matrix X using the ClassifierChain model.

* **Parameters:**
  **X**
  : The input data.
* **Returns:**
  **Y_pred**
  : The predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RegressorChain](#sklearn.multioutput.RegressorChain)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->
