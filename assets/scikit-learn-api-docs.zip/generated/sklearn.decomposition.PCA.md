# PCA

### *class* sklearn.decomposition.PCA(n_components=None, \*, copy=True, whiten=False, svd_solver='auto', tol=0.0, iterated_power='auto', n_oversamples=10, power_iteration_normalizer='auto', random_state=None)

Principal component analysis (PCA).

Linear dimensionality reduction using Singular Value Decomposition of the
data to project it to a lower dimensional space. The input data is centered
but not scaled for each feature before applying the SVD.

It uses the LAPACK implementation of the full SVD or a randomized truncated
SVD by the method of Halko et al. 2009, depending on the shape of the input
data and the number of components to extract.

With sparse inputs, the ARPACK implementation of the truncated SVD can be
used (i.e. through [`scipy.sparse.linalg.svds`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.svds.html#scipy.sparse.linalg.svds)). Alternatively, one
may consider [`TruncatedSVD`](sklearn.decomposition.TruncatedSVD.md#sklearn.decomposition.TruncatedSVD) where the data are not centered.

Notice that this class only supports sparse inputs for some solvers such as
“arpack” and “covariance_eigh”. See [`TruncatedSVD`](sklearn.decomposition.TruncatedSVD.md#sklearn.decomposition.TruncatedSVD) for an
alternative with sparse data.

For a usage example, see
[Principal Component Analysis (PCA) on Iris Dataset](../../auto_examples/decomposition/plot_pca_iris.md#sphx-glr-auto-examples-decomposition-plot-pca-iris-py)

Read more in the [User Guide](../decomposition.md#pca).

* **Parameters:**
  **n_components**
  : Number of components to keep.
    if n_components is not set all components are kept:
    ```default
    n_components == min(n_samples, n_features)
    ```
    <br/>
    If `n_components == 'mle'` and `svd_solver == 'full'`, Minka’s
    MLE is used to guess the dimension. Use of `n_components == 'mle'`
    will interpret `svd_solver == 'auto'` as `svd_solver == 'full'`.
    <br/>
    If `0 < n_components < 1` and `svd_solver == 'full'`, select the
    number of components such that the amount of variance that needs to be
    explained is greater than the percentage specified by n_components.
    <br/>
    If `svd_solver == 'arpack'`, the number of components must be
    strictly less than the minimum of n_features and n_samples.
    <br/>
    Hence, the None case results in:
    ```default
    n_components == min(n_samples, n_features) - 1
    ```

  **copy**
  : If False, data passed to fit are overwritten and running
    fit(X).transform(X) will not yield the expected results,
    use fit_transform(X) instead.

  **whiten**
  : When True (False by default) the `components_` vectors are multiplied
    by the square root of n_samples and then divided by the singular values
    to ensure uncorrelated outputs with unit component-wise variances.
    <br/>
    Whitening will remove some information from the transformed signal
    (the relative variance scales of the components) but can sometime
    improve the predictive accuracy of the downstream estimators by
    making their data respect some hard-wired assumptions.

  **svd_solver**
  : “auto” :
    : The solver is selected by a default ‘auto’ policy is based on `X.shape` and
      `n_components`: if the input data has fewer than 1000 features and
      more than 10 times as many samples, then the “covariance_eigh”
      solver is used. Otherwise, if the input data is larger than 500x500
      and the number of components to extract is lower than 80% of the
      smallest dimension of the data, then the more efficient
      “randomized” method is selected. Otherwise the exact “full” SVD is
      computed and optionally truncated afterwards.
    <br/>
    “full” :
    : Run exact full SVD calling the standard LAPACK solver via
      `scipy.linalg.svd` and select the components by postprocessing
    <br/>
    “covariance_eigh” :
    : Precompute the covariance matrix (on centered data), run a
      classical eigenvalue decomposition on the covariance matrix
      typically using LAPACK and select the components by postprocessing.
      This solver is very efficient for n_samples >> n_features and small
      n_features. It is, however, not tractable otherwise for large
      n_features (large memory footprint required to materialize the
      covariance matrix). Also note that compared to the “full” solver,
      this solver effectively doubles the condition number and is
      therefore less numerical stable (e.g. on input data with a large
      range of singular values).
    <br/>
    “arpack” :
    : Run SVD truncated to `n_components` calling ARPACK solver via
      `scipy.sparse.linalg.svds`. It requires strictly
      `0 < n_components < min(X.shape)`
    <br/>
    “randomized” :
    : Run randomized SVD by the method of Halko et al.
    <br/>
    #### Versionadded
    Added in version 0.18.0.
    <br/>
    #### Versionchanged
    Changed in version 1.5: Added the ‘covariance_eigh’ solver.

  **tol**
  : Tolerance for singular values computed by svd_solver == ‘arpack’.
    Must be of range [0.0, infinity).
    <br/>
    #### Versionadded
    Added in version 0.18.0.

  **iterated_power**
  : Number of iterations for the power method computed by
    svd_solver == ‘randomized’.
    Must be of range [0, infinity).
    <br/>
    #### Versionadded
    Added in version 0.18.0.

  **n_oversamples**
  : This parameter is only relevant when `svd_solver="randomized"`.
    It corresponds to the additional number of random vectors to sample the
    range of `X` so as to ensure proper conditioning. See
    [`randomized_svd`](sklearn.utils.extmath.randomized_svd.md#sklearn.utils.extmath.randomized_svd) for more details.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **power_iteration_normalizer**
  : Power iteration normalizer for randomized SVD solver.
    Not used by ARPACK. See [`randomized_svd`](sklearn.utils.extmath.randomized_svd.md#sklearn.utils.extmath.randomized_svd)
    for more details.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **random_state**
  : Used when the ‘arpack’ or ‘randomized’ solvers are used. Pass an int
    for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
    <br/>
    #### Versionadded
    Added in version 0.18.0.
* **Attributes:**
  **components_**
  : Principal axes in feature space, representing the directions of
    maximum variance in the data. Equivalently, the right singular
    vectors of the centered input data, parallel to its eigenvectors.
    The components are sorted by decreasing `explained_variance_`.

  **explained_variance_**
  : The amount of variance explained by each of the selected components.
    The variance estimation uses `n_samples - 1` degrees of freedom.
    <br/>
    Equal to n_components largest eigenvalues
    of the covariance matrix of X.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **explained_variance_ratio_**
  : Percentage of variance explained by each of the selected components.
    <br/>
    If `n_components` is not set then all components are stored and the
    sum of the ratios is equal to 1.0.

  **singular_values_**
  : The singular values corresponding to each of the selected components.
    The singular values are equal to the 2-norms of the `n_components`
    variables in the lower-dimensional space.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **mean_**
  : Per-feature empirical mean, estimated from the training set.
    <br/>
    Equal to `X.mean(axis=0)`.

  **n_components_**
  : The estimated number of components. When n_components is set
    to ‘mle’ or a number between 0 and 1 (with svd_solver == ‘full’) this
    number is estimated from input data. Otherwise it equals the parameter
    n_components, or the lesser value of n_features and n_samples
    if n_components is None.

  **n_samples_**
  : Number of samples in the training data.

  **noise_variance_**
  : The estimated noise covariance following the Probabilistic PCA model
    from Tipping and Bishop 1999. See “Pattern Recognition and
    Machine Learning” by C. Bishop, 12.2.1 p. 574 or
    [http://www.miketipping.com/papers/met-mppca.pdf](http://www.miketipping.com/papers/met-mppca.pdf). It is required to
    compute the estimated data covariance and score samples.
    <br/>
    Equal to the average of (min(n_features, n_samples) - n_components)
    smallest eigenvalues of the covariance matrix of X.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`KernelPCA`](sklearn.decomposition.KernelPCA.md#sklearn.decomposition.KernelPCA)
: Kernel Principal Component Analysis.

[`SparsePCA`](sklearn.decomposition.SparsePCA.md#sklearn.decomposition.SparsePCA)
: Sparse Principal Component Analysis.

[`TruncatedSVD`](sklearn.decomposition.TruncatedSVD.md#sklearn.decomposition.TruncatedSVD)
: Dimensionality reduction using truncated SVD.

[`IncrementalPCA`](sklearn.decomposition.IncrementalPCA.md#sklearn.decomposition.IncrementalPCA)
: Incremental Principal Component Analysis.

### References

For n_components == ‘mle’, this class uses the method from:
[Minka, T. P.. “Automatic choice of dimensionality for PCA”.
In NIPS, pp. 598-604](https://tminka.github.io/papers/pca/minka-pca.pdf)

Implements the probabilistic PCA model from:
[Tipping, M. E., and Bishop, C. M. (1999). “Probabilistic principal
component analysis”. Journal of the Royal Statistical Society:
Series B (Statistical Methodology), 61(3), 611-622.](http://www.miketipping.com/papers/met-mppca.pdf)
via the score and score_samples methods.

For svd_solver == ‘arpack’, refer to `scipy.sparse.linalg.svds`.

For svd_solver == ‘randomized’, see:
[Halko, N., Martinsson, P. G., and Tropp, J. A. (2011).
“Finding structure with randomness: Probabilistic algorithms for
constructing approximate matrix decompositions”.
SIAM review, 53(2), 217-288.](https://doi.org/10.1137/090771806)
and also
[Martinsson, P. G., Rokhlin, V., and Tygert, M. (2011).
“A randomized algorithm for the decomposition of matrices”.
Applied and Computational Harmonic Analysis, 30(1), 47-68.](https://doi.org/10.1016/j.acha.2010.02.003)

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.decomposition import PCA
>>> X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
>>> pca = PCA(n_components=2)
>>> pca.fit(X)
PCA(n_components=2)
>>> print(pca.explained_variance_ratio_)
[0.9924... 0.0075...]
>>> print(pca.singular_values_)
[6.30061... 0.54980...]
```

```pycon
>>> pca = PCA(n_components=2, svd_solver='full')
>>> pca.fit(X)
PCA(n_components=2, svd_solver='full')
>>> print(pca.explained_variance_ratio_)
[0.9924... 0.00755...]
>>> print(pca.singular_values_)
[6.30061... 0.54980...]
```

```pycon
>>> pca = PCA(n_components=1, svd_solver='arpack')
>>> pca.fit(X)
PCA(n_components=1, svd_solver='arpack')
>>> print(pca.explained_variance_ratio_)
[0.99244...]
>>> print(pca.singular_values_)
[6.30061...]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the model with X.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Ignored.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Fit the model with X and apply the dimensionality reduction on X.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Ignored.
* **Returns:**
  **X_new**
  : Transformed values.

### Notes

This method returns a Fortran-ordered array. To convert it to a
C-ordered array, use ‘np.ascontiguousarray’.

<!-- !! processed by numpydoc !! -->

#### get_covariance()

Compute data covariance with the generative model.

`cov = components_.T * S**2 * components_ + sigma2 * eye(n_features)`
where S\*\*2 contains the explained variances, and sigma2 contains the
noise variances.

* **Returns:**
  **cov**
  : Estimated covariance of data.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_precision()

Compute data precision matrix with the generative model.

Equals the inverse of the covariance but computed with
the matrix inversion lemma for efficiency.

* **Returns:**
  **precision**
  : Estimated precision of data.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Transform data back to its original space.

In other words, return an input `X_original` whose transform would be X.

* **Parameters:**
  **X**
  : New data, where `n_samples` is the number of samples
    and `n_components` is the number of components.
* **Returns:**
  X_original array-like of shape (n_samples, n_features)
  : Original data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

### Notes

If whitening is enabled, inverse_transform will compute the
exact inverse operation, which includes reversing whitening.

<!-- !! processed by numpydoc !! -->

#### score(X, y=None)

Return the average log-likelihood of all samples.

See. “Pattern Recognition and Machine Learning”
by C. Bishop, 12.2.1 p. 574
or [http://www.miketipping.com/papers/met-mppca.pdf](http://www.miketipping.com/papers/met-mppca.pdf)

* **Parameters:**
  **X**
  : The data.

  **y**
  : Ignored.
* **Returns:**
  **ll**
  : Average log-likelihood of the samples under the current model.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Return the log-likelihood of each sample.

See. “Pattern Recognition and Machine Learning”
by C. Bishop, 12.2.1 p. 574
or [http://www.miketipping.com/papers/met-mppca.pdf](http://www.miketipping.com/papers/met-mppca.pdf)

* **Parameters:**
  **X**
  : The data.
* **Returns:**
  **ll**
  : Log-likelihood of each sample under the current model.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Apply dimensionality reduction to X.

X is projected on the first principal components previously extracted
from a training set.

* **Parameters:**
  **X**
  : New data, where `n_samples` is the number of samples
    and `n_features` is the number of features.
* **Returns:**
  **X_new**
  : Projection of X in the first principal components, where `n_samples`
    is the number of samples and `n_components` is the number of the components.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is a preprocessed excerpt of the &quot;Labeled Faces in the Wild&quot;, aka LFW_: http://vis-www.cs.umass.edu/lfw/lfw-funneled.tgz (233MB)">  <div class="sphx-glr-thumbnail-title">Faces recognition example using eigenfaces and SVMs</div>
</div>
* [Faces recognition example using eigenfaces and SVMs](../../auto_examples/applications/plot_face_recognition.md#sphx-glr-auto-examples-applications-plot-face-recognition-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use KernelPCA to denoise images. In short, we take advantage of the approximation function learned during fit to reconstruct the original image.">  <div class="sphx-glr-thumbnail-title">Image denoising using kernel PCA</div>
</div>
* [Image denoising using kernel PCA](../../auto_examples/applications/plot_digits_denoising.md#sphx-glr-auto-examples-applications-plot-digits-denoising-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the various initialization strategies for K-means in terms of runtime and quality of the results.">  <div class="sphx-glr-thumbnail-title">A demo of K-Means clustering on the handwritten digits data</div>
</div>
* [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="Datasets can often contain components that require different feature extraction and processing pipelines. This scenario might occur when:">  <div class="sphx-glr-thumbnail-title">Column Transformer with Heterogeneous Data Sources</div>
</div>
* [Column Transformer with Heterogeneous Data Sources](../../auto_examples/compose/plot_column_transformer.md#sphx-glr-auto-examples-compose-plot-column-transformer-py)

<div class="sphx-glr-thumbcontainer" tooltip="In many real-world examples, there are many ways to extract features from a dataset. Often it is beneficial to combine several methods to obtain good performance. This example shows how to use FeatureUnion to combine features obtained by PCA and univariate selection.">  <div class="sphx-glr-thumbnail-title">Concatenating multiple feature extraction methods</div>
</div>
* [Concatenating multiple feature extraction methods](../../auto_examples/compose/plot_feature_union.md#sphx-glr-auto-examples-compose-plot-feature-union-py)

<div class="sphx-glr-thumbcontainer" tooltip="The PCA does an unsupervised dimensionality reduction, while the logistic regression does the prediction.">  <div class="sphx-glr-thumbnail-title">Pipelining: chaining a PCA and a logistic regression</div>
</div>
* [Pipelining: chaining a PCA and a logistic regression](../../auto_examples/compose/plot_digits_pipe.md#sphx-glr-auto-examples-compose-plot-digits-pipe-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example constructs a pipeline that does dimensionality reduction followed by prediction with a support vector classifier. It demonstrates the use of GridSearchCV and Pipeline to optimize over different classes of estimators in a single CV run -- unsupervised PCA and NMF dimensionality reductions are compared to univariate feature selection during the grid search.">  <div class="sphx-glr-thumbnail-title">Selecting dimensionality reduction with Pipeline and GridSearchCV</div>
</div>
* [Selecting dimensionality reduction with Pipeline and GridSearchCV](../../auto_examples/compose/plot_compare_reduction.md#sphx-glr-auto-examples-compose-plot-compare-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares Principal Component Regression (PCR) and Partial Least Squares Regression (PLS) on a toy dataset. Our goal is to illustrate how PLS can outperform PCR when the target is strongly correlated with some directions in the data that have a low variance.">  <div class="sphx-glr-thumbnail-title">Principal Component Regression vs Partial Least Squares Regression</div>
</div>
* [Principal Component Regression vs Partial Least Squares Regression](../../auto_examples/cross_decomposition/plot_pcr_vs_pls.md#sphx-glr-auto-examples-cross-decomposition-plot-pcr-vs-pls-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example of estimating sources from noisy data.">  <div class="sphx-glr-thumbnail-title">Blind source separation using FastICA</div>
</div>
* [Blind source separation using FastICA](../../auto_examples/decomposition/plot_ica_blind_source_separation.md#sphx-glr-auto-examples-decomposition-plot-ica-blind-source-separation-py)

<div class="sphx-glr-thumbcontainer" tooltip="The Iris dataset represents 3 kind of Iris flowers (Setosa, Versicolour and Virginica) with 4 attributes: sepal length, sepal width, petal length and petal width.">  <div class="sphx-glr-thumbnail-title">Comparison of LDA and PCA 2D projection of Iris dataset</div>
</div>
* [Comparison of LDA and PCA 2D projection of Iris dataset](../../auto_examples/decomposition/plot_pca_vs_lda.md#sphx-glr-auto-examples-decomposition-plot-pca-vs-lda-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example applies to olivetti_faces_dataset different unsupervised matrix decomposition (dimension reduction) methods from the module sklearn.decomposition (see the documentation chapter decompositions).">  <div class="sphx-glr-thumbnail-title">Faces dataset decompositions</div>
</div>
* [Faces dataset decompositions](../../auto_examples/decomposition/plot_faces_decomposition.md#sphx-glr-auto-examples-decomposition-plot-faces-decomposition-py)

<div class="sphx-glr-thumbcontainer" tooltip="Investigating the Iris dataset, we see that sepal length, petal length and petal width are highly correlated. Sepal width is less redundant. Matrix decomposition techniques can uncover these latent patterns. Applying rotations to the resulting components does not inherently improve the predictive value of the derived latent space, but can help visualise their structure; here, for example, the varimax rotation, which is found by maximizing the squared variances of the weights, finds a structure where the second component only loads positively on sepal width.">  <div class="sphx-glr-thumbnail-title">Factor Analysis (with rotation) to visualize patterns</div>
</div>
* [Factor Analysis (with rotation) to visualize patterns](../../auto_examples/decomposition/plot_varimax_fa.md#sphx-glr-auto-examples-decomposition-plot-varimax-fa-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates visually in the feature space a comparison by results using two different component analysis techniques.">  <div class="sphx-glr-thumbnail-title">FastICA on 2D point clouds</div>
</div>
* [FastICA on 2D point clouds](../../auto_examples/decomposition/plot_ica_vs_pca.md#sphx-glr-auto-examples-decomposition-plot-ica-vs-pca-py)

<div class="sphx-glr-thumbcontainer" tooltip="Incremental principal component analysis (IPCA) is typically used as a replacement for principal component analysis (PCA) when the dataset to be decomposed is too large to fit in memory. IPCA builds a low-rank approximation for the input data using an amount of memory which is independent of the number of input data samples. It is still dependent on the input data features, but changing the batch size allows for control of memory usage.">  <div class="sphx-glr-thumbnail-title">Incremental PCA</div>
</div>
* [Incremental PCA](../../auto_examples/decomposition/plot_incremental_pca.md#sphx-glr-auto-examples-decomposition-plot-incremental-pca-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows the difference between the Principal Components Analysis (~sklearn.decomposition.PCA) and its kernelized version (~sklearn.decomposition.KernelPCA).">  <div class="sphx-glr-thumbnail-title">Kernel PCA</div>
</div>
* [Kernel PCA](../../auto_examples/decomposition/plot_kernel_pca.md#sphx-glr-auto-examples-decomposition-plot-kernel-pca-py)

<div class="sphx-glr-thumbcontainer" tooltip="Probabilistic PCA and Factor Analysis are probabilistic models. The consequence is that the likelihood of new data can be used for model selection and covariance estimation. Here we compare PCA and FA with cross-validation on low rank data corrupted with homoscedastic noise (noise variance is the same for each feature) or heteroscedastic noise (noise variance is the different for each feature). In a second step we compare the model likelihood to the likelihoods obtained from shrinkage covariance estimators.">  <div class="sphx-glr-thumbnail-title">Model selection with Probabilistic PCA and Factor Analysis (FA)</div>
</div>
* [Model selection with Probabilistic PCA and Factor Analysis (FA)](../../auto_examples/decomposition/plot_pca_vs_fa_model_selection.md#sphx-glr-auto-examples-decomposition-plot-pca-vs-fa-model-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows a well known decomposition technique known as Principal Component Analysis (PCA) on the Iris dataset.">  <div class="sphx-glr-thumbnail-title">Principal Component Analysis (PCA) on Iris Dataset</div>
</div>
* [Principal Component Analysis (PCA) on Iris Dataset](../../auto_examples/decomposition/plot_pca_iris.md#sphx-glr-auto-examples-decomposition-plot-pca-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of the metric and non-metric MDS on generated noisy data.">  <div class="sphx-glr-thumbnail-title">Multi-dimensional scaling</div>
</div>
* [Multi-dimensional scaling](../../auto_examples/manifold/plot_mds.md#sphx-glr-auto-examples-manifold-plot-mds-py)

<div class="sphx-glr-thumbcontainer" tooltip="The default configuration for displaying a pipeline in a Jupyter Notebook is &#x27;diagram&#x27; where set_config(display=&#x27;diagram&#x27;). To deactivate HTML representation, use set_config(display=&#x27;text&#x27;).">  <div class="sphx-glr-thumbnail-title">Displaying Pipelines</div>
</div>
* [Displaying Pipelines](../../auto_examples/miscellaneous/plot_pipeline_display.md#sphx-glr-auto-examples-miscellaneous-plot-pipeline-display-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example illustrating the approximation of the feature map of an RBF kernel.">  <div class="sphx-glr-thumbnail-title">Explicit feature map approximation for RBF kernels</div>
</div>
* [Explicit feature map approximation for RBF kernels](../../auto_examples/miscellaneous/plot_kernel_approximation.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-approximation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example simulates a multi-label document classification problem. The dataset is generated randomly based on the following process:">  <div class="sphx-glr-thumbnail-title">Multilabel classification</div>
</div>
* [Multilabel classification](../../auto_examples/miscellaneous/plot_multilabel.md#sphx-glr-auto-examples-miscellaneous-plot-multilabel-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example balances model complexity and cross-validated score by finding a decent accuracy within 1 standard deviation of the best accuracy score while minimising the number of PCA components [1].">  <div class="sphx-glr-thumbnail-title">Balance model complexity and cross-validated score</div>
</div>
* [Balance model complexity and cross-validated score](../../auto_examples/model_selection/plot_grid_search_refit_callable.md#sphx-glr-auto-examples-model-selection-plot-grid-search-refit-callable-py)

<div class="sphx-glr-thumbcontainer" tooltip="Sample usage of Neighborhood Components Analysis for dimensionality reduction.">  <div class="sphx-glr-thumbnail-title">Dimensionality Reduction with Neighborhood Components Analysis</div>
</div>
* [Dimensionality Reduction with Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_dim_reduction.md#sphx-glr-auto-examples-neighbors-plot-nca-dim-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how kernel density estimation (KDE), a powerful non-parametric density estimation technique, can be used to learn a generative model for a dataset.  With this generative model in place, new samples can be drawn.  These new samples reflect the underlying model of the data.">  <div class="sphx-glr-thumbnail-title">Kernel Density Estimation</div>
</div>
* [Kernel Density Estimation](../../auto_examples/neighbors/plot_digits_kde_sampling.md#sphx-glr-auto-examples-neighbors-plot-digits-kde-sampling-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature scaling through standardization, also called Z-score normalization, is an important preprocessing step for many machine learning algorithms. It involves rescaling each feature such that it has a standard deviation of 1 and a mean of 0.">  <div class="sphx-glr-thumbnail-title">Importance of Feature Scaling</div>
</div>
* [Importance of Feature Scaling](../../auto_examples/preprocessing/plot_scaling_importance.md#sphx-glr-auto-examples-preprocessing-plot-scaling-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<!-- thumbnail-parent-div-close --></div>
