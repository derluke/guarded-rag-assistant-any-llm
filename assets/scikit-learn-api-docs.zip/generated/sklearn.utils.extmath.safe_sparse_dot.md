# safe_sparse_dot

### sklearn.utils.extmath.safe_sparse_dot(a, b, \*, dense_output=False)

Dot product that handle the sparse matrix case correctly.

* **Parameters:**
  **a**

  **b**

  **dense_output**
  : When False, `a` and `b` both being sparse will yield sparse output.
    When True, output will always be a dense array.
* **Returns:**
  **dot_product**
  : Sparse if `a` and `b` are sparse and `dense_output=False`.

### Examples

```pycon
>>> from scipy.sparse import csr_matrix
>>> from sklearn.utils.extmath import safe_sparse_dot
>>> X = csr_matrix([[1, 2], [3, 4], [5, 6]])
>>> dot_product = safe_sparse_dot(X, X.T)
>>> dot_product.toarray()
array([[ 5, 11, 17],
       [11, 25, 39],
       [17, 39, 61]])
```

<!-- !! processed by numpydoc !! -->
