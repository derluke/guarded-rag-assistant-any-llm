# LabelEncoder

### *class* sklearn.preprocessing.LabelEncoder

Encode target labels with value between 0 and n_classes-1.

This transformer should be used to encode target values, *i.e.* `y`, and
not the input `X`.

Read more in the [User Guide](../preprocessing_targets.md#preprocessing-targets).

#### Versionadded
Added in version 0.12.

* **Attributes:**
  **classes_**
  : Holds the label for each class.

#### SEE ALSO
[`OrdinalEncoder`](sklearn.preprocessing.OrdinalEncoder.md#sklearn.preprocessing.OrdinalEncoder)
: Encode categorical features using an ordinal encoding scheme.

[`OneHotEncoder`](sklearn.preprocessing.OneHotEncoder.md#sklearn.preprocessing.OneHotEncoder)
: Encode categorical features as a one-hot numeric array.

### Examples

`LabelEncoder` can be used to normalize labels.

```pycon
>>> from sklearn.preprocessing import LabelEncoder
>>> le = LabelEncoder()
>>> le.fit([1, 2, 2, 6])
LabelEncoder()
>>> le.classes_
array([1, 2, 6])
>>> le.transform([1, 1, 2, 6])
array([0, 0, 1, 2]...)
>>> le.inverse_transform([0, 0, 1, 2])
array([1, 1, 2, 6])
```

It can also be used to transform non-numerical labels (as long as they are
hashable and comparable) to numerical labels.

```pycon
>>> le = LabelEncoder()
>>> le.fit(["paris", "paris", "tokyo", "amsterdam"])
LabelEncoder()
>>> list(le.classes_)
[np.str_('amsterdam'), np.str_('paris'), np.str_('tokyo')]
>>> le.transform(["tokyo", "tokyo", "paris"])
array([2, 2, 1]...)
>>> list(le.inverse_transform([2, 2, 1]))
[np.str_('tokyo'), np.str_('tokyo'), np.str_('paris')]
```

<!-- !! processed by numpydoc !! -->

#### fit(y)

Fit label encoder.

* **Parameters:**
  **y**
  : Target values.
* **Returns:**
  **self**
  : Fitted label encoder.

<!-- !! processed by numpydoc !! -->

#### fit_transform(y)

Fit label encoder and return encoded labels.

* **Parameters:**
  **y**
  : Target values.
* **Returns:**
  **y**
  : Encoded labels.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(y)

Transform labels back to original encoding.

* **Parameters:**
  **y**
  : Target values.
* **Returns:**
  **y**
  : Original encoding.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(y)

Transform labels to normalized encoding.

* **Parameters:**
  **y**
  : Target values.
* **Returns:**
  **y**
  : Labels as normalized encodings.

<!-- !! processed by numpydoc !! -->
