# make_biclusters

### sklearn.datasets.make_biclusters(shape, n_clusters, \*, noise=0.0, minval=10, maxval=100, shuffle=True, random_state=None)

Generate a constant block diagonal structure array for biclustering.

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **shape**
  : The shape of the result.

  **n_clusters**
  : The number of biclusters.

  **noise**
  : The standard deviation of the gaussian noise.

  **minval**
  : Minimum value of a bicluster.

  **maxval**
  : Maximum value of a bicluster.

  **shuffle**
  : Shuffle the samples.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : The generated array.

  **rows**
  : The indicators for cluster membership of each row.

  **cols**
  : The indicators for cluster membership of each column.

#### SEE ALSO
[`make_checkerboard`](sklearn.datasets.make_checkerboard.md#sklearn.datasets.make_checkerboard)
: Generate an array with block checkerboard structure for biclustering.

### References

### Examples

```pycon
>>> from sklearn.datasets import make_biclusters
>>> data, rows, cols = make_biclusters(
...     shape=(10, 20), n_clusters=2, random_state=42
... )
>>> data.shape
(10, 20)
>>> rows.shape
(2, 10)
>>> cols.shape
(2, 20)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to generate a dataset and bicluster it using the Spectral Co-Clustering algorithm.">  <div class="sphx-glr-thumbnail-title">A demo of the Spectral Co-Clustering algorithm</div>
</div>
* [A demo of the Spectral Co-Clustering algorithm](../../auto_examples/bicluster/plot_spectral_coclustering.md#sphx-glr-auto-examples-bicluster-plot-spectral-coclustering-py)

<!-- thumbnail-parent-div-close --></div>
