# load_digits

### sklearn.datasets.load_digits(\*, n_class=10, return_X_y=False, as_frame=False)

Load and return the digits dataset (classification).

Each datapoint is a 8x8 image of a digit.

| Classes           | 10            |
|-------------------|---------------|
| Samples per class | ~180          |
| Samples total     | 1797          |
| Dimensionality    | 64            |
| Features          | integers 0-16 |

This is a copy of the test set of the UCI ML hand-written digits datasets
[https://archive.ics.uci.edu/ml/datasets/Optical+Recognition+of+Handwritten+Digits](https://archive.ics.uci.edu/ml/datasets/Optical+Recognition+of+Handwritten+Digits)

Read more in the [User Guide](../../datasets/toy_dataset.md#digits-dataset).

* **Parameters:**
  **n_class**
  : The number of classes to return. Between 0 and 10.

  **return_X_y**
  : If True, returns `(data, target)` instead of a Bunch object.
    See below for more information about the `data` and `target` object.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **as_frame**
  : If True, the data is a pandas DataFrame including columns with
    appropriate dtypes (numeric). The target is
    a pandas DataFrame or Series depending on the number of target columns.
    If `return_X_y` is True, then (`data`, `target`) will be pandas
    DataFrames or Series as described below.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : The flattened data matrix. If `as_frame=True`, `data` will be
      a pandas DataFrame.
    <br/>
    target: {ndarray, Series} of shape (1797,)
    : The classification target. If `as_frame=True`, `target` will be
      a pandas Series.
    <br/>
    feature_names: list
    : The names of the dataset columns.
    <br/>
    target_names: list
    : The names of target classes.
      <br/>
      #### Versionadded
      Added in version 0.20.
    <br/>
    frame: DataFrame of shape (1797, 65)
    : Only present when `as_frame=True`. DataFrame with `data` and
      `target`.
      <br/>
      #### Versionadded
      Added in version 0.23.
    <br/>
    images: {ndarray} of shape (1797, 8, 8)
    : The raw image data.
    <br/>
    DESCR: str
    : The full description of the dataset.

  **(data, target)**
  : A tuple of two ndarrays by default. The first contains a 2D ndarray of
    shape (1797, 64) with each row representing one sample and each column
    representing the features. The second ndarray of shape (1797) contains
    the target samples.  If `as_frame=True`, both arrays are pandas objects,
    i.e. `X` a dataframe and `y` a series.
    <br/>
    #### Versionadded
    Added in version 0.18.

### Examples

To load the data and visualize the images:

```default
>>> from sklearn.datasets import load_digits
>>> digits = load_digits()
>>> print(digits.data.shape)
(1797, 64)
>>> import matplotlib.pyplot as plt
>>> plt.gray()
>>> plt.matshow(digits.images[0])
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-datasets-load_digits-1_00.*)![image](../md/plot_directive/modules/generated/sklearn-datasets-load_digits-1_01.*)
<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows how scikit-learn can be used to recognize images of hand-written digits, from 0-9.">  <div class="sphx-glr-thumbnail-title">Recognizing hand-written digits</div>
</div>
* [Recognizing hand-written digits](../../auto_examples/classification/plot_digits_classification.md#sphx-glr-auto-examples-classification-plot-digits-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the various initialization strategies for K-means in terms of runtime and quality of the results.">  <div class="sphx-glr-thumbnail-title">A demo of K-Means clustering on the handwritten digits data</div>
</div>
* [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="These images show how similar features are merged together using feature agglomeration.">  <div class="sphx-glr-thumbnail-title">Feature agglomeration</div>
</div>
* [Feature agglomeration](../../auto_examples/cluster/plot_digits_agglomeration.md#sphx-glr-auto-examples-cluster-plot-digits-agglomeration-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of various linkage option for agglomerative clustering on a 2D embedding of the digits dataset.">  <div class="sphx-glr-thumbnail-title">Various Agglomerative Clustering on a 2D embedding of digits</div>
</div>
* [Various Agglomerative Clustering on a 2D embedding of digits](../../auto_examples/cluster/plot_digits_linkage.md#sphx-glr-auto-examples-cluster-plot-digits-linkage-py)

<div class="sphx-glr-thumbcontainer" tooltip="The PCA does an unsupervised dimensionality reduction, while the logistic regression does the prediction.">  <div class="sphx-glr-thumbnail-title">Pipelining: chaining a PCA and a logistic regression</div>
</div>
* [Pipelining: chaining a PCA and a logistic regression](../../auto_examples/compose/plot_digits_pipe.md#sphx-glr-auto-examples-compose-plot-digits-pipe-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example constructs a pipeline that does dimensionality reduction followed by prediction with a support vector classifier. It demonstrates the use of GridSearchCV and Pipeline to optimize over different classes of estimators in a single CV run -- unsupervised PCA and NMF dimensionality reductions are compared to univariate feature selection during the grid search.">  <div class="sphx-glr-thumbnail-title">Selecting dimensionality reduction with Pipeline and GridSearchCV</div>
</div>
* [Selecting dimensionality reduction with Pipeline and GridSearchCV](../../auto_examples/compose/plot_compare_reduction.md#sphx-glr-auto-examples-compose-plot-compare-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Recursive Feature Elimination (~sklearn.feature_selection.RFE) can be used to determine the importance of individual pixels for classifying handwritten digits. RFE recursively removes the least significant features, assigning ranks based on their importance, where higher ranking_ values denote lower importance. The ranking is visualized using both shades of blue and pixel annotations for clarity. As expected, pixels positioned at the center of the image tend to be more predictive than those near the edges.">  <div class="sphx-glr-thumbnail-title">Recursive feature elimination</div>
</div>
* [Recursive feature elimination](../../auto_examples/feature_selection/plot_rfe_digits.md#sphx-glr-auto-examples-feature-selection-plot-rfe-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparing various online solvers">  <div class="sphx-glr-thumbnail-title">Comparing various online solvers</div>
</div>
* [Comparing various online solvers](../../auto_examples/linear_model/plot_sgd_comparison.md#sphx-glr-auto-examples-linear-model-plot-sgd-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparison of the sparsity (percentage of zero coefficients) of solutions when L1, L2 and Elastic-Net penalty are used for different values of C. We can see that large values of C give more freedom to the model.  Conversely, smaller values of C constrain the model more. In the L1 penalty case, this leads to sparser solutions. As expected, the Elastic-Net penalty sparsity is between that of L1 and L2.">  <div class="sphx-glr-thumbnail-title">L1 Penalty and Sparsity in Logistic Regression</div>
</div>
* [L1 Penalty and Sparsity in Logistic Regression](../../auto_examples/linear_model/plot_logistic_l1_l2_sparsity.md#sphx-glr-auto-examples-linear-model-plot-logistic-l1-l2-sparsity-py)

<div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example illustrating the approximation of the feature map of an RBF kernel.">  <div class="sphx-glr-thumbnail-title">Explicit feature map approximation for RBF kernels</div>
</div>
* [Explicit feature map approximation for RBF kernels](../../auto_examples/miscellaneous/plot_kernel_approximation.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-approximation-py)

<div class="sphx-glr-thumbcontainer" tooltip=" The \`Johnson-Lindenstrauss lemma\`_ states that any high dimensional dataset can be randomly projected into a lower dimensional Euclidean space while controlling the distortion in the pairwise distances.">  <div class="sphx-glr-thumbnail-title">The Johnson-Lindenstrauss bound for embedding with random projections</div>
</div>
* [The Johnson-Lindenstrauss bound for embedding with random projections](../../auto_examples/miscellaneous/plot_johnson_lindenstrauss_bound.md#sphx-glr-auto-examples-miscellaneous-plot-johnson-lindenstrauss-bound-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example balances model complexity and cross-validated score by finding a decent accuracy within 1 standard deviation of the best accuracy score while minimising the number of PCA components [1].">  <div class="sphx-glr-thumbnail-title">Balance model complexity and cross-validated score</div>
</div>
* [Balance model complexity and cross-validated score](../../auto_examples/model_selection/plot_grid_search_refit_callable.md#sphx-glr-auto-examples-model-selection-plot-grid-search-refit-callable-py)

<div class="sphx-glr-thumbcontainer" tooltip="Compare randomized search and grid search for optimizing hyperparameters of a linear SVM with SGD training. All parameters that influence the learning are searched simultaneously (except for the number of estimators, which poses a time / quality tradeoff).">  <div class="sphx-glr-thumbnail-title">Comparing randomized search and grid search for hyperparameter estimation</div>
</div>
* [Comparing randomized search and grid search for hyperparameter estimation](../../auto_examples/model_selection/plot_randomized_search.md#sphx-glr-auto-examples-model-selection-plot-randomized-search-py)

<div class="sphx-glr-thumbcontainer" tooltip="This examples shows how a classifier is optimized by cross-validation, which is done using the GridSearchCV object on a development set that comprises only half of the available labeled data.">  <div class="sphx-glr-thumbnail-title">Custom refit strategy of a grid search with cross-validation</div>
</div>
* [Custom refit strategy of a grid search with cross-validation](../../auto_examples/model_selection/plot_grid_search_digits.md#sphx-glr-auto-examples-model-selection-plot-grid-search-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we show how to use the class LearningCurveDisplay to easily plot learning curves. In addition, we give an interpretation to the learning curves obtained for a naive Bayes and SVM classifiers.">  <div class="sphx-glr-thumbnail-title">Plotting Learning Curves and Checking Models' Scalability</div>
</div>
* [Plotting Learning Curves and Checking Models’ Scalability](../../auto_examples/model_selection/plot_learning_curve.md#sphx-glr-auto-examples-model-selection-plot-learning-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to precompute the k nearest neighbors before using them in KNeighborsClassifier. KNeighborsClassifier can compute the nearest neighbors internally, but precomputing them can have several benefits, such as finer parameter control, caching for multiple use, or custom implementations.">  <div class="sphx-glr-thumbnail-title">Caching nearest neighbors</div>
</div>
* [Caching nearest neighbors](../../auto_examples/neighbors/plot_caching_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-plot-caching-nearest-neighbors-py)

<div class="sphx-glr-thumbcontainer" tooltip="Sample usage of Neighborhood Components Analysis for dimensionality reduction.">  <div class="sphx-glr-thumbnail-title">Dimensionality Reduction with Neighborhood Components Analysis</div>
</div>
* [Dimensionality Reduction with Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_dim_reduction.md#sphx-glr-auto-examples-neighbors-plot-nca-dim-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how kernel density estimation (KDE), a powerful non-parametric density estimation technique, can be used to learn a generative model for a dataset.  With this generative model in place, new samples can be drawn.  These new samples reflect the underlying model of the data.">  <div class="sphx-glr-thumbnail-title">Kernel Density Estimation</div>
</div>
* [Kernel Density Estimation](../../auto_examples/neighbors/plot_digits_kde_sampling.md#sphx-glr-auto-examples-neighbors-plot-digits-kde-sampling-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example visualizes some training loss curves for different stochastic learning strategies, including SGD and Adam. Because of time-constraints, we use several small datasets, for which L-BFGS might be more suitable. The general trend shown in these examples seems to carry over to larger datasets, however.">  <div class="sphx-glr-thumbnail-title">Compare Stochastic learning strategies for MLPClassifier</div>
</div>
* [Compare Stochastic learning strategies for MLPClassifier](../../auto_examples/neural_networks/plot_mlp_training_curves.md#sphx-glr-auto-examples-neural-networks-plot-mlp-training-curves-py)

<div class="sphx-glr-thumbcontainer" tooltip="For greyscale image data where pixel values can be interpreted as degrees of blackness on a white background, like handwritten digit recognition, the Bernoulli Restricted Boltzmann machine model (BernoulliRBM) can perform effective non-linear feature extraction.">  <div class="sphx-glr-thumbnail-title">Restricted Boltzmann Machine features for digit classification</div>
</div>
* [Restricted Boltzmann Machine features for digit classification](../../auto_examples/neural_networks/plot_rbm_logistic_classification.md#sphx-glr-auto-examples-neural-networks-plot-rbm-logistic-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Demonstrates an active learning technique to learn handwritten digits using label propagation.">  <div class="sphx-glr-thumbnail-title">Label Propagation digits active learning</div>
</div>
* [Label Propagation digits active learning](../../auto_examples/semi_supervised/plot_label_propagation_digits_active_learning.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-digits-active-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the power of semisupervised learning by training a Label Spreading model to classify handwritten digits with sets of very few labels.">  <div class="sphx-glr-thumbnail-title">Label Propagation digits: Demonstrating performance</div>
</div>
* [Label Propagation digits: Demonstrating performance](../../auto_examples/semi_supervised/plot_label_propagation_digits.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.3! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_3&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.3</div>
</div>
* [Release Highlights for scikit-learn 1.3](../../auto_examples/release_highlights/plot_release_highlights_1_3_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-3-0-py)

<!-- thumbnail-parent-div-close --></div>
