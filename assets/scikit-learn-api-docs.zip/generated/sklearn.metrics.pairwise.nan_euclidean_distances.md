# nan_euclidean_distances

### sklearn.metrics.pairwise.nan_euclidean_distances(X, Y=None, \*, squared=False, missing_values=nan, copy=True)

Calculate the euclidean distances in the presence of missing values.

Compute the euclidean distance between each pair of samples in X and Y,
where Y=X is assumed if Y=None. When calculating the distance between a
pair of samples, this formulation ignores feature coordinates with a
missing value in either sample and scales up the weight of the remaining
coordinates:

```text
dist(x,y) = sqrt(weight * sq. distance from present coordinates)
```

where:

```text
weight = Total # of coordinates / # of present coordinates
```

For example, the distance between `[3, na, na, 6]` and `[1, na, 4, 5]` is:

$$
\sqrt{\frac{4}{2}((3-1)^2 + (6-5)^2)}

$$

If all the coordinates are missing or if there are no common present
coordinates then NaN is returned for that pair.

Read more in the [User Guide](../metrics.md#metrics).

#### Versionadded
Added in version 0.22.

* **Parameters:**
  **X**
  : An array where each row is a sample and each column is a feature.

  **Y**
  : An array where each row is a sample and each column is a feature.
    If `None`, method uses `Y=X`.

  **squared**
  : Return squared Euclidean distances.

  **missing_values**
  : Representation of missing value.

  **copy**
  : Make and use a deep copy of X and Y (if Y exists).
* **Returns:**
  **distances**
  : Returns the distances between the row vectors of `X`
    and the row vectors of `Y`.

#### SEE ALSO
[`paired_distances`](sklearn.metrics.pairwise.paired_distances.md#sklearn.metrics.pairwise.paired_distances)
: Distances between pairs of elements of X and Y.

### References

* John K. Dixon, “Pattern Recognition with Partly Missing Data”,
  IEEE Transactions on Systems, Man, and Cybernetics, Volume: 9, Issue:
  10, pp. 617 - 621, Oct. 1979.
  [http://ieeexplore.ieee.org/abstract/document/4310090/](http://ieeexplore.ieee.org/abstract/document/4310090/)

### Examples

```pycon
>>> from sklearn.metrics.pairwise import nan_euclidean_distances
>>> nan = float("NaN")
>>> X = [[0, 1], [1, nan]]
>>> nan_euclidean_distances(X, X) # distance between rows of X
array([[0.        , 1.41421356],
       [1.41421356, 0.        ]])
```

```pycon
>>> # get distance to origin
>>> nan_euclidean_distances(X, [[0, 0]])
array([[1.        ],
       [1.41421356]])
```

<!-- !! processed by numpydoc !! -->
