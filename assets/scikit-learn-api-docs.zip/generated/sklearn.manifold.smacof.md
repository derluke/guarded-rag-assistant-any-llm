# smacof

### sklearn.manifold.smacof(dissimilarities, \*, metric=True, n_components=2, init=None, n_init=8, n_jobs=None, max_iter=300, verbose=0, eps=0.001, random_state=None, return_n_iter=False, normalized_stress='auto')

Compute multidimensional scaling using the SMACOF algorithm.

The SMACOF (Scaling by MAjorizing a COmplicated Function) algorithm is a
multidimensional scaling algorithm which minimizes an objective function
(the *stress*) using a majorization technique. Stress majorization, also
known as the Guttman Transform, guarantees a monotone convergence of
stress, and is more powerful than traditional techniques such as gradient
descent.

The SMACOF algorithm for metric MDS can be summarized by the following
steps:

1. Set an initial start configuration, randomly or not.
2. Compute the stress
3. Compute the Guttman Transform
4. Iterate 2 and 3 until convergence.

The nonmetric algorithm adds a monotonic regression step before computing
the stress.

* **Parameters:**
  **dissimilarities**
  : Pairwise dissimilarities between the points. Must be symmetric.

  **metric**
  : Compute metric or nonmetric SMACOF algorithm.
    When `False` (i.e. non-metric MDS), dissimilarities with 0 are considered as
    missing values.

  **n_components**
  : Number of dimensions in which to immerse the dissimilarities. If an
    `init` array is provided, this option is overridden and the shape of
    `init` is used to determine the dimensionality of the embedding
    space.

  **init**
  : Starting configuration of the embedding to initialize the algorithm. By
    default, the algorithm is initialized with a randomly chosen array.

  **n_init**
  : Number of times the SMACOF algorithm will be run with different
    initializations. The final results will be the best output of the runs,
    determined by the run with the smallest final stress. If `init` is
    provided, this option is overridden and a single run is performed.

  **n_jobs**
  : The number of jobs to use for the computation. If multiple
    initializations are used (`n_init`), each run of the algorithm is
    computed in parallel.
    <br/>
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **max_iter**
  : Maximum number of iterations of the SMACOF algorithm for a single run.

  **verbose**
  : Level of verbosity.

  **eps**
  : Relative tolerance with respect to stress at which to declare
    convergence. The value of `eps` should be tuned separately depending
    on whether or not `normalized_stress` is being used.

  **random_state**
  : Determines the random number generator used to initialize the centers.
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **return_n_iter**
  : Whether or not to return the number of iterations.

  **normalized_stress**
  : Whether use and return normed stress value (Stress-1) instead of raw
    stress calculated by default. Only supported in non-metric MDS.
    <br/>
    #### Versionadded
    Added in version 1.2.
    <br/>
    #### Versionchanged
    Changed in version 1.4: The default value changed from `False` to `"auto"` in version 1.4.
* **Returns:**
  **X**
  : Coordinates of the points in a `n_components`-space.

  **stress**
  : The final value of the stress (sum of squared distance of the
    disparities and the distances for all constrained points).
    If `normalized_stress=True`, and `metric=False` returns Stress-1.
    A value of 0 indicates “perfect” fit, 0.025 excellent, 0.05 good,
    0.1 fair, and 0.2 poor [[1]](#r8e3dcaa71efe-1).

  **n_iter**
  : The number of iterations corresponding to the best stress. Returned
    only if `return_n_iter` is set to `True`.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.manifold import smacof
>>> from sklearn.metrics import euclidean_distances
>>> X = np.array([[0, 1, 2], [1, 0, 3],[2, 3, 0]])
>>> dissimilarities = euclidean_distances(X)
>>> mds_result, stress = smacof(dissimilarities, n_components=2, random_state=42)
>>> mds_result
array([[ 0.05... -1.07... ],
       [ 1.74..., -0.75...],
       [-1.79...,  1.83...]])
>>> stress
np.float64(0.0012...)
```

<!-- !! processed by numpydoc !! -->
