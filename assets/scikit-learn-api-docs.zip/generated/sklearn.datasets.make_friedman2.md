# make_friedman2

### sklearn.datasets.make_friedman2(n_samples=100, \*, noise=0.0, random_state=None)

Generate the “Friedman #2” regression problem.

This dataset is described in Friedman [1] and Breiman [2].

Inputs `X` are 4 independent features uniformly distributed on the
intervals:

```default
0 <= X[:, 0] <= 100,
40 * pi <= X[:, 1] <= 560 * pi,
0 <= X[:, 2] <= 1,
1 <= X[:, 3] <= 11.
```

The output `y` is created according to the formula:

```default
y(X) = (X[:, 0] ** 2 + (X[:, 1] * X[:, 2]  - 1 / (X[:, 1] * X[:, 3])) ** 2) ** 0.5 + noise * N(0, 1).
```

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **n_samples**
  : The number of samples.

  **noise**
  : The standard deviation of the gaussian noise applied to the output.

  **random_state**
  : Determines random number generation for dataset noise. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : The input samples.

  **y**
  : The output values.

### References

### Examples

```pycon
>>> from sklearn.datasets import make_friedman2
>>> X, y = make_friedman2(random_state=42)
>>> X.shape
(100, 4)
>>> y.shape
(100,)
>>> list(y[:3])
[np.float64(1229.4...), np.float64(27.0...), np.float64(65.6...)]
```

<!-- !! processed by numpydoc !! -->
