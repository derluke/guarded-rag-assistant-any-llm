# cross_val_predict

### sklearn.model_selection.cross_val_predict(estimator, X, y=None, \*, groups=None, cv=None, n_jobs=None, verbose=0, params=None, pre_dispatch='2\*n_jobs', method='predict')

Generate cross-validated estimates for each input data point.

The data is split according to the cv parameter. Each sample belongs
to exactly one test set, and its prediction is computed with an
estimator fitted on the corresponding training set.

Passing these predictions into an evaluation metric may not be a valid
way to measure generalization performance. Results can differ from
[`cross_validate`](sklearn.model_selection.cross_validate.md#sklearn.model_selection.cross_validate) and [`cross_val_score`](sklearn.model_selection.cross_val_score.md#sklearn.model_selection.cross_val_score) unless all tests sets
have equal size and the metric decomposes over samples.

Read more in the [User Guide](../cross_validation.md#cross-validation).

* **Parameters:**
  **estimator**
  : The estimator instance to use to fit the data. It must implement a `fit`
    method and the method given by the `method` parameter.

  **X**
  : The data to fit. Can be, for example a list, or an array at least 2d.

  **y**
  : The target variable to try to predict in the case of
    supervised learning.

  **groups**
  : Group labels for the samples used while splitting the dataset into
    train/test set. Only used in conjunction with a “Group” [cv](../../glossary.md#term-cv)
    instance (e.g., [`GroupKFold`](sklearn.model_selection.GroupKFold.md#sklearn.model_selection.GroupKFold)).
    <br/>
    #### Versionchanged
    Changed in version 1.4: `groups` can only be passed if metadata routing is not enabled
    via `sklearn.set_config(enable_metadata_routing=True)`. When routing
    is enabled, pass `groups` alongside other metadata via the `params`
    argument instead. E.g.:
    `cross_val_predict(..., params={'groups': groups})`.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross validation,
    - int, to specify the number of folds in a `(Stratified)KFold`,
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable that generates (train, test) splits as arrays of indices.
    <br/>
    For int/None inputs, if the estimator is a classifier and `y` is
    either binary or multiclass, [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. In all
    other cases, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used. These splitters are instantiated
    with `shuffle=False` so the splits will be the same across calls.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value if None changed from 3-fold to 5-fold.

  **n_jobs**
  : Number of jobs to run in parallel. Training the estimator and
    predicting are parallelized over the cross-validation splits.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **verbose**
  : The verbosity level.

  **params**
  : Parameters to pass to the underlying estimator’s `fit` and the CV
    splitter.
    <br/>
    #### Versionadded
    Added in version 1.4.

  **pre_dispatch**
  : Controls the number of jobs that get dispatched during parallel
    execution. Reducing this number can be useful to avoid an
    explosion of memory consumption when more jobs get dispatched
    than CPUs can process. This parameter can be:
    - None, in which case all the jobs are immediately created and spawned. Use
      this for lightweight and fast-running jobs, to avoid delays due to on-demand
      spawning of the jobs
    - An int, giving the exact number of total jobs that are spawned
    - A str, giving an expression as a function of n_jobs, as in ‘2\*n_jobs’

  **method**
  : The method to be invoked by `estimator`.
* **Returns:**
  **predictions**
  : This is the result of calling `method`. Shape:
    - When `method` is ‘predict’ and in special case where `method` is
      ‘decision_function’ and the target is binary: (n_samples,)
    - When `method` is one of {‘predict_proba’, ‘predict_log_proba’,
      ‘decision_function’} (unless special case above):
      (n_samples, n_classes)
    - If `estimator` is [multioutput](../../glossary.md#term-multioutput), an extra dimension
      ‘n_outputs’ is added to the end of each shape above.

#### SEE ALSO
[`cross_val_score`](sklearn.model_selection.cross_val_score.md#sklearn.model_selection.cross_val_score)
: Calculate score for each CV split.

[`cross_validate`](sklearn.model_selection.cross_validate.md#sklearn.model_selection.cross_validate)
: Calculate one or more scores and timings for each CV split.

### Notes

In the case that one or more classes are absent in a training portion, a
default score needs to be assigned to all instances for that class if
`method` produces columns per class, as in {‘decision_function’,
‘predict_proba’, ‘predict_log_proba’}.  For `predict_proba` this value is
0.  In order to ensure finite output, we approximate negative infinity by
the minimum finite float value for the dtype in other cases.

### Examples

```pycon
>>> from sklearn import datasets, linear_model
>>> from sklearn.model_selection import cross_val_predict
>>> diabetes = datasets.load_diabetes()
>>> X = diabetes.data[:150]
>>> y = diabetes.target[:150]
>>> lasso = linear_model.Lasso()
>>> y_pred = cross_val_predict(lasso, X, y, cv=3)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use cross_val_predict together with PredictionErrorDisplay to visualize prediction errors.">  <div class="sphx-glr-thumbnail-title">Plotting Cross-Validated Predictions</div>
</div>
* [Plotting Cross-Validated Predictions](../../auto_examples/model_selection/plot_cv_predict.md#sphx-glr-auto-examples-model-selection-plot-cv-predict-py)

<!-- thumbnail-parent-div-close --></div>
