# johnson_lindenstrauss_min_dim

### sklearn.random_projection.johnson_lindenstrauss_min_dim(n_samples, \*, eps=0.1)

Find a ‘safe’ number of components to randomly project to.

The distortion introduced by a random projection `p` only changes the
distance between two points by a factor (1 +- eps) in a euclidean space
with good probability. The projection `p` is an eps-embedding as defined
by:

```text
(1 - eps) ||u - v||^2 < ||p(u) - p(v)||^2 < (1 + eps) ||u - v||^2
```

Where u and v are any rows taken from a dataset of shape (n_samples,
n_features), eps is in ]0, 1[ and p is a projection by a random Gaussian
N(0, 1) matrix of shape (n_components, n_features) (or a sparse
Achlioptas matrix).

The minimum number of components to guarantee the eps-embedding is
given by:

```text
n_components >= 4 log(n_samples) / (eps^2 / 2 - eps^3 / 3)
```

Note that the number of dimensions is independent of the original
number of features but instead depends on the size of the dataset:
the larger the dataset, the higher is the minimal dimensionality of
an eps-embedding.

Read more in the [User Guide](../random_projection.md#johnson-lindenstrauss).

* **Parameters:**
  **n_samples**
  : Number of samples that should be an integer greater than 0. If an array
    is given, it will compute a safe number of components array-wise.

  **eps**
  : Maximum distortion rate in the range (0, 1) as defined by the
    Johnson-Lindenstrauss lemma. If an array is given, it will compute a
    safe number of components array-wise.
* **Returns:**
  **n_components**
  : The minimal number of components to guarantee with good probability
    an eps-embedding with n_samples.

### References

### Examples

```pycon
>>> from sklearn.random_projection import johnson_lindenstrauss_min_dim
>>> johnson_lindenstrauss_min_dim(1e6, eps=0.5)
np.int64(663)
```

```pycon
>>> johnson_lindenstrauss_min_dim(1e6, eps=[0.5, 0.1, 0.01])
array([    663,   11841, 1112658])
```

```pycon
>>> johnson_lindenstrauss_min_dim([1e4, 1e5, 1e6], eps=0.1)
array([ 7894,  9868, 11841])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip=" The \`Johnson-Lindenstrauss lemma\`_ states that any high dimensional dataset can be randomly projected into a lower dimensional Euclidean space while controlling the distortion in the pairwise distances.">  <div class="sphx-glr-thumbnail-title">The Johnson-Lindenstrauss bound for embedding with random projections</div>
</div>
* [The Johnson-Lindenstrauss bound for embedding with random projections](../../auto_examples/miscellaneous/plot_johnson_lindenstrauss_bound.md#sphx-glr-auto-examples-miscellaneous-plot-johnson-lindenstrauss-bound-py)

<!-- thumbnail-parent-div-close --></div>
