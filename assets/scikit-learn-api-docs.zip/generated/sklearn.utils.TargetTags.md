# TargetTags

### *class* sklearn.utils.TargetTags(required: [bool](https://docs.python.org/3/library/functions.html#bool), one_d_labels: [bool](https://docs.python.org/3/library/functions.html#bool) = False, two_d_labels: [bool](https://docs.python.org/3/library/functions.html#bool) = False, positive_only: [bool](https://docs.python.org/3/library/functions.html#bool) = False, multi_output: [bool](https://docs.python.org/3/library/functions.html#bool) = False, single_output: [bool](https://docs.python.org/3/library/functions.html#bool) = True)

Tags for the target data.

* **Parameters:**
  **required**
  : Whether the estimator requires y to be passed to `fit`,
    `fit_predict` or `fit_transform` methods. The tag is `True`
    for estimators inheriting from `~sklearn.base.RegressorMixin`
    and `~sklearn.base.ClassifierMixin`.

  **one_d_labels**
  : Whether the input is a 1D labels (y).

  **two_d_labels**
  : Whether the input is a 2D labels (y).

  **positive_only**
  : Whether the estimator requires a positive y (only applicable
    for regression).

  **multi_output**
  : Whether a regressor supports multi-target outputs or a classifier supports
    multi-class multi-output.
    <br/>
    See [multi-output](../../glossary.md#term-multi-output) in the glossary.

  **single_output**
  : Whether the target can be single-output. This can be `False` if the
    estimator supports only multi-output cases.

<!-- !! processed by numpydoc !! -->
