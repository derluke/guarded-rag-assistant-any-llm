# EllipticEnvelope

### *class* sklearn.covariance.EllipticEnvelope(\*, store_precision=True, assume_centered=False, support_fraction=None, contamination=0.1, random_state=None)

An object for detecting outliers in a Gaussian distributed dataset.

Read more in the [User Guide](../outlier_detection.md#outlier-detection).

* **Parameters:**
  **store_precision**
  : Specify if the estimated precision is stored.

  **assume_centered**
  : If True, the support of robust location and covariance estimates
    is computed, and a covariance estimate is recomputed from it,
    without centering the data.
    Useful to work with data whose mean is significantly equal to
    zero but is not exactly zero.
    If False, the robust location and covariance are directly computed
    with the FastMCD algorithm without additional treatment.

  **support_fraction**
  : The proportion of points to be included in the support of the raw
    MCD estimate. If None, the minimum value of support_fraction will
    be used within the algorithm: `(n_samples + n_features + 1) / 2 * n_samples`.
    Range is (0, 1).

  **contamination**
  : The amount of contamination of the data set, i.e. the proportion
    of outliers in the data set. Range is (0, 0.5].

  **random_state**
  : Determines the pseudo random number generator for shuffling
    the data. Pass an int for reproducible results across multiple function
    calls. See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **location_**
  : Estimated robust location.

  **covariance_**
  : Estimated robust covariance matrix.

  **precision_**
  : Estimated pseudo inverse matrix.
    (stored only if store_precision is True)

  **support_**
  : A mask of the observations that have been used to compute the
    robust estimates of location and shape.

  **offset_**
  : Offset used to define the decision function from the raw scores.
    We have the relation: `decision_function = score_samples - offset_`.
    The offset depends on the contamination parameter and is defined in
    such a way we obtain the expected number of outliers (samples with
    decision function < 0) in training.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **raw_location_**
  : The raw robust estimated location before correction and re-weighting.

  **raw_covariance_**
  : The raw robust estimated covariance before correction and re-weighting.

  **raw_support_**
  : A mask of the observations that have been used to compute
    the raw robust estimates of location and shape, before correction
    and re-weighting.

  **dist_**
  : Mahalanobis distances of the training set (on which [`fit`](#sklearn.covariance.EllipticEnvelope.fit) is
    called) observations.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`EmpiricalCovariance`](sklearn.covariance.EmpiricalCovariance.md#sklearn.covariance.EmpiricalCovariance)
: Maximum likelihood covariance estimator.

[`GraphicalLasso`](sklearn.covariance.GraphicalLasso.md#sklearn.covariance.GraphicalLasso)
: Sparse inverse covariance estimation with an l1-penalized estimator.

[`LedoitWolf`](sklearn.covariance.LedoitWolf.md#sklearn.covariance.LedoitWolf)
: LedoitWolf Estimator.

[`MinCovDet`](sklearn.covariance.MinCovDet.md#sklearn.covariance.MinCovDet)
: Minimum Covariance Determinant (robust estimator of covariance).

[`OAS`](sklearn.covariance.OAS.md#sklearn.covariance.OAS)
: Oracle Approximating Shrinkage Estimator.

[`ShrunkCovariance`](sklearn.covariance.ShrunkCovariance.md#sklearn.covariance.ShrunkCovariance)
: Covariance estimator with shrinkage.

### Notes

Outlier detection from covariance estimation may break or not
perform well in high-dimensional settings. In particular, one will
always take care to work with `n_samples > n_features ** 2`.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.covariance import EllipticEnvelope
>>> true_cov = np.array([[.8, .3],
...                      [.3, .4]])
>>> X = np.random.RandomState(0).multivariate_normal(mean=[0, 0],
...                                                  cov=true_cov,
...                                                  size=500)
>>> cov = EllipticEnvelope(random_state=0).fit(X)
>>> # predict returns 1 for an inlier and -1 for an outlier
>>> cov.predict([[0, 0],
...              [3, 3]])
array([ 1, -1])
>>> cov.covariance_
array([[0.7411..., 0.2535...],
       [0.2535..., 0.3053...]])
>>> cov.location_
array([0.0813... , 0.0427...])
```

<!-- !! processed by numpydoc !! -->

#### correct_covariance(data)

Apply a correction to raw Minimum Covariance Determinant estimates.

Correction using the empirical correction factor suggested
by Rousseeuw and Van Driessen in [[RVD]](#rbb2ba44703ed-rvd).

* **Parameters:**
  **data**
  : The data matrix, with p features and n samples.
    The data set must be the one which was used to compute
    the raw estimates.
* **Returns:**
  **covariance_corrected**
  : Corrected robust covariance estimate.

### References

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Compute the decision function of the given observations.

* **Parameters:**
  **X**
  : The data matrix.
* **Returns:**
  **decision**
  : Decision function of the samples.
    It is equal to the shifted Mahalanobis distances.
    The threshold for being an outlier is 0, which ensures a
    compatibility with other outlier detection algorithms.

<!-- !! processed by numpydoc !! -->

#### error_norm(comp_cov, norm='frobenius', scaling=True, squared=True)

Compute the Mean Squared Error between two covariance estimators.

* **Parameters:**
  **comp_cov**
  : The covariance to compare with.

  **norm**
  : The type of norm used to compute the error. Available error types:
    - ‘frobenius’ (default): sqrt(tr(A^t.A))
    - ‘spectral’: sqrt(max(eigenvalues(A^t.A))
    where A is the error `(comp_cov - self.covariance_)`.

  **scaling**
  : If True (default), the squared error norm is divided by n_features.
    If False, the squared error norm is not rescaled.

  **squared**
  : Whether to compute the squared error norm or the error norm.
    If True (default), the squared error norm is returned.
    If False, the error norm is returned.
* **Returns:**
  **result**
  : The Mean Squared Error (in the sense of the Frobenius norm) between
    `self` and `comp_cov` covariance estimators.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the EllipticEnvelope model.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None, \*\*kwargs)

Perform fit on X and returns labels for X.

Returns -1 for outliers and 1 for inliers.

* **Parameters:**
  **X**
  : The input samples.

  **y**
  : Not used, present for API consistency by convention.

  **\*\*kwargs**
  : Arguments to be passed to `fit`.
    <br/>
    #### Versionadded
    Added in version 1.4.
* **Returns:**
  **y**
  : 1 for inliers, -1 for outliers.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_precision()

Getter for the precision matrix.

* **Returns:**
  **precision_**
  : The precision matrix associated to the current covariance object.

<!-- !! processed by numpydoc !! -->

#### mahalanobis(X)

Compute the squared Mahalanobis distances of given observations.

* **Parameters:**
  **X**
  : The observations, the Mahalanobis distances of the which we
    compute. Observations are assumed to be drawn from the same
    distribution than the data used in fit.
* **Returns:**
  **dist**
  : Squared Mahalanobis distances of the observations.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict labels (1 inlier, -1 outlier) of X according to fitted model.

* **Parameters:**
  **X**
  : The data matrix.
* **Returns:**
  **is_inlier**
  : Returns -1 for anomalies/outliers and +1 for inliers.

<!-- !! processed by numpydoc !! -->

#### reweight_covariance(data)

Re-weight raw Minimum Covariance Determinant estimates.

Re-weight observations using Rousseeuw’s method (equivalent to
deleting outlying observations from the data set before
computing location and covariance estimates) described
in [[RVDriessen]](#rd2c89e63f1c9-rvdriessen).

* **Parameters:**
  **data**
  : The data matrix, with p features and n samples.
    The data set must be the one which was used to compute
    the raw estimates.
* **Returns:**
  **location_reweighted**
  : Re-weighted robust location estimate.

  **covariance_reweighted**
  : Re-weighted robust covariance estimate.

  **support_reweighted**
  : A mask of the observations that have been used to compute
    the re-weighted robust location and covariance estimates.

### References

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for X.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of self.predict(X) w.r.t. y.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Compute the negative Mahalanobis distances.

* **Parameters:**
  **X**
  : The data matrix.
* **Returns:**
  **negative_mahal_distances**
  : Opposite of the Mahalanobis distances.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the need for robust covariance estimation on a real data set. It is useful both for outlier detection and for a better understanding of the data structure.">  <div class="sphx-glr-thumbnail-title">Outlier detection on a real data set</div>
</div>
* [Outlier detection on a real data set](../../auto_examples/applications/plot_outlier_detection_wine.md#sphx-glr-auto-examples-applications-plot-outlier-detection-wine-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different anomaly detection algorithms on 2D datasets. Datasets contain one or two modes (regions of high density) to illustrate the ability of algorithms to cope with multimodal data.">  <div class="sphx-glr-thumbnail-title">Comparing anomaly detection algorithms for outlier detection on toy datasets</div>
</div>
* [Comparing anomaly detection algorithms for outlier detection on toy datasets](../../auto_examples/miscellaneous/plot_anomaly_comparison.md#sphx-glr-auto-examples-miscellaneous-plot-anomaly-comparison-py)

<!-- thumbnail-parent-div-close --></div>
