# AdaBoostClassifier

### *class* sklearn.ensemble.AdaBoostClassifier(estimator=None, \*, n_estimators=50, learning_rate=1.0, algorithm='deprecated', random_state=None)

An AdaBoost classifier.

An AdaBoost [[1]](#r33e4ec8c4ad5-1) classifier is a meta-estimator that begins by fitting a
classifier on the original dataset and then fits additional copies of the
classifier on the same dataset but where the weights of incorrectly
classified instances are adjusted such that subsequent classifiers focus
more on difficult cases.

This class implements the algorithm based on [[2]](#r33e4ec8c4ad5-2).

Read more in the [User Guide](../ensemble.md#adaboost).

#### Versionadded
Added in version 0.14.

* **Parameters:**
  **estimator**
  : The base estimator from which the boosted ensemble is built.
    Support for sample weighting is required, as well as proper
    `classes_` and `n_classes_` attributes. If `None`, then
    the base estimator is [`DecisionTreeClassifier`](sklearn.tree.DecisionTreeClassifier.md#sklearn.tree.DecisionTreeClassifier)
    initialized with `max_depth=1`.
    <br/>
    #### Versionadded
    Added in version 1.2: `base_estimator` was renamed to `estimator`.

  **n_estimators**
  : The maximum number of estimators at which boosting is terminated.
    In case of perfect fit, the learning procedure is stopped early.
    Values must be in the range `[1, inf)`.

  **learning_rate**
  : Weight applied to each classifier at each boosting iteration. A higher
    learning rate increases the contribution of each classifier. There is
    a trade-off between the `learning_rate` and `n_estimators` parameters.
    Values must be in the range `(0.0, inf)`.

  **algorithm**
  : Use the SAMME discrete boosting algorithm.
    <br/>
    #### Deprecated
    Deprecated since version 1.6: `algorithm` is deprecated and will be removed in version 1.8. This
    estimator only implements the ‘SAMME’ algorithm.

  **random_state**
  : Controls the random seed given at each `estimator` at each
    boosting iteration.
    Thus, it is only used when `estimator` exposes a `random_state`.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **estimator_**
  : The base estimator from which the ensemble is grown.
    <br/>
    #### Versionadded
    Added in version 1.2: `base_estimator_` was renamed to `estimator_`.

  **estimators_**
  : The collection of fitted sub-estimators.

  **classes_**
  : The classes labels.

  **n_classes_**
  : The number of classes.

  **estimator_weights_**
  : Weights for each estimator in the boosted ensemble.

  **estimator_errors_**
  : Classification error for each estimator in the boosted
    ensemble.

  [`feature_importances_`](#sklearn.ensemble.AdaBoostClassifier.feature_importances_)
  : The impurity-based feature importances.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`AdaBoostRegressor`](sklearn.ensemble.AdaBoostRegressor.md#sklearn.ensemble.AdaBoostRegressor)
: An AdaBoost regressor that begins by fitting a regressor on the original dataset and then fits additional copies of the regressor on the same dataset but where the weights of instances are adjusted according to the error of the current prediction.

[`GradientBoostingClassifier`](sklearn.ensemble.GradientBoostingClassifier.md#sklearn.ensemble.GradientBoostingClassifier)
: GB builds an additive model in a forward stage-wise fashion. Regression trees are fit on the negative gradient of the binomial or multinomial deviance loss function. Binary classification is a special case where only a single regression tree is induced.

[`sklearn.tree.DecisionTreeClassifier`](sklearn.tree.DecisionTreeClassifier.md#sklearn.tree.DecisionTreeClassifier)
: A non-parametric supervised learning method used for classification. Creates a model that predicts the value of a target variable by learning simple decision rules inferred from the data features.

### References

### Examples

```pycon
>>> from sklearn.ensemble import AdaBoostClassifier
>>> from sklearn.datasets import make_classification
>>> X, y = make_classification(n_samples=1000, n_features=4,
...                            n_informative=2, n_redundant=0,
...                            random_state=0, shuffle=False)
>>> clf = AdaBoostClassifier(n_estimators=100, random_state=0)
>>> clf.fit(X, y)
AdaBoostClassifier(n_estimators=100, random_state=0)
>>> clf.predict([[0, 0, 0, 0]])
array([1])
>>> clf.score(X, y)
0.96...
```

For a detailed example of using AdaBoost to fit a sequence of DecisionTrees
as weaklearners, please refer to
[Multi-class AdaBoosted Decision Trees](../../auto_examples/ensemble/plot_adaboost_multiclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-multiclass-py).

For a detailed example of using AdaBoost to fit a non-linearly seperable
classification dataset composed of two Gaussian quantiles clusters, please
refer to [Two-class AdaBoost](../../auto_examples/ensemble/plot_adaboost_twoclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-twoclass-py).

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Compute the decision function of `X`.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.
* **Returns:**
  **score**
  : The decision function of the input samples. The order of
    outputs is the same as that of the [classes_](../../glossary.md#term-classes_) attribute.
    Binary classification is a special cases with `k == 1`,
    otherwise `k==n_classes`. For binary classification,
    values closer to -1 or 1 mean more like the first or second
    class in `classes_`, respectively.

<!-- !! processed by numpydoc !! -->

#### *property* feature_importances_

The impurity-based feature importances.

The higher, the more important the feature.
The importance of a feature is computed as the (normalized)
total reduction of the criterion brought by that feature.  It is also
known as the Gini importance.

Warning: impurity-based feature importances can be misleading for
high cardinality features (many unique values). See
[`sklearn.inspection.permutation_importance`](sklearn.inspection.permutation_importance.md#sklearn.inspection.permutation_importance) as an alternative.

* **Returns:**
  **feature_importances_**
  : The feature importances.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Build a boosted classifier/regressor from the training set (X, y).

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.

  **y**
  : The target values.

  **sample_weight**
  : Sample weights. If None, the sample weights are initialized to
    1 / n_samples.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Raise `NotImplementedError`.

This estimator does not support metadata routing yet.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict classes for X.

The predicted class of an input sample is computed as the weighted mean
prediction of the classifiers in the ensemble.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.
* **Returns:**
  **y**
  : The predicted classes.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Predict class log-probabilities for X.

The predicted class log-probabilities of an input sample is computed as
the weighted mean predicted class log-probabilities of the classifiers
in the ensemble.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.
* **Returns:**
  **p**
  : The class probabilities of the input samples. The order of
    outputs is the same of that of the [classes_](../../glossary.md#term-classes_) attribute.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict class probabilities for X.

The predicted class probabilities of an input sample is computed as
the weighted mean predicted class probabilities of the classifiers
in the ensemble.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.
* **Returns:**
  **p**
  : The class probabilities of the input samples. The order of
    outputs is the same of that of the [classes_](../../glossary.md#term-classes_) attribute.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [AdaBoostClassifier](#sklearn.ensemble.AdaBoostClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [AdaBoostClassifier](#sklearn.ensemble.AdaBoostClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### staged_decision_function(X)

Compute decision function of `X` for each boosting iteration.

This method allows monitoring (i.e. determine error on testing set)
after each boosting iteration.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.
* **Yields:**
  **score**
  : The decision function of the input samples. The order of
    outputs is the same of that of the [classes_](../../glossary.md#term-classes_) attribute.
    Binary classification is a special cases with `k == 1`,
    otherwise `k==n_classes`. For binary classification,
    values closer to -1 or 1 mean more like the first or second
    class in `classes_`, respectively.

<!-- !! processed by numpydoc !! -->

#### staged_predict(X)

Return staged predictions for X.

The predicted class of an input sample is computed as the weighted mean
prediction of the classifiers in the ensemble.

This generator method yields the ensemble prediction after each
iteration of boosting and therefore allows monitoring, such as to
determine the prediction on a test set after each boost.

* **Parameters:**
  **X**
  : The input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.
* **Yields:**
  **y**
  : The predicted classes.

<!-- !! processed by numpydoc !! -->

#### staged_predict_proba(X)

Predict class probabilities for X.

The predicted class probabilities of an input sample is computed as
the weighted mean predicted class probabilities of the classifiers
in the ensemble.

This generator method yields the ensemble predicted class probabilities
after each iteration of boosting and therefore allows monitoring, such
as to determine the predicted class probabilities on a test set after
each boost.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.
* **Yields:**
  **p**
  : The class probabilities of the input samples. The order of
    outputs is the same of that of the [classes_](../../glossary.md#term-classes_) attribute.

<!-- !! processed by numpydoc !! -->

#### staged_score(X, y, sample_weight=None)

Return staged scores for X, y.

This generator method yields the ensemble score after each iteration of
boosting and therefore allows monitoring, such as to determine the
score on a test set after each boost.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.

  **y**
  : Labels for X.

  **sample_weight**
  : Sample weights.
* **Yields:**
  **z**

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how boosting can improve the prediction accuracy on a multi-label classification problem. It reproduces a similar experiment as depicted by Figure 1 in Zhu et al [1]_.">  <div class="sphx-glr-thumbnail-title">Multi-class AdaBoosted Decision Trees</div>
</div>
* [Multi-class AdaBoosted Decision Trees](../../auto_examples/ensemble/plot_adaboost_multiclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-multiclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision surfaces of forests of randomized trees trained on pairs of features of the iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision surfaces of ensembles of trees on the iris dataset</div>
</div>
* [Plot the decision surfaces of ensembles of trees on the iris dataset](../../auto_examples/ensemble/plot_forest_iris.md#sphx-glr-auto-examples-ensemble-plot-forest-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example fits an AdaBoosted decision stump on a non-linearly separable classification dataset composed of two &quot;Gaussian quantiles&quot; clusters (see sklearn.datasets.make_gaussian_quantiles) and plots the decision boundary and decision scores. The distributions of decision scores are shown separately for samples of class A and B. The predicted class label for each sample is determined by the sign of the decision score. Samples with decision scores greater than zero are classified as B, and are otherwise classified as A. The magnitude of a decision score determines the degree of likeness with the predicted class label. Additionally, a new dataset could be constructed containing a desired purity of class B, for example, by only selecting samples with a decision score above some value.">  <div class="sphx-glr-thumbnail-title">Two-class AdaBoost</div>
</div>
* [Two-class AdaBoost](../../auto_examples/ensemble/plot_adaboost_twoclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-twoclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how boosting can improve the prediction accuracy on a multi-label classification problem. It reproduces a similar experiment as depicted by Figure 1 in Zhu et al [1]_.">  <div class="sphx-glr-thumbnail-title">Multi-class AdaBoosted Decision Trees</div>
</div>
* [Multi-class AdaBoosted Decision Trees](../../auto_examples/ensemble/plot_adaboost_multiclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-multiclass-py)

<!-- thumbnail-parent-div-close --></div>
