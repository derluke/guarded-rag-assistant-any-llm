# DictionaryLearning

### *class* sklearn.decomposition.DictionaryLearning(n_components=None, \*, alpha=1, max_iter=1000, tol=1e-08, fit_algorithm='lars', transform_algorithm='omp', transform_n_nonzero_coefs=None, transform_alpha=None, n_jobs=None, code_init=None, dict_init=None, callback=None, verbose=False, split_sign=False, random_state=None, positive_code=False, positive_dict=False, transform_max_iter=1000)

Dictionary learning.

Finds a dictionary (a set of atoms) that performs well at sparsely
encoding the fitted data.

Solves the optimization problem:

```default
(U^*,V^*) = argmin 0.5 || X - U V ||_Fro^2 + alpha * || U ||_1,1
            (U,V)
            with || V_k ||_2 <= 1 for all  0 <= k < n_components
```

||.||_Fro stands for the Frobenius norm and ||.||_1,1 stands for
the entry-wise matrix norm which is the sum of the absolute values
of all the entries in the matrix.

Read more in the [User Guide](../decomposition.md#dictionarylearning).

* **Parameters:**
  **n_components**
  : Number of dictionary elements to extract. If None, then `n_components`
    is set to `n_features`.

  **alpha**
  : Sparsity controlling parameter.

  **max_iter**
  : Maximum number of iterations to perform.

  **tol**
  : Tolerance for numerical error.

  **fit_algorithm**
  : * `'lars'`: uses the least angle regression method to solve the lasso
      problem ([`lars_path`](sklearn.linear_model.lars_path.md#sklearn.linear_model.lars_path));
    * `'cd'`: uses the coordinate descent method to compute the
      Lasso solution ([`Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso)). Lars will be
      faster if the estimated components are sparse.
    <br/>
    #### Versionadded
    Added in version 0.17: *cd* coordinate descent method to improve speed.

  **transform_algorithm**
  : Algorithm used to transform the data:
    - `'lars'`: uses the least angle regression method
      ([`lars_path`](sklearn.linear_model.lars_path.md#sklearn.linear_model.lars_path));
    - `'lasso_lars'`: uses Lars to compute the Lasso solution.
    - `'lasso_cd'`: uses the coordinate descent method to compute the
      Lasso solution ([`Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso)). `'lasso_lars'`
      will be faster if the estimated components are sparse.
    - `'omp'`: uses orthogonal matching pursuit to estimate the sparse
      solution.
    - `'threshold'`: squashes to zero all coefficients less than alpha from
      the projection `dictionary * X'`.
    <br/>
    #### Versionadded
    Added in version 0.17: *lasso_cd* coordinate descent method to improve speed.

  **transform_n_nonzero_coefs**
  : Number of nonzero coefficients to target in each column of the
    solution. This is only used by `algorithm='lars'` and
    `algorithm='omp'`. If `None`, then
    `transform_n_nonzero_coefs=int(n_features / 10)`.

  **transform_alpha**
  : If `algorithm='lasso_lars'` or `algorithm='lasso_cd'`, `alpha` is the
    penalty applied to the L1 norm.
    If `algorithm='threshold'`, `alpha` is the absolute value of the
    threshold below which coefficients will be squashed to zero.
    If `None`, defaults to `alpha`.
    <br/>
    #### Versionchanged
    Changed in version 1.2: When None, default value changed from 1.0 to `alpha`.

  **n_jobs**
  : Number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **code_init**
  : Initial value for the code, for warm restart. Only used if `code_init`
    and `dict_init` are not None.

  **dict_init**
  : Initial values for the dictionary, for warm restart. Only used if
    `code_init` and `dict_init` are not None.

  **callback**
  : Callable that gets invoked every five iterations.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **verbose**
  : To control the verbosity of the procedure.

  **split_sign**
  : Whether to split the sparse feature vector into the concatenation of
    its negative part and its positive part. This can improve the
    performance of downstream classifiers.

  **random_state**
  : Used for initializing the dictionary when `dict_init` is not
    specified, randomly shuffling the data when `shuffle` is set to
    `True`, and updating the dictionary. Pass an int for reproducible
    results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **positive_code**
  : Whether to enforce positivity when finding the code.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **positive_dict**
  : Whether to enforce positivity when finding the dictionary.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **transform_max_iter**
  : Maximum number of iterations to perform if `algorithm='lasso_cd'` or
    `'lasso_lars'`.
    <br/>
    #### Versionadded
    Added in version 0.22.
* **Attributes:**
  **components_**
  : dictionary atoms extracted from the data

  **error_**
  : vector of errors at each iteration

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Number of iterations run.

#### SEE ALSO
[`MiniBatchDictionaryLearning`](sklearn.decomposition.MiniBatchDictionaryLearning.md#sklearn.decomposition.MiniBatchDictionaryLearning)
: A faster, less accurate, version of the dictionary learning algorithm.

[`MiniBatchSparsePCA`](sklearn.decomposition.MiniBatchSparsePCA.md#sklearn.decomposition.MiniBatchSparsePCA)
: Mini-batch Sparse Principal Components Analysis.

[`SparseCoder`](sklearn.decomposition.SparseCoder.md#sklearn.decomposition.SparseCoder)
: Find a sparse representation of data from a fixed, precomputed dictionary.

[`SparsePCA`](sklearn.decomposition.SparsePCA.md#sklearn.decomposition.SparsePCA)
: Sparse Principal Components Analysis.

### References

J. Mairal, F. Bach, J. Ponce, G. Sapiro, 2009: Online dictionary learning
for sparse coding ([https://www.di.ens.fr/~fbach/mairal_icml09.pdf](https://www.di.ens.fr/~fbach/mairal_icml09.pdf))

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.datasets import make_sparse_coded_signal
>>> from sklearn.decomposition import DictionaryLearning
>>> X, dictionary, code = make_sparse_coded_signal(
...     n_samples=30, n_components=15, n_features=20, n_nonzero_coefs=10,
...     random_state=42,
... )
>>> dict_learner = DictionaryLearning(
...     n_components=15, transform_algorithm='lasso_lars', transform_alpha=0.1,
...     random_state=42,
... )
>>> X_transformed = dict_learner.fit(X).transform(X)
```

We can check the level of sparsity of `X_transformed`:

```pycon
>>> np.mean(X_transformed == 0)
np.float64(0.52...)
```

We can compare the average squared euclidean norm of the reconstruction
error of the sparse coded signal relative to the squared euclidean norm of
the original signal:

```pycon
>>> X_hat = X_transformed @ dict_learner.components_
>>> np.mean(np.sum((X_hat - X) ** 2, axis=1) / np.sum(X ** 2, axis=1))
np.float64(0.05...)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the model from data in X.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Fit the model from data in X and return the transformed data.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **V**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Encode the data as a sparse combination of the dictionary atoms.

Coding method is determined by the object parameter
`transform_algorithm`.

* **Parameters:**
  **X**
  : Test data to be transformed, must have the same number of
    features as the data used to train the model.
* **Returns:**
  **X_new**
  : Transformed data.

<!-- !! processed by numpydoc !! -->
