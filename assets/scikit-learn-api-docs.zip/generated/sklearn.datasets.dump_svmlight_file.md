# dump_svmlight_file

### sklearn.datasets.dump_svmlight_file(X, y, f, \*, zero_based=True, comment=None, query_id=None, multilabel=False)

Dump the dataset in svmlight / libsvm file format.

This format is a text-based format, with one sample per line. It does
not store zero valued features hence is suitable for sparse dataset.

The first element of each line can be used to store a target variable
to predict.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target values. Class labels must be an
    integer or float, or array-like objects of integer or float for
    multilabel classifications.

  **f**
  : If string, specifies the path that will contain the data.
    If file-like, data will be written to f. f should be opened in binary
    mode.

  **zero_based**
  : Whether column indices should be written zero-based (True) or one-based
    (False).

  **comment**
  : Comment to insert at the top of the file. This should be either a
    Unicode string, which will be encoded as UTF-8, or an ASCII byte
    string.
    If a comment is given, then it will be preceded by one that identifies
    the file as having been dumped by scikit-learn. Note that not all
    tools grok comments in SVMlight files.

  **query_id**
  : Array containing pairwise preference constraints (qid in svmlight
    format).

  **multilabel**
  : Samples may have several labels each (see
    [https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/multilabel.html](https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/multilabel.html)).
    <br/>
    #### Versionadded
    Added in version 0.17: parameter `multilabel` to support multilabel datasets.

### Examples

```pycon
>>> from sklearn.datasets import dump_svmlight_file, make_classification
>>> X, y = make_classification(random_state=0)
>>> output_file = "my_dataset.svmlight"
>>> dump_svmlight_file(X, y, output_file)  
```

<!-- !! processed by numpydoc !! -->
