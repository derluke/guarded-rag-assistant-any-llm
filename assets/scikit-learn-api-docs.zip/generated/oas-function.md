# oas

### sklearn.covariance.oas(X, \*, assume_centered=False)

Estimate covariance with the Oracle Approximating Shrinkage.

Read more in the [User Guide](../covariance.md#shrunk-covariance).

* **Parameters:**
  **X**
  : Data from which to compute the covariance estimate.

  **assume_centered**
  : If True, data will not be centered before computation.
    Useful to work with data whose mean is significantly equal to
    zero but is not exactly zero.
    If False, data will be centered before computation.
* **Returns:**
  **shrunk_cov**
  : Shrunk covariance.

  **shrinkage**
  : Coefficient in the convex combination used for the computation
    of the shrunk estimate.

### Notes

The regularised covariance is:

(1 - shrinkage) \* cov + shrinkage \* mu \* np.identity(n_features),

where mu = trace(cov) / n_features and shrinkage is given by the OAS formula
(see [[1]](#rca3a42e5ec35-1)).

The shrinkage formulation implemented here differs from Eq. 23 in [[1]](#rca3a42e5ec35-1). In
the original article, formula (23) states that 2/p (p being the number of
features) is multiplied by Trace(cov\*cov) in both the numerator and
denominator, but this operation is omitted because for a large p, the value
of 2/p is so small that it doesn’t affect the value of the estimator.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.covariance import oas
>>> rng = np.random.RandomState(0)
>>> real_cov = [[.8, .3], [.3, .4]]
>>> X = rng.multivariate_normal(mean=[0, 0], cov=real_cov, size=500)
>>> shrunk_cov, shrinkage = oas(X)
>>> shrunk_cov
array([[0.7533..., 0.2763...],
       [0.2763..., 0.3964...]])
>>> shrinkage
np.float64(0.0195...)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how the Ledoit-Wolf and Oracle Approximating Shrinkage (OAS) estimators of covariance can improve classification.">  <div class="sphx-glr-thumbnail-title">Normal, Ledoit-Wolf and OAS Linear Discriminant Analysis for classification</div>
</div>
* [Normal, Ledoit-Wolf and OAS Linear Discriminant Analysis for classification](../../auto_examples/classification/plot_lda.md#sphx-glr-auto-examples-classification-plot-lda-py)

<div class="sphx-glr-thumbcontainer" tooltip="The usual covariance maximum likelihood estimate can be regularized using shrinkage. Ledoit and Wolf proposed a close formula to compute the asymptotically optimal shrinkage parameter (minimizing a MSE criterion), yielding the Ledoit-Wolf covariance estimate.">  <div class="sphx-glr-thumbnail-title">Ledoit-Wolf vs OAS estimation</div>
</div>
* [Ledoit-Wolf vs OAS estimation](../../auto_examples/covariance/plot_lw_vs_oas.md#sphx-glr-auto-examples-covariance-plot-lw-vs-oas-py)

<div class="sphx-glr-thumbcontainer" tooltip="When working with covariance estimation, the usual approach is to use a maximum likelihood estimator, such as the EmpiricalCovariance. It is unbiased, i.e. it converges to the true (population) covariance when given many observations. However, it can also be beneficial to regularize it, in order to reduce its variance; this, in turn, introduces some bias. This example illustrates the simple regularization used in shrunk_covariance estimators. In particular, it focuses on how to set the amount of regularization, i.e. how to choose the bias-variance trade-off.">  <div class="sphx-glr-thumbnail-title">Shrinkage covariance estimation: LedoitWolf vs OAS and max-likelihood</div>
</div>
* [Shrinkage covariance estimation: LedoitWolf vs OAS and max-likelihood](../../auto_examples/covariance/plot_covariance_estimation.md#sphx-glr-auto-examples-covariance-plot-covariance-estimation-py)

<!-- thumbnail-parent-div-close --></div>
