# RandomForestClassifier

### *class* sklearn.ensemble.RandomForestClassifier(n_estimators=100, \*, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features='sqrt', max_leaf_nodes=None, min_impurity_decrease=0.0, bootstrap=True, oob_score=False, n_jobs=None, random_state=None, verbose=0, warm_start=False, class_weight=None, ccp_alpha=0.0, max_samples=None, monotonic_cst=None)

A random forest classifier.

A random forest is a meta estimator that fits a number of decision tree
classifiers on various sub-samples of the dataset and uses averaging to
improve the predictive accuracy and control over-fitting.
Trees in the forest use the best split strategy, i.e. equivalent to passing
`splitter="best"` to the underlying [`DecisionTreeClassifier`](sklearn.tree.DecisionTreeClassifier.md#sklearn.tree.DecisionTreeClassifier).
The sub-sample size is controlled with the `max_samples` parameter if
`bootstrap=True` (default), otherwise the whole dataset is used to build
each tree.

For a comparison between tree-based ensemble models see the example
[Comparing Random Forests and Histogram Gradient Boosting models](../../auto_examples/ensemble/plot_forest_hist_grad_boosting_comparison.md#sphx-glr-auto-examples-ensemble-plot-forest-hist-grad-boosting-comparison-py).

Read more in the [User Guide](../ensemble.md#forest).

* **Parameters:**
  **n_estimators**
  : The number of trees in the forest.
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default value of `n_estimators` changed from 10 to 100
    in 0.22.

  **criterion**
  : The function to measure the quality of a split. Supported criteria are
    “gini” for the Gini impurity and “log_loss” and “entropy” both for the
    Shannon information gain, see [Mathematical formulation](../tree.md#tree-mathematical-formulation).
    Note: This parameter is tree-specific.

  **max_depth**
  : The maximum depth of the tree. If None, then nodes are expanded until
    all leaves are pure or until all leaves contain less than
    min_samples_split samples.

  **min_samples_split**
  : The minimum number of samples required to split an internal node:
    - If int, then consider `min_samples_split` as the minimum number.
    - If float, then `min_samples_split` is a fraction and
      `ceil(min_samples_split * n_samples)` are the minimum
      number of samples for each split.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_samples_leaf**
  : The minimum number of samples required to be at a leaf node.
    A split point at any depth will only be considered if it leaves at
    least `min_samples_leaf` training samples in each of the left and
    right branches.  This may have the effect of smoothing the model,
    especially in regression.
    - If int, then consider `min_samples_leaf` as the minimum number.
    - If float, then `min_samples_leaf` is a fraction and
      `ceil(min_samples_leaf * n_samples)` are the minimum
      number of samples for each node.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_weight_fraction_leaf**
  : The minimum weighted fraction of the sum total of weights (of all
    the input samples) required to be at a leaf node. Samples have
    equal weight when sample_weight is not provided.

  **max_features**
  : The number of features to consider when looking for the best split:
    - If int, then consider `max_features` features at each split.
    - If float, then `max_features` is a fraction and
      `max(1, int(max_features * n_features_in_))` features are considered at each
      split.
    - If “sqrt”, then `max_features=sqrt(n_features)`.
    - If “log2”, then `max_features=log2(n_features)`.
    - If None, then `max_features=n_features`.
    <br/>
    #### Versionchanged
    Changed in version 1.1: The default of `max_features` changed from `"auto"` to `"sqrt"`.
    <br/>
    Note: the search for a split does not stop until at least one
    valid partition of the node samples is found, even if it requires to
    effectively inspect more than `max_features` features.

  **max_leaf_nodes**
  : Grow trees with `max_leaf_nodes` in best-first fashion.
    Best nodes are defined as relative reduction in impurity.
    If None then unlimited number of leaf nodes.

  **min_impurity_decrease**
  : A node will be split if this split induces a decrease of the impurity
    greater than or equal to this value.
    <br/>
    The weighted impurity decrease equation is the following:
    ```default
    N_t / N * (impurity - N_t_R / N_t * right_impurity
                        - N_t_L / N_t * left_impurity)
    ```
    <br/>
    where `N` is the total number of samples, `N_t` is the number of
    samples at the current node, `N_t_L` is the number of samples in the
    left child, and `N_t_R` is the number of samples in the right child.
    <br/>
    `N`, `N_t`, `N_t_R` and `N_t_L` all refer to the weighted sum,
    if `sample_weight` is passed.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **bootstrap**
  : Whether bootstrap samples are used when building trees. If False, the
    whole dataset is used to build each tree.

  **oob_score**
  : Whether to use out-of-bag samples to estimate the generalization score.
    By default, [`accuracy_score`](sklearn.metrics.accuracy_score.md#sklearn.metrics.accuracy_score) is used.
    Provide a callable with signature `metric(y_true, y_pred)` to use a
    custom metric. Only available if `bootstrap=True`.

  **n_jobs**
  : The number of jobs to run in parallel. [`fit`](#sklearn.ensemble.RandomForestClassifier.fit), [`predict`](#sklearn.ensemble.RandomForestClassifier.predict),
    [`decision_path`](#sklearn.ensemble.RandomForestClassifier.decision_path) and [`apply`](#sklearn.ensemble.RandomForestClassifier.apply) are all parallelized over the
    trees. `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend)
    context. `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs) for more details.

  **random_state**
  : Controls both the randomness of the bootstrapping of the samples used
    when building trees (if `bootstrap=True`) and the sampling of the
    features to consider when looking for the best split at each node
    (if `max_features < n_features`).
    See [Glossary](../../glossary.md#term-random_state) for details.

  **verbose**
  : Controls the verbosity when fitting and predicting.

  **warm_start**
  : When set to `True`, reuse the solution of the previous call to fit
    and add more estimators to the ensemble, otherwise, just fit a whole
    new forest. See [Glossary](../../glossary.md#term-warm_start) and
    [Fitting additional trees](../ensemble.md#tree-ensemble-warm-start) for details.

  **class_weight**
  : Weights associated with classes in the form `{class_label: weight}`.
    If not given, all classes are supposed to have weight one. For
    multi-output problems, a list of dicts can be provided in the same
    order as the columns of y.
    <br/>
    Note that for multioutput (including multilabel) weights should be
    defined for each class of every column in its own dict. For example,
    for four-class multilabel classification weights should be
    [{0: 1, 1: 1}, {0: 1, 1: 5}, {0: 1, 1: 1}, {0: 1, 1: 1}] instead of
    [{1:1}, {2:5}, {3:1}, {4:1}].
    <br/>
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`
    <br/>
    The “balanced_subsample” mode is the same as “balanced” except that
    weights are computed based on the bootstrap sample for every tree
    grown.
    <br/>
    For multi-output, the weights of each column of y will be multiplied.
    <br/>
    Note that these weights will be multiplied with sample_weight (passed
    through the fit method) if sample_weight is specified.

  **ccp_alpha**
  : Complexity parameter used for Minimal Cost-Complexity Pruning. The
    subtree with the largest cost complexity that is smaller than
    `ccp_alpha` will be chosen. By default, no pruning is performed. See
    [Minimal Cost-Complexity Pruning](../tree.md#minimal-cost-complexity-pruning) for details. See
    [Post pruning decision trees with cost complexity pruning](../../auto_examples/tree/plot_cost_complexity_pruning.md#sphx-glr-auto-examples-tree-plot-cost-complexity-pruning-py)
    for an example of such pruning.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **max_samples**
  : If bootstrap is True, the number of samples to draw from X
    to train each base estimator.
    - If None (default), then draw `X.shape[0]` samples.
    - If int, then draw `max_samples` samples.
    - If float, then draw `max(round(n_samples * max_samples), 1)` samples. Thus,
      `max_samples` should be in the interval `(0.0, 1.0]`.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **monotonic_cst**
  : Indicates the monotonicity constraint to enforce on each feature.
    : - 1: monotonic increase
      - 0: no constraint
      - -1: monotonic decrease
    <br/>
    If monotonic_cst is None, no constraints are applied.
    <br/>
    Monotonicity constraints are not supported for:
    : - multiclass classifications (i.e. when `n_classes > 2`),
      - multioutput classifications (i.e. when `n_outputs_ > 1`),
      - classifications trained on data with missing values.
    <br/>
    The constraints hold over the probability of the positive class.
    <br/>
    Read more in the [User Guide](../ensemble.md#monotonic-cst-gbdt).
    <br/>
    #### Versionadded
    Added in version 1.4.
* **Attributes:**
  **estimator_**
  : The child estimator template used to create the collection of fitted
    sub-estimators.
    <br/>
    #### Versionadded
    Added in version 1.2: `base_estimator_` was renamed to `estimator_`.

  **estimators_**
  : The collection of fitted sub-estimators.

  **classes_**
  : The classes labels (single output problem), or a list of arrays of
    class labels (multi-output problem).

  **n_classes_**
  : The number of classes (single output problem), or a list containing the
    number of classes for each output (multi-output problem).

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_outputs_**
  : The number of outputs when `fit` is performed.

  [`feature_importances_`](#sklearn.ensemble.RandomForestClassifier.feature_importances_)
  : The impurity-based feature importances.

  **oob_score_**
  : Score of the training dataset obtained using an out-of-bag estimate.
    This attribute exists only when `oob_score` is True.

  **oob_decision_function_**
  : Decision function computed with out-of-bag estimate on the training
    set. If n_estimators is small it might be possible that a data point
    was never left out during the bootstrap. In this case,
    `oob_decision_function_` might contain NaN. This attribute exists
    only when `oob_score` is True.

  [`estimators_samples_`](#sklearn.ensemble.RandomForestClassifier.estimators_samples_)
  : The subset of drawn samples for each base estimator.

#### SEE ALSO
[`sklearn.tree.DecisionTreeClassifier`](sklearn.tree.DecisionTreeClassifier.md#sklearn.tree.DecisionTreeClassifier)
: A decision tree classifier.

[`sklearn.ensemble.ExtraTreesClassifier`](sklearn.ensemble.ExtraTreesClassifier.md#sklearn.ensemble.ExtraTreesClassifier)
: Ensemble of extremely randomized tree classifiers.

[`sklearn.ensemble.HistGradientBoostingClassifier`](sklearn.ensemble.HistGradientBoostingClassifier.md#sklearn.ensemble.HistGradientBoostingClassifier)
: A Histogram-based Gradient Boosting Classification Tree, very fast for big datasets (n_samples >= 10_000).

### Notes

The default values for the parameters controlling the size of the trees
(e.g. `max_depth`, `min_samples_leaf`, etc.) lead to fully grown and
unpruned trees which can potentially be very large on some data sets. To
reduce memory consumption, the complexity and size of the trees should be
controlled by setting those parameter values.

The features are always randomly permuted at each split. Therefore,
the best found split may vary, even with the same training data,
`max_features=n_features` and `bootstrap=False`, if the improvement
of the criterion is identical for several splits enumerated during the
search of the best split. To obtain a deterministic behaviour during
fitting, `random_state` has to be fixed.

### References

### Examples

```pycon
>>> from sklearn.ensemble import RandomForestClassifier
>>> from sklearn.datasets import make_classification
>>> X, y = make_classification(n_samples=1000, n_features=4,
...                            n_informative=2, n_redundant=0,
...                            random_state=0, shuffle=False)
>>> clf = RandomForestClassifier(max_depth=2, random_state=0)
>>> clf.fit(X, y)
RandomForestClassifier(...)
>>> print(clf.predict([[0, 0, 0, 0]]))
[1]
```

<!-- !! processed by numpydoc !! -->

#### apply(X)

Apply trees in the forest to X, return leaf indices.

* **Parameters:**
  **X**
  : The input samples. Internally, its dtype will be converted to
    `dtype=np.float32`. If a sparse matrix is provided, it will be
    converted into a sparse `csr_matrix`.
* **Returns:**
  **X_leaves**
  : For each datapoint x in X and for each tree in the forest,
    return the index of the leaf x ends up in.

<!-- !! processed by numpydoc !! -->

#### decision_path(X)

Return the decision path in the forest.

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **X**
  : The input samples. Internally, its dtype will be converted to
    `dtype=np.float32`. If a sparse matrix is provided, it will be
    converted into a sparse `csr_matrix`.
* **Returns:**
  **indicator**
  : Return a node indicator matrix where non zero elements indicates
    that the samples goes through the nodes. The matrix is of CSR
    format.

  **n_nodes_ptr**
  : The columns from indicator[n_nodes_ptr[i]:n_nodes_ptr[i+1]]
    gives the indicator value for the i-th estimator.

<!-- !! processed by numpydoc !! -->

#### *property* estimators_samples_

The subset of drawn samples for each base estimator.

Returns a dynamically generated list of indices identifying
the samples used for fitting each member of the ensemble, i.e.,
the in-bag samples.

Note: the list is re-created at each call to the property in order
to reduce the object memory footprint by not storing the sampling
data. Thus fetching the property may be slower than expected.

<!-- !! processed by numpydoc !! -->

#### *property* feature_importances_

The impurity-based feature importances.

The higher, the more important the feature.
The importance of a feature is computed as the (normalized)
total reduction of the criterion brought by that feature.  It is also
known as the Gini importance.

Warning: impurity-based feature importances can be misleading for
high cardinality features (many unique values). See
[`sklearn.inspection.permutation_importance`](sklearn.inspection.permutation_importance.md#sklearn.inspection.permutation_importance) as an alternative.

* **Returns:**
  **feature_importances_**
  : The values of this array sum to 1, unless all trees are single node
    trees consisting of only the root node, in which case it will be an
    array of zeros.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Build a forest of trees from the training set (X, y).

* **Parameters:**
  **X**
  : The training input samples. Internally, its dtype will be converted
    to `dtype=np.float32`. If a sparse matrix is provided, it will be
    converted into a sparse `csc_matrix`.

  **y**
  : The target values (class labels in classification, real numbers in
    regression).

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted. Splits
    that would create child nodes with net zero or negative weight are
    ignored while searching for a split in each node. In the case of
    classification, splits are also ignored if they would result in any
    single class carrying a negative weight in either child node.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict class for X.

The predicted class of an input sample is a vote by the trees in
the forest, weighted by their probability estimates. That is,
the predicted class is the one with highest mean probability
estimate across the trees.

* **Parameters:**
  **X**
  : The input samples. Internally, its dtype will be converted to
    `dtype=np.float32`. If a sparse matrix is provided, it will be
    converted into a sparse `csr_matrix`.
* **Returns:**
  **y**
  : The predicted classes.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Predict class log-probabilities for X.

The predicted class log-probabilities of an input sample is computed as
the log of the mean predicted class probabilities of the trees in the
forest.

* **Parameters:**
  **X**
  : The input samples. Internally, its dtype will be converted to
    `dtype=np.float32`. If a sparse matrix is provided, it will be
    converted into a sparse `csr_matrix`.
* **Returns:**
  **p**
  : The class probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict class probabilities for X.

The predicted class probabilities of an input sample are computed as
the mean predicted class probabilities of the trees in the forest.
The class probability of a single tree is the fraction of samples of
the same class in a leaf.

* **Parameters:**
  **X**
  : The input samples. Internally, its dtype will be converted to
    `dtype=np.float32`. If a sparse matrix is provided, it will be
    converted into a sparse `csr_matrix`.
* **Returns:**
  **p**
  : The class probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RandomForestClassifier](#sklearn.ensemble.RandomForestClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RandomForestClassifier](#sklearn.ensemble.RandomForestClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Well calibrated classifiers are probabilistic classifiers for which the output of predict_proba can be directly interpreted as a confidence level. For instance, a well calibrated (binary) classifier should classify the samples such that for the samples to which it gave a predict_proba value close to 0.8, approximately 80% actually belong to the positive class.">  <div class="sphx-glr-thumbnail-title">Comparison of Calibration of Classifiers</div>
</div>
* [Comparison of Calibration of Classifiers](../../auto_examples/calibration/plot_compare_calibration.md#sphx-glr-auto-examples-calibration-plot-compare-calibration-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how sigmoid calibration changes predicted probabilities for a 3-class classification problem. Illustrated is the standard 2-simplex, where the three corners correspond to the three classes. Arrows point from the probability vectors predicted by an uncalibrated classifier to the probability vectors predicted by the same classifier after sigmoid calibration on a hold-out validation set. Colors indicate the true class of an instance (red: class 1, green: class 2, blue: class 3).">  <div class="sphx-glr-thumbnail-title">Probability Calibration for 3-class classification</div>
</div>
* [Probability Calibration for 3-class classification](../../auto_examples/calibration/plot_calibration_multiclass.md#sphx-glr-auto-examples-calibration-plot-calibration-multiclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Clustering can be expensive, especially when our dataset contains millions of datapoints. Many clustering algorithms are not inductive and so cannot be directly applied to new data samples without recomputing the clustering, which may be intractable. Instead, we can use clustering to then learn an inductive model with a classifier, which has several benefits:">  <div class="sphx-glr-thumbnail-title">Inductive Clustering</div>
</div>
* [Inductive Clustering](../../auto_examples/cluster/plot_inductive_clustering.md#sphx-glr-auto-examples-cluster-plot-inductive-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the performance of Random Forest (RF) and Histogram Gradient Boosting (HGBT) models in terms of score and computation time for a regression dataset, though all the concepts here presented apply to classification as well.">  <div class="sphx-glr-thumbnail-title">Comparing Random Forests and Histogram Gradient Boosting models</div>
</div>
* [Comparing Random Forests and Histogram Gradient Boosting models](../../auto_examples/ensemble/plot_forest_hist_grad_boosting_comparison.md#sphx-glr-auto-examples-ensemble-plot-forest-hist-grad-boosting-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows the use of a forest of trees to evaluate the importance of features on an artificial classification task. The blue bars are the feature importances of the forest, along with their inter-trees variability represented by the error bars.">  <div class="sphx-glr-thumbnail-title">Feature importances with a forest of trees</div>
</div>
* [Feature importances with a forest of trees](../../auto_examples/ensemble/plot_forest_importances.md#sphx-glr-auto-examples-ensemble-plot-forest-importances-py)

<div class="sphx-glr-thumbcontainer" tooltip="Transform your features into a higher dimensional, sparse space. Then train a linear model on these features.">  <div class="sphx-glr-thumbnail-title">Feature transformations with ensembles of trees</div>
</div>
* [Feature transformations with ensembles of trees](../../auto_examples/ensemble/plot_feature_transformation.md#sphx-glr-auto-examples-ensemble-plot-feature-transformation-py)

<div class="sphx-glr-thumbcontainer" tooltip="The RandomForestClassifier is trained using bootstrap aggregation, where each new tree is fit from a bootstrap sample of the training observations z_i = (x_i, y_i). The out-of-bag (OOB) error is the average error for each z_i calculated using predictions from the trees that do not contain z_i in their respective bootstrap sample. This allows the RandomForestClassifier to be fit and validated whilst being trained [1]_.">  <div class="sphx-glr-thumbnail-title">OOB Errors for Random Forests</div>
</div>
* [OOB Errors for Random Forests](../../auto_examples/ensemble/plot_ensemble_oob.md#sphx-glr-auto-examples-ensemble-plot-ensemble-oob-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the class probabilities of the first sample in a toy dataset predicted by three different classifiers and averaged by the VotingClassifier.">  <div class="sphx-glr-thumbnail-title">Plot class probabilities calculated by the VotingClassifier</div>
</div>
* [Plot class probabilities calculated by the VotingClassifier](../../auto_examples/ensemble/plot_voting_probas.md#sphx-glr-auto-examples-ensemble-plot-voting-probas-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision surfaces of forests of randomized trees trained on pairs of features of the iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision surfaces of ensembles of trees on the iris dataset</div>
</div>
* [Plot the decision surfaces of ensembles of trees on the iris dataset](../../auto_examples/ensemble/plot_forest_iris.md#sphx-glr-auto-examples-ensemble-plot-forest-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the impurity-based feature importance of RandomForestClassifier with the permutation importance on the titanic dataset using permutation_importance. We will show that the impurity-based feature importance can inflate the importance of numerical features.">  <div class="sphx-glr-thumbnail-title">Permutation Importance vs Random Forest Feature Importance (MDI)</div>
</div>
* [Permutation Importance vs Random Forest Feature Importance (MDI)](../../auto_examples/inspection/plot_permutation_importance.md#sphx-glr-auto-examples-inspection-plot-permutation-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we compute the permutation_importance of the features to a trained RandomForestClassifier using the breast_cancer_dataset. The model can easily get about 97% accuracy on a test dataset. Because this dataset contains multicollinear features, the permutation importance shows that none of the features are important, in contradiction with the high test accuracy.">  <div class="sphx-glr-thumbnail-title">Permutation Importance with Multicollinear or Correlated Features</div>
</div>
* [Permutation Importance with Multicollinear or Correlated Features](../../auto_examples/inspection/plot_permutation_importance_multicollinear.md#sphx-glr-auto-examples-inspection-plot-permutation-importance-multicollinear-py)

<div class="sphx-glr-thumbcontainer" tooltip="The default configuration for displaying a pipeline in a Jupyter Notebook is &#x27;diagram&#x27; where set_config(display=&#x27;diagram&#x27;). To deactivate HTML representation, use set_config(display=&#x27;text&#x27;).">  <div class="sphx-glr-thumbnail-title">Displaying Pipelines</div>
</div>
* [Displaying Pipelines](../../auto_examples/miscellaneous/plot_pipeline_display.md#sphx-glr-auto-examples-miscellaneous-plot-pipeline-display-py)

<div class="sphx-glr-thumbcontainer" tooltip="ROC Curve with Visualization API">  <div class="sphx-glr-thumbnail-title">ROC Curve with Visualization API</div>
</div>
* [ROC Curve with Visualization API](../../auto_examples/miscellaneous/plot_roc_curve_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-roc-curve-visualization-api-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we compare two binary classification multi-threshold metrics: the Receiver Operating Characteristic (ROC) and the Detection Error Tradeoff (DET). For such purpose, we evaluate two different classifiers for the same classification task.">  <div class="sphx-glr-thumbnail-title">Detection error tradeoff (DET) curve</div>
</div>
* [Detection error tradeoff (DET) curve](../../auto_examples/model_selection/plot_det.md#sphx-glr-auto-examples-model-selection-plot-det-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how a successive halving search (~sklearn.model_selection.HalvingGridSearchCV and HalvingRandomSearchCV) iteratively chooses the best parameter combination out of multiple candidates.">  <div class="sphx-glr-thumbnail-title">Successive Halving Iterations</div>
</div>
* [Successive Halving Iterations](../../auto_examples/model_selection/plot_successive_halving_iterations.md#sphx-glr-auto-examples-model-selection-plot-successive-halving-iterations-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
