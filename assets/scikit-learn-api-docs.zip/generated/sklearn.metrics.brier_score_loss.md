# brier_score_loss

### sklearn.metrics.brier_score_loss(y_true, y_proba=None, \*, sample_weight=None, pos_label=None, y_prob='deprecated')

Compute the Brier score loss.

The smaller the Brier score loss, the better, hence the naming with “loss”.
The Brier score measures the mean squared difference between the predicted
probability and the actual outcome. The Brier score always
takes on a value between zero and one, since this is the largest
possible difference between a predicted probability (which must be
between zero and one) and the actual outcome (which can take on values
of only 0 and 1). It can be decomposed as the sum of refinement loss and
calibration loss.

The Brier score is appropriate for binary and categorical outcomes that
can be structured as true or false, but is inappropriate for ordinal
variables which can take on three or more values (this is because the
Brier score assumes that all possible outcomes are equivalently
“distant” from one another). Which label is considered to be the positive
label is controlled via the parameter `pos_label`, which defaults to
the greater label unless `y_true` is all 0 or all -1, in which case
`pos_label` defaults to 1.

Read more in the [User Guide](../model_evaluation.md#brier-score-loss).

* **Parameters:**
  **y_true**
  : True targets.

  **y_proba**
  : Probabilities of the positive class.

  **sample_weight**
  : Sample weights.

  **pos_label**
  : Label of the positive class. `pos_label` will be inferred in the
    following manner:
    * if `y_true` in {-1, 1} or {0, 1}, `pos_label` defaults to 1;
    * else if `y_true` contains string, an error will be raised and
      `pos_label` should be explicitly specified;
    * otherwise, `pos_label` defaults to the greater label,
      i.e. `np.unique(y_true)[-1]`.

  **y_prob**
  : Probabilities of the positive class.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `y_prob` is deprecated and will be removed in 1.7. Use
    `y_proba` instead.
* **Returns:**
  **score**
  : Brier score loss.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.metrics import brier_score_loss
>>> y_true = np.array([0, 1, 1, 0])
>>> y_true_categorical = np.array(["spam", "ham", "ham", "spam"])
>>> y_prob = np.array([0.1, 0.9, 0.8, 0.3])
>>> brier_score_loss(y_true, y_prob)
np.float64(0.037...)
>>> brier_score_loss(y_true, 1-y_prob, pos_label=0)
np.float64(0.037...)
>>> brier_score_loss(y_true_categorical, y_prob, pos_label="ham")
np.float64(0.037...)
>>> brier_score_loss(y_true, np.array(y_prob) > 0.5)
np.float64(0.0)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="When performing classification one often wants to predict not only the class label, but also the associated probability. This probability gives some kind of confidence on the prediction. This example demonstrates how to visualize how well calibrated the predicted probabilities are using calibration curves, also known as reliability diagrams. Calibration of an uncalibrated classifier will also be demonstrated.">  <div class="sphx-glr-thumbnail-title">Probability Calibration curves</div>
</div>
* [Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="When performing classification you often want to predict not only the class label, but also the associated probability. This probability gives you some kind of confidence on the prediction. However, not all classifiers provide well-calibrated probabilities, some being over-confident while others being under-confident. Thus, a separate calibration of predicted probabilities is often desirable as a postprocessing. This example illustrates two different methods for this calibration and evaluates the quality of the returned probabilities using Brier&#x27;s score (see https://en.wikipedia.org/wiki/Brier_score).">  <div class="sphx-glr-thumbnail-title">Probability calibration of classifiers</div>
</div>
* [Probability calibration of classifiers](../../auto_examples/calibration/plot_calibration.md#sphx-glr-auto-examples-calibration-plot-calibration-py)

<div class="sphx-glr-thumbcontainer" tooltip="This examples showcases some use cases of FrozenEstimator.">  <div class="sphx-glr-thumbnail-title">Examples of Using FrozenEstimator</div>
</div>
* [Examples of Using FrozenEstimator](../../auto_examples/frozen/plot_frozen_examples.md#sphx-glr-auto-examples-frozen-plot-frozen-examples-py)

<!-- thumbnail-parent-div-close --></div>
