# mutual_info_score

### sklearn.metrics.mutual_info_score(labels_true, labels_pred, \*, contingency=None)

Mutual Information between two clusterings.

The Mutual Information is a measure of the similarity between two labels
of the same data. Where $|U_i|$ is the number of the samples
in cluster $U_i$ and $|V_j|$ is the number of the
samples in cluster $V_j$, the Mutual Information
between clusterings $U$ and $V$ is given as:

$$
MI(U,V)=\sum_{i=1}^{|U|} \sum_{j=1}^{|V|} \frac{|U_i\cap V_j|}{N}
\log\frac{N|U_i \cap V_j|}{|U_i||V_j|}
$$

This metric is independent of the absolute values of the labels:
a permutation of the class or cluster label values won’t change the
score value in any way.

This metric is furthermore symmetric: switching $U$ (i.e
`label_true`) with $V$ (i.e. `label_pred`) will return the
same score value. This can be useful to measure the agreement of two
independent label assignments strategies on the same dataset when the
real ground truth is not known.

Read more in the [User Guide](../clustering.md#mutual-info-score).

* **Parameters:**
  **labels_true**
  : A clustering of the data into disjoint subsets, called $U$ in
    the above formula.

  **labels_pred**
  : A clustering of the data into disjoint subsets, called $V$ in
    the above formula.

  **contingency**
  : A contingency matrix given by the
    [`contingency_matrix`](sklearn.metrics.cluster.contingency_matrix.md#sklearn.metrics.cluster.contingency_matrix) function. If value
    is `None`, it will be computed, otherwise the given value is used,
    with `labels_true` and `labels_pred` ignored.
* **Returns:**
  **mi**
  : Mutual information, a non-negative value, measured in nats using the
    natural logarithm.

#### SEE ALSO
[`adjusted_mutual_info_score`](sklearn.metrics.adjusted_mutual_info_score.md#sklearn.metrics.adjusted_mutual_info_score)
: Adjusted against chance Mutual Information.

[`normalized_mutual_info_score`](sklearn.metrics.normalized_mutual_info_score.md#sklearn.metrics.normalized_mutual_info_score)
: Normalized Mutual Information.

### Notes

The logarithm used is the natural logarithm (base-e).

### Examples

```pycon
>>> from sklearn.metrics import mutual_info_score
>>> labels_true = [0, 1, 1, 0, 1, 0]
>>> labels_pred = [0, 1, 0, 0, 1, 1]
>>> mutual_info_score(labels_true, labels_pred)
np.float64(0.056...)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="- a first experiment with fixed &quot;ground truth labels&quot; (and therefore fixed   number of classes) and randomly &quot;predicted labels&quot;; - a second experiment with varying &quot;ground truth labels&quot;, randomly &quot;predicted   labels&quot;. The &quot;predicted labels&quot; have the same number of classes and clusters   as the &quot;ground truth labels&quot;.">  <div class="sphx-glr-thumbnail-title">Adjustment for chance in clustering performance evaluation</div>
</div>
* [Adjustment for chance in clustering performance evaluation](../../auto_examples/cluster/plot_adjusted_for_chance_measures.md#sphx-glr-auto-examples-cluster-plot-adjusted-for-chance-measures-py)

<!-- thumbnail-parent-div-close --></div>
