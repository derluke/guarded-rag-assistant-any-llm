# confusion_matrix

### sklearn.metrics.confusion_matrix(y_true, y_pred, \*, labels=None, sample_weight=None, normalize=None)

Compute confusion matrix to evaluate the accuracy of a classification.

By definition a confusion matrix $C$ is such that $C_{i, j}$
is equal to the number of observations known to be in group $i$ and
predicted to be in group $j$.

Thus in binary classification, the count of true negatives is
$C_{0,0}$, false negatives is $C_{1,0}$, true positives is
$C_{1,1}$ and false positives is $C_{0,1}$.

Read more in the [User Guide](../model_evaluation.md#confusion-matrix).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated targets as returned by a classifier.

  **labels**
  : List of labels to index the matrix. This may be used to reorder
    or select a subset of labels.
    If `None` is given, those that appear at least once
    in `y_true` or `y_pred` are used in sorted order.

  **sample_weight**
  : Sample weights.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **normalize**
  : Normalizes confusion matrix over the true (rows), predicted (columns)
    conditions or all the population. If None, confusion matrix will not be
    normalized.
* **Returns:**
  **C**
  : Confusion matrix whose i-th row and j-th
    column entry indicates the number of
    samples with true label being i-th class
    and predicted label being j-th class.

#### SEE ALSO
[`ConfusionMatrixDisplay.from_estimator`](sklearn.metrics.ConfusionMatrixDisplay.md#sklearn.metrics.ConfusionMatrixDisplay.from_estimator)
: Plot the confusion matrix given an estimator, the data, and the label.

[`ConfusionMatrixDisplay.from_predictions`](sklearn.metrics.ConfusionMatrixDisplay.md#sklearn.metrics.ConfusionMatrixDisplay.from_predictions)
: Plot the confusion matrix given the true and predicted labels.

[`ConfusionMatrixDisplay`](sklearn.metrics.ConfusionMatrixDisplay.md#sklearn.metrics.ConfusionMatrixDisplay)
: Confusion Matrix visualization.

### References

### Examples

```pycon
>>> from sklearn.metrics import confusion_matrix
>>> y_true = [2, 0, 2, 2, 0, 1]
>>> y_pred = [0, 0, 2, 2, 0, 2]
>>> confusion_matrix(y_true, y_pred)
array([[2, 0, 0],
       [0, 0, 1],
       [1, 0, 2]])
```

```pycon
>>> y_true = ["cat", "ant", "cat", "cat", "ant", "bird"]
>>> y_pred = ["ant", "ant", "cat", "cat", "ant", "cat"]
>>> confusion_matrix(y_true, y_pred, labels=["ant", "bird", "cat"])
array([[2, 0, 0],
       [0, 0, 1],
       [1, 0, 2]])
```

In the binary case, we can extract true positives, etc. as follows:

```pycon
>>> tn, fp, fn, tp = confusion_matrix([0, 1, 0, 1], [1, 1, 1, 0]).ravel()
>>> (tn, fp, fn, tp)
(np.int64(0), np.int64(2), np.int64(1), np.int64(1))
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="Demonstrates an active learning technique to learn handwritten digits using label propagation.">  <div class="sphx-glr-thumbnail-title">Label Propagation digits active learning</div>
</div>
* [Label Propagation digits active learning](../../auto_examples/semi_supervised/plot_label_propagation_digits_active_learning.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-digits-active-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<!-- thumbnail-parent-div-close --></div>
