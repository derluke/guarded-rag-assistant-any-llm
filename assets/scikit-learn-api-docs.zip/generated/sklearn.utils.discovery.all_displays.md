# all_displays

### sklearn.utils.discovery.all_displays()

Get a list of all displays from `sklearn`.

* **Returns:**
  **displays**
  : List of (name, class), where `name` is the display class name as
    string and `class` is the actual type of the class.

### Examples

```pycon
>>> from sklearn.utils.discovery import all_displays
>>> displays = all_displays()
>>> displays[0]
('CalibrationDisplay', <class 'sklearn.calibration.CalibrationDisplay'>)
```

<!-- !! processed by numpydoc !! -->
