# mutual_info_classif

### sklearn.feature_selection.mutual_info_classif(X, y, \*, discrete_features='auto', n_neighbors=3, copy=True, random_state=None, n_jobs=None)

Estimate mutual information for a discrete target variable.

Mutual information (MI) [[1]](#r50b872b699c4-1) between two random variables is a non-negative
value, which measures the dependency between the variables. It is equal
to zero if and only if two random variables are independent, and higher
values mean higher dependency.

The function relies on nonparametric methods based on entropy estimation
from k-nearest neighbors distances as described in [[2]](#r50b872b699c4-2) and [[3]](#r50b872b699c4-3). Both
methods are based on the idea originally proposed in [[4]](#r50b872b699c4-4).

It can be used for univariate features selection, read more in the
[User Guide](../feature_selection.md#univariate-feature-selection).

* **Parameters:**
  **X**
  : Feature matrix.

  **y**
  : Target vector.

  **discrete_features**
  : If bool, then determines whether to consider all features discrete
    or continuous. If array, then it should be either a boolean mask
    with shape (n_features,) or array with indices of discrete features.
    If ‘auto’, it is assigned to False for dense `X` and to True for
    sparse `X`.

  **n_neighbors**
  : Number of neighbors to use for MI estimation for continuous variables,
    see [[2]](#r50b872b699c4-2) and [[3]](#r50b872b699c4-3). Higher values reduce variance of the estimation, but
    could introduce a bias.

  **copy**
  : Whether to make a copy of the given data. If set to False, the initial
    data will be overwritten.

  **random_state**
  : Determines random number generation for adding small noise to
    continuous variables in order to remove repeated values.
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **n_jobs**
  : The number of jobs to use for computing the mutual information.
    The parallelization is done on the columns of `X`.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **mi**
  : Estimated mutual information between each feature and the target in
    nat units.

### Notes

1. The term “discrete features” is used instead of naming them
   “categorical”, because it describes the essence more accurately.
   For example, pixel intensities of an image are discrete features
   (but hardly categorical) and you will get better results if mark them
   as such. Also note, that treating a continuous variable as discrete and
   vice versa will usually give incorrect results, so be attentive about
   that.
2. True mutual information can’t be negative. If its estimate turns out
   to be negative, it is replaced by zero.

### References

### Examples

```pycon
>>> from sklearn.datasets import make_classification
>>> from sklearn.feature_selection import mutual_info_classif
>>> X, y = make_classification(
...     n_samples=100, n_features=10, n_informative=2, n_clusters_per_class=1,
...     shuffle=False, random_state=42
... )
>>> mutual_info_classif(X, y)
array([0.58..., 0.10..., 0.19..., 0.09... , 0.        ,
       0.     , 0.     , 0.     , 0.      , 0.        ])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example constructs a pipeline that does dimensionality reduction followed by prediction with a support vector classifier. It demonstrates the use of GridSearchCV and Pipeline to optimize over different classes of estimators in a single CV run -- unsupervised PCA and NMF dimensionality reductions are compared to univariate feature selection during the grid search.">  <div class="sphx-glr-thumbnail-title">Selecting dimensionality reduction with Pipeline and GridSearchCV</div>
</div>
* [Selecting dimensionality reduction with Pipeline and GridSearchCV](../../auto_examples/compose/plot_compare_reduction.md#sphx-glr-auto-examples-compose-plot-compare-reduction-py)

<!-- thumbnail-parent-div-close --></div>
