# inplace_swap_column

### sklearn.utils.sparsefuncs.inplace_swap_column(X, m, n)

Swap two columns of a CSC/CSR matrix in-place.

* **Parameters:**
  **X**
  : Matrix whose two columns are to be swapped. It should be of
    CSR or CSC format.

  **m**
  : Index of the column of X to be swapped.

  **n**
  : Index of the column of X to be swapped.

### Examples

```pycon
>>> from sklearn.utils import sparsefuncs
>>> from scipy import sparse
>>> import numpy as np
>>> indptr = np.array([0, 2, 3, 3, 3])
>>> indices = np.array([0, 2, 2])
>>> data = np.array([8, 2, 5])
>>> csr = sparse.csr_matrix((data, indices, indptr))
>>> csr.todense()
matrix([[8, 0, 2],
        [0, 0, 5],
        [0, 0, 0],
        [0, 0, 0]])
>>> sparsefuncs.inplace_swap_column(csr, 0, 1)
>>> csr.todense()
matrix([[0, 8, 2],
        [0, 0, 5],
        [0, 0, 0],
        [0, 0, 0]])
```

<!-- !! processed by numpydoc !! -->
