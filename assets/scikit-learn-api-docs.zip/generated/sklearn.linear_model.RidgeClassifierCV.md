# RidgeClassifierCV

### *class* sklearn.linear_model.RidgeClassifierCV(alphas=(0.1, 1.0, 10.0), \*, fit_intercept=True, scoring=None, cv=None, class_weight=None, store_cv_results=None, store_cv_values='deprecated')

Ridge classifier with built-in cross-validation.

See glossary entry for [cross-validation estimator](../../glossary.md#term-cross-validation-estimator).

By default, it performs Leave-One-Out Cross-Validation. Currently,
only the n_features > n_samples case is handled efficiently.

Read more in the [User Guide](../linear_model.md#ridge-regression).

* **Parameters:**
  **alphas**
  : Array of alpha values to try.
    Regularization strength; must be a positive float. Regularization
    improves the conditioning of the problem and reduces the variance of
    the estimates. Larger values specify stronger regularization.
    Alpha corresponds to `1 / (2C)` in other linear models such as
    [`LogisticRegression`](sklearn.linear_model.LogisticRegression.md#sklearn.linear_model.LogisticRegression) or
    [`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC).
    If using Leave-One-Out cross-validation, alphas must be strictly positive.

  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to false, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **scoring**
  : A string (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter)) or a scorer callable object /
    function with signature `scorer(estimator, X, y)`.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the efficient Leave-One-Out cross-validation
    - integer, to specify the number of folds.
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.

  **class_weight**
  : Weights associated with classes in the form `{class_label: weight}`.
    If not given, all classes are supposed to have weight one.
    <br/>
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`.

  **store_cv_results**
  : Flag indicating if the cross-validation results corresponding to
    each alpha should be stored in the `cv_results_` attribute (see
    below). This flag is only compatible with `cv=None` (i.e. using
    Leave-One-Out Cross-Validation).
    <br/>
    #### Versionchanged
    Changed in version 1.5: Parameter name changed from `store_cv_values` to `store_cv_results`.

  **store_cv_values**
  : Flag indicating if the cross-validation values corresponding to
    each alpha should be stored in the `cv_values_` attribute (see
    below). This flag is only compatible with `cv=None` (i.e. using
    Leave-One-Out Cross-Validation).
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `store_cv_values` is deprecated in version 1.5 in favor of
    `store_cv_results` and will be removed in version 1.7.
* **Attributes:**
  **cv_results_**
  : Cross-validation results for each alpha (only if `store_cv_results=True` and
    `cv=None`). After `fit()` has been called, this attribute will
    contain the mean squared errors if `scoring is None` otherwise it
    will contain standardized per point prediction values.
    <br/>
    #### Versionchanged
    Changed in version 1.5: `cv_values_` changed to `cv_results_`.

  **coef_**
  : Coefficient of the features in the decision function.
    <br/>
    `coef_` is of shape (1, n_features) when the given problem is binary.

  **intercept_**
  : Independent term in decision function. Set to 0.0 if
    `fit_intercept = False`.

  **alpha_**
  : Estimated regularization parameter.

  **best_score_**
  : Score of base estimator with best alpha.
    <br/>
    #### Versionadded
    Added in version 0.23.

  [`classes_`](#sklearn.linear_model.RidgeClassifierCV.classes_)
  : Classes labels.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`Ridge`](sklearn.linear_model.Ridge.md#sklearn.linear_model.Ridge)
: Ridge regression.

[`RidgeClassifier`](sklearn.linear_model.RidgeClassifier.md#sklearn.linear_model.RidgeClassifier)
: Ridge classifier.

[`RidgeCV`](sklearn.linear_model.RidgeCV.md#sklearn.linear_model.RidgeCV)
: Ridge regression with built-in cross validation.

### Notes

For multi-class classification, n_class classifiers are trained in
a one-versus-all approach. Concretely, this is implemented by taking
advantage of the multi-variate response support in Ridge.

### Examples

```pycon
>>> from sklearn.datasets import load_breast_cancer
>>> from sklearn.linear_model import RidgeClassifierCV
>>> X, y = load_breast_cancer(return_X_y=True)
>>> clf = RidgeClassifierCV(alphas=[1e-3, 1e-2, 1e-1, 1]).fit(X, y)
>>> clf.score(X, y)
0.9630...
```

<!-- !! processed by numpydoc !! -->

#### *property* classes_

Classes labels.

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Predict confidence scores for samples.

The confidence score for a sample is proportional to the signed
distance of that sample to the hyperplane.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the confidence scores.
* **Returns:**
  **scores**
  : Confidence scores per `(n_samples, n_classes)` combination. In the
    binary case, confidence score for `self.classes_[1]` where >0 means
    this class would be predicted.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, \*\*params)

Fit Ridge classifier with cv.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples
    and `n_features` is the number of features. When using GCV,
    will be cast to float64 if necessary.

  **y**
  : Target values. Will be cast to X’s dtype if necessary.

  **sample_weight**
  : Individual weights for each sample. If given a float, every sample
    will have the same weight.

  **\*\*params**
  : Parameters to be passed to the underlying scorer.
    <br/>
    #### Versionadded
    Added in version 1.5: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.5.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict class labels for samples in `X`.

* **Parameters:**
  **X**
  : The data matrix for which we want to predict the targets.
* **Returns:**
  **y_pred**
  : Vector or matrix containing the predictions. In binary and
    multiclass problems, this is a vector containing `n_samples`. In
    a multilabel problem, it returns a matrix of shape
    `(n_samples, n_outputs)`.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RidgeClassifierCV](#sklearn.linear_model.RidgeClassifierCV)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RidgeClassifierCV](#sklearn.linear_model.RidgeClassifierCV)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->
