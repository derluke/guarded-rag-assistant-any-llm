# kneighbors_graph

### sklearn.neighbors.kneighbors_graph(X, n_neighbors, \*, mode='connectivity', metric='minkowski', p=2, metric_params=None, include_self=False, n_jobs=None)

Compute the (weighted) graph of k-Neighbors for points in X.

Read more in the [User Guide](../neighbors.md#unsupervised-neighbors).

* **Parameters:**
  **X**
  : Sample data.

  **n_neighbors**
  : Number of neighbors for each sample.

  **mode**
  : Type of returned matrix: ‘connectivity’ will return the connectivity
    matrix with ones and zeros, and ‘distance’ will return the distances
    between neighbors according to the given metric.

  **metric**
  : Metric to use for distance computation. Default is “minkowski”, which
    results in the standard Euclidean distance when p = 2. See the
    documentation of [scipy.spatial.distance](https://docs.scipy.org/doc/scipy/reference/spatial.distance.html) and
    the metrics listed in
    [`distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics) for valid metric
    values.

  **p**
  : Power parameter for the Minkowski metric. When p = 1, this is equivalent
    to using manhattan_distance (l1), and euclidean_distance (l2) for p = 2.
    For arbitrary p, minkowski_distance (l_p) is used. This parameter is expected
    to be positive.

  **metric_params**
  : Additional keyword arguments for the metric function.

  **include_self**
  : Whether or not to mark each sample as the first nearest neighbor to
    itself. If ‘auto’, then True is used for mode=’connectivity’ and False
    for mode=’distance’.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Returns:**
  **A**
  : Graph where A[i, j] is assigned the weight of edge that
    connects i to j. The matrix is of CSR format.

#### SEE ALSO
[`radius_neighbors_graph`](sklearn.neighbors.radius_neighbors_graph.md#sklearn.neighbors.radius_neighbors_graph)
: Compute the (weighted) graph of Neighbors for points in X.

### Examples

```pycon
>>> X = [[0], [3], [1]]
>>> from sklearn.neighbors import kneighbors_graph
>>> A = kneighbors_graph(X, 2, mode='connectivity', include_self=True)
>>> A.toarray()
array([[1., 0., 1.],
       [0., 1., 1.],
       [1., 0., 1.]])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows the effect of imposing a connectivity graph to capture local structure in the data. The graph is simply the graph of 20 nearest neighbors.">  <div class="sphx-glr-thumbnail-title">Agglomerative clustering with and without structure</div>
</div>
* [Agglomerative clustering with and without structure](../../auto_examples/cluster/plot_agglomerative_clustering.md#sphx-glr-auto-examples-cluster-plot-agglomerative-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example builds a swiss roll dataset and runs hierarchical clustering on their position.">  <div class="sphx-glr-thumbnail-title">Hierarchical clustering: structured vs unstructured ward</div>
</div>
* [Hierarchical clustering: structured vs unstructured ward](../../auto_examples/cluster/plot_ward_structured_vs_unstructured.md#sphx-glr-auto-examples-cluster-plot-ward-structured-vs-unstructured-py)

<!-- thumbnail-parent-div-close --></div>
