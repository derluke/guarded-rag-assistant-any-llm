# reconstruct_from_patches_2d

### sklearn.feature_extraction.image.reconstruct_from_patches_2d(patches, image_size)

Reconstruct the image from all of its patches.

Patches are assumed to overlap and the image is constructed by filling in
the patches from left to right, top to bottom, averaging the overlapping
regions.

Read more in the [User Guide](../feature_extraction.md#image-feature-extraction).

* **Parameters:**
  **patches**
  : The complete set of patches. If the patches contain colour information,
    channels are indexed along the last dimension: RGB patches would
    have `n_channels=3`.

  **image_size**
  : The size of the image that will be reconstructed.
* **Returns:**
  **image**
  : The reconstructed image.

### Examples

```pycon
>>> from sklearn.datasets import load_sample_image
>>> from sklearn.feature_extraction import image
>>> one_image = load_sample_image("china.jpg")
>>> print('Image shape: {}'.format(one_image.shape))
Image shape: (427, 640, 3)
>>> image_patches = image.extract_patches_2d(image=one_image, patch_size=(10, 10))
>>> print('Patches shape: {}'.format(image_patches.shape))
Patches shape: (263758, 10, 10, 3)
>>> image_reconstructed = image.reconstruct_from_patches_2d(
...     patches=image_patches,
...     image_size=one_image.shape
... )
>>> print(f"Reconstructed shape: {image_reconstructed.shape}")
Reconstructed shape: (427, 640, 3)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An example comparing the effect of reconstructing noisy fragments of a raccoon face image using firstly online DictionaryLearning and various transform methods.">  <div class="sphx-glr-thumbnail-title">Image denoising using dictionary learning</div>
</div>
* [Image denoising using dictionary learning](../../auto_examples/decomposition/plot_image_denoising.md#sphx-glr-auto-examples-decomposition-plot-image-denoising-py)

<!-- thumbnail-parent-div-close --></div>
