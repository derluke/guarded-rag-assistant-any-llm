# NearestCentroid

### *class* sklearn.neighbors.NearestCentroid(metric='euclidean', \*, shrink_threshold=None, priors='uniform')

Nearest centroid classifier.

Each class is represented by its centroid, with test samples classified to
the class with the nearest centroid.

Read more in the [User Guide](../neighbors.md#nearest-centroid-classifier).

* **Parameters:**
  **metric**
  : Metric to use for distance computation.
    <br/>
    If `metric="euclidean"`, the centroid for the samples corresponding to each
    class is the arithmetic mean, which minimizes the sum of squared L1 distances.
    If `metric="manhattan"`, the centroid is the feature-wise median, which
    minimizes the sum of L1 distances.
    <br/>
    #### Versionchanged
    Changed in version 1.5: All metrics but `"euclidean"` and `"manhattan"` were deprecated and
    now raise an error.
    <br/>
    #### Versionchanged
    Changed in version 0.19: `metric='precomputed'` was deprecated and now raises an error

  **shrink_threshold**
  : Threshold for shrinking centroids to remove features.

  **priors**
  : The class prior probabilities. By default, the class proportions are
    inferred from the training data.
    <br/>
    #### Versionadded
    Added in version 1.6.
* **Attributes:**
  **centroids_**
  : Centroid of each class.

  **classes_**
  : The unique classes labels.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **deviations_**
  : Deviations (or shrinkages) of the centroids of each class from the
    overall centroid. Equal to eq. (18.4) if `shrink_threshold=None`,
    else (18.5) p. 653 of [2]. Can be used to identify features used
    for classification.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **within_class_std_dev_**
  : Pooled or within-class standard deviation of input data.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **class_prior_**
  : The class prior probabilities.
    <br/>
    #### Versionadded
    Added in version 1.6.

#### SEE ALSO
[`KNeighborsClassifier`](sklearn.neighbors.KNeighborsClassifier.md#sklearn.neighbors.KNeighborsClassifier)
: Nearest neighbors classifier.

### Notes

When used for text classification with tf-idf vectors, this classifier is
also known as the Rocchio classifier.

### References

[1] Tibshirani, R., Hastie, T., Narasimhan, B., & Chu, G. (2002). Diagnosis of
multiple cancer types by shrunken centroids of gene expression. Proceedings
of the National Academy of Sciences of the United States of America,
99(10), 6567-6572. The National Academy of Sciences.

[2] Hastie, T., Tibshirani, R., Friedman, J. (2009). The Elements of Statistical
Learning Data Mining, Inference, and Prediction. 2nd Edition. New York, Springer.

### Examples

```pycon
>>> from sklearn.neighbors import NearestCentroid
>>> import numpy as np
>>> X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
>>> y = np.array([1, 1, 1, 2, 2, 2])
>>> clf = NearestCentroid()
>>> clf.fit(X, y)
NearestCentroid()
>>> print(clf.predict([[-0.8, -1]]))
[1]
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Apply decision function to an array of samples.

* **Parameters:**
  **X**
  : Array of samples (test vectors).
* **Returns:**
  **y_scores**
  : Decision function values related to each class, per sample.
    In the two-class case, the shape is `(n_samples,)`, giving the
    log likelihood ratio of the positive class.

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit the NearestCentroid model according to the given training data.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the number of features.
    Note that centroid shrinking cannot be used with sparse matrices.

  **y**
  : Target values.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Perform classification on an array of test vectors `X`.

The predicted class `C` for each sample in `X` is returned.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  **y_pred**
  : The predicted classes.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Estimate log class probabilities.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  **y_log_proba**
  : Estimated log probabilities.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Estimate class probabilities.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  **y_proba**
  : Probability estimate of the sample for each class in the
    model, where classes are ordered as they are in `self.classes_`.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [NearestCentroid](#sklearn.neighbors.NearestCentroid)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Sample usage of Nearest Centroid classification. It will plot the decision boundaries for each class.">  <div class="sphx-glr-thumbnail-title">Nearest Centroid Classification</div>
</div>
* [Nearest Centroid Classification](../../auto_examples/neighbors/plot_nearest_centroid.md#sphx-glr-auto-examples-neighbors-plot-nearest-centroid-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<!-- thumbnail-parent-div-close --></div>
