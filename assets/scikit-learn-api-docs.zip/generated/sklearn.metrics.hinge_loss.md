# hinge_loss

### sklearn.metrics.hinge_loss(y_true, pred_decision, \*, labels=None, sample_weight=None)

Average hinge loss (non-regularized).

In binary class case, assuming labels in y_true are encoded with +1 and -1,
when a prediction mistake is made, `margin = y_true * pred_decision` is
always negative (since the signs disagree), implying `1 - margin` is
always greater than 1.  The cumulated hinge loss is therefore an upper
bound of the number of mistakes made by the classifier.

In multiclass case, the function expects that either all the labels are
included in y_true or an optional labels argument is provided which
contains all the labels. The multilabel margin is calculated according
to Crammer-Singer’s method. As in the binary case, the cumulated hinge loss
is an upper bound of the number of mistakes made by the classifier.

Read more in the [User Guide](../model_evaluation.md#hinge-loss).

* **Parameters:**
  **y_true**
  : True target, consisting of integers of two values. The positive label
    must be greater than the negative label.

  **pred_decision**
  : Predicted decisions, as output by decision_function (floats).

  **labels**
  : Contains all the labels for the problem. Used in multiclass hinge loss.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **loss**
  : Average hinge loss.

### References

### Examples

```pycon
>>> from sklearn import svm
>>> from sklearn.metrics import hinge_loss
>>> X = [[0], [1]]
>>> y = [-1, 1]
>>> est = svm.LinearSVC(random_state=0)
>>> est.fit(X, y)
LinearSVC(random_state=0)
>>> pred_decision = est.decision_function([[-2], [3], [0.5]])
>>> pred_decision
array([-2.18...,  2.36...,  0.09...])
>>> hinge_loss([-1, 1, 1], pred_decision)
np.float64(0.30...)
```

In the multiclass case:

```pycon
>>> import numpy as np
>>> X = np.array([[0], [1], [2], [3]])
>>> Y = np.array([0, 1, 2, 3])
>>> labels = np.array([0, 1, 2, 3])
>>> est = svm.LinearSVC()
>>> est.fit(X, Y)
LinearSVC()
>>> pred_decision = est.decision_function([[-1], [2], [3]])
>>> y_true = [0, 2, 3]
>>> hinge_loss(y_true, pred_decision, labels=labels)
np.float64(0.56...)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="SVCs aim to find a hyperplane that effectively separates the classes in their training data by maximizing the margin between the outermost data points of each class. This is achieved by finding the best weight vector w that defines the decision boundary hyperplane and minimizes the sum of hinge losses for misclassified samples, as measured by the hinge_loss function. By default, regularization is applied with the parameter C=1, which allows for a certain degree of misclassification tolerance.">  <div class="sphx-glr-thumbnail-title">Plot classification boundaries with different SVM Kernels</div>
</div>
* [Plot classification boundaries with different SVM Kernels](../../auto_examples/svm/plot_svm_kernels.md#sphx-glr-auto-examples-svm-plot-svm-kernels-py)

<!-- thumbnail-parent-div-close --></div>
