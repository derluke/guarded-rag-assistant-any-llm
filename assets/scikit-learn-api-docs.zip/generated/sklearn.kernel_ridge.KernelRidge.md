# KernelRidge

### *class* sklearn.kernel_ridge.KernelRidge(alpha=1, \*, kernel='linear', gamma=None, degree=3, coef0=1, kernel_params=None)

Kernel ridge regression.

Kernel ridge regression (KRR) combines ridge regression (linear least
squares with l2-norm regularization) with the kernel trick. It thus
learns a linear function in the space induced by the respective kernel and
the data. For non-linear kernels, this corresponds to a non-linear
function in the original space.

The form of the model learned by KRR is identical to support vector
regression (SVR). However, different loss functions are used: KRR uses
squared error loss while support vector regression uses epsilon-insensitive
loss, both combined with l2 regularization. In contrast to SVR, fitting a
KRR model can be done in closed-form and is typically faster for
medium-sized datasets. On the other hand, the learned model is non-sparse
and thus slower than SVR, which learns a sparse model for epsilon > 0, at
prediction-time.

This estimator has built-in support for multi-variate regression
(i.e., when y is a 2d-array of shape [n_samples, n_targets]).

Read more in the [User Guide](../kernel_ridge.md#kernel-ridge).

* **Parameters:**
  **alpha**
  : Regularization strength; must be a positive float. Regularization
    improves the conditioning of the problem and reduces the variance of
    the estimates. Larger values specify stronger regularization.
    Alpha corresponds to `1 / (2C)` in other linear models such as
    [`LogisticRegression`](sklearn.linear_model.LogisticRegression.md#sklearn.linear_model.LogisticRegression) or
    [`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC). If an array is passed, penalties are
    assumed to be specific to the targets. Hence they must correspond in
    number. See [Ridge regression and classification](../linear_model.md#ridge-regression) for formula.

  **kernel**
  : Kernel mapping used internally. This parameter is directly passed to
    [`pairwise_kernels`](sklearn.metrics.pairwise.pairwise_kernels.md#sklearn.metrics.pairwise.pairwise_kernels).
    If `kernel` is a string, it must be one of the metrics
    in `pairwise.PAIRWISE_KERNEL_FUNCTIONS` or “precomputed”.
    If `kernel` is “precomputed”, X is assumed to be a kernel matrix.
    Alternatively, if `kernel` is a callable function, it is called on
    each pair of instances (rows) and the resulting value recorded. The
    callable should take two rows from X as input and return the
    corresponding kernel value as a single number. This means that
    callables from [`sklearn.metrics.pairwise`](../../api/sklearn.metrics.md#module-sklearn.metrics.pairwise) are not allowed, as
    they operate on matrices, not single samples. Use the string
    identifying the kernel instead.

  **gamma**
  : Gamma parameter for the RBF, laplacian, polynomial, exponential chi2
    and sigmoid kernels. Interpretation of the default value is left to
    the kernel; see the documentation for sklearn.metrics.pairwise.
    Ignored by other kernels.

  **degree**
  : Degree of the polynomial kernel. Ignored by other kernels.

  **coef0**
  : Zero coefficient for polynomial and sigmoid kernels.
    Ignored by other kernels.

  **kernel_params**
  : Additional parameters (keyword arguments) for kernel function passed
    as callable object.
* **Attributes:**
  **dual_coef_**
  : Representation of weight vector(s) in kernel space

  **X_fit_**
  : Training data, which is also required for prediction. If
    kernel == “precomputed” this is instead the precomputed
    training matrix, of shape (n_samples, n_samples).

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`sklearn.gaussian_process.GaussianProcessRegressor`](sklearn.gaussian_process.GaussianProcessRegressor.md#sklearn.gaussian_process.GaussianProcessRegressor)
: Gaussian Process regressor providing automatic kernel hyperparameters tuning and predictions uncertainty.

[`sklearn.linear_model.Ridge`](sklearn.linear_model.Ridge.md#sklearn.linear_model.Ridge)
: Linear ridge regression.

[`sklearn.linear_model.RidgeCV`](sklearn.linear_model.RidgeCV.md#sklearn.linear_model.RidgeCV)
: Ridge regression with built-in cross-validation.

[`sklearn.svm.SVR`](sklearn.svm.SVR.md#sklearn.svm.SVR)
: Support Vector Regression accepting a large variety of kernels.

### References

* Kevin P. Murphy
  “Machine Learning: A Probabilistic Perspective”, The MIT Press
  chapter 14.4.3, pp. 492-493

### Examples

```pycon
>>> from sklearn.kernel_ridge import KernelRidge
>>> import numpy as np
>>> n_samples, n_features = 10, 5
>>> rng = np.random.RandomState(0)
>>> y = rng.randn(n_samples)
>>> X = rng.randn(n_samples, n_features)
>>> krr = KernelRidge(alpha=1.0)
>>> krr.fit(X, y)
KernelRidge(alpha=1.0)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit Kernel Ridge regression model.

* **Parameters:**
  **X**
  : Training data. If kernel == “precomputed” this is instead
    a precomputed kernel matrix, of shape (n_samples, n_samples).

  **y**
  : Target values.

  **sample_weight**
  : Individual weights for each sample, ignored if None is passed.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the kernel ridge model.

* **Parameters:**
  **X**
  : Samples. If kernel == “precomputed” this is instead a
    precomputed kernel matrix, shape = [n_samples,
    n_samples_fitted], where n_samples_fitted is the number of
    samples used in the fitting for this estimator.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [KernelRidge](#sklearn.kernel_ridge.KernelRidge)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [KernelRidge](#sklearn.kernel_ridge.KernelRidge)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows the difference between the Principal Components Analysis (~sklearn.decomposition.PCA) and its kernelized version (~sklearn.decomposition.KernelPCA).">  <div class="sphx-glr-thumbnail-title">Kernel PCA</div>
</div>
* [Kernel PCA](../../auto_examples/decomposition/plot_kernel_pca.md#sphx-glr-auto-examples-decomposition-plot-kernel-pca-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates differences between a kernel ridge regression and a Gaussian process regression.">  <div class="sphx-glr-thumbnail-title">Comparison of kernel ridge and Gaussian process regression</div>
</div>
* [Comparison of kernel ridge and Gaussian process regression](../../auto_examples/gaussian_process/plot_compare_gpr_krr.md#sphx-glr-auto-examples-gaussian-process-plot-compare-gpr-krr-py)

<div class="sphx-glr-thumbcontainer" tooltip="Both kernel ridge regression (KRR) and SVR learn a non-linear function by employing the kernel trick, i.e., they learn a linear function in the space induced by the respective kernel which corresponds to a non-linear function in the original space. They differ in the loss functions (ridge versus epsilon-insensitive loss). In contrast to SVR, fitting a KRR can be done in closed-form and is typically faster for medium-sized datasets. On the other hand, the learned model is non-sparse and thus slower than SVR at prediction-time.">  <div class="sphx-glr-thumbnail-title">Comparison of kernel ridge regression and SVR</div>
</div>
* [Comparison of kernel ridge regression and SVR](../../auto_examples/miscellaneous/plot_kernel_ridge_regression.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-ridge-regression-py)

<!-- thumbnail-parent-div-close --></div>
