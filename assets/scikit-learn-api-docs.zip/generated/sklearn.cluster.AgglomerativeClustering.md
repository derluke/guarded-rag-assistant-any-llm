# AgglomerativeClustering

### *class* sklearn.cluster.AgglomerativeClustering(n_clusters=2, \*, metric='euclidean', memory=None, connectivity=None, compute_full_tree='auto', linkage='ward', distance_threshold=None, compute_distances=False)

Agglomerative Clustering.

Recursively merges pair of clusters of sample data; uses linkage distance.

Read more in the [User Guide](../clustering.md#hierarchical-clustering).

* **Parameters:**
  **n_clusters**
  : The number of clusters to find. It must be `None` if
    `distance_threshold` is not `None`.

  **metric**
  : Metric used to compute the linkage. Can be “euclidean”, “l1”, “l2”,
    “manhattan”, “cosine”, or “precomputed”. If linkage is “ward”, only
    “euclidean” is accepted. If “precomputed”, a distance matrix is needed
    as input for the fit method. If connectivity is None, linkage is
    “single” and affinity is not “precomputed” any valid pairwise distance
    metric can be assigned.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **memory**
  : Used to cache the output of the computation of the tree.
    By default, no caching is done. If a string is given, it is the
    path to the caching directory.

  **connectivity**
  : Connectivity matrix. Defines for each sample the neighboring
    samples following a given structure of the data.
    This can be a connectivity matrix itself or a callable that transforms
    the data into a connectivity matrix, such as derived from
    `kneighbors_graph`. Default is `None`, i.e, the
    hierarchical clustering algorithm is unstructured.
    <br/>
    For an example of connectivity matrix using
    [`kneighbors_graph`](sklearn.neighbors.kneighbors_graph.md#sklearn.neighbors.kneighbors_graph), see
    [Agglomerative clustering with and without structure](../../auto_examples/cluster/plot_agglomerative_clustering.md#sphx-glr-auto-examples-cluster-plot-agglomerative-clustering-py).

  **compute_full_tree**
  : Stop early the construction of the tree at `n_clusters`. This is
    useful to decrease computation time if the number of clusters is not
    small compared to the number of samples. This option is useful only
    when specifying a connectivity matrix. Note also that when varying the
    number of clusters and using caching, it may be advantageous to compute
    the full tree. It must be `True` if `distance_threshold` is not
    `None`. By default `compute_full_tree` is “auto”, which is equivalent
    to `True` when `distance_threshold` is not `None` or that `n_clusters`
    is inferior to the maximum between 100 or `0.02 * n_samples`.
    Otherwise, “auto” is equivalent to `False`.

  **linkage**
  : Which linkage criterion to use. The linkage criterion determines which
    distance to use between sets of observation. The algorithm will merge
    the pairs of cluster that minimize this criterion.
    - ‘ward’ minimizes the variance of the clusters being merged.
    - ‘average’ uses the average of the distances of each observation of
      the two sets.
    - ‘complete’ or ‘maximum’ linkage uses the maximum distances between
      all observations of the two sets.
    - ‘single’ uses the minimum of the distances between all observations
      of the two sets.
    <br/>
    #### Versionadded
    Added in version 0.20: Added the ‘single’ option
    <br/>
    For examples comparing different `linkage` criteria, see
    [Comparing different hierarchical linkage methods on toy datasets](../../auto_examples/cluster/plot_linkage_comparison.md#sphx-glr-auto-examples-cluster-plot-linkage-comparison-py).

  **distance_threshold**
  : The linkage distance threshold at or above which clusters will not be
    merged. If not `None`, `n_clusters` must be `None` and
    `compute_full_tree` must be `True`.
    <br/>
    #### Versionadded
    Added in version 0.21.

  **compute_distances**
  : Computes distances between clusters even if `distance_threshold` is not
    used. This can be used to make dendrogram visualization, but introduces
    a computational and memory overhead.
    <br/>
    #### Versionadded
    Added in version 0.24.
    <br/>
    For an example of dendrogram visualization, see
    [Plot Hierarchical Clustering Dendrogram](../../auto_examples/cluster/plot_agglomerative_dendrogram.md#sphx-glr-auto-examples-cluster-plot-agglomerative-dendrogram-py).
* **Attributes:**
  **n_clusters_**
  : The number of clusters found by the algorithm. If
    `distance_threshold=None`, it will be equal to the given
    `n_clusters`.

  **labels_**
  : Cluster labels for each point.

  **n_leaves_**
  : Number of leaves in the hierarchical tree.

  **n_connected_components_**
  : The estimated number of connected components in the graph.
    <br/>
    #### Versionadded
    Added in version 0.21: `n_connected_components_` was added to replace `n_components_`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **children_**
  : The children of each non-leaf node. Values less than `n_samples`
    correspond to leaves of the tree which are the original samples.
    A node `i` greater than or equal to `n_samples` is a non-leaf
    node and has children `children_[i - n_samples]`. Alternatively
    at the i-th iteration, children[i][0] and children[i][1]
    are merged to form node `n_samples + i`.

  **distances_**
  : Distances between nodes in the corresponding place in `children_`.
    Only computed if `distance_threshold` is used or `compute_distances`
    is set to `True`.

#### SEE ALSO
[`FeatureAgglomeration`](sklearn.cluster.FeatureAgglomeration.md#sklearn.cluster.FeatureAgglomeration)
: Agglomerative clustering but for features instead of samples.

[`ward_tree`](sklearn.cluster.ward_tree.md#sklearn.cluster.ward_tree)
: Hierarchical clustering with ward linkage.

### Examples

```pycon
>>> from sklearn.cluster import AgglomerativeClustering
>>> import numpy as np
>>> X = np.array([[1, 2], [1, 4], [1, 0],
...               [4, 2], [4, 4], [4, 0]])
>>> clustering = AgglomerativeClustering().fit(X)
>>> clustering
AgglomerativeClustering()
>>> clustering.labels_
array([1, 1, 1, 0, 0, 0])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the hierarchical clustering from features, or distance matrix.

* **Parameters:**
  **X**
  : Training instances to cluster, or distances between instances if
    `metric='precomputed'`.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : Returns the fitted instance.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None)

Fit and return the result of each sample’s clustering assignment.

In addition to fitting, this method also return the result of the
clustering assignment for each sample in the training set.

* **Parameters:**
  **X**
  : Training instances to cluster, or distances between instances if
    `affinity='precomputed'`.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **labels**
  : Cluster labels.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Compute the segmentation of a 2D image with Ward hierarchical clustering. The clustering is spatially constrained in order for each segmented region to be in one piece.">  <div class="sphx-glr-thumbnail-title">A demo of structured Ward hierarchical clustering on an image of coins</div>
</div>
* [A demo of structured Ward hierarchical clustering on an image of coins](../../auto_examples/cluster/plot_coin_ward_segmentation.md#sphx-glr-auto-examples-cluster-plot-coin-ward-segmentation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows the effect of imposing a connectivity graph to capture local structure in the data. The graph is simply the graph of 20 nearest neighbors.">  <div class="sphx-glr-thumbnail-title">Agglomerative clustering with and without structure</div>
</div>
* [Agglomerative clustering with and without structure](../../auto_examples/cluster/plot_agglomerative_clustering.md#sphx-glr-auto-examples-cluster-plot-agglomerative-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="Demonstrates the effect of different metrics on the hierarchical clustering.">  <div class="sphx-glr-thumbnail-title">Agglomerative clustering with different metrics</div>
</div>
* [Agglomerative clustering with different metrics](../../auto_examples/cluster/plot_agglomerative_clustering_metrics.md#sphx-glr-auto-examples-cluster-plot-agglomerative-clustering-metrics-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different linkage methods for hierarchical clustering on datasets that are &quot;interesting&quot; but still in 2D.">  <div class="sphx-glr-thumbnail-title">Comparing different hierarchical linkage methods on toy datasets</div>
</div>
* [Comparing different hierarchical linkage methods on toy datasets](../../auto_examples/cluster/plot_linkage_comparison.md#sphx-glr-auto-examples-cluster-plot-linkage-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example builds a swiss roll dataset and runs hierarchical clustering on their position.">  <div class="sphx-glr-thumbnail-title">Hierarchical clustering: structured vs unstructured ward</div>
</div>
* [Hierarchical clustering: structured vs unstructured ward](../../auto_examples/cluster/plot_ward_structured_vs_unstructured.md#sphx-glr-auto-examples-cluster-plot-ward-structured-vs-unstructured-py)

<div class="sphx-glr-thumbcontainer" tooltip="Clustering can be expensive, especially when our dataset contains millions of datapoints. Many clustering algorithms are not inductive and so cannot be directly applied to new data samples without recomputing the clustering, which may be intractable. Instead, we can use clustering to then learn an inductive model with a classifier, which has several benefits:">  <div class="sphx-glr-thumbnail-title">Inductive Clustering</div>
</div>
* [Inductive Clustering](../../auto_examples/cluster/plot_inductive_clustering.md#sphx-glr-auto-examples-cluster-plot-inductive-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot Hierarchical Clustering Dendrogram">  <div class="sphx-glr-thumbnail-title">Plot Hierarchical Clustering Dendrogram</div>
</div>
* [Plot Hierarchical Clustering Dendrogram](../../auto_examples/cluster/plot_agglomerative_dendrogram.md#sphx-glr-auto-examples-cluster-plot-agglomerative-dendrogram-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of various linkage option for agglomerative clustering on a 2D embedding of the digits dataset.">  <div class="sphx-glr-thumbnail-title">Various Agglomerative Clustering on a 2D embedding of digits</div>
</div>
* [Various Agglomerative Clustering on a 2D embedding of digits](../../auto_examples/cluster/plot_digits_linkage.md#sphx-glr-auto-examples-cluster-plot-digits-linkage-py)

<!-- thumbnail-parent-div-close --></div>
