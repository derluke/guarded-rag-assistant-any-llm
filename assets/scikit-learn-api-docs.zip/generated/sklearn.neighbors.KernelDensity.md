# KernelDensity

### *class* sklearn.neighbors.KernelDensity(\*, bandwidth=1.0, algorithm='auto', kernel='gaussian', metric='euclidean', atol=0, rtol=0, breadth_first=True, leaf_size=40, metric_params=None)

Kernel Density Estimation.

Read more in the [User Guide](../density.md#kernel-density).

* **Parameters:**
  **bandwidth**
  : The bandwidth of the kernel. If bandwidth is a float, it defines the
    bandwidth of the kernel. If bandwidth is a string, one of the estimation
    methods is implemented.

  **algorithm**
  : The tree algorithm to use.

  **kernel**
  : The kernel to use.

  **metric**
  : Metric to use for distance computation. See the
    documentation of [scipy.spatial.distance](https://docs.scipy.org/doc/scipy/reference/spatial.distance.html) and
    the metrics listed in
    [`distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics) for valid metric
    values.
    <br/>
    Not all metrics are valid with all algorithms: refer to the
    documentation of [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree) and [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree). Note that the
    normalization of the density output is correct only for the Euclidean
    distance metric.

  **atol**
  : The desired absolute tolerance of the result.  A larger tolerance will
    generally lead to faster execution.

  **rtol**
  : The desired relative tolerance of the result.  A larger tolerance will
    generally lead to faster execution.

  **breadth_first**
  : If true (default), use a breadth-first approach to the problem.
    Otherwise use a depth-first approach.

  **leaf_size**
  : Specify the leaf size of the underlying tree.  See [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree)
    or [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree) for details.

  **metric_params**
  : Additional parameters to be passed to the tree for use with the
    metric.  For more information, see the documentation of
    [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree) or [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree).
* **Attributes:**
  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **tree_**
  : The tree algorithm for fast generalized N-point problems.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.

  **bandwidth_**
  : Value of the bandwidth, given directly by the bandwidth parameter or
    estimated using the ‘scott’ or ‘silverman’ method.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`sklearn.neighbors.KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree)
: K-dimensional tree for fast generalized N-point problems.

[`sklearn.neighbors.BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree)
: Ball tree for fast generalized N-point problems.

### Examples

Compute a gaussian kernel density estimate with a fixed bandwidth.

```pycon
>>> from sklearn.neighbors import KernelDensity
>>> import numpy as np
>>> rng = np.random.RandomState(42)
>>> X = rng.random_sample((100, 3))
>>> kde = KernelDensity(kernel='gaussian', bandwidth=0.5).fit(X)
>>> log_density = kde.score_samples(X[:3])
>>> log_density
array([-1.52955942, -1.51462041, -1.60244657])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Fit the Kernel Density model on the data.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points.  Each row
    corresponds to a single data point.

  **y**
  : Ignored. This parameter exists only for compatibility with
    [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline).

  **sample_weight**
  : List of sample weights attached to the data X.
    <br/>
    #### Versionadded
    Added in version 0.20.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### sample(n_samples=1, random_state=None)

Generate random samples from the model.

Currently, this is implemented only for gaussian and tophat kernels.

* **Parameters:**
  **n_samples**
  : Number of samples to generate.

  **random_state**
  : Determines random number generation used to generate
    random samples. Pass an int for reproducible results
    across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : List of samples.

<!-- !! processed by numpydoc !! -->

#### score(X, y=None)

Compute the total log-likelihood under the model.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points.  Each row
    corresponds to a single data point.

  **y**
  : Ignored. This parameter exists only for compatibility with
    [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline).
* **Returns:**
  **logprob**
  : Total log-likelihood of the data in X. This is normalized to be a
    probability density, so the value will be low for high-dimensional
    data.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Compute the log-likelihood of each sample under the model.

* **Parameters:**
  **X**
  : An array of points to query.  Last dimension should match dimension
    of training data (n_features).
* **Returns:**
  **density**
  : Log-likelihood of each sample in `X`. These are normalized to be
    probability densities, so values will be low for high-dimensional
    data.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [KernelDensity](#sklearn.neighbors.KernelDensity)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example does not perform any learning over the data (see sphx_glr_auto_examples_applications_plot_species_distribution_modeling.py for an example of classification based on the attributes in this dataset).  It simply shows the kernel density estimate of observed data points in geospatial coordinates.">  <div class="sphx-glr-thumbnail-title">Kernel Density Estimate of Species Distributions</div>
</div>
* [Kernel Density Estimate of Species Distributions](../../auto_examples/neighbors/plot_species_kde.md#sphx-glr-auto-examples-neighbors-plot-species-kde-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how kernel density estimation (KDE), a powerful non-parametric density estimation technique, can be used to learn a generative model for a dataset.  With this generative model in place, new samples can be drawn.  These new samples reflect the underlying model of the data.">  <div class="sphx-glr-thumbnail-title">Kernel Density Estimation</div>
</div>
* [Kernel Density Estimation](../../auto_examples/neighbors/plot_digits_kde_sampling.md#sphx-glr-auto-examples-neighbors-plot-digits-kde-sampling-py)

<div class="sphx-glr-thumbcontainer" tooltip="The first plot shows one of the problems with using histograms to visualize the density of points in 1D. Intuitively, a histogram can be thought of as a scheme in which a unit &quot;block&quot; is stacked above each point on a regular grid. As the top two panels show, however, the choice of gridding for these blocks can lead to wildly divergent ideas about the underlying shape of the density distribution.  If we instead center each block on the point it represents, we get the estimate shown in the bottom left panel.  This is a kernel density estimation with a &quot;top hat&quot; kernel.  This idea can be generalized to other kernel shapes: the bottom-right panel of the first figure shows a Gaussian kernel density estimate over the same distribution.">  <div class="sphx-glr-thumbnail-title">Simple 1D Kernel Density Estimation</div>
</div>
* [Simple 1D Kernel Density Estimation](../../auto_examples/neighbors/plot_kde_1d.md#sphx-glr-auto-examples-neighbors-plot-kde-1d-py)

<!-- thumbnail-parent-div-close --></div>
