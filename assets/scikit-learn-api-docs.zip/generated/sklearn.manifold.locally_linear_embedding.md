# locally_linear_embedding

### sklearn.manifold.locally_linear_embedding(X, \*, n_neighbors, n_components, reg=0.001, eigen_solver='auto', tol=1e-06, max_iter=100, method='standard', hessian_tol=0.0001, modified_tol=1e-12, random_state=None, n_jobs=None)

Perform a Locally Linear Embedding analysis on the data.

Read more in the [User Guide](../manifold.md#locally-linear-embedding).

* **Parameters:**
  **X**
  : Sample data, shape = (n_samples, n_features), in the form of a
    numpy array or a NearestNeighbors object.

  **n_neighbors**
  : Number of neighbors to consider for each point.

  **n_components**
  : Number of coordinates for the manifold.

  **reg**
  : Regularization constant, multiplies the trace of the local covariance
    matrix of the distances.

  **eigen_solver**
  : auto : algorithm will attempt to choose the best method for input data
    <br/>
    arpack
    : For this method, M may be a dense matrix, sparse matrix,
      or general linear operator.
      Warning: ARPACK can be unstable for some problems.  It is
      best to try several random seeds in order to check results.
    <br/>
    dense
    : decomposition.  For this method, M must be an array
      or matrix type.  This method should be avoided for
      large problems.

  **tol**
  : Tolerance for ‘arpack’ method
    Not used if eigen_solver==’dense’.

  **max_iter**
  : Maximum number of iterations for the arpack solver.

  **method**
  : standard
    : see reference [[1]](#rb2a5641379f7-1)
    <br/>
    hessian
    : n_neighbors > n_components \* (1 + (n_components + 1) / 2.
      see reference [[2]](#rb2a5641379f7-2)
    <br/>
    modified
    : see reference [[3]](#rb2a5641379f7-3)
    <br/>
    ltsa
    : see reference [[4]](#rb2a5641379f7-4)

  **hessian_tol**
  : Tolerance for Hessian eigenmapping method.
    Only used if method == ‘hessian’.

  **modified_tol**
  : Tolerance for modified LLE method.
    Only used if method == ‘modified’.

  **random_state**
  : Determines the random number generator when `solver` == ‘arpack’.
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Returns:**
  **Y**
  : Embedding vectors.

  **squared_error**
  : Reconstruction error for the embedding vectors. Equivalent to
    `norm(Y - W Y, 'fro')**2`, where W are the reconstruction weights.

### References

### Examples

```pycon
>>> from sklearn.datasets import load_digits
>>> from sklearn.manifold import locally_linear_embedding
>>> X, _ = load_digits(return_X_y=True)
>>> X.shape
(1797, 64)
>>> embedding, _ = locally_linear_embedding(X[:100],n_neighbors=5, n_components=2)
>>> embedding.shape
(100, 2)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Swiss Roll And Swiss-Hole Reduction">  <div class="sphx-glr-thumbnail-title">Swiss Roll And Swiss-Hole Reduction</div>
</div>
* [Swiss Roll And Swiss-Hole Reduction](../../auto_examples/manifold/plot_swissroll.md#sphx-glr-auto-examples-manifold-plot-swissroll-py)

<!-- thumbnail-parent-div-close --></div>
