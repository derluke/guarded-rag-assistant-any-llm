# chi2

### sklearn.feature_selection.chi2(X, y)

Compute chi-squared stats between each non-negative feature and class.

This score can be used to select the `n_features` features with the
highest values for the test chi-squared statistic from X, which must
contain only **non-negative integer feature values** such as booleans or frequencies
(e.g., term counts in document classification), relative to the classes.

If some of your features are continuous, you need to bin them, for
example by using [`KBinsDiscretizer`](sklearn.preprocessing.KBinsDiscretizer.md#sklearn.preprocessing.KBinsDiscretizer).

Recall that the chi-square test measures dependence between stochastic
variables, so using this function “weeds out” the features that are the
most likely to be independent of class and therefore irrelevant for
classification.

Read more in the [User Guide](../feature_selection.md#univariate-feature-selection).

* **Parameters:**
  **X**
  : Sample vectors.

  **y**
  : Target vector (class labels).
* **Returns:**
  **chi2**
  : Chi2 statistics for each feature.

  **p_values**
  : P-values for each feature.

#### SEE ALSO
[`f_classif`](sklearn.feature_selection.f_classif.md#sklearn.feature_selection.f_classif)
: ANOVA F-value between label/feature for classification tasks.

[`f_regression`](sklearn.feature_selection.f_regression.md#sklearn.feature_selection.f_regression)
: F-value between label/feature for regression tasks.

### Notes

Complexity of this algorithm is O(n_classes \* n_features).

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.feature_selection import chi2
>>> X = np.array([[1, 1, 3],
...               [0, 1, 5],
...               [5, 4, 1],
...               [6, 6, 2],
...               [1, 4, 0],
...               [0, 0, 0]])
>>> y = np.array([1, 1, 0, 0, 2, 2])
>>> chi2_stats, p_values = chi2(X, y)
>>> chi2_stats
array([15.3...,  6.5       ,  8.9...])
>>> p_values
array([0.0004..., 0.0387..., 0.0116... ])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to apply different preprocessing and feature extraction pipelines to different subsets of features, using ColumnTransformer. This is particularly handy for the case of datasets that contain heterogeneous data types, since we may want to scale the numeric features and one-hot encode the categorical ones.">  <div class="sphx-glr-thumbnail-title">Column Transformer with Mixed Types</div>
</div>
* [Column Transformer with Mixed Types](../../auto_examples/compose/plot_column_transformer_mixed_types.md#sphx-glr-auto-examples-compose-plot-column-transformer-mixed-types-py)

<!-- thumbnail-parent-div-close --></div>
