# TfidfVectorizer

### *class* sklearn.feature_extraction.text.TfidfVectorizer(\*, input='content', encoding='utf-8', decode_error='strict', strip_accents=None, lowercase=True, preprocessor=None, tokenizer=None, analyzer='word', stop_words=None, token_pattern='(?u)\\\\b\\\\w\\\\w+\\\\b', ngram_range=(1, 1), max_df=1.0, min_df=1, max_features=None, vocabulary=None, binary=False, dtype=<class 'numpy.float64'>, norm='l2', use_idf=True, smooth_idf=True, sublinear_tf=False)

Convert a collection of raw documents to a matrix of TF-IDF features.

Equivalent to [`CountVectorizer`](sklearn.feature_extraction.text.CountVectorizer.md#sklearn.feature_extraction.text.CountVectorizer) followed by
[`TfidfTransformer`](sklearn.feature_extraction.text.TfidfTransformer.md#sklearn.feature_extraction.text.TfidfTransformer).

For an example of usage, see
[Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py).

For an efficiency comparison of the different feature extractors, see
[FeatureHasher and DictVectorizer Comparison](../../auto_examples/text/plot_hashing_vs_dict_vectorizer.md#sphx-glr-auto-examples-text-plot-hashing-vs-dict-vectorizer-py).

For an example of document clustering and comparison with
[`HashingVectorizer`](sklearn.feature_extraction.text.HashingVectorizer.md#sklearn.feature_extraction.text.HashingVectorizer), see
[Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py).

Read more in the [User Guide](../feature_extraction.md#text-feature-extraction).

* **Parameters:**
  **input**
  : - If `'filename'`, the sequence passed as an argument to fit is
      expected to be a list of filenames that need reading to fetch
      the raw content to analyze.
    - If `'file'`, the sequence items must have a ‘read’ method (file-like
      object) that is called to fetch the bytes in memory.
    - If `'content'`, the input is expected to be a sequence of items that
      can be of type string or byte.

  **encoding**
  : If bytes or files are given to analyze, this encoding is used to
    decode.

  **decode_error**
  : Instruction on what to do if a byte sequence is given to analyze that
    contains characters not of the given `encoding`. By default, it is
    ‘strict’, meaning that a UnicodeDecodeError will be raised. Other
    values are ‘ignore’ and ‘replace’.

  **strip_accents**
  : Remove accents and perform other character normalization
    during the preprocessing step.
    ‘ascii’ is a fast method that only works on characters that have
    a direct ASCII mapping.
    ‘unicode’ is a slightly slower method that works on any characters.
    None (default) means no character normalization is performed.
    <br/>
    Both ‘ascii’ and ‘unicode’ use NFKD normalization from
    [`unicodedata.normalize`](https://docs.python.org/3/library/unicodedata.html#unicodedata.normalize).

  **lowercase**
  : Convert all characters to lowercase before tokenizing.

  **preprocessor**
  : Override the preprocessing (string transformation) stage while
    preserving the tokenizing and n-grams generation steps.
    Only applies if `analyzer` is not callable.

  **tokenizer**
  : Override the string tokenization step while preserving the
    preprocessing and n-grams generation steps.
    Only applies if `analyzer == 'word'`.

  **analyzer**
  : Whether the feature should be made of word or character n-grams.
    Option ‘char_wb’ creates character n-grams only from text inside
    word boundaries; n-grams at the edges of words are padded with space.
    <br/>
    If a callable is passed it is used to extract the sequence of features
    out of the raw, unprocessed input.
    <br/>
    #### Versionchanged
    Changed in version 0.21: Since v0.21, if `input` is `'filename'` or `'file'`, the data
    is first read from the file and then passed to the given callable
    analyzer.

  **stop_words**
  : If a string, it is passed to \_check_stop_list and the appropriate stop
    list is returned. ‘english’ is currently the only supported string
    value.
    There are several known issues with ‘english’ and you should
    consider an alternative (see [Using stop words](../feature_extraction.md#stop-words)).
    <br/>
    If a list, that list is assumed to contain stop words, all of which
    will be removed from the resulting tokens.
    Only applies if `analyzer == 'word'`.
    <br/>
    If None, no stop words will be used. In this case, setting `max_df`
    to a higher value, such as in the range (0.7, 1.0), can automatically detect
    and filter stop words based on intra corpus document frequency of terms.

  **token_pattern**
  : Regular expression denoting what constitutes a “token”, only used
    if `analyzer == 'word'`. The default regexp selects tokens of 2
    or more alphanumeric characters (punctuation is completely ignored
    and always treated as a token separator).
    <br/>
    If there is a capturing group in token_pattern then the
    captured group content, not the entire match, becomes the token.
    At most one capturing group is permitted.

  **ngram_range**
  : The lower and upper boundary of the range of n-values for different
    n-grams to be extracted. All values of n such that min_n <= n <= max_n
    will be used. For example an `ngram_range` of `(1, 1)` means only
    unigrams, `(1, 2)` means unigrams and bigrams, and `(2, 2)` means
    only bigrams.
    Only applies if `analyzer` is not callable.

  **max_df**
  : When building the vocabulary ignore terms that have a document
    frequency strictly higher than the given threshold (corpus-specific
    stop words).
    If float in range [0.0, 1.0], the parameter represents a proportion of
    documents, integer absolute counts.
    This parameter is ignored if vocabulary is not None.

  **min_df**
  : When building the vocabulary ignore terms that have a document
    frequency strictly lower than the given threshold. This value is also
    called cut-off in the literature.
    If float in range of [0.0, 1.0], the parameter represents a proportion
    of documents, integer absolute counts.
    This parameter is ignored if vocabulary is not None.

  **max_features**
  : If not None, build a vocabulary that only consider the top
    `max_features` ordered by term frequency across the corpus.
    Otherwise, all features are used.
    <br/>
    This parameter is ignored if vocabulary is not None.

  **vocabulary**
  : Either a Mapping (e.g., a dict) where keys are terms and values are
    indices in the feature matrix, or an iterable over terms. If not
    given, a vocabulary is determined from the input documents.

  **binary**
  : If True, all non-zero term counts are set to 1. This does not mean
    outputs will have only 0/1 values, only that the tf term in tf-idf
    is binary. (Set `binary` to True, `use_idf` to False and
    `norm` to None to get 0/1 outputs).

  **dtype**
  : Type of the matrix returned by fit_transform() or transform().

  **norm**
  : Each output row will have unit norm, either:
    - ‘l2’: Sum of squares of vector elements is 1. The cosine
      similarity between two vectors is their dot product when l2 norm has
      been applied.
    - ‘l1’: Sum of absolute values of vector elements is 1.
      See [`normalize`](sklearn.preprocessing.normalize.md#sklearn.preprocessing.normalize).
    - None: No normalization.

  **use_idf**
  : Enable inverse-document-frequency reweighting. If False, idf(t) = 1.

  **smooth_idf**
  : Smooth idf weights by adding one to document frequencies, as if an
    extra document was seen containing every term in the collection
    exactly once. Prevents zero divisions.

  **sublinear_tf**
  : Apply sublinear tf scaling, i.e. replace tf with 1 + log(tf).
* **Attributes:**
  **vocabulary_**
  : A mapping of terms to feature indices.

  **fixed_vocabulary_**
  : True if a fixed vocabulary of term to indices mapping
    is provided by the user.

  [`idf_`](#sklearn.feature_extraction.text.TfidfVectorizer.idf_)
  : Inverse document frequency vector, only defined if `use_idf=True`.

#### SEE ALSO
[`CountVectorizer`](sklearn.feature_extraction.text.CountVectorizer.md#sklearn.feature_extraction.text.CountVectorizer)
: Transforms text into a sparse matrix of n-gram counts.

[`TfidfTransformer`](sklearn.feature_extraction.text.TfidfTransformer.md#sklearn.feature_extraction.text.TfidfTransformer)
: Performs the TF-IDF transformation from a provided matrix of counts.

### Examples

```pycon
>>> from sklearn.feature_extraction.text import TfidfVectorizer
>>> corpus = [
...     'This is the first document.',
...     'This document is the second document.',
...     'And this is the third one.',
...     'Is this the first document?',
... ]
>>> vectorizer = TfidfVectorizer()
>>> X = vectorizer.fit_transform(corpus)
>>> vectorizer.get_feature_names_out()
array(['and', 'document', 'first', 'is', 'one', 'second', 'the', 'third',
       'this'], ...)
>>> print(X.shape)
(4, 9)
```

<!-- !! processed by numpydoc !! -->

#### build_analyzer()

Return a callable to process input data.

The callable handles preprocessing, tokenization, and n-grams generation.

* **Returns:**
  analyzer: callable
  : A function to handle preprocessing, tokenization
    and n-grams generation.

<!-- !! processed by numpydoc !! -->

#### build_preprocessor()

Return a function to preprocess the text before tokenization.

* **Returns:**
  preprocessor: callable
  : A function to preprocess the text before tokenization.

<!-- !! processed by numpydoc !! -->

#### build_tokenizer()

Return a function that splits a string into a sequence of tokens.

* **Returns:**
  tokenizer: callable
  : A function to split a string into a sequence of tokens.

<!-- !! processed by numpydoc !! -->

#### decode(doc)

Decode the input into a string of unicode symbols.

The decoding strategy depends on the vectorizer parameters.

* **Parameters:**
  **doc**
  : The string to decode.
* **Returns:**
  doc: str
  : A string of unicode symbols.

<!-- !! processed by numpydoc !! -->

#### fit(raw_documents, y=None)

Learn vocabulary and idf from training set.

* **Parameters:**
  **raw_documents**
  : An iterable which generates either str, unicode or file objects.

  **y**
  : This parameter is not needed to compute tfidf.
* **Returns:**
  **self**
  : Fitted vectorizer.

<!-- !! processed by numpydoc !! -->

#### fit_transform(raw_documents, y=None)

Learn vocabulary and idf, return document-term matrix.

This is equivalent to fit followed by transform, but more efficiently
implemented.

* **Parameters:**
  **raw_documents**
  : An iterable which generates either str, unicode or file objects.

  **y**
  : This parameter is ignored.
* **Returns:**
  **X**
  : Tf-idf-weighted document-term matrix.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_stop_words()

Build or fetch the effective stop words list.

* **Returns:**
  stop_words: list or None
  : A list of stop words.

<!-- !! processed by numpydoc !! -->

#### *property* idf_

Inverse document frequency vector, only defined if `use_idf=True`.

* **Returns:**
  ndarray of shape (n_features,)

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Return terms per document with nonzero entries in X.

* **Parameters:**
  **X**
  : Document-term matrix.
* **Returns:**
  **X_inv**
  : List of arrays of terms.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(raw_documents)

Transform documents to document-term matrix.

Uses the vocabulary and document frequencies (df) learned by fit (or
fit_transform).

* **Parameters:**
  **raw_documents**
  : An iterable which generates either str, unicode or file objects.
* **Returns:**
  **X**
  : Tf-idf-weighted document-term matrix.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This is an example of applying NMF and LatentDirichletAllocation on a corpus of documents and extract additive models of the topic structure of the corpus.  The output is a plot of topics, each represented as bar plot using top few words based on weights.">  <div class="sphx-glr-thumbnail-title">Topic extraction with Non-negative Matrix Factorization and Latent Dirichlet Allocation</div>
</div>
* [Topic extraction with Non-negative Matrix Factorization and Latent Dirichlet Allocation](../../auto_examples/applications/plot_topics_extraction_with_nmf_lda.md#sphx-glr-auto-examples-applications-plot-topics-extraction-with-nmf-lda-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the Spectral Co-clustering algorithm on the twenty newsgroups dataset. The &#x27;comp.os.ms-windows.misc&#x27; category is excluded because it contains many posts containing nothing but data.">  <div class="sphx-glr-thumbnail-title">Biclustering documents with the Spectral Co-clustering algorithm</div>
</div>
* [Biclustering documents with the Spectral Co-clustering algorithm](../../auto_examples/bicluster/plot_bicluster_newsgroups.md#sphx-glr-auto-examples-bicluster-plot-bicluster-newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="Datasets can often contain components that require different feature extraction and processing pipelines. This scenario might occur when:">  <div class="sphx-glr-thumbnail-title">Column Transformer with Heterogeneous Data Sources</div>
</div>
* [Column Transformer with Heterogeneous Data Sources](../../auto_examples/compose/plot_column_transformer.md#sphx-glr-auto-examples-compose-plot-column-transformer-py)

<div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is 20newsgroups_dataset which will be automatically downloaded, cached and reused for the document classification example.">  <div class="sphx-glr-thumbnail-title">Sample pipeline for text feature extraction and evaluation</div>
</div>
* [Sample pipeline for text feature extraction and evaluation](../../auto_examples/model_selection/plot_grid_search_text_feature_extraction.md#sphx-glr-auto-examples-model-selection-plot-grid-search-text-feature-extraction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how the scikit-learn API can be used to cluster documents by topics using a Bag of Words approach.">  <div class="sphx-glr-thumbnail-title">Clustering text documents using k-means</div>
</div>
* [Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we illustrate text vectorization, which is the process of representing non-numerical input data (such as dictionaries or text documents) as vectors of real numbers.">  <div class="sphx-glr-thumbnail-title">FeatureHasher and DictVectorizer Comparison</div>
</div>
* [FeatureHasher and DictVectorizer Comparison](../../auto_examples/text/plot_hashing_vs_dict_vectorizer.md#sphx-glr-auto-examples-text-plot-hashing-vs-dict-vectorizer-py)

<!-- thumbnail-parent-div-close --></div>
