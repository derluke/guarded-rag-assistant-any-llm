# laplacian_kernel

### sklearn.metrics.pairwise.laplacian_kernel(X, Y=None, gamma=None)

Compute the laplacian kernel between X and Y.

The laplacian kernel is defined as:

```text
K(x, y) = exp(-gamma ||x-y||_1)
```

for each pair of rows x in X and y in Y.
Read more in the [User Guide](../metrics.md#laplacian-kernel).

#### Versionadded
Added in version 0.17.

* **Parameters:**
  **X**
  : A feature array.

  **Y**
  : An optional second feature array. If `None`, uses `Y=X`.

  **gamma**
  : If None, defaults to 1.0 / n_features. Otherwise it should be strictly positive.
* **Returns:**
  **kernel**
  : The kernel matrix.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import laplacian_kernel
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> laplacian_kernel(X, Y)
array([[0.71..., 0.51...],
       [0.51..., 0.71...]])
```

<!-- !! processed by numpydoc !! -->
