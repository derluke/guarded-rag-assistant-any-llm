# LearningCurveDisplay

### *class* sklearn.model_selection.LearningCurveDisplay(\*, train_sizes, train_scores, test_scores, score_name=None)

Learning Curve visualization.

It is recommended to use
[`from_estimator`](#sklearn.model_selection.LearningCurveDisplay.from_estimator) to
create a [`LearningCurveDisplay`](#sklearn.model_selection.LearningCurveDisplay) instance.
All parameters are stored as attributes.

Read more in the [User Guide](../../visualizations.md#visualizations) for general information
about the visualization API and
[detailed documentation](../learning_curve.md#learning-curve) regarding the learning
curve visualization.

#### Versionadded
Added in version 1.2.

* **Parameters:**
  **train_sizes**
  : Numbers of training examples that has been used to generate the
    learning curve.

  **train_scores**
  : Scores on training sets.

  **test_scores**
  : Scores on test set.

  **score_name**
  : The name of the score used in `learning_curve`. It will override the name
    inferred from the `scoring` parameter. If `score` is `None`, we use `"Score"` if
    `negate_score` is `False` and `"Negative score"` otherwise. If `scoring` is a
    string or a callable, we infer the name. We replace `_` by spaces and capitalize
    the first letter. We remove `neg_` and replace it by `"Negative"` if
    `negate_score` is `False` or just remove it otherwise.
* **Attributes:**
  **ax_**
  : Axes with the learning curve.

  **figure_**
  : Figure containing the learning curve.

  **errorbar_**
  : When the `std_display_style` is `"errorbar"`, this is a list of
    `matplotlib.container.ErrorbarContainer` objects. If another style is
    used, `errorbar_` is `None`.

  **lines_**
  : When the `std_display_style` is `"fill_between"`, this is a list of
    `matplotlib.lines.Line2D` objects corresponding to the mean train and
    test scores. If another style is used, `line_` is `None`.

  **fill_between_**
  : When the `std_display_style` is `"fill_between"`, this is a list of
    `matplotlib.collections.PolyCollection` objects. If another style is
    used, `fill_between_` is `None`.

#### SEE ALSO
[`sklearn.model_selection.learning_curve`](sklearn.model_selection.learning_curve.md#sklearn.model_selection.learning_curve)
: Compute the learning curve.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import load_iris
>>> from sklearn.model_selection import LearningCurveDisplay, learning_curve
>>> from sklearn.tree import DecisionTreeClassifier
>>> X, y = load_iris(return_X_y=True)
>>> tree = DecisionTreeClassifier(random_state=0)
>>> train_sizes, train_scores, test_scores = learning_curve(
...     tree, X, y)
>>> display = LearningCurveDisplay(train_sizes=train_sizes,
...     train_scores=train_scores, test_scores=test_scores, score_name="Score")
>>> display.plot()
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-model_selection-LearningCurveDisplay-1.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_estimator(estimator, X, y, \*, groups=None, train_sizes=array([0.1, 0.33, 0.55, 0.78, 1.]), cv=None, scoring=None, exploit_incremental_learning=False, n_jobs=None, pre_dispatch='all', verbose=0, shuffle=False, random_state=None, error_score=nan, fit_params=None, ax=None, negate_score=False, score_name=None, score_type='both', std_display_style='fill_between', line_kw=None, fill_between_kw=None, errorbar_kw=None)

Create a learning curve display from an estimator.

Read more in the [User Guide](../../visualizations.md#visualizations) for general
information about the visualization API and [detailed
documentation](../learning_curve.md#learning-curve) regarding the learning curve
visualization.

* **Parameters:**
  **estimator**
  : An object of that type which is cloned for each validation.

  **X**
  : Training data, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target relative to X for classification or regression;
    None for unsupervised learning.

  **groups**
  : Group labels for the samples used while splitting the dataset into
    train/test set. Only used in conjunction with a “Group” [cv](../../glossary.md#term-cv)
    instance (e.g., [`GroupKFold`](sklearn.model_selection.GroupKFold.md#sklearn.model_selection.GroupKFold)).

  **train_sizes**
  : Relative or absolute numbers of training examples that will be used
    to generate the learning curve. If the dtype is float, it is
    regarded as a fraction of the maximum size of the training set
    (that is determined by the selected validation method), i.e. it has
    to be within (0, 1]. Otherwise it is interpreted as absolute sizes
    of the training sets. Note that for classification the number of
    samples usually have to be big enough to contain at least one
    sample from each class.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross validation,
    - int, to specify the number of folds in a `(Stratified)KFold`,
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For int/None inputs, if the estimator is a classifier and `y` is
    either binary or multiclass,
    [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. In all
    other cases, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used. These
    splitters are instantiated with `shuffle=False` so the splits will
    be the same across calls.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.

  **scoring**
  : A string (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter)) or
    a scorer callable object / function with signature
    `scorer(estimator, X, y)` (see [Callable scorers](../model_evaluation.md#scoring-callable)).

  **exploit_incremental_learning**
  : If the estimator supports incremental learning, this will be
    used to speed up fitting for different training set sizes.

  **n_jobs**
  : Number of jobs to run in parallel. Training the estimator and
    computing the score are parallelized over the different training
    and test sets. `None` means 1 unless in a
    [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context. `-1` means using all
    processors. See [Glossary](../../glossary.md#term-n_jobs) for more details.

  **pre_dispatch**
  : Number of predispatched jobs for parallel execution (default is
    all). The option can reduce the allocated memory. The str can
    be an expression like ‘2\*n_jobs’.

  **verbose**
  : Controls the verbosity: the higher, the more messages.

  **shuffle**
  : Whether to shuffle training data before taking prefixes of it
    based on\`train_sizes\`.

  **random_state**
  : Used when `shuffle` is True. Pass an int for reproducible
    output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **error_score**
  : Value to assign to the score if an error occurs in estimator
    fitting. If set to ‘raise’, the error is raised. If a numeric value
    is given, FitFailedWarning is raised.

  **fit_params**
  : Parameters to pass to the fit method of the estimator.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **negate_score**
  : Whether or not to negate the scores obtained through
    [`learning_curve`](sklearn.model_selection.learning_curve.md#sklearn.model_selection.learning_curve). This is
    particularly useful when using the error denoted by `neg_*` in
    `scikit-learn`.

  **score_name**
  : The name of the score used to decorate the y-axis of the plot. It will
    override the name inferred from the `scoring` parameter. If `score` is
    `None`, we use `"Score"` if `negate_score` is `False` and `"Negative score"`
    otherwise. If `scoring` is a string or a callable, we infer the name. We
    replace `_` by spaces and capitalize the first letter. We remove `neg_` and
    replace it by `"Negative"` if `negate_score` is
    `False` or just remove it otherwise.

  **score_type**
  : The type of score to plot. Can be one of `"test"`, `"train"`, or
    `"both"`.

  **std_display_style**
  : The style used to display the score standard deviation around the
    mean score. If `None`, no representation of the standard deviation
    is displayed.

  **line_kw**
  : Additional keyword arguments passed to the `plt.plot` used to draw
    the mean score.

  **fill_between_kw**
  : Additional keyword arguments passed to the `plt.fill_between` used
    to draw the score standard deviation.

  **errorbar_kw**
  : Additional keyword arguments passed to the `plt.errorbar` used to
    draw mean score and standard deviation score.
* **Returns:**
  **display**
  : Object that stores computed values.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import load_iris
>>> from sklearn.model_selection import LearningCurveDisplay
>>> from sklearn.tree import DecisionTreeClassifier
>>> X, y = load_iris(return_X_y=True)
>>> tree = DecisionTreeClassifier(random_state=0)
>>> LearningCurveDisplay.from_estimator(tree, X, y)
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-model_selection-LearningCurveDisplay-2.*)
<!-- !! processed by numpydoc !! -->

#### plot(ax=None, \*, negate_score=False, score_name=None, score_type='both', std_display_style='fill_between', line_kw=None, fill_between_kw=None, errorbar_kw=None)

Plot visualization.

* **Parameters:**
  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **negate_score**
  : Whether or not to negate the scores obtained through
    [`learning_curve`](sklearn.model_selection.learning_curve.md#sklearn.model_selection.learning_curve). This is
    particularly useful when using the error denoted by `neg_*` in
    `scikit-learn`.

  **score_name**
  : The name of the score used to decorate the y-axis of the plot. It will
    override the name inferred from the `scoring` parameter. If `score` is
    `None`, we use `"Score"` if `negate_score` is `False` and `"Negative score"`
    otherwise. If `scoring` is a string or a callable, we infer the name. We
    replace `_` by spaces and capitalize the first letter. We remove `neg_` and
    replace it by `"Negative"` if `negate_score` is
    `False` or just remove it otherwise.

  **score_type**
  : The type of score to plot. Can be one of `"test"`, `"train"`, or
    `"both"`.

  **std_display_style**
  : The style used to display the score standard deviation around the
    mean score. If None, no standard deviation representation is
    displayed.

  **line_kw**
  : Additional keyword arguments passed to the `plt.plot` used to draw
    the mean score.

  **fill_between_kw**
  : Additional keyword arguments passed to the `plt.fill_between` used
    to draw the score standard deviation.

  **errorbar_kw**
  : Additional keyword arguments passed to the `plt.errorbar` used to
    draw mean score and standard deviation score.
* **Returns:**
  **display**
  : Object that stores computed values.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we show how to use the class LearningCurveDisplay to easily plot learning curves. In addition, we give an interpretation to the learning curves obtained for a naive Bayes and SVM classifiers.">  <div class="sphx-glr-thumbnail-title">Plotting Learning Curves and Checking Models' Scalability</div>
</div>
* [Plotting Learning Curves and Checking Models’ Scalability](../../auto_examples/model_selection/plot_learning_curve.md#sphx-glr-auto-examples-model-selection-plot-learning-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="Both kernel ridge regression (KRR) and SVR learn a non-linear function by employing the kernel trick, i.e., they learn a linear function in the space induced by the respective kernel which corresponds to a non-linear function in the original space. They differ in the loss functions (ridge versus epsilon-insensitive loss). In contrast to SVR, fitting a KRR can be done in closed-form and is typically faster for medium-sized datasets. On the other hand, the learned model is non-sparse and thus slower than SVR at prediction-time.">  <div class="sphx-glr-thumbnail-title">Comparison of kernel ridge regression and SVR</div>
</div>
* [Comparison of kernel ridge regression and SVR](../../auto_examples/miscellaneous/plot_kernel_ridge_regression.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-ridge-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we show how to use the class LearningCurveDisplay to easily plot learning curves. In addition, we give an interpretation to the learning curves obtained for a naive Bayes and SVM classifiers.">  <div class="sphx-glr-thumbnail-title">Plotting Learning Curves and Checking Models' Scalability</div>
</div>
* [Plotting Learning Curves and Checking Models’ Scalability](../../auto_examples/model_selection/plot_learning_curve.md#sphx-glr-auto-examples-model-selection-plot-learning-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.2! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_2&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.2</div>
</div>
* [Release Highlights for scikit-learn 1.2](../../auto_examples/release_highlights/plot_release_highlights_1_2_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-2-0-py)

<!-- thumbnail-parent-div-close --></div>
