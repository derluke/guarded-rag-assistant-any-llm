# GaussianMixture

### *class* sklearn.mixture.GaussianMixture(n_components=1, \*, covariance_type='full', tol=0.001, reg_covar=1e-06, max_iter=100, n_init=1, init_params='kmeans', weights_init=None, means_init=None, precisions_init=None, random_state=None, warm_start=False, verbose=0, verbose_interval=10)

Gaussian Mixture.

Representation of a Gaussian mixture model probability distribution.
This class allows to estimate the parameters of a Gaussian mixture
distribution.

Read more in the [User Guide](../mixture.md#gmm).

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **n_components**
  : The number of mixture components.

  **covariance_type**
  : String describing the type of covariance parameters to use.
    Must be one of:
    - ‘full’: each component has its own general covariance matrix.
    - ‘tied’: all components share the same general covariance matrix.
    - ‘diag’: each component has its own diagonal covariance matrix.
    - ‘spherical’: each component has its own single variance.

  **tol**
  : The convergence threshold. EM iterations will stop when the
    lower bound average gain is below this threshold.

  **reg_covar**
  : Non-negative regularization added to the diagonal of covariance.
    Allows to assure that the covariance matrices are all positive.

  **max_iter**
  : The number of EM iterations to perform.

  **n_init**
  : The number of initializations to perform. The best results are kept.

  **init_params**
  : The method used to initialize the weights, the means and the
    precisions.
    String must be one of:
    - ‘kmeans’ : responsibilities are initialized using kmeans.
    - ‘k-means++’ : use the k-means++ method to initialize.
    - ‘random’ : responsibilities are initialized randomly.
    - ‘random_from_data’ : initial means are randomly selected data points.
    <br/>
    #### Versionchanged
    Changed in version v1.1: `init_params` now accepts ‘random_from_data’ and ‘k-means++’ as
    initialization methods.

  **weights_init**
  : The user-provided initial weights.
    If it is None, weights are initialized using the `init_params` method.

  **means_init**
  : The user-provided initial means,
    If it is None, means are initialized using the `init_params` method.

  **precisions_init**
  : The user-provided initial precisions (inverse of the covariance
    matrices).
    If it is None, precisions are initialized using the ‘init_params’
    method.
    The shape depends on ‘covariance_type’:
    ```default
    (n_components,)                        if 'spherical',
    (n_features, n_features)               if 'tied',
    (n_components, n_features)             if 'diag',
    (n_components, n_features, n_features) if 'full'
    ```

  **random_state**
  : Controls the random seed given to the method chosen to initialize the
    parameters (see `init_params`).
    In addition, it controls the generation of random samples from the
    fitted distribution (see the method `sample`).
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **warm_start**
  : If ‘warm_start’ is True, the solution of the last fitting is used as
    initialization for the next call of fit(). This can speed up
    convergence when fit is called several times on similar problems.
    In that case, ‘n_init’ is ignored and only a single initialization
    occurs upon the first call.
    See [the Glossary](../../glossary.md#term-warm_start).

  **verbose**
  : Enable verbose output. If 1 then it prints the current
    initialization and each iteration step. If greater than 1 then
    it prints also the log probability and the time needed
    for each step.

  **verbose_interval**
  : Number of iteration done before the next print.
* **Attributes:**
  **weights_**
  : The weights of each mixture components.

  **means_**
  : The mean of each mixture component.

  **covariances_**
  : The covariance of each mixture component.
    The shape depends on `covariance_type`:
    ```default
    (n_components,)                        if 'spherical',
    (n_features, n_features)               if 'tied',
    (n_components, n_features)             if 'diag',
    (n_components, n_features, n_features) if 'full'
    ```

  **precisions_**
  : The precision matrices for each component in the mixture. A precision
    matrix is the inverse of a covariance matrix. A covariance matrix is
    symmetric positive definite so the mixture of Gaussian can be
    equivalently parameterized by the precision matrices. Storing the
    precision matrices instead of the covariance matrices makes it more
    efficient to compute the log-likelihood of new samples at test time.
    The shape depends on `covariance_type`:
    ```default
    (n_components,)                        if 'spherical',
    (n_features, n_features)               if 'tied',
    (n_components, n_features)             if 'diag',
    (n_components, n_features, n_features) if 'full'
    ```

  **precisions_cholesky_**
  : The cholesky decomposition of the precision matrices of each mixture
    component. A precision matrix is the inverse of a covariance matrix.
    A covariance matrix is symmetric positive definite so the mixture of
    Gaussian can be equivalently parameterized by the precision matrices.
    Storing the precision matrices instead of the covariance matrices makes
    it more efficient to compute the log-likelihood of new samples at test
    time. The shape depends on `covariance_type`:
    ```default
    (n_components,)                        if 'spherical',
    (n_features, n_features)               if 'tied',
    (n_components, n_features)             if 'diag',
    (n_components, n_features, n_features) if 'full'
    ```

  **converged_**
  : True when convergence of the best fit of EM was reached, False otherwise.

  **n_iter_**
  : Number of step used by the best fit of EM to reach the convergence.

  **lower_bound_**
  : Lower bound value on the log-likelihood (of the training data with
    respect to the model) of the best fit of EM.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`BayesianGaussianMixture`](sklearn.mixture.BayesianGaussianMixture.md#sklearn.mixture.BayesianGaussianMixture)
: Gaussian mixture model fit with a variational inference.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.mixture import GaussianMixture
>>> X = np.array([[1, 2], [1, 4], [1, 0], [10, 2], [10, 4], [10, 0]])
>>> gm = GaussianMixture(n_components=2, random_state=0).fit(X)
>>> gm.means_
array([[10.,  2.],
       [ 1.,  2.]])
>>> gm.predict([[0, 0], [12, 3]])
array([1, 0])
```

<!-- !! processed by numpydoc !! -->

#### aic(X)

Akaike information criterion for the current model on the input X.

You can refer to this [mathematical section](../linear_model.md#aic-bic) for more
details regarding the formulation of the AIC used.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **aic**
  : The lower the better.

<!-- !! processed by numpydoc !! -->

#### bic(X)

Bayesian information criterion for the current model on the input X.

You can refer to this [mathematical section](../linear_model.md#aic-bic) for more
details regarding the formulation of the BIC used.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **bic**
  : The lower the better.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Estimate model parameters with the EM algorithm.

The method fits the model `n_init` times and sets the parameters with
which the model has the largest likelihood or lower bound. Within each
trial, the method iterates between E-step and M-step for `max_iter`
times until the change of likelihood or lower bound is less than
`tol`, otherwise, a `ConvergenceWarning` is raised.
If `warm_start` is `True`, then `n_init` is ignored and a single
initialization is performed upon the first call. Upon consecutive
calls, training starts where it left off.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : The fitted mixture.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None)

Estimate model parameters using X and predict the labels for X.

The method fits the model n_init times and sets the parameters with
which the model has the largest likelihood or lower bound. Within each
trial, the method iterates between E-step and M-step for `max_iter`
times until the change of likelihood or lower bound is less than
`tol`, otherwise, a [`ConvergenceWarning`](sklearn.exceptions.ConvergenceWarning.md#sklearn.exceptions.ConvergenceWarning) is
raised. After fitting, it predicts the most probable label for the
input data points.

#### Versionadded
Added in version 0.20.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **labels**
  : Component labels.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict the labels for the data samples in X using trained model.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.
* **Returns:**
  **labels**
  : Component labels.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Evaluate the components’ density for each sample.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.
* **Returns:**
  **resp**
  : Density of each Gaussian component for each sample in X.

<!-- !! processed by numpydoc !! -->

#### sample(n_samples=1)

Generate random samples from the fitted Gaussian distribution.

* **Parameters:**
  **n_samples**
  : Number of samples to generate.
* **Returns:**
  **X**
  : Randomly generated sample.

  **y**
  : Component labels.

<!-- !! processed by numpydoc !! -->

#### score(X, y=None)

Compute the per-sample average log-likelihood of the given data X.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **log_likelihood**
  : Log-likelihood of `X` under the Gaussian mixture model.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Compute the log-likelihood of each sample.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.
* **Returns:**
  **log_prob**
  : Log-likelihood of each sample in `X` under the current model.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example is meant to illustrate situations where k-means produces unintuitive and possibly undesirable clusters.">  <div class="sphx-glr-thumbnail-title">Demonstration of k-means assumptions</div>
</div>
* [Demonstration of k-means assumptions](../../auto_examples/cluster/plot_kmeans_assumptions.md#sphx-glr-auto-examples-cluster-plot-kmeans-assumptions-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the density estimation of a mixture of two Gaussians. Data is generated from two Gaussians with different centers and covariance matrices.">  <div class="sphx-glr-thumbnail-title">Density Estimation for a Gaussian mixture</div>
</div>
* [Density Estimation for a Gaussian mixture](../../auto_examples/mixture/plot_gmm_pdf.md#sphx-glr-auto-examples-mixture-plot-gmm-pdf-py)

<div class="sphx-glr-thumbcontainer" tooltip="Examples of the different methods of initialization in Gaussian Mixture Models">  <div class="sphx-glr-thumbnail-title">GMM Initialization Methods</div>
</div>
* [GMM Initialization Methods](../../auto_examples/mixture/plot_gmm_init.md#sphx-glr-auto-examples-mixture-plot-gmm-init-py)

<div class="sphx-glr-thumbcontainer" tooltip="Demonstration of several covariances types for Gaussian mixture models.">  <div class="sphx-glr-thumbnail-title">GMM covariances</div>
</div>
* [GMM covariances](../../auto_examples/mixture/plot_gmm_covariances.md#sphx-glr-auto-examples-mixture-plot-gmm-covariances-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the confidence ellipsoids of a mixture of two Gaussians obtained with Expectation Maximisation (\`\`GaussianMixture\`\` class) and Variational Inference (\`\`BayesianGaussianMixture\`\` class models with a Dirichlet process prior).">  <div class="sphx-glr-thumbnail-title">Gaussian Mixture Model Ellipsoids</div>
</div>
* [Gaussian Mixture Model Ellipsoids](../../auto_examples/mixture/plot_gmm.md#sphx-glr-auto-examples-mixture-plot-gmm-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows that model selection can be performed with Gaussian Mixture Models (GMM) using information-theory criteria &lt;aic_bic&gt;. Model selection concerns both the covariance type and the number of components in the model.">  <div class="sphx-glr-thumbnail-title">Gaussian Mixture Model Selection</div>
</div>
* [Gaussian Mixture Model Selection](../../auto_examples/mixture/plot_gmm_selection.md#sphx-glr-auto-examples-mixture-plot-gmm-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the behavior of Gaussian mixture models fit on data that was not sampled from a mixture of Gaussian random variables. The dataset is formed by 100 points loosely spaced following a noisy sine curve. There is therefore no ground truth value for the number of Gaussian components.">  <div class="sphx-glr-thumbnail-title">Gaussian Mixture Model Sine Curve</div>
</div>
* [Gaussian Mixture Model Sine Curve](../../auto_examples/mixture/plot_gmm_sin.md#sphx-glr-auto-examples-mixture-plot-gmm-sin-py)

<!-- thumbnail-parent-div-close --></div>
