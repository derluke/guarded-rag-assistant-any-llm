# roc_auc_score

### sklearn.metrics.roc_auc_score(y_true, y_score, \*, average='macro', sample_weight=None, max_fpr=None, multi_class='raise', labels=None)

Compute Area Under the Receiver Operating Characteristic Curve (ROC AUC)     from prediction scores.

Note: this implementation can be used with binary, multiclass and
multilabel classification, but some restrictions apply (see Parameters).

Read more in the [User Guide](../model_evaluation.md#roc-metrics).

* **Parameters:**
  **y_true**
  : True labels or binary label indicators. The binary and multiclass cases
    expect labels with shape (n_samples,) while the multilabel case expects
    binary label indicators with shape (n_samples, n_classes).

  **y_score**
  : Target scores.
    * In the binary case, it corresponds to an array of shape
      `(n_samples,)`. Both probability estimates and non-thresholded
      decision values can be provided. The probability estimates correspond
      to the **probability of the class with the greater label**,
      i.e. `estimator.classes_[1]` and thus
      `estimator.predict_proba(X, y)[:, 1]`. The decision values
      corresponds to the output of `estimator.decision_function(X, y)`.
      See more information in the [User guide](../model_evaluation.md#roc-auc-binary);
    * In the multiclass case, it corresponds to an array of shape
      `(n_samples, n_classes)` of probability estimates provided by the
      `predict_proba` method. The probability estimates **must**
      sum to 1 across the possible classes. In addition, the order of the
      class scores must correspond to the order of `labels`,
      if provided, or else to the numerical or lexicographical order of
      the labels in `y_true`. See more information in the
      [User guide](../model_evaluation.md#roc-auc-multiclass);
    * In the multilabel case, it corresponds to an array of shape
      `(n_samples, n_classes)`. Probability estimates are provided by the
      `predict_proba` method and the non-thresholded decision values by
      the `decision_function` method. The probability estimates correspond
      to the **probability of the class with the greater label for each
      output** of the classifier. See more information in the
      [User guide](../model_evaluation.md#roc-auc-multilabel).

  **average**
  : If `None`, the scores for each class are returned.
    Otherwise, this determines the type of averaging performed on the data.
    Note: multiclass ROC AUC currently only handles the ‘macro’ and
    ‘weighted’ averages. For multiclass targets, `average=None` is only
    implemented for `multi_class='ovr'` and `average='micro'` is only
    implemented for `multi_class='ovr'`.
    <br/>
    `'micro'`:
    : Calculate metrics globally by considering each element of the label
      indicator matrix as a label.
    <br/>
    `'macro'`:
    : Calculate metrics for each label, and find their unweighted
      mean.  This does not take label imbalance into account.
    <br/>
    `'weighted'`:
    : Calculate metrics for each label, and find their average, weighted
      by support (the number of true instances for each label).
    <br/>
    `'samples'`:
    : Calculate metrics for each instance, and find their average.
    <br/>
    Will be ignored when `y_true` is binary.

  **sample_weight**
  : Sample weights.

  **max_fpr**
  : If not `None`, the standardized partial AUC [[2]](#r4bb7c4558997-2) over the range
    [0, max_fpr] is returned. For the multiclass case, `max_fpr`,
    should be either equal to `None` or `1.0` as AUC ROC partial
    computation currently is not supported for multiclass.

  **multi_class**
  : Only used for multiclass targets. Determines the type of configuration
    to use. The default value raises an error, so either
    `'ovr'` or `'ovo'` must be passed explicitly.
    <br/>
    `'ovr'`:
    : Stands for One-vs-rest. Computes the AUC of each class
      against the rest [[3]](#r4bb7c4558997-3) [[4]](#r4bb7c4558997-4). This
      treats the multiclass case in the same way as the multilabel case.
      Sensitive to class imbalance even when `average == 'macro'`,
      because class imbalance affects the composition of each of the
      ‘rest’ groupings.
    <br/>
    `'ovo'`:
    : Stands for One-vs-one. Computes the average AUC of all
      possible pairwise combinations of classes [[5]](#r4bb7c4558997-5).
      Insensitive to class imbalance when
      `average == 'macro'`.

  **labels**
  : Only used for multiclass targets. List of labels that index the
    classes in `y_score`. If `None`, the numerical or lexicographical
    order of the labels in `y_true` is used.
* **Returns:**
  **auc**
  : Area Under the Curve score.

#### SEE ALSO
[`average_precision_score`](sklearn.metrics.average_precision_score.md#sklearn.metrics.average_precision_score)
: Area under the precision-recall curve.

[`roc_curve`](sklearn.metrics.roc_curve.md#sklearn.metrics.roc_curve)
: Compute Receiver operating characteristic (ROC) curve.

[`RocCurveDisplay.from_estimator`](sklearn.metrics.RocCurveDisplay.md#sklearn.metrics.RocCurveDisplay.from_estimator)
: Plot Receiver Operating Characteristic (ROC) curve given an estimator and some data.

[`RocCurveDisplay.from_predictions`](sklearn.metrics.RocCurveDisplay.md#sklearn.metrics.RocCurveDisplay.from_predictions)
: Plot Receiver Operating Characteristic (ROC) curve given the true and predicted values.

### Notes

The Gini Coefficient is a summary measure of the ranking ability of binary
classifiers. It is expressed using the area under of the ROC as follows:

G = 2 \* AUC - 1

Where G is the Gini coefficient and AUC is the ROC-AUC score. This normalisation
will ensure that random guessing will yield a score of 0 in expectation, and it is
upper bounded by 1.

### References

### Examples

Binary case:

```pycon
>>> from sklearn.datasets import load_breast_cancer
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.metrics import roc_auc_score
>>> X, y = load_breast_cancer(return_X_y=True)
>>> clf = LogisticRegression(solver="liblinear", random_state=0).fit(X, y)
>>> roc_auc_score(y, clf.predict_proba(X)[:, 1])
np.float64(0.99...)
>>> roc_auc_score(y, clf.decision_function(X))
np.float64(0.99...)
```

Multiclass case:

```pycon
>>> from sklearn.datasets import load_iris
>>> X, y = load_iris(return_X_y=True)
>>> clf = LogisticRegression(solver="liblinear").fit(X, y)
>>> roc_auc_score(y, clf.predict_proba(X), multi_class='ovr')
np.float64(0.99...)
```

Multilabel case:

```pycon
>>> import numpy as np
>>> from sklearn.datasets import make_multilabel_classification
>>> from sklearn.multioutput import MultiOutputClassifier
>>> X, y = make_multilabel_classification(random_state=0)
>>> clf = MultiOutputClassifier(clf).fit(X, y)
>>> # get a list of n_output containing probability arrays of shape
>>> # (n_samples, n_classes)
>>> y_pred = clf.predict_proba(X)
>>> # extract the positive columns for each output
>>> y_pred = np.transpose([pred[:, 1] for pred in y_pred])
>>> roc_auc_score(y, y_pred, average=None)
array([0.82..., 0.86..., 0.94..., 0.85... , 0.94...])
>>> from sklearn.linear_model import RidgeClassifierCV
>>> clf = RidgeClassifierCV().fit(X, y)
>>> roc_auc_score(y, clf.decision_function(X), average=None)
array([0.81..., 0.84... , 0.93..., 0.87..., 0.94...])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="When performing classification one often wants to predict not only the class label, but also the associated probability. This probability gives some kind of confidence on the prediction. This example demonstrates how to visualize how well calibrated the predicted probabilities are using calibration curves, also known as reliability diagrams. Calibration of an uncalibrated classifier will also be demonstrated.">  <div class="sphx-glr-thumbnail-title">Probability Calibration curves</div>
</div>
* [Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares two approaches for feature selection: SelectFromModel which is based on feature importance, and SequentialFeatureSelector which relies on a greedy approach.">  <div class="sphx-glr-thumbnail-title">Model-based and sequential feature selection</div>
</div>
* [Model-based and sequential feature selection](../../auto_examples/feature_selection/plot_select_from_model_diabetes.md#sphx-glr-auto-examples-feature-selection-plot-select-from-model-diabetes-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example describes the use of the Receiver Operating Characteristic (ROC) metric to evaluate the quality of multiclass classifiers.">  <div class="sphx-glr-thumbnail-title">Multiclass Receiver Operating Characteristic (ROC)</div>
</div>
* [Multiclass Receiver Operating Characteristic (ROC)](../../auto_examples/model_selection/plot_roc.md#sphx-glr-auto-examples-model-selection-plot-roc-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to statistically compare the performance of models trained and evaluated using GridSearchCV.">  <div class="sphx-glr-thumbnail-title">Statistical comparison of models using grid search</div>
</div>
* [Statistical comparison of models using grid search](../../auto_examples/model_selection/plot_grid_search_stats.md#sphx-glr-auto-examples-model-selection-plot-grid-search-stats-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
