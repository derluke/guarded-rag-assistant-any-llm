# root_mean_squared_log_error

### sklearn.metrics.root_mean_squared_log_error(y_true, y_pred, \*, sample_weight=None, multioutput='uniform_average')

Root mean squared logarithmic error regression loss.

Read more in the [User Guide](../model_evaluation.md#mean-squared-log-error).

#### Versionadded
Added in version 1.4.

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated target values.

  **sample_weight**
  : Sample weights.

  **multioutput**
  : Defines aggregating of multiple output values.
    Array-like value defines weights used to average errors.
    <br/>
    ‘raw_values’ :
    : Returns a full set of errors when the input is of multioutput
      format.
    <br/>
    ‘uniform_average’ :
    : Errors of all outputs are averaged with uniform weight.
* **Returns:**
  **loss**
  : A non-negative floating point value (the best value is 0.0), or an
    array of floating point values, one for each individual target.

### Examples

```pycon
>>> from sklearn.metrics import root_mean_squared_log_error
>>> y_true = [3, 5, 2.5, 7]
>>> y_pred = [2.5, 5, 4, 8]
>>> root_mean_squared_log_error(y_true, y_pred)
0.199...
```

<!-- !! processed by numpydoc !! -->
