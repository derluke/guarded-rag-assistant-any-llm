# FeatureHasher

### *class* sklearn.feature_extraction.FeatureHasher(n_features=1048576, \*, input_type='dict', dtype=<class 'numpy.float64'>, alternate_sign=True)

Implements feature hashing, aka the hashing trick.

This class turns sequences of symbolic feature names (strings) into
scipy.sparse matrices, using a hash function to compute the matrix column
corresponding to a name. The hash function employed is the signed 32-bit
version of Murmurhash3.

Feature names of type byte string are used as-is. Unicode strings are
converted to UTF-8 first, but no Unicode normalization is done.
Feature values must be (finite) numbers.

This class is a low-memory alternative to DictVectorizer and
CountVectorizer, intended for large-scale (online) learning and situations
where memory is tight, e.g. when running prediction code on embedded
devices.

For an efficiency comparison of the different feature extractors, see
[FeatureHasher and DictVectorizer Comparison](../../auto_examples/text/plot_hashing_vs_dict_vectorizer.md#sphx-glr-auto-examples-text-plot-hashing-vs-dict-vectorizer-py).

Read more in the [User Guide](../feature_extraction.md#feature-hashing).

#### Versionadded
Added in version 0.13.

* **Parameters:**
  **n_features**
  : The number of features (columns) in the output matrices. Small numbers
    of features are likely to cause hash collisions, but large numbers
    will cause larger coefficient dimensions in linear learners.

  **input_type**
  : Choose a string from {‘dict’, ‘pair’, ‘string’}.
    Either “dict” (the default) to accept dictionaries over
    (feature_name, value); “pair” to accept pairs of (feature_name, value);
    or “string” to accept single strings.
    feature_name should be a string, while value should be a number.
    In the case of “string”, a value of 1 is implied.
    The feature_name is hashed to find the appropriate column for the
    feature. The value’s sign might be flipped in the output (but see
    non_negative, below).

  **dtype**
  : The type of feature values. Passed to scipy.sparse matrix constructors
    as the dtype argument. Do not set this to bool, np.boolean or any
    unsigned integer type.

  **alternate_sign**
  : When True, an alternating sign is added to the features as to
    approximately conserve the inner product in the hashed space even for
    small n_features. This approach is similar to sparse random projection.
    <br/>
    #### Versionchanged
    Changed in version 0.19: `alternate_sign` replaces the now deprecated `non_negative`
    parameter.

#### SEE ALSO
[`DictVectorizer`](sklearn.feature_extraction.DictVectorizer.md#sklearn.feature_extraction.DictVectorizer)
: Vectorizes string-valued features using a hash table.

[`sklearn.preprocessing.OneHotEncoder`](sklearn.preprocessing.OneHotEncoder.md#sklearn.preprocessing.OneHotEncoder)
: Handles nominal/categorical features.

### Notes

This estimator is [stateless](../../glossary.md#term-stateless) and does not need to be fitted.
However, we recommend to call [`fit_transform`](#sklearn.feature_extraction.FeatureHasher.fit_transform) instead of
[`transform`](#sklearn.feature_extraction.FeatureHasher.transform), as parameter validation is only performed in
[`fit`](#sklearn.feature_extraction.FeatureHasher.fit).

### Examples

```pycon
>>> from sklearn.feature_extraction import FeatureHasher
>>> h = FeatureHasher(n_features=10)
>>> D = [{'dog': 1, 'cat':2, 'elephant':4},{'dog': 2, 'run': 5}]
>>> f = h.transform(D)
>>> f.toarray()
array([[ 0.,  0., -4., -1.,  0.,  0.,  0.,  0.,  0.,  2.],
       [ 0.,  0.,  0., -2., -5.,  0.,  0.,  0.,  0.,  0.]])
```

With `input_type="string"`, the input must be an iterable over iterables of
strings:

```pycon
>>> h = FeatureHasher(n_features=8, input_type="string")
>>> raw_X = [["dog", "cat", "snake"], ["snake", "dog"], ["cat", "bird"]]
>>> f = h.transform(raw_X)
>>> f.toarray()
array([[ 0.,  0.,  0., -1.,  0., -1.,  0.,  1.],
       [ 0.,  0.,  0., -1.,  0., -1.,  0.,  0.],
       [ 0., -1.,  0.,  0.,  0.,  0.,  0.,  1.]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X=None, y=None)

Only validates estimator’s parameters.

This method allows to: (i) validate the estimator’s parameters and
(ii) be consistent with the scikit-learn transformer API.

* **Parameters:**
  **X**
  : Not used, present here for API consistency by convention.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : FeatureHasher class instance.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(raw_X)

Transform a sequence of instances to a scipy.sparse matrix.

* **Parameters:**
  **raw_X**
  : Samples. Each sample must be iterable an (e.g., a list or tuple)
    containing/generating feature names (and optionally values, see
    the input_type constructor argument) which will be hashed.
    raw_X need not support the len function, so it can be the result
    of a generator; n_samples is determined on the fly.
* **Returns:**
  **X**
  : Feature matrix, for use with estimators or further transformers.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example we illustrate text vectorization, which is the process of representing non-numerical input data (such as dictionaries or text documents) as vectors of real numbers.">  <div class="sphx-glr-thumbnail-title">FeatureHasher and DictVectorizer Comparison</div>
</div>
* [FeatureHasher and DictVectorizer Comparison](../../auto_examples/text/plot_hashing_vs_dict_vectorizer.md#sphx-glr-auto-examples-text-plot-hashing-vs-dict-vectorizer-py)

<!-- thumbnail-parent-div-close --></div>
