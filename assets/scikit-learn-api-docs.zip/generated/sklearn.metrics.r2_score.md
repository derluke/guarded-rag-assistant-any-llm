# r2_score

### sklearn.metrics.r2_score(y_true, y_pred, \*, sample_weight=None, multioutput='uniform_average', force_finite=True)

$R^2$ (coefficient of determination) regression score function.

Best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). In the general case when the true y is
non-constant, a constant model that always predicts the average y
disregarding the input features would get a $R^2$ score of 0.0.

In the particular case when `y_true` is constant, the $R^2$ score
is not finite: it is either `NaN` (perfect predictions) or `-Inf`
(imperfect predictions). To prevent such non-finite numbers to pollute
higher-level experiments such as a grid search cross-validation, by default
these cases are replaced with 1.0 (perfect predictions) or 0.0 (imperfect
predictions) respectively. You can set `force_finite` to `False` to
prevent this fix from happening.

Note: when the prediction residuals have zero mean, the $R^2$ score
is identical to the
[`Explained Variance score`](sklearn.metrics.explained_variance_score.md#sklearn.metrics.explained_variance_score).

Read more in the [User Guide](../model_evaluation.md#r2-score).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated target values.

  **sample_weight**
  : Sample weights.

  **multioutput**
  : Defines aggregating of multiple output scores.
    Array-like value defines weights used to average scores.
    Default is “uniform_average”.
    <br/>
    ‘raw_values’ :
    : Returns a full set of scores in case of multioutput input.
    <br/>
    ‘uniform_average’ :
    : Scores of all outputs are averaged with uniform weight.
    <br/>
    ‘variance_weighted’ :
    : Scores of all outputs are averaged, weighted by the variances
      of each individual output.
    <br/>
    #### Versionchanged
    Changed in version 0.19: Default value of multioutput is ‘uniform_average’.

  **force_finite**
  : Flag indicating if `NaN` and `-Inf` scores resulting from constant
    data should be replaced with real numbers (`1.0` if prediction is
    perfect, `0.0` otherwise). Default is `True`, a convenient setting
    for hyperparameters’ search procedures (e.g. grid search
    cross-validation).
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Returns:**
  **z**
  : The $R^2$ score or ndarray of scores if ‘multioutput’ is
    ‘raw_values’.

### Notes

This is not a symmetric function.

Unlike most other scores, $R^2$ score may be negative (it need not
actually be the square of a quantity R).

This metric is not well-defined for single samples and will return a NaN
value if n_samples is less than two.

### References

### Examples

```pycon
>>> from sklearn.metrics import r2_score
>>> y_true = [3, -0.5, 2, 7]
>>> y_pred = [2.5, 0.0, 2, 8]
>>> r2_score(y_true, y_pred)
0.948...
>>> y_true = [[0.5, 1], [-1, 1], [7, -6]]
>>> y_pred = [[0, 2], [-1, 2], [8, -5]]
>>> r2_score(y_true, y_pred,
...          multioutput='variance_weighted')
0.938...
>>> y_true = [1, 2, 3]
>>> y_pred = [1, 2, 3]
>>> r2_score(y_true, y_pred)
1.0
>>> y_true = [1, 2, 3]
>>> y_pred = [2, 2, 2]
>>> r2_score(y_true, y_pred)
0.0
>>> y_true = [1, 2, 3]
>>> y_pred = [3, 2, 1]
>>> r2_score(y_true, y_pred)
-3.0
>>> y_true = [-2, -2, -2]
>>> y_pred = [-2, -2, -2]
>>> r2_score(y_true, y_pred)
1.0
>>> r2_score(y_true, y_pred, force_finite=False)
nan
>>> y_true = [-2, -2, -2]
>>> y_pred = [-2, -2, -2 + 1e-8]
>>> r2_score(y_true, y_pred)
0.0
>>> r2_score(y_true, y_pred, force_finite=False)
-inf
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we give an overview of TransformedTargetRegressor. We use two examples to illustrate the benefit of transforming the targets before learning a linear regression model. The first example uses synthetic data while the second example is based on the Ames housing data set.">  <div class="sphx-glr-thumbnail-title">Effect of transforming the targets in regression model</div>
</div>
* [Effect of transforming the targets in regression model](../../auto_examples/compose/plot_transformed_target.md#sphx-glr-auto-examples-compose-plot-transformed-target-py)

<div class="sphx-glr-thumbcontainer" tooltip="Machine Learning models are great for measuring statistical associations. Unfortunately, unless we&#x27;re willing to make strong assumptions about the data, those models are unable to infer causal effects.">  <div class="sphx-glr-thumbnail-title">Failure of Machine Learning to infer causal effects</div>
</div>
* [Failure of Machine Learning to infer causal effects](../../auto_examples/inspection/plot_causal_interpretation.md#sphx-glr-auto-examples-inspection-plot-causal-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="The present example compares three l1-based regression models on a synthetic signal obtained from sparse and correlated features that are further corrupted with additive gaussian noise:">  <div class="sphx-glr-thumbnail-title">L1-based models for Sparse Signals</div>
</div>
* [L1-based models for Sparse Signals](../../auto_examples/linear_model/plot_lasso_and_elasticnet.md#sphx-glr-auto-examples-linear-model-plot-lasso-and-elasticnet-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we fit a linear model with positive constraints on the regression coefficients and compare the estimated coefficients to a classic linear regression.">  <div class="sphx-glr-thumbnail-title">Non-negative least squares</div>
</div>
* [Non-negative least squares](../../auto_examples/linear_model/plot_nnls.md#sphx-glr-auto-examples-linear-model-plot-nnls-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use the ordinary least squares (OLS) model called LinearRegression in scikit-learn.">  <div class="sphx-glr-thumbnail-title">Ordinary Least Squares Example</div>
</div>
* [Ordinary Least Squares Example](../../auto_examples/linear_model/plot_ols.md#sphx-glr-auto-examples-linear-model-plot-ols-py)

<!-- thumbnail-parent-div-close --></div>
