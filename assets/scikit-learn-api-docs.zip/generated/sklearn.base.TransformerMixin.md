# TransformerMixin

### *class* sklearn.base.TransformerMixin

Mixin class for all transformers in scikit-learn.

This mixin defines the following functionality:

- a `fit_transform` method that delegates to `fit` and `transform`;
- a `set_output` method to output `X` as a specific container type.

If [get_feature_names_out](../../glossary.md#term-get_feature_names_out) is defined, then [`BaseEstimator`](sklearn.base.BaseEstimator.md#sklearn.base.BaseEstimator) will
automatically wrap `transform` and `fit_transform` to follow the `set_output`
API. See the [Developer API for set_output](../../developers/develop.md#developer-api-set-output) for details.

[`OneToOneFeatureMixin`](sklearn.base.OneToOneFeatureMixin.md#sklearn.base.OneToOneFeatureMixin) and
[`ClassNamePrefixFeaturesOutMixin`](sklearn.base.ClassNamePrefixFeaturesOutMixin.md#sklearn.base.ClassNamePrefixFeaturesOutMixin) are helpful mixins for
defining [get_feature_names_out](../../glossary.md#term-get_feature_names_out).

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.base import BaseEstimator, TransformerMixin
>>> class MyTransformer(TransformerMixin, BaseEstimator):
...     def __init__(self, *, param=1):
...         self.param = param
...     def fit(self, X, y=None):
...         return self
...     def transform(self, X):
...         return np.full(shape=len(X), fill_value=self.param)
>>> transformer = MyTransformer()
>>> X = [[1, 2], [2, 3], [3, 4]]
>>> transformer.fit_transform(X)
array([1, 1, 1])
```

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This document shows how you can use the metadata routing mechanism &lt;metadata_routing&gt; in scikit-learn to route metadata to the estimators, scorers, and CV splitters consuming them.">  <div class="sphx-glr-thumbnail-title">Metadata Routing</div>
</div>
* [Metadata Routing](../../auto_examples/miscellaneous/plot_metadata_routing.md#sphx-glr-auto-examples-miscellaneous-plot-metadata-routing-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents how to chain KNeighborsTransformer and TSNE in a pipeline. It also shows how to wrap the packages nmslib and pynndescent to replace KNeighborsTransformer and perform approximate nearest neighbors. These packages can be installed with pip install nmslib pynndescent.">  <div class="sphx-glr-thumbnail-title">Approximate nearest neighbors in TSNE</div>
</div>
* [Approximate nearest neighbors in TSNE](../../auto_examples/neighbors/approximate_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-approximate-nearest-neighbors-py)

<!-- thumbnail-parent-div-close --></div>
