# PassiveAggressiveRegressor

### *class* sklearn.linear_model.PassiveAggressiveRegressor(\*, C=1.0, fit_intercept=True, max_iter=1000, tol=0.001, early_stopping=False, validation_fraction=0.1, n_iter_no_change=5, shuffle=True, verbose=0, loss='epsilon_insensitive', epsilon=0.1, random_state=None, warm_start=False, average=False)

Passive Aggressive Regressor.

Read more in the [User Guide](../linear_model.md#passive-aggressive).

* **Parameters:**
  **C**
  : Maximum step size (regularization). Defaults to 1.0.

  **fit_intercept**
  : Whether the intercept should be estimated or not. If False, the
    data is assumed to be already centered. Defaults to True.

  **max_iter**
  : The maximum number of passes over the training data (aka epochs).
    It only impacts the behavior in the `fit` method, and not the
    [`partial_fit`](#sklearn.linear_model.PassiveAggressiveRegressor.partial_fit) method.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **tol**
  : The stopping criterion. If it is not None, the iterations will stop
    when (loss > previous_loss - tol).
    <br/>
    #### Versionadded
    Added in version 0.19.

  **early_stopping**
  : Whether to use early stopping to terminate training when validation.
    score is not improving. If set to True, it will automatically set aside
    a fraction of training data as validation and terminate
    training when validation score is not improving by at least tol for
    n_iter_no_change consecutive epochs.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **validation_fraction**
  : The proportion of training data to set aside as validation set for
    early stopping. Must be between 0 and 1.
    Only used if early_stopping is True.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **n_iter_no_change**
  : Number of iterations with no improvement to wait before early stopping.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **shuffle**
  : Whether or not the training data should be shuffled after each epoch.

  **verbose**
  : The verbosity level.

  **loss**
  : The loss function to be used:
    epsilon_insensitive: equivalent to PA-I in the reference paper.
    squared_epsilon_insensitive: equivalent to PA-II in the reference
    paper.

  **epsilon**
  : If the difference between the current prediction and the correct label
    is below this threshold, the model is not updated.

  **random_state**
  : Used to shuffle the training data, when `shuffle` is set to
    `True`. Pass an int for reproducible output across multiple
    function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **warm_start**
  : When set to True, reuse the solution of the previous call to fit as
    initialization, otherwise, just erase the previous solution.
    See [the Glossary](../../glossary.md#term-warm_start).
    <br/>
    Repeatedly calling fit or partial_fit when warm_start is True can
    result in a different solution than when calling fit a single time
    because of the way the data is shuffled.

  **average**
  : When set to True, computes the averaged SGD weights and stores the
    result in the `coef_` attribute. If set to an int greater than 1,
    averaging will begin once the total number of samples seen reaches
    average. So average=10 will begin averaging after seeing 10 samples.
    <br/>
    #### Versionadded
    Added in version 0.19: parameter *average* to use weights averaging in SGD.
* **Attributes:**
  **coef_**
  : Weights assigned to the features.

  **intercept_**
  : Constants in decision function.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : The actual number of iterations to reach the stopping criterion.

  **t_**
  : Number of weight updates performed during training.
    Same as `(n_iter_ * n_samples + 1)`.

#### SEE ALSO
[`SGDRegressor`](sklearn.linear_model.SGDRegressor.md#sklearn.linear_model.SGDRegressor)
: Linear model fitted by minimizing a regularized empirical loss with SGD.

### References

Online Passive-Aggressive Algorithms
<[http://jmlr.csail.mit.edu/papers/volume7/crammer06a/crammer06a.pdf](http://jmlr.csail.mit.edu/papers/volume7/crammer06a/crammer06a.pdf)>
K. Crammer, O. Dekel, J. Keshat, S. Shalev-Shwartz, Y. Singer - JMLR (2006).

### Examples

```pycon
>>> from sklearn.linear_model import PassiveAggressiveRegressor
>>> from sklearn.datasets import make_regression
```

```pycon
>>> X, y = make_regression(n_features=4, random_state=0)
>>> regr = PassiveAggressiveRegressor(max_iter=100, random_state=0,
... tol=1e-3)
>>> regr.fit(X, y)
PassiveAggressiveRegressor(max_iter=100, random_state=0)
>>> print(regr.coef_)
[20.48736655 34.18818427 67.59122734 87.94731329]
>>> print(regr.intercept_)
[-0.02306214]
>>> print(regr.predict([[0, 0, 0, 0]]))
[-0.02306214]
```

<!-- !! processed by numpydoc !! -->

#### densify()

Convert coefficient matrix to dense array format.

Converts the `coef_` member (back) to a numpy.ndarray. This is the
default format of `coef_` and is required for fitting, so calling
this method is only required on models that have previously been
sparsified; otherwise, it is a no-op.

* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, coef_init=None, intercept_init=None)

Fit linear model with Passive Aggressive algorithm.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **coef_init**
  : The initial coefficients to warm-start the optimization.

  **intercept_init**
  : The initial intercept to warm-start the optimization.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y)

Fit linear model with Passive Aggressive algorithm.

* **Parameters:**
  **X**
  : Subset of training data.

  **y**
  : Subset of target values.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  ndarray of shape (n_samples,)
  : Predicted target values per element in X.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, coef_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', intercept_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PassiveAggressiveRegressor](#sklearn.linear_model.PassiveAggressiveRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **coef_init**
  : Metadata routing for `coef_init` parameter in `fit`.

  **intercept_init**
  : Metadata routing for `intercept_init` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PassiveAggressiveRegressor](#sklearn.linear_model.PassiveAggressiveRegressor)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PassiveAggressiveRegressor](#sklearn.linear_model.PassiveAggressiveRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### sparsify()

Convert coefficient matrix to sparse format.

Converts the `coef_` member to a scipy.sparse matrix, which for
L1-regularized models can be much more memory- and storage-efficient
than the usual numpy.ndarray representation.

The `intercept_` member is not converted.

* **Returns:**
  self
  : Fitted estimator.

### Notes

For non-sparse models, i.e. when there are not many zeros in `coef_`,
this may actually *increase* memory usage, so use this method with
care. A rule of thumb is that the number of zero elements, which can
be computed with `(coef_ == 0).sum()`, must be more than 50% for this
to provide significant benefits.

After calling this method, further fitting with the partial_fit
method (if any) will not work until you call densify.

<!-- !! processed by numpydoc !! -->
