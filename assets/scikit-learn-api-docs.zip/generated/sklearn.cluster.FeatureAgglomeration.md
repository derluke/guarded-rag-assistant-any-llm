# FeatureAgglomeration

### *class* sklearn.cluster.FeatureAgglomeration(n_clusters=2, \*, metric='euclidean', memory=None, connectivity=None, compute_full_tree='auto', linkage='ward', pooling_func=<function mean>, distance_threshold=None, compute_distances=False)

Agglomerate features.

Recursively merges pair of clusters of features.

Refer to
[Feature agglomeration vs. univariate selection](../../auto_examples/cluster/plot_feature_agglomeration_vs_univariate_selection.md#sphx-glr-auto-examples-cluster-plot-feature-agglomeration-vs-univariate-selection-py)
for an example comparison of [`FeatureAgglomeration`](#sklearn.cluster.FeatureAgglomeration) strategy with a
univariate feature selection strategy (based on ANOVA).

Read more in the [User Guide](../clustering.md#hierarchical-clustering).

* **Parameters:**
  **n_clusters**
  : The number of clusters to find. It must be `None` if
    `distance_threshold` is not `None`.

  **metric**
  : Metric used to compute the linkage. Can be “euclidean”, “l1”, “l2”,
    “manhattan”, “cosine”, or “precomputed”. If linkage is “ward”, only
    “euclidean” is accepted. If “precomputed”, a distance matrix is needed
    as input for the fit method.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **memory**
  : Used to cache the output of the computation of the tree.
    By default, no caching is done. If a string is given, it is the
    path to the caching directory.

  **connectivity**
  : Connectivity matrix. Defines for each feature the neighboring
    features following a given structure of the data.
    This can be a connectivity matrix itself or a callable that transforms
    the data into a connectivity matrix, such as derived from
    `kneighbors_graph`. Default is `None`, i.e, the
    hierarchical clustering algorithm is unstructured.

  **compute_full_tree**
  : Stop early the construction of the tree at `n_clusters`. This is useful
    to decrease computation time if the number of clusters is not small
    compared to the number of features. This option is useful only when
    specifying a connectivity matrix. Note also that when varying the
    number of clusters and using caching, it may be advantageous to compute
    the full tree. It must be `True` if `distance_threshold` is not
    `None`. By default `compute_full_tree` is “auto”, which is equivalent
    to `True` when `distance_threshold` is not `None` or that `n_clusters`
    is inferior to the maximum between 100 or `0.02 * n_samples`.
    Otherwise, “auto” is equivalent to `False`.

  **linkage**
  : Which linkage criterion to use. The linkage criterion determines which
    distance to use between sets of features. The algorithm will merge
    the pairs of cluster that minimize this criterion.
    - “ward” minimizes the variance of the clusters being merged.
    - “complete” or maximum linkage uses the maximum distances between
      all features of the two sets.
    - “average” uses the average of the distances of each feature of
      the two sets.
    - “single” uses the minimum of the distances between all features
      of the two sets.

  **pooling_func**
  : This combines the values of agglomerated features into a single
    value, and should accept an array of shape [M, N] and the keyword
    argument `axis=1`, and reduce it to an array of size [M].

  **distance_threshold**
  : The linkage distance threshold at or above which clusters will not be
    merged. If not `None`, `n_clusters` must be `None` and
    `compute_full_tree` must be `True`.
    <br/>
    #### Versionadded
    Added in version 0.21.

  **compute_distances**
  : Computes distances between clusters even if `distance_threshold` is not
    used. This can be used to make dendrogram visualization, but introduces
    a computational and memory overhead.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  **n_clusters_**
  : The number of clusters found by the algorithm. If
    `distance_threshold=None`, it will be equal to the given
    `n_clusters`.

  **labels_**
  : Cluster labels for each feature.

  **n_leaves_**
  : Number of leaves in the hierarchical tree.

  **n_connected_components_**
  : The estimated number of connected components in the graph.
    <br/>
    #### Versionadded
    Added in version 0.21: `n_connected_components_` was added to replace `n_components_`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **children_**
  : The children of each non-leaf node. Values less than `n_features`
    correspond to leaves of the tree which are the original samples.
    A node `i` greater than or equal to `n_features` is a non-leaf
    node and has children `children_[i - n_features]`. Alternatively
    at the i-th iteration, children[i][0] and children[i][1]
    are merged to form node `n_features + i`.

  **distances_**
  : Distances between nodes in the corresponding place in `children_`.
    Only computed if `distance_threshold` is used or `compute_distances`
    is set to `True`.

#### SEE ALSO
[`AgglomerativeClustering`](sklearn.cluster.AgglomerativeClustering.md#sklearn.cluster.AgglomerativeClustering)
: Agglomerative clustering samples instead of features.

[`ward_tree`](sklearn.cluster.ward_tree.md#sklearn.cluster.ward_tree)
: Hierarchical clustering with ward linkage.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn import datasets, cluster
>>> digits = datasets.load_digits()
>>> images = digits.images
>>> X = np.reshape(images, (len(images), -1))
>>> agglo = cluster.FeatureAgglomeration(n_clusters=32)
>>> agglo.fit(X)
FeatureAgglomeration(n_clusters=32)
>>> X_reduced = agglo.transform(X)
>>> X_reduced.shape
(1797, 32)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the hierarchical clustering on the data.

* **Parameters:**
  **X**
  : The data.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : Returns the transformer.

<!-- !! processed by numpydoc !! -->

#### *property* fit_predict

Fit and return the result of each sample’s clustering assignment.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X=None, \*, Xt=None)

Inverse the transformation and return a vector of size `n_features`.

* **Parameters:**
  **X**
  : The values to be assigned to each cluster of samples.

  **Xt**
  : The values to be assigned to each cluster of samples.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Xt` was deprecated in 1.5 and will be removed in 1.7. Use `X` instead.
* **Returns:**
  **X**
  : A vector of size `n_samples` with the values of `Xred` assigned to
    each of the cluster of samples.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform a new matrix using the built clustering.

* **Parameters:**
  **X**
  : A M by N array of M observations in N dimensions or a length
    M array of M one-dimensional observations.
* **Returns:**
  **Y**
  : The pooled values for each feature cluster.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="These images show how similar features are merged together using feature agglomeration.">  <div class="sphx-glr-thumbnail-title">Feature agglomeration</div>
</div>
* [Feature agglomeration](../../auto_examples/cluster/plot_digits_agglomeration.md#sphx-glr-auto-examples-cluster-plot-digits-agglomeration-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares 2 dimensionality reduction strategies:">  <div class="sphx-glr-thumbnail-title">Feature agglomeration vs. univariate selection</div>
</div>
* [Feature agglomeration vs. univariate selection](../../auto_examples/cluster/plot_feature_agglomeration_vs_univariate_selection.md#sphx-glr-auto-examples-cluster-plot-feature-agglomeration-vs-univariate-selection-py)

<!-- thumbnail-parent-div-close --></div>
