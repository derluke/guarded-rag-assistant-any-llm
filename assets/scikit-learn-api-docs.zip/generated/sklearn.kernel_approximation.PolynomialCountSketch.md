# PolynomialCountSketch

### *class* sklearn.kernel_approximation.PolynomialCountSketch(\*, gamma=1.0, degree=2, coef0=0, n_components=100, random_state=None)

Polynomial kernel approximation via Tensor Sketch.

Implements Tensor Sketch, which approximates the feature map
of the polynomial kernel:

```default
K(X, Y) = (gamma * <X, Y> + coef0)^degree
```

by efficiently computing a Count Sketch of the outer product of a
vector with itself using Fast Fourier Transforms (FFT). Read more in the
[User Guide](../kernel_approximation.md#polynomial-kernel-approx).

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **gamma**
  : Parameter of the polynomial kernel whose feature map
    will be approximated.

  **degree**
  : Degree of the polynomial kernel whose feature map
    will be approximated.

  **coef0**
  : Constant term of the polynomial kernel whose feature map
    will be approximated.

  **n_components**
  : Dimensionality of the output feature space. Usually, `n_components`
    should be greater than the number of features in input samples in
    order to achieve good performance. The optimal score / run time
    balance is typically achieved around `n_components` = 10 \* `n_features`,
    but this depends on the specific dataset being used.

  **random_state**
  : Determines random number generation for indexHash and bitHash
    initialization. Pass an int for reproducible results across multiple
    function calls. See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **indexHash_**
  : Array of indexes in range [0, n_components) used to represent
    the 2-wise independent hash functions for Count Sketch computation.

  **bitHash_**
  : Array with random entries in {+1, -1}, used to represent
    the 2-wise independent hash functions for Count Sketch computation.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`AdditiveChi2Sampler`](sklearn.kernel_approximation.AdditiveChi2Sampler.md#sklearn.kernel_approximation.AdditiveChi2Sampler)
: Approximate feature map for additive chi2 kernel.

[`Nystroem`](sklearn.kernel_approximation.Nystroem.md#sklearn.kernel_approximation.Nystroem)
: Approximate a kernel map using a subset of the training data.

[`RBFSampler`](sklearn.kernel_approximation.RBFSampler.md#sklearn.kernel_approximation.RBFSampler)
: Approximate a RBF kernel feature map using random Fourier features.

[`SkewedChi2Sampler`](sklearn.kernel_approximation.SkewedChi2Sampler.md#sklearn.kernel_approximation.SkewedChi2Sampler)
: Approximate feature map for “skewed chi-squared” kernel.

[`sklearn.metrics.pairwise.kernel_metrics`](sklearn.metrics.pairwise.kernel_metrics.md#sklearn.metrics.pairwise.kernel_metrics)
: List of built-in kernels.

### Examples

```pycon
>>> from sklearn.kernel_approximation import PolynomialCountSketch
>>> from sklearn.linear_model import SGDClassifier
>>> X = [[0, 0], [1, 1], [1, 0], [0, 1]]
>>> y = [0, 0, 1, 1]
>>> ps = PolynomialCountSketch(degree=3, random_state=1)
>>> X_features = ps.fit_transform(X)
>>> clf = SGDClassifier(max_iter=10, tol=1e-3)
>>> clf.fit(X_features, y)
SGDClassifier(max_iter=10)
>>> clf.score(X_features, y)
1.0
```

For a more detailed example of usage, see
[Scalable learning with polynomial kernel approximation](../../auto_examples/kernel_approximation/plot_scalable_poly_kernels.md#sphx-glr-auto-examples-kernel-approximation-plot-scalable-poly-kernels-py)

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the model with X.

Initializes the internal variables. The method needs no information
about the distribution of data, so we only care about n_features in X.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Target values (None for unsupervised transformations).
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Generate the feature map approximation for X.

* **Parameters:**
  **X**
  : New data, where `n_samples` is the number of samples
    and `n_features` is the number of features.
* **Returns:**
  **X_new**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of PolynomialCountSketch to efficiently generate polynomial kernel feature-space approximations. This is used to train linear classifiers that approximate the accuracy of kernelized ones.">  <div class="sphx-glr-thumbnail-title">Scalable learning with polynomial kernel approximation</div>
</div>
* [Scalable learning with polynomial kernel approximation](../../auto_examples/kernel_approximation/plot_scalable_poly_kernels.md#sphx-glr-auto-examples-kernel-approximation-plot-scalable-poly-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
