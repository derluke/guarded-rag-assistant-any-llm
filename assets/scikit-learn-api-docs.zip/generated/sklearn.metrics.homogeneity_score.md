# homogeneity_score

### sklearn.metrics.homogeneity_score(labels_true, labels_pred)

Homogeneity metric of a cluster labeling given a ground truth.

A clustering result satisfies homogeneity if all of its clusters
contain only data points which are members of a single class.

This metric is independent of the absolute values of the labels:
a permutation of the class or cluster label values won’t change the
score value in any way.

This metric is not symmetric: switching `label_true` with `label_pred`
will return the [`completeness_score`](sklearn.metrics.completeness_score.md#sklearn.metrics.completeness_score) which will be different in
general.

Read more in the [User Guide](../clustering.md#homogeneity-completeness).

* **Parameters:**
  **labels_true**
  : Ground truth class labels to be used as a reference.

  **labels_pred**
  : Cluster labels to evaluate.
* **Returns:**
  **homogeneity**
  : Score between 0.0 and 1.0. 1.0 stands for perfectly homogeneous labeling.

#### SEE ALSO
[`completeness_score`](sklearn.metrics.completeness_score.md#sklearn.metrics.completeness_score)
: Completeness metric of cluster labeling.

[`v_measure_score`](sklearn.metrics.v_measure_score.md#sklearn.metrics.v_measure_score)
: V-Measure (NMI with arithmetic mean option).

### References

### Examples

Perfect labelings are homogeneous:

```default
>>> from sklearn.metrics.cluster import homogeneity_score
>>> homogeneity_score([0, 0, 1, 1], [1, 1, 0, 0])
np.float64(1.0)
```

Non-perfect labelings that further split classes into more clusters can be
perfectly homogeneous:

```default
>>> print("%.6f" % homogeneity_score([0, 0, 1, 1], [0, 0, 1, 2]))
1.000000
>>> print("%.6f" % homogeneity_score([0, 0, 1, 1], [0, 1, 2, 3]))
1.000000
```

Clusters that include samples from different classes do not make for an
homogeneous labeling:

```default
>>> print("%.6f" % homogeneity_score([0, 0, 1, 1], [0, 1, 0, 1]))
0.0...
>>> print("%.6f" % homogeneity_score([0, 0, 1, 1], [0, 0, 0, 0]))
0.0...
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the various initialization strategies for K-means in terms of runtime and quality of the results.">  <div class="sphx-glr-thumbnail-title">A demo of K-Means clustering on the handwritten digits data</div>
</div>
* [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="DBSCAN (Density-Based Spatial Clustering of Applications with Noise) finds core samples in regions of high density and expands clusters from them. This algorithm is good for data which contains clusters of similar density.">  <div class="sphx-glr-thumbnail-title">Demo of DBSCAN clustering algorithm</div>
</div>
* [Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="Reference: Brendan J. Frey and Delbert Dueck, &quot;Clustering by Passing Messages Between Data Points&quot;, Science Feb. 2007">  <div class="sphx-glr-thumbnail-title">Demo of affinity propagation clustering algorithm</div>
</div>
* [Demo of affinity propagation clustering algorithm](../../auto_examples/cluster/plot_affinity_propagation.md#sphx-glr-auto-examples-cluster-plot-affinity-propagation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how the scikit-learn API can be used to cluster documents by topics using a Bag of Words approach.">  <div class="sphx-glr-thumbnail-title">Clustering text documents using k-means</div>
</div>
* [Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py)

<!-- thumbnail-parent-div-close --></div>
