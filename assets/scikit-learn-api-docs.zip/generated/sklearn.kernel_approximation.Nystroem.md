# Nystroem

### *class* sklearn.kernel_approximation.Nystroem(kernel='rbf', \*, gamma=None, coef0=None, degree=None, kernel_params=None, n_components=100, random_state=None, n_jobs=None)

Approximate a kernel map using a subset of the training data.

Constructs an approximate feature map for an arbitrary kernel
using a subset of the data as basis.

Read more in the [User Guide](../kernel_approximation.md#nystroem-kernel-approx).

#### Versionadded
Added in version 0.13.

* **Parameters:**
  **kernel**
  : Kernel map to be approximated. A callable should accept two arguments
    and the keyword arguments passed to this object as `kernel_params`, and
    should return a floating point number.

  **gamma**
  : Gamma parameter for the RBF, laplacian, polynomial, exponential chi2
    and sigmoid kernels. Interpretation of the default value is left to
    the kernel; see the documentation for sklearn.metrics.pairwise.
    Ignored by other kernels.

  **coef0**
  : Zero coefficient for polynomial and sigmoid kernels.
    Ignored by other kernels.

  **degree**
  : Degree of the polynomial kernel. Ignored by other kernels.

  **kernel_params**
  : Additional parameters (keyword arguments) for kernel function passed
    as callable object.

  **n_components**
  : Number of features to construct.
    How many data points will be used to construct the mapping.

  **random_state**
  : Pseudo-random number generator to control the uniform sampling without
    replacement of `n_components` of the training data to construct the
    basis kernel.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **n_jobs**
  : The number of jobs to use for the computation. This works by breaking
    down the kernel matrix into `n_jobs` even slices and computing them in
    parallel.
    <br/>
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  **components_**
  : Subset of training points used to construct the feature map.

  **component_indices_**
  : Indices of `components_` in the training set.

  **normalization_**
  : Normalization matrix needed for embedding.
    Square root of the kernel matrix on `components_`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`AdditiveChi2Sampler`](sklearn.kernel_approximation.AdditiveChi2Sampler.md#sklearn.kernel_approximation.AdditiveChi2Sampler)
: Approximate feature map for additive chi2 kernel.

[`PolynomialCountSketch`](sklearn.kernel_approximation.PolynomialCountSketch.md#sklearn.kernel_approximation.PolynomialCountSketch)
: Polynomial kernel approximation via Tensor Sketch.

[`RBFSampler`](sklearn.kernel_approximation.RBFSampler.md#sklearn.kernel_approximation.RBFSampler)
: Approximate a RBF kernel feature map using random Fourier features.

[`SkewedChi2Sampler`](sklearn.kernel_approximation.SkewedChi2Sampler.md#sklearn.kernel_approximation.SkewedChi2Sampler)
: Approximate feature map for “skewed chi-squared” kernel.

[`sklearn.metrics.pairwise.kernel_metrics`](sklearn.metrics.pairwise.kernel_metrics.md#sklearn.metrics.pairwise.kernel_metrics)
: List of built-in kernels.

### References

* Williams, C.K.I. and Seeger, M.
  “Using the Nystroem method to speed up kernel machines”,
  Advances in neural information processing systems 2001
* T. Yang, Y. Li, M. Mahdavi, R. Jin and Z. Zhou
  “Nystroem Method vs Random Fourier Features: A Theoretical and Empirical
  Comparison”,
  Advances in Neural Information Processing Systems 2012

### Examples

```pycon
>>> from sklearn import datasets, svm
>>> from sklearn.kernel_approximation import Nystroem
>>> X, y = datasets.load_digits(n_class=9, return_X_y=True)
>>> data = X / 16.
>>> clf = svm.LinearSVC()
>>> feature_map_nystroem = Nystroem(gamma=.2,
...                                 random_state=1,
...                                 n_components=300)
>>> data_transformed = feature_map_nystroem.fit_transform(data)
>>> clf.fit(data_transformed, y)
LinearSVC()
>>> clf.score(data_transformed, y)
0.9987...
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit estimator to data.

Samples a subset of training points, computes kernel
on these and computes normalization matrix.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Target values (None for unsupervised transformations).
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Apply feature map to X.

Computes an approximate feature map using the kernel
between some training points and X.

* **Parameters:**
  **X**
  : Data to transform.
* **Returns:**
  **X_transformed**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="The IterativeImputer class is very flexible - it can be used with a variety of estimators to do round-robin regression, treating every variable as an output in turn.">  <div class="sphx-glr-thumbnail-title">Imputing missing values with variants of IterativeImputer</div>
</div>
* [Imputing missing values with variants of IterativeImputer](../../auto_examples/impute/plot_iterative_imputer_variants_comparison.md#sphx-glr-auto-examples-impute-plot-iterative-imputer-variants-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to approximate the solution of sklearn.svm.OneClassSVM in the case of an RBF kernel with sklearn.linear_model.SGDOneClassSVM, a Stochastic Gradient Descent (SGD) version of the One-Class SVM. A kernel approximation is first used in order to apply sklearn.linear_model.SGDOneClassSVM which implements a linear One-Class SVM using SGD.">  <div class="sphx-glr-thumbnail-title">One-Class SVM versus One-Class SVM using Stochastic Gradient Descent</div>
</div>
* [One-Class SVM versus One-Class SVM using Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgdocsvm_vs_ocsvm.md#sphx-glr-auto-examples-linear-model-plot-sgdocsvm-vs-ocsvm-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different anomaly detection algorithms on 2D datasets. Datasets contain one or two modes (regions of high density) to illustrate the ability of algorithms to cope with multimodal data.">  <div class="sphx-glr-thumbnail-title">Comparing anomaly detection algorithms for outlier detection on toy datasets</div>
</div>
* [Comparing anomaly detection algorithms for outlier detection on toy datasets](../../auto_examples/miscellaneous/plot_anomaly_comparison.md#sphx-glr-auto-examples-miscellaneous-plot-anomaly-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example illustrating the approximation of the feature map of an RBF kernel.">  <div class="sphx-glr-thumbnail-title">Explicit feature map approximation for RBF kernels</div>
</div>
* [Explicit feature map approximation for RBF kernels](../../auto_examples/miscellaneous/plot_kernel_approximation.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-approximation-py)

<!-- thumbnail-parent-div-close --></div>
