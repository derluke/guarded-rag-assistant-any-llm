# fast_logdet

### sklearn.utils.extmath.fast_logdet(A)

Compute logarithm of determinant of a square matrix.

The (natural) logarithm of the determinant of a square matrix
is returned if det(A) is non-negative and well defined.
If the determinant is zero or negative returns -Inf.

Equivalent to : np.log(np.det(A)) but more robust.

* **Parameters:**
  **A**
  : The square matrix.
* **Returns:**
  **logdet**
  : When det(A) is strictly positive, log(det(A)) is returned.
    When det(A) is non-positive or not defined, then -inf is returned.

#### SEE ALSO
[`numpy.linalg.slogdet`](https://numpy.org/doc/stable/reference/generated/numpy.linalg.slogdet.html#numpy.linalg.slogdet)
: Compute the sign and (natural) logarithm of the determinant of an array.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.utils.extmath import fast_logdet
>>> a = np.array([[5, 1], [2, 8]])
>>> fast_logdet(a)
np.float64(3.6375861597263857)
```

<!-- !! processed by numpydoc !! -->
