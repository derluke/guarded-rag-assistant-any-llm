# OPTICS

### *class* sklearn.cluster.OPTICS(\*, min_samples=5, max_eps=inf, metric='minkowski', p=2, metric_params=None, cluster_method='xi', eps=None, xi=0.05, predecessor_correction=True, min_cluster_size=None, algorithm='auto', leaf_size=30, memory=None, n_jobs=None)

Estimate clustering structure from vector array.

OPTICS (Ordering Points To Identify the Clustering Structure), closely
related to DBSCAN, finds core sample of high density and expands clusters
from them [[1]](#r2c55e37003fe-1). Unlike DBSCAN, keeps cluster hierarchy for a variable
neighborhood radius. Better suited for usage on large datasets than the
current sklearn implementation of DBSCAN.

Clusters are then extracted using a DBSCAN-like method
(cluster_method = ‘dbscan’) or an automatic
technique proposed in [[1]](#r2c55e37003fe-1) (cluster_method = ‘xi’).

This implementation deviates from the original OPTICS by first performing
k-nearest-neighborhood searches on all points to identify core sizes, then
computing only the distances to unprocessed points when constructing the
cluster order. Note that we do not employ a heap to manage the expansion
candidates, so the time complexity will be O(n^2).

Read more in the [User Guide](../clustering.md#optics).

* **Parameters:**
  **min_samples**
  : The number of samples in a neighborhood for a point to be considered as
    a core point. Also, up and down steep regions can’t have more than
    `min_samples` consecutive non-steep points. Expressed as an absolute
    number or a fraction of the number of samples (rounded to be at least
    2).

  **max_eps**
  : The maximum distance between two samples for one to be considered as
    in the neighborhood of the other. Default value of `np.inf` will
    identify clusters across all scales; reducing `max_eps` will result
    in shorter run times.

  **metric**
  : Metric to use for distance computation. Any metric from scikit-learn
    or scipy.spatial.distance can be used.
    <br/>
    If metric is a callable function, it is called on each
    pair of instances (rows) and the resulting value recorded. The callable
    should take two arrays as input and return one value indicating the
    distance between them. This works for Scipy’s metrics, but is less
    efficient than passing the metric name as a string. If metric is
    “precomputed”, `X` is assumed to be a distance matrix and must be
    square.
    <br/>
    Valid values for metric are:
    - from scikit-learn: [‘cityblock’, ‘cosine’, ‘euclidean’, ‘l1’, ‘l2’,
      ‘manhattan’]
    - from scipy.spatial.distance: [‘braycurtis’, ‘canberra’, ‘chebyshev’,
      ‘correlation’, ‘dice’, ‘hamming’, ‘jaccard’, ‘kulsinski’,
      ‘mahalanobis’, ‘minkowski’, ‘rogerstanimoto’, ‘russellrao’,
      ‘seuclidean’, ‘sokalmichener’, ‘sokalsneath’, ‘sqeuclidean’,
      ‘yule’]
    <br/>
    Sparse matrices are only supported by scikit-learn metrics.
    See the documentation for scipy.spatial.distance for details on these
    metrics.
    <br/>
    #### NOTE
    `'kulsinski'` is deprecated from SciPy 1.9 and will be removed in SciPy 1.11.

  **p**
  : Parameter for the Minkowski metric from
    [`pairwise_distances`](sklearn.metrics.pairwise_distances.md#sklearn.metrics.pairwise_distances). When p = 1, this is
    equivalent to using manhattan_distance (l1), and euclidean_distance
    (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.

  **metric_params**
  : Additional keyword arguments for the metric function.

  **cluster_method**
  : The extraction method used to extract clusters using the calculated
    reachability and ordering. Possible values are “xi” and “dbscan”.

  **eps**
  : The maximum distance between two samples for one to be considered as
    in the neighborhood of the other. By default it assumes the same value
    as `max_eps`.
    Used only when `cluster_method='dbscan'`.

  **xi**
  : Determines the minimum steepness on the reachability plot that
    constitutes a cluster boundary. For example, an upwards point in the
    reachability plot is defined by the ratio from one point to its
    successor being at most 1-xi.
    Used only when `cluster_method='xi'`.

  **predecessor_correction**
  : Correct clusters according to the predecessors calculated by OPTICS
    [[2]](#r2c55e37003fe-2). This parameter has minimal effect on most datasets.
    Used only when `cluster_method='xi'`.

  **min_cluster_size**
  : Minimum number of samples in an OPTICS cluster, expressed as an
    absolute number or a fraction of the number of samples (rounded to be
    at least 2). If `None`, the value of `min_samples` is used instead.
    Used only when `cluster_method='xi'`.

  **algorithm**
  : Algorithm used to compute the nearest neighbors:
    - ‘ball_tree’ will use [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree).
    - ‘kd_tree’ will use [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree).
    - ‘brute’ will use a brute-force search.
    - ‘auto’ (default) will attempt to decide the most appropriate
      algorithm based on the values passed to [`fit`](#sklearn.cluster.OPTICS.fit) method.
    <br/>
    Note: fitting on sparse input will override the setting of
    this parameter, using brute force.

  **leaf_size**
  : Leaf size passed to [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree) or
    [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree). This can affect the speed of the
    construction and query, as well as the memory required to store the
    tree. The optimal value depends on the nature of the problem.

  **memory**
  : Used to cache the output of the computation of the tree.
    By default, no caching is done. If a string is given, it is the
    path to the caching directory.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **labels_**
  : Cluster labels for each point in the dataset given to fit().
    Noisy samples and points which are not included in a leaf cluster
    of `cluster_hierarchy_` are labeled as -1.

  **reachability_**
  : Reachability distances per sample, indexed by object order. Use
    `clust.reachability_[clust.ordering_]` to access in cluster order.

  **ordering_**
  : The cluster ordered list of sample indices.

  **core_distances_**
  : Distance at which each sample becomes a core point, indexed by object
    order. Points which will never be core have a distance of inf. Use
    `clust.core_distances_[clust.ordering_]` to access in cluster order.

  **predecessor_**
  : Point that a sample was reached from, indexed by object order.
    Seed points have a predecessor of -1.

  **cluster_hierarchy_**
  : The list of clusters in the form of `[start, end]` in each row, with
    all indices inclusive. The clusters are ordered according to
    `(end, -start)` (ascending) so that larger clusters encompassing
    smaller clusters come after those smaller ones. Since `labels_` does
    not reflect the hierarchy, usually
    `len(cluster_hierarchy_) > np.unique(optics.labels_)`. Please also
    note that these indices are of the `ordering_`, i.e.
    `X[ordering_][start:end + 1]` form a cluster.
    Only available when `cluster_method='xi'`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`DBSCAN`](sklearn.cluster.DBSCAN.md#sklearn.cluster.DBSCAN)
: A similar clustering for a specified neighborhood radius (eps). Our implementation is optimized for runtime.

### References

### Examples

```pycon
>>> from sklearn.cluster import OPTICS
>>> import numpy as np
>>> X = np.array([[1, 2], [2, 5], [3, 6],
...               [8, 7], [8, 8], [7, 3]])
>>> clustering = OPTICS(min_samples=2).fit(X)
>>> clustering.labels_
array([0, 0, 0, 1, 1, 1])
```

For a more detailed example see
[Demo of OPTICS clustering algorithm](../../auto_examples/cluster/plot_optics.md#sphx-glr-auto-examples-cluster-plot-optics-py).

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Perform OPTICS clustering.

Extracts an ordered list of points and reachability distances, and
performs initial clustering using `max_eps` distance specified at
OPTICS object instantiation.

* **Parameters:**
  **X**
  : A feature array, or array of distances between samples if
    metric=’precomputed’. If a sparse matrix is provided, it will be
    converted into CSR format.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns a fitted instance of self.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None, \*\*kwargs)

Perform clustering on `X` and returns cluster labels.

* **Parameters:**
  **X**
  : Input data.

  **y**
  : Not used, present for API consistency by convention.

  **\*\*kwargs**
  : Arguments to be passed to `fit`.
    <br/>
    #### Versionadded
    Added in version 1.4.
* **Returns:**
  **labels**
  : Cluster labels.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Finds core samples of high density and expands clusters from them. This example uses data that is generated so that the clusters have different densities.">  <div class="sphx-glr-thumbnail-title">Demo of OPTICS clustering algorithm</div>
</div>
* [Demo of OPTICS clustering algorithm](../../auto_examples/cluster/plot_optics.md#sphx-glr-auto-examples-cluster-plot-optics-py)

<!-- thumbnail-parent-div-close --></div>
