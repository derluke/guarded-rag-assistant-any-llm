# SGDRegressor

### *class* sklearn.linear_model.SGDRegressor(loss='squared_error', \*, penalty='l2', alpha=0.0001, l1_ratio=0.15, fit_intercept=True, max_iter=1000, tol=0.001, shuffle=True, verbose=0, epsilon=0.1, random_state=None, learning_rate='invscaling', eta0=0.01, power_t=0.25, early_stopping=False, validation_fraction=0.1, n_iter_no_change=5, warm_start=False, average=False)

Linear model fitted by minimizing a regularized empirical loss with SGD.

SGD stands for Stochastic Gradient Descent: the gradient of the loss is
estimated each sample at a time and the model is updated along the way with
a decreasing strength schedule (aka learning rate).

The regularizer is a penalty added to the loss function that shrinks model
parameters towards the zero vector using either the squared euclidean norm
L2 or the absolute norm L1 or a combination of both (Elastic Net). If the
parameter update crosses the 0.0 value because of the regularizer, the
update is truncated to 0.0 to allow for learning sparse models and achieve
online feature selection.

This implementation works with data represented as dense numpy arrays of
floating point values for the features.

Read more in the [User Guide](../sgd.md#sgd).

* **Parameters:**
  **loss**
  : The loss function to be used. The possible values are ‘squared_error’,
    ‘huber’, ‘epsilon_insensitive’, or ‘squared_epsilon_insensitive’
    <br/>
    The ‘squared_error’ refers to the ordinary least squares fit.
    ‘huber’ modifies ‘squared_error’ to focus less on getting outliers
    correct by switching from squared to linear loss past a distance of
    epsilon. ‘epsilon_insensitive’ ignores errors less than epsilon and is
    linear past that; this is the loss function used in SVR.
    ‘squared_epsilon_insensitive’ is the same but becomes squared loss past
    a tolerance of epsilon.
    <br/>
    More details about the losses formulas can be found in the
    [User Guide](../sgd.md#sgd-mathematical-formulation).

  **penalty**
  : The penalty (aka regularization term) to be used. Defaults to ‘l2’
    which is the standard regularizer for linear SVM models. ‘l1’ and
    ‘elasticnet’ might bring sparsity to the model (feature selection)
    not achievable with ‘l2’. No penalty is added when set to `None`.
    <br/>
    You can see a visualisation of the penalties in
    [SGD: Penalties](../../auto_examples/linear_model/plot_sgd_penalties.md#sphx-glr-auto-examples-linear-model-plot-sgd-penalties-py).

  **alpha**
  : Constant that multiplies the regularization term. The higher the
    value, the stronger the regularization. Also used to compute the
    learning rate when `learning_rate` is set to ‘optimal’.
    Values must be in the range `[0.0, inf)`.

  **l1_ratio**
  : The Elastic Net mixing parameter, with 0 <= l1_ratio <= 1.
    l1_ratio=0 corresponds to L2 penalty, l1_ratio=1 to L1.
    Only used if `penalty` is ‘elasticnet’.
    Values must be in the range `[0.0, 1.0]`.

  **fit_intercept**
  : Whether the intercept should be estimated or not. If False, the
    data is assumed to be already centered.

  **max_iter**
  : The maximum number of passes over the training data (aka epochs).
    It only impacts the behavior in the `fit` method, and not the
    [`partial_fit`](#sklearn.linear_model.SGDRegressor.partial_fit) method.
    Values must be in the range `[1, inf)`.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **tol**
  : The stopping criterion. If it is not None, training will stop
    when (loss > best_loss - tol) for `n_iter_no_change` consecutive
    epochs.
    Convergence is checked against the training loss or the
    validation loss depending on the `early_stopping` parameter.
    Values must be in the range `[0.0, inf)`.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **shuffle**
  : Whether or not the training data should be shuffled after each epoch.

  **verbose**
  : The verbosity level.
    Values must be in the range `[0, inf)`.

  **epsilon**
  : Epsilon in the epsilon-insensitive loss functions; only if `loss` is
    ‘huber’, ‘epsilon_insensitive’, or ‘squared_epsilon_insensitive’.
    For ‘huber’, determines the threshold at which it becomes less
    important to get the prediction exactly right.
    For epsilon-insensitive, any differences between the current prediction
    and the correct label are ignored if they are less than this threshold.
    Values must be in the range `[0.0, inf)`.

  **random_state**
  : Used for shuffling the data, when `shuffle` is set to `True`.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **learning_rate**
  : The learning rate schedule:
    - ‘constant’: `eta = eta0`
    - ‘optimal’: `eta = 1.0 / (alpha * (t + t0))`
      where t0 is chosen by a heuristic proposed by Leon Bottou.
    - ‘invscaling’: `eta = eta0 / pow(t, power_t)`
    - ‘adaptive’: eta = eta0, as long as the training keeps decreasing.
      Each time n_iter_no_change consecutive epochs fail to decrease the
      training loss by tol or fail to increase validation score by tol if
      early_stopping is True, the current learning rate is divided by 5.
    <br/>
    #### Versionadded
    Added in version 0.20: Added ‘adaptive’ option.

  **eta0**
  : The initial learning rate for the ‘constant’, ‘invscaling’ or
    ‘adaptive’ schedules. The default value is 0.01.
    Values must be in the range `[0.0, inf)`.

  **power_t**
  : The exponent for inverse scaling learning rate.
    Values must be in the range `(-inf, inf)`.

  **early_stopping**
  : Whether to use early stopping to terminate training when validation
    score is not improving. If set to True, it will automatically set aside
    a fraction of training data as validation and terminate
    training when validation score returned by the `score` method is not
    improving by at least `tol` for `n_iter_no_change` consecutive
    epochs.
    <br/>
    See [Early stopping of Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgd_early_stopping.md#sphx-glr-auto-examples-linear-model-plot-sgd-early-stopping-py) for an
    example of the effects of early stopping.
    <br/>
    #### Versionadded
    Added in version 0.20: Added ‘early_stopping’ option

  **validation_fraction**
  : The proportion of training data to set aside as validation set for
    early stopping. Must be between 0 and 1.
    Only used if `early_stopping` is True.
    Values must be in the range `(0.0, 1.0)`.
    <br/>
    #### Versionadded
    Added in version 0.20: Added ‘validation_fraction’ option

  **n_iter_no_change**
  : Number of iterations with no improvement to wait before stopping
    fitting.
    Convergence is checked against the training loss or the
    validation loss depending on the `early_stopping` parameter.
    Integer values must be in the range `[1, max_iter)`.
    <br/>
    #### Versionadded
    Added in version 0.20: Added ‘n_iter_no_change’ option

  **warm_start**
  : When set to True, reuse the solution of the previous call to fit as
    initialization, otherwise, just erase the previous solution.
    See [the Glossary](../../glossary.md#term-warm_start).
    <br/>
    Repeatedly calling fit or partial_fit when warm_start is True can
    result in a different solution than when calling fit a single time
    because of the way the data is shuffled.
    If a dynamic learning rate is used, the learning rate is adapted
    depending on the number of samples already seen. Calling `fit` resets
    this counter, while `partial_fit`  will result in increasing the
    existing counter.

  **average**
  : When set to True, computes the averaged SGD weights across all
    updates and stores the result in the `coef_` attribute. If set to
    an int greater than 1, averaging will begin once the total number of
    samples seen reaches `average`. So `average=10` will begin
    averaging after seeing 10 samples.
* **Attributes:**
  **coef_**
  : Weights assigned to the features.

  **intercept_**
  : The intercept term.

  **n_iter_**
  : The actual number of iterations before reaching the stopping criterion.

  **t_**
  : Number of weight updates performed during training.
    Same as `(n_iter_ * n_samples + 1)`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`HuberRegressor`](sklearn.linear_model.HuberRegressor.md#sklearn.linear_model.HuberRegressor)
: Linear regression model that is robust to outliers.

[`Lars`](sklearn.linear_model.Lars.md#sklearn.linear_model.Lars)
: Least Angle Regression model.

[`Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso)
: Linear Model trained with L1 prior as regularizer.

[`RANSACRegressor`](sklearn.linear_model.RANSACRegressor.md#sklearn.linear_model.RANSACRegressor)
: RANSAC (RANdom SAmple Consensus) algorithm.

[`Ridge`](sklearn.linear_model.Ridge.md#sklearn.linear_model.Ridge)
: Linear least squares with l2 regularization.

[`sklearn.svm.SVR`](sklearn.svm.SVR.md#sklearn.svm.SVR)
: Epsilon-Support Vector Regression.

[`TheilSenRegressor`](sklearn.linear_model.TheilSenRegressor.md#sklearn.linear_model.TheilSenRegressor)
: Theil-Sen Estimator robust multivariate regression model.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.linear_model import SGDRegressor
>>> from sklearn.pipeline import make_pipeline
>>> from sklearn.preprocessing import StandardScaler
>>> n_samples, n_features = 10, 5
>>> rng = np.random.RandomState(0)
>>> y = rng.randn(n_samples)
>>> X = rng.randn(n_samples, n_features)
>>> # Always scale the input. The most convenient way is to use a pipeline.
>>> reg = make_pipeline(StandardScaler(),
...                     SGDRegressor(max_iter=1000, tol=1e-3))
>>> reg.fit(X, y)
Pipeline(steps=[('standardscaler', StandardScaler()),
                ('sgdregressor', SGDRegressor())])
```

<!-- !! processed by numpydoc !! -->

#### densify()

Convert coefficient matrix to dense array format.

Converts the `coef_` member (back) to a numpy.ndarray. This is the
default format of `coef_` and is required for fitting, so calling
this method is only required on models that have previously been
sparsified; otherwise, it is a no-op.

* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, coef_init=None, intercept_init=None, sample_weight=None)

Fit linear model with Stochastic Gradient Descent.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **coef_init**
  : The initial coefficients to warm-start the optimization.

  **intercept_init**
  : The initial intercept to warm-start the optimization.

  **sample_weight**
  : Weights applied to individual samples (1. for unweighted).
* **Returns:**
  **self**
  : Fitted `SGDRegressor` estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y, sample_weight=None)

Perform one epoch of stochastic gradient descent on given samples.

Internally, this method uses `max_iter = 1`. Therefore, it is not
guaranteed that a minimum of the cost function is reached after calling
it once. Matters such as objective convergence and early stopping
should be handled by the user.

* **Parameters:**
  **X**
  : Subset of training data.

  **y**
  : Subset of target values.

  **sample_weight**
  : Weights applied to individual samples.
    If not provided, uniform weights are assumed.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  ndarray of shape (n_samples,)
  : Predicted target values per element in X.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, coef_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', intercept_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SGDRegressor](#sklearn.linear_model.SGDRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **coef_init**
  : Metadata routing for `coef_init` parameter in `fit`.

  **intercept_init**
  : Metadata routing for `intercept_init` parameter in `fit`.

  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SGDRegressor](#sklearn.linear_model.SGDRegressor)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SGDRegressor](#sklearn.linear_model.SGDRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### sparsify()

Convert coefficient matrix to sparse format.

Converts the `coef_` member to a scipy.sparse matrix, which for
L1-regularized models can be much more memory- and storage-efficient
than the usual numpy.ndarray representation.

The `intercept_` member is not converted.

* **Returns:**
  self
  : Fitted estimator.

### Notes

For non-sparse models, i.e. when there are not many zeros in `coef_`,
this may actually *increase* memory usage, so use this method with
care. A rule of thumb is that the number of zero elements, which can
be computed with `(coef_ == 0).sum()`, must be more than 50% for this
to provide significant benefits.

After calling this method, further fitting with the partial_fit
method (if any) will not work until you call densify.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This is an example showing the prediction latency of various scikit-learn estimators.">  <div class="sphx-glr-thumbnail-title">Prediction Latency</div>
</div>
* [Prediction Latency](../../auto_examples/applications/plot_prediction_latency.md#sphx-glr-auto-examples-applications-plot-prediction-latency-py)

<div class="sphx-glr-thumbcontainer" tooltip="Contours of where the penalty is equal to 1 for the three penalties L1, L2 and elastic-net.">  <div class="sphx-glr-thumbnail-title">SGD: Penalties</div>
</div>
* [SGD: Penalties](../../auto_examples/linear_model/plot_sgd_penalties.md#sphx-glr-auto-examples-linear-model-plot-sgd-penalties-py)

<!-- thumbnail-parent-div-close --></div>
