# process_routing

### sklearn.utils.metadata_routing.process_routing(\_obj, \_method, /, \*\*kwargs)

Validate and route input parameters.

This function is used inside a router’s method, e.g. [fit](../../glossary.md#term-fit),
to validate the metadata and handle the routing.

Assuming this signature of a router’s fit method:
`fit(self, X, y, sample_weight=None, **fit_params)`,
a call to this function would be:
`process_routing(self, "fit", sample_weight=sample_weight, **fit_params)`.

Note that if routing is not enabled and `kwargs` is empty, then it
returns an empty routing where `process_routing(...).ANYTHING.ANY_METHOD`
is always an empty dictionary.

#### Versionadded
Added in version 1.3.

* **Parameters:**
  **\_obj**
  : An object implementing `get_metadata_routing`. Typically a
    meta-estimator.

  **\_method**
  : The name of the router’s method in which this function is called.

  **\*\*kwargs**
  : Metadata to be routed.
* **Returns:**
  **routed_params**
  : A `Bunch` of the form `{"object_name": {"method_name":
    {params: value}}}` which can be used to pass the required metadata to
    A [`Bunch`](sklearn.utils.Bunch.md#sklearn.utils.Bunch) of the form `{"object_name": {"method_name":
    {params: value}}}` which can be used to pass the required metadata to
    corresponding methods or corresponding child objects. The object names
    are those defined in `obj.get_metadata_routing()`.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This document shows how you can use the metadata routing mechanism &lt;metadata_routing&gt; in scikit-learn to route metadata to the estimators, scorers, and CV splitters consuming them.">  <div class="sphx-glr-thumbnail-title">Metadata Routing</div>
</div>
* [Metadata Routing](../../auto_examples/miscellaneous/plot_metadata_routing.md#sphx-glr-auto-examples-miscellaneous-plot-metadata-routing-py)

<!-- thumbnail-parent-div-close --></div>
