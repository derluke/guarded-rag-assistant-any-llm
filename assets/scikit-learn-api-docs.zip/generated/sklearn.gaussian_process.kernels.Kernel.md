# Kernel

### *class* sklearn.gaussian_process.kernels.Kernel

Base class for all kernels.

#### Versionadded
Added in version 0.18.

### Examples

```pycon
>>> from sklearn.gaussian_process.kernels import Kernel, RBF
>>> import numpy as np
>>> class CustomKernel(Kernel):
...     def __init__(self, length_scale=1.0):
...         self.length_scale = length_scale
...     def __call__(self, X, Y=None):
...         if Y is None:
...             Y = X
...         return np.inner(X, X if Y is None else Y) ** 2
...     def diag(self, X):
...         return np.ones(X.shape[0])
...     def is_stationary(self):
...         return True
>>> kernel = CustomKernel(length_scale=2.0)
>>> X = np.array([[1, 2], [3, 4]])
>>> print(kernel(X))
[[ 25 121]
 [121 625]]
```

<!-- !! processed by numpydoc !! -->

#### *abstract* \_\_call_\_(X, Y=None, eval_gradient=False)

Evaluate the kernel.

<!-- !! processed by numpydoc !! -->

#### *property* bounds

Returns the log-transformed bounds on the theta.

* **Returns:**
  **bounds**
  : The log-transformed bounds on the kernel’s hyperparameters theta

<!-- !! processed by numpydoc !! -->

#### clone_with_theta(theta)

Returns a clone of self with given hyperparameters theta.

* **Parameters:**
  **theta**
  : The hyperparameters

<!-- !! processed by numpydoc !! -->

#### *abstract* diag(X)

Returns the diagonal of the kernel k(X, X).

The result of this method is identical to np.diag(self(X)); however,
it can be evaluated more efficiently since only the diagonal is
evaluated.

* **Parameters:**
  **X**
  : Left argument of the returned kernel k(X, Y)
* **Returns:**
  **K_diag**
  : Diagonal of kernel k(X, X)

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters of this kernel.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* hyperparameters

Returns a list of all hyperparameter specifications.

<!-- !! processed by numpydoc !! -->

#### *abstract* is_stationary()

Returns whether the kernel is stationary.

<!-- !! processed by numpydoc !! -->

#### *property* n_dims

Returns the number of non-fixed hyperparameters of the kernel.

<!-- !! processed by numpydoc !! -->

#### *property* requires_vector_input

Returns whether the kernel is defined on fixed-length feature
vectors or generic objects. Defaults to True for backward
compatibility.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this kernel.

The method works on simple kernels as well as on nested kernels.
The latter have parameters of the form `<component>__<parameter>`
so that it’s possible to update each component of a nested object.

* **Returns:**
  self

<!-- !! processed by numpydoc !! -->

#### *property* theta

Returns the (flattened, log-transformed) non-fixed hyperparameters.

Note that theta are typically the log-transformed values of the
kernel’s hyperparameters as this representation of the search space
is more amenable for hyperparameter search, as hyperparameters like
length-scales naturally live on a log-scale.

* **Returns:**
  **theta**
  : The non-fixed, log-transformed hyperparameters of the kernel

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Gaussian processes for regression and classification tasks on data that are not in fixed-length feature vector form. This is achieved through the use of kernel functions that operates directly on discrete structures such as variable-length sequences, trees, and graphs.">  <div class="sphx-glr-thumbnail-title">Gaussian processes on discrete data structures</div>
</div>
* [Gaussian processes on discrete data structures](../../auto_examples/gaussian_process/plot_gpr_on_structured_data.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-on-structured-data-py)

<!-- thumbnail-parent-div-close --></div>
