# label_binarize

### sklearn.preprocessing.label_binarize(y, \*, classes, neg_label=0, pos_label=1, sparse_output=False)

Binarize labels in a one-vs-all fashion.

Several regression and binary classification algorithms are
available in scikit-learn. A simple way to extend these algorithms
to the multi-class classification case is to use the so-called
one-vs-all scheme.

This function makes it possible to compute this transformation for a
fixed set of class labels known ahead of time.

* **Parameters:**
  **y**
  : Sequence of integer labels or multilabel data to encode.

  **classes**
  : Uniquely holds the label for each class.

  **neg_label**
  : Value with which negative labels must be encoded.

  **pos_label**
  : Value with which positive labels must be encoded.

  **sparse_output**
  : Set to true if output binary array is desired in CSR sparse format.
* **Returns:**
  **Y**
  : Shape will be (n_samples, 1) for binary problems. Sparse matrix will
    be of CSR format.

#### SEE ALSO
[`LabelBinarizer`](sklearn.preprocessing.LabelBinarizer.md#sklearn.preprocessing.LabelBinarizer)
: Class used to wrap the functionality of label_binarize and allow for fitting to classes independently of the transform operation.

### Examples

```pycon
>>> from sklearn.preprocessing import label_binarize
>>> label_binarize([1, 6], classes=[1, 2, 4, 6])
array([[1, 0, 0, 0],
       [0, 0, 0, 1]])
```

The class ordering is preserved:

```pycon
>>> label_binarize([1, 6], classes=[1, 6, 4, 2])
array([[1, 0, 0, 0],
       [0, 1, 0, 0]])
```

Binary targets transform to a column vector

```pycon
>>> label_binarize(['yes', 'no', 'no', 'yes'], classes=['no', 'yes'])
array([[1],
       [0],
       [0],
       [1]])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<!-- thumbnail-parent-div-close --></div>
