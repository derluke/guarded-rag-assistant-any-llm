# ledoit_wolf

### sklearn.covariance.ledoit_wolf(X, \*, assume_centered=False, block_size=1000)

Estimate the shrunk Ledoit-Wolf covariance matrix.

Read more in the [User Guide](../covariance.md#shrunk-covariance).

* **Parameters:**
  **X**
  : Data from which to compute the covariance estimate.

  **assume_centered**
  : If True, data will not be centered before computation.
    Useful to work with data whose mean is significantly equal to
    zero but is not exactly zero.
    If False, data will be centered before computation.

  **block_size**
  : Size of blocks into which the covariance matrix will be split.
    This is purely a memory optimization and does not affect results.
* **Returns:**
  **shrunk_cov**
  : Shrunk covariance.

  **shrinkage**
  : Coefficient in the convex combination used for the computation
    of the shrunk estimate.

### Notes

The regularized (shrunk) covariance is:

(1 - shrinkage) \* cov + shrinkage \* mu \* np.identity(n_features)

where mu = trace(cov) / n_features

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.covariance import empirical_covariance, ledoit_wolf
>>> real_cov = np.array([[.4, .2], [.2, .8]])
>>> rng = np.random.RandomState(0)
>>> X = rng.multivariate_normal(mean=[0, 0], cov=real_cov, size=50)
>>> covariance, shrinkage = ledoit_wolf(X)
>>> covariance
array([[0.44..., 0.16...],
       [0.16..., 0.80...]])
>>> shrinkage
np.float64(0.23...)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Using the GraphicalLasso estimator to learn a covariance and sparse precision from a small number of samples.">  <div class="sphx-glr-thumbnail-title">Sparse inverse covariance estimation</div>
</div>
* [Sparse inverse covariance estimation](../../auto_examples/covariance/plot_sparse_cov.md#sphx-glr-auto-examples-covariance-plot-sparse-cov-py)

<!-- thumbnail-parent-div-close --></div>
