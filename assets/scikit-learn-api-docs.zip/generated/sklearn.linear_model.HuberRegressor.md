# HuberRegressor

### *class* sklearn.linear_model.HuberRegressor(\*, epsilon=1.35, max_iter=100, alpha=0.0001, warm_start=False, fit_intercept=True, tol=1e-05)

L2-regularized linear regression model that is robust to outliers.

The Huber Regressor optimizes the squared loss for the samples where
`|(y - Xw - c) / sigma| < epsilon` and the absolute loss for the samples
where `|(y - Xw - c) / sigma| > epsilon`, where the model coefficients
`w`, the intercept `c` and the scale `sigma` are parameters
to be optimized. The parameter `sigma` makes sure that if `y` is scaled up
or down by a certain factor, one does not need to rescale `epsilon` to
achieve the same robustness. Note that this does not take into account
the fact that the different features of `X` may be of different scales.

The Huber loss function has the advantage of not being heavily influenced
by the outliers while not completely ignoring their effect.

Read more in the [User Guide](../linear_model.md#huber-regression)

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **epsilon**
  : The parameter epsilon controls the number of samples that should be
    classified as outliers. The smaller the epsilon, the more robust it is
    to outliers. Epsilon must be in the range `[1, inf)`.

  **max_iter**
  : Maximum number of iterations that
    `scipy.optimize.minimize(method="L-BFGS-B")` should run for.

  **alpha**
  : Strength of the squared L2 regularization. Note that the penalty is
    equal to `alpha * ||w||^2`.
    Must be in the range `[0, inf)`.

  **warm_start**
  : This is useful if the stored attributes of a previously used model
    has to be reused. If set to False, then the coefficients will
    be rewritten for every call to fit.
    See [the Glossary](../../glossary.md#term-warm_start).

  **fit_intercept**
  : Whether or not to fit the intercept. This can be set to False
    if the data is already centered around the origin.

  **tol**
  : The iteration will stop when
    `max{|proj g_i | i = 1, ..., n}` <= `tol`
    where pg_i is the i-th component of the projected gradient.
* **Attributes:**
  **coef_**
  : Features got by optimizing the L2-regularized Huber loss.

  **intercept_**
  : Bias.

  **scale_**
  : The value by which `|y - Xw - c|` is scaled down.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Number of iterations that
    `scipy.optimize.minimize(method="L-BFGS-B")` has run for.
    <br/>
    #### Versionchanged
    Changed in version 0.20: In SciPy <= 1.0.0 the number of lbfgs iterations may exceed
    `max_iter`. `n_iter_` will now report at most `max_iter`.

  **outliers_**
  : A boolean mask which is set to True where the samples are identified
    as outliers.

#### SEE ALSO
[`RANSACRegressor`](sklearn.linear_model.RANSACRegressor.md#sklearn.linear_model.RANSACRegressor)
: RANSAC (RANdom SAmple Consensus) algorithm.

[`TheilSenRegressor`](sklearn.linear_model.TheilSenRegressor.md#sklearn.linear_model.TheilSenRegressor)
: Theil-Sen Estimator robust multivariate regression model.

[`SGDRegressor`](sklearn.linear_model.SGDRegressor.md#sklearn.linear_model.SGDRegressor)
: Fitted by minimizing a regularized empirical loss with SGD.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.linear_model import HuberRegressor, LinearRegression
>>> from sklearn.datasets import make_regression
>>> rng = np.random.RandomState(0)
>>> X, y, coef = make_regression(
...     n_samples=200, n_features=2, noise=4.0, coef=True, random_state=0)
>>> X[:4] = rng.uniform(10, 20, (4, 2))
>>> y[:4] = rng.uniform(10, 20, 4)
>>> huber = HuberRegressor().fit(X, y)
>>> huber.score(X, y)
-7.284...
>>> huber.predict(X[:1,])
array([806.7200...])
>>> linear = LinearRegression().fit(X, y)
>>> print("True coefficients:", coef)
True coefficients: [20.4923...  34.1698...]
>>> print("Huber coefficients:", huber.coef_)
Huber coefficients: [17.7906... 31.0106...]
>>> print("Linear Regression coefficients:", linear.coef_)
Linear Regression coefficients: [-1.9221...  7.0226...]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the model according to the given training data.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target vector relative to X.

  **sample_weight**
  : Weight given to each sample.
* **Returns:**
  **self**
  : Fitted `HuberRegressor` estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [HuberRegressor](#sklearn.linear_model.HuberRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [HuberRegressor](#sklearn.linear_model.HuberRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Fit Ridge and HuberRegressor on a dataset with outliers.">  <div class="sphx-glr-thumbnail-title">HuberRegressor vs Ridge on dataset with strong outliers</div>
</div>
* [HuberRegressor vs Ridge on dataset with strong outliers](../../auto_examples/linear_model/plot_huber_vs_ridge.md#sphx-glr-auto-examples-linear-model-plot-huber-vs-ridge-py)

<div class="sphx-glr-thumbcontainer" tooltip="A model that overfits learns the training data too well, capturing both the underlying patterns and the noise in the data. However, when applied to unseen data, the learned associations may not hold. We normally detect this when we apply our trained predictions to the test data and see the statistical performance drop significantly compared to the training data.">  <div class="sphx-glr-thumbnail-title">Ridge coefficients as a function of the L2 Regularization</div>
</div>
* [Ridge coefficients as a function of the L2 Regularization](../../auto_examples/linear_model/plot_ridge_coeffs.md#sphx-glr-auto-examples-linear-model-plot-ridge-coeffs-py)

<div class="sphx-glr-thumbcontainer" tooltip="Here a sine function is fit with a polynomial of order 3, for values close to zero.">  <div class="sphx-glr-thumbnail-title">Robust linear estimator fitting</div>
</div>
* [Robust linear estimator fitting](../../auto_examples/linear_model/plot_robust_fit.md#sphx-glr-auto-examples-linear-model-plot-robust-fit-py)

<!-- thumbnail-parent-div-close --></div>
