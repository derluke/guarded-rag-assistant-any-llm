# PassiveAggressiveClassifier

### *class* sklearn.linear_model.PassiveAggressiveClassifier(\*, C=1.0, fit_intercept=True, max_iter=1000, tol=0.001, early_stopping=False, validation_fraction=0.1, n_iter_no_change=5, shuffle=True, verbose=0, loss='hinge', n_jobs=None, random_state=None, warm_start=False, class_weight=None, average=False)

Passive Aggressive Classifier.

Read more in the [User Guide](../linear_model.md#passive-aggressive).

* **Parameters:**
  **C**
  : Maximum step size (regularization). Defaults to 1.0.

  **fit_intercept**
  : Whether the intercept should be estimated or not. If False, the
    data is assumed to be already centered.

  **max_iter**
  : The maximum number of passes over the training data (aka epochs).
    It only impacts the behavior in the `fit` method, and not the
    [`partial_fit`](#sklearn.linear_model.PassiveAggressiveClassifier.partial_fit) method.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **tol**
  : The stopping criterion. If it is not None, the iterations will stop
    when (loss > previous_loss - tol).
    <br/>
    #### Versionadded
    Added in version 0.19.

  **early_stopping**
  : Whether to use early stopping to terminate training when validation
    score is not improving. If set to True, it will automatically set aside
    a stratified fraction of training data as validation and terminate
    training when validation score is not improving by at least `tol` for
    `n_iter_no_change` consecutive epochs.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **validation_fraction**
  : The proportion of training data to set aside as validation set for
    early stopping. Must be between 0 and 1.
    Only used if early_stopping is True.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **n_iter_no_change**
  : Number of iterations with no improvement to wait before early stopping.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **shuffle**
  : Whether or not the training data should be shuffled after each epoch.

  **verbose**
  : The verbosity level.

  **loss**
  : The loss function to be used:
    hinge: equivalent to PA-I in the reference paper.
    squared_hinge: equivalent to PA-II in the reference paper.

  **n_jobs**
  : The number of CPUs to use to do the OVA (One Versus All, for
    multi-class problems) computation.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **random_state**
  : Used to shuffle the training data, when `shuffle` is set to
    `True`. Pass an int for reproducible output across multiple
    function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **warm_start**
  : When set to True, reuse the solution of the previous call to fit as
    initialization, otherwise, just erase the previous solution.
    See [the Glossary](../../glossary.md#term-warm_start).
    <br/>
    Repeatedly calling fit or partial_fit when warm_start is True can
    result in a different solution than when calling fit a single time
    because of the way the data is shuffled.

  **class_weight**
  : Preset for the class_weight fit parameter.
    <br/>
    Weights associated with classes. If not given, all classes
    are supposed to have weight one.
    <br/>
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`.
    <br/>
    #### Versionadded
    Added in version 0.17: parameter *class_weight* to automatically weight samples.

  **average**
  : When set to True, computes the averaged SGD weights and stores the
    result in the `coef_` attribute. If set to an int greater than 1,
    averaging will begin once the total number of samples seen reaches
    average. So average=10 will begin averaging after seeing 10 samples.
    <br/>
    #### Versionadded
    Added in version 0.19: parameter *average* to use weights averaging in SGD.
* **Attributes:**
  **coef_**
  : Weights assigned to the features.

  **intercept_**
  : Constants in decision function.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : The actual number of iterations to reach the stopping criterion.
    For multiclass fits, it is the maximum over every binary fit.

  **classes_**
  : The unique classes labels.

  **t_**
  : Number of weight updates performed during training.
    Same as `(n_iter_ * n_samples + 1)`.

#### SEE ALSO
[`SGDClassifier`](sklearn.linear_model.SGDClassifier.md#sklearn.linear_model.SGDClassifier)
: Incrementally trained logistic regression.

[`Perceptron`](sklearn.linear_model.Perceptron.md#sklearn.linear_model.Perceptron)
: Linear perceptron classifier.

### References

Online Passive-Aggressive Algorithms
<[http://jmlr.csail.mit.edu/papers/volume7/crammer06a/crammer06a.pdf](http://jmlr.csail.mit.edu/papers/volume7/crammer06a/crammer06a.pdf)>
K. Crammer, O. Dekel, J. Keshat, S. Shalev-Shwartz, Y. Singer - JMLR (2006)

### Examples

```pycon
>>> from sklearn.linear_model import PassiveAggressiveClassifier
>>> from sklearn.datasets import make_classification
>>> X, y = make_classification(n_features=4, random_state=0)
>>> clf = PassiveAggressiveClassifier(max_iter=1000, random_state=0,
... tol=1e-3)
>>> clf.fit(X, y)
PassiveAggressiveClassifier(random_state=0)
>>> print(clf.coef_)
[[0.26642044 0.45070924 0.67251877 0.64185414]]
>>> print(clf.intercept_)
[1.84127814]
>>> print(clf.predict([[0, 0, 0, 0]]))
[1]
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Predict confidence scores for samples.

The confidence score for a sample is proportional to the signed
distance of that sample to the hyperplane.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the confidence scores.
* **Returns:**
  **scores**
  : Confidence scores per `(n_samples, n_classes)` combination. In the
    binary case, confidence score for `self.classes_[1]` where >0 means
    this class would be predicted.

<!-- !! processed by numpydoc !! -->

#### densify()

Convert coefficient matrix to dense array format.

Converts the `coef_` member (back) to a numpy.ndarray. This is the
default format of `coef_` and is required for fitting, so calling
this method is only required on models that have previously been
sparsified; otherwise, it is a no-op.

* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, coef_init=None, intercept_init=None)

Fit linear model with Passive Aggressive algorithm.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **coef_init**
  : The initial coefficients to warm-start the optimization.

  **intercept_init**
  : The initial intercept to warm-start the optimization.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y, classes=None)

Fit linear model with Passive Aggressive algorithm.

* **Parameters:**
  **X**
  : Subset of the training data.

  **y**
  : Subset of the target values.

  **classes**
  : Classes across all calls to partial_fit.
    Can be obtained by via `np.unique(y_all)`, where y_all is the
    target vector of the entire dataset.
    This argument is required for the first call to partial_fit
    and can be omitted in the subsequent calls.
    Note that y doesn’t need to contain all labels in `classes`.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict class labels for samples in X.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the predictions.
* **Returns:**
  **y_pred**
  : Vector containing the class labels for each sample.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, coef_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', intercept_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PassiveAggressiveClassifier](#sklearn.linear_model.PassiveAggressiveClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **coef_init**
  : Metadata routing for `coef_init` parameter in `fit`.

  **intercept_init**
  : Metadata routing for `intercept_init` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, classes: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PassiveAggressiveClassifier](#sklearn.linear_model.PassiveAggressiveClassifier)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **classes**
  : Metadata routing for `classes` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PassiveAggressiveClassifier](#sklearn.linear_model.PassiveAggressiveClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### sparsify()

Convert coefficient matrix to sparse format.

Converts the `coef_` member to a scipy.sparse matrix, which for
L1-regularized models can be much more memory- and storage-efficient
than the usual numpy.ndarray representation.

The `intercept_` member is not converted.

* **Returns:**
  self
  : Fitted estimator.

### Notes

For non-sparse models, i.e. when there are not many zeros in `coef_`,
this may actually *increase* memory usage, so use this method with
care. A rule of thumb is that the number of zero elements, which can
be computed with `(coef_ == 0).sum()`, must be more than 50% for this
to provide significant benefits.

After calling this method, further fitting with the partial_fit
method (if any) will not work until you call densify.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used for classification using an out-of-core approach: learning from data that doesn&#x27;t fit into main memory. We make use of an online classifier, i.e., one that supports the partial_fit method, that will be fed with batches of examples. To guarantee that the features space remains the same over time we leverage a HashingVectorizer that will project each example into the same feature space. This is especially useful in the case of text classification where new features (words) may appear in each batch.">  <div class="sphx-glr-thumbnail-title">Out-of-core classification of text documents</div>
</div>
* [Out-of-core classification of text documents](../../auto_examples/applications/plot_out_of_core_classification.md#sphx-glr-auto-examples-applications-plot-out-of-core-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparing various online solvers">  <div class="sphx-glr-thumbnail-title">Comparing various online solvers</div>
</div>
* [Comparing various online solvers](../../auto_examples/linear_model/plot_sgd_comparison.md#sphx-glr-auto-examples-linear-model-plot-sgd-comparison-py)

<!-- thumbnail-parent-div-close --></div>
