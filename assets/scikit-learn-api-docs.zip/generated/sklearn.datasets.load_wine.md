# load_wine

### sklearn.datasets.load_wine(\*, return_X_y=False, as_frame=False)

Load and return the wine dataset (classification).

#### Versionadded
Added in version 0.18.

The wine dataset is a classic and very easy multi-class classification
dataset.

| Classes           | 3              |
|-------------------|----------------|
| Samples per class | [59,71,48]     |
| Samples total     | 178            |
| Dimensionality    | 13             |
| Features          | real, positive |

The copy of UCI ML Wine Data Set dataset is downloaded and modified to fit
standard format from:
[https://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data](https://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data)

Read more in the [User Guide](../../datasets/toy_dataset.md#wine-dataset).

* **Parameters:**
  **return_X_y**
  : If True, returns `(data, target)` instead of a Bunch object.
    See below for more information about the `data` and `target` object.

  **as_frame**
  : If True, the data is a pandas DataFrame including columns with
    appropriate dtypes (numeric). The target is
    a pandas DataFrame or Series depending on the number of target columns.
    If `return_X_y` is True, then (`data`, `target`) will be pandas
    DataFrames or Series as described below.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : The data matrix. If `as_frame=True`, `data` will be a pandas
      DataFrame.
    <br/>
    target: {ndarray, Series} of shape (178,)
    : The classification target. If `as_frame=True`, `target` will be
      a pandas Series.
    <br/>
    feature_names: list
    : The names of the dataset columns.
    <br/>
    target_names: list
    : The names of target classes.
    <br/>
    frame: DataFrame of shape (178, 14)
    : Only present when `as_frame=True`. DataFrame with `data` and
      `target`.
      <br/>
      #### Versionadded
      Added in version 0.23.
    <br/>
    DESCR: str
    : The full description of the dataset.

  **(data, target)**
  : A tuple of two ndarrays by default. The first contains a 2D array of shape
    (178, 13) with each row representing one sample and each column representing
    the features. The second array of shape (178,) contains the target samples.

### Examples

Let’s say you are interested in the samples 10, 80, and 140, and want to
know their class name.

```pycon
>>> from sklearn.datasets import load_wine
>>> data = load_wine()
>>> data.target[[10, 80, 140]]
array([0, 1, 2])
>>> list(data.target_names)
[np.str_('class_0'), np.str_('class_1'), np.str_('class_2')]
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the need for robust covariance estimation on a real data set. It is useful both for outlier detection and for a better understanding of the data structure.">  <div class="sphx-glr-thumbnail-title">Outlier detection on a real data set</div>
</div>
* [Outlier detection on a real data set](../../auto_examples/applications/plot_outlier_detection_wine.md#sphx-glr-auto-examples-applications-plot-outlier-detection-wine-py)

<div class="sphx-glr-thumbcontainer" tooltip="ROC Curve with Visualization API">  <div class="sphx-glr-thumbnail-title">ROC Curve with Visualization API</div>
</div>
* [ROC Curve with Visualization API](../../auto_examples/miscellaneous/plot_roc_curve_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-roc-curve-visualization-api-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature scaling through standardization, also called Z-score normalization, is an important preprocessing step for many machine learning algorithms. It involves rescaling each feature such that it has a standard deviation of 1 and a mean of 0.">  <div class="sphx-glr-thumbnail-title">Importance of Feature Scaling</div>
</div>
* [Importance of Feature Scaling](../../auto_examples/preprocessing/plot_scaling_importance.md#sphx-glr-auto-examples-preprocessing-plot-scaling-importance-py)

<!-- thumbnail-parent-div-close --></div>
