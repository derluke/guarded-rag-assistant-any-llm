# GaussianProcessRegressor

### *class* sklearn.gaussian_process.GaussianProcessRegressor(kernel=None, \*, alpha=1e-10, optimizer='fmin_l_bfgs_b', n_restarts_optimizer=0, normalize_y=False, copy_X_train=True, n_targets=None, random_state=None)

Gaussian process regression (GPR).

The implementation is based on Algorithm 2.1 of [[RW2006]](#rf75674b0f418-rw2006).

In addition to standard scikit-learn estimator API,
[`GaussianProcessRegressor`](#sklearn.gaussian_process.GaussianProcessRegressor):

* allows prediction without prior fitting (based on the GP prior)
* provides an additional method `sample_y(X)`, which evaluates samples
  drawn from the GPR (prior or posterior) at given inputs
* exposes a method `log_marginal_likelihood(theta)`, which can be used
  externally for other ways of selecting hyperparameters, e.g., via
  Markov chain Monte Carlo.

To learn the difference between a point-estimate approach vs. a more
Bayesian modelling approach, refer to the example entitled
[Comparison of kernel ridge and Gaussian process regression](../../auto_examples/gaussian_process/plot_compare_gpr_krr.md#sphx-glr-auto-examples-gaussian-process-plot-compare-gpr-krr-py).

Read more in the [User Guide](../gaussian_process.md#gaussian-process).

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **kernel**
  : The kernel specifying the covariance function of the GP. If None is
    passed, the kernel `ConstantKernel(1.0, constant_value_bounds="fixed")
    * RBF(1.0, length_scale_bounds="fixed")` is used as default. Note that
    the kernel hyperparameters are optimized during fitting unless the
    bounds are marked as “fixed”.

  **alpha**
  : Value added to the diagonal of the kernel matrix during fitting.
    This can prevent a potential numerical issue during fitting, by
    ensuring that the calculated values form a positive definite matrix.
    It can also be interpreted as the variance of additional Gaussian
    measurement noise on the training observations. Note that this is
    different from using a `WhiteKernel`. If an array is passed, it must
    have the same number of entries as the data used for fitting and is
    used as datapoint-dependent noise level. Allowing to specify the
    noise level directly as a parameter is mainly for convenience and
    for consistency with [`Ridge`](sklearn.linear_model.Ridge.md#sklearn.linear_model.Ridge).

  **optimizer**
  : Can either be one of the internally supported optimizers for optimizing
    the kernel’s parameters, specified by a string, or an externally
    defined optimizer passed as a callable. If a callable is passed, it
    must have the signature:
    ```default
    def optimizer(obj_func, initial_theta, bounds):
        # * 'obj_func': the objective function to be minimized, which
        #   takes the hyperparameters theta as a parameter and an
        #   optional flag eval_gradient, which determines if the
        #   gradient is returned additionally to the function value
        # * 'initial_theta': the initial value for theta, which can be
        #   used by local optimizers
        # * 'bounds': the bounds on the values of theta
        ....
        # Returned are the best found hyperparameters theta and
        # the corresponding value of the target function.
        return theta_opt, func_min
    ```
    <br/>
    Per default, the L-BFGS-B algorithm from `scipy.optimize.minimize`
    is used. If None is passed, the kernel’s parameters are kept fixed.
    Available internal optimizers are: `{'fmin_l_bfgs_b'}`.

  **n_restarts_optimizer**
  : The number of restarts of the optimizer for finding the kernel’s
    parameters which maximize the log-marginal likelihood. The first run
    of the optimizer is performed from the kernel’s initial parameters,
    the remaining ones (if any) from thetas sampled log-uniform randomly
    from the space of allowed theta-values. If greater than 0, all bounds
    must be finite. Note that `n_restarts_optimizer == 0` implies that one
    run is performed.

  **normalize_y**
  : Whether or not to normalize the target values `y` by removing the mean
    and scaling to unit-variance. This is recommended for cases where
    zero-mean, unit-variance priors are used. Note that, in this
    implementation, the normalisation is reversed before the GP predictions
    are reported.
    <br/>
    #### Versionchanged
    Changed in version 0.23.

  **copy_X_train**
  : If True, a persistent copy of the training data is stored in the
    object. Otherwise, just a reference to the training data is stored,
    which might cause predictions to change if the data is modified
    externally.

  **n_targets**
  : The number of dimensions of the target values. Used to decide the number
    of outputs when sampling from the prior distributions (i.e. calling
    [`sample_y`](#sklearn.gaussian_process.GaussianProcessRegressor.sample_y) before [`fit`](#sklearn.gaussian_process.GaussianProcessRegressor.fit)). This parameter is ignored once
    [`fit`](#sklearn.gaussian_process.GaussianProcessRegressor.fit) has been called.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **random_state**
  : Determines random number generation used to initialize the centers.
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **X_train_**
  : Feature vectors or other representations of training data (also
    required for prediction).

  **y_train_**
  : Target values in training data (also required for prediction).

  **kernel_**
  : The kernel used for prediction. The structure of the kernel is the
    same as the one passed as parameter but with optimized hyperparameters.

  **L_**
  : Lower-triangular Cholesky decomposition of the kernel in `X_train_`.

  **alpha_**
  : Dual coefficients of training data points in kernel space.

  **log_marginal_likelihood_value_**
  : The log-marginal-likelihood of `self.kernel_.theta`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`GaussianProcessClassifier`](sklearn.gaussian_process.GaussianProcessClassifier.md#sklearn.gaussian_process.GaussianProcessClassifier)
: Gaussian process classification (GPC) based on Laplace approximation.

### References

### Examples

```pycon
>>> from sklearn.datasets import make_friedman2
>>> from sklearn.gaussian_process import GaussianProcessRegressor
>>> from sklearn.gaussian_process.kernels import DotProduct, WhiteKernel
>>> X, y = make_friedman2(n_samples=500, noise=0, random_state=0)
>>> kernel = DotProduct() + WhiteKernel()
>>> gpr = GaussianProcessRegressor(kernel=kernel,
...         random_state=0).fit(X, y)
>>> gpr.score(X, y)
0.3680...
>>> gpr.predict(X[:2,:], return_std=True)
(array([653.0..., 592.1...]), array([316.6..., 316.6...]))
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit Gaussian process regression model.

* **Parameters:**
  **X**
  : Feature vectors or other representations of training data.

  **y**
  : Target values.
* **Returns:**
  **self**
  : GaussianProcessRegressor class instance.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### log_marginal_likelihood(theta=None, eval_gradient=False, clone_kernel=True)

Return log-marginal likelihood of theta for training data.

* **Parameters:**
  **theta**
  : Kernel hyperparameters for which the log-marginal likelihood is
    evaluated. If None, the precomputed log_marginal_likelihood
    of `self.kernel_.theta` is returned.

  **eval_gradient**
  : If True, the gradient of the log-marginal likelihood with respect
    to the kernel hyperparameters at position theta is returned
    additionally. If True, theta must not be None.

  **clone_kernel**
  : If True, the kernel attribute is copied. If False, the kernel
    attribute is modified, but may result in a performance improvement.
* **Returns:**
  **log_likelihood**
  : Log-marginal likelihood of theta for training data.

  **log_likelihood_gradient**
  : Gradient of the log-marginal likelihood with respect to the kernel
    hyperparameters at position theta.
    Only returned when eval_gradient is True.

<!-- !! processed by numpydoc !! -->

#### predict(X, return_std=False, return_cov=False)

Predict using the Gaussian process regression model.

We can also predict based on an unfitted model by using the GP prior.
In addition to the mean of the predictive distribution, optionally also
returns its standard deviation (`return_std=True`) or covariance
(`return_cov=True`). Note that at most one of the two can be requested.

* **Parameters:**
  **X**
  : Query points where the GP is evaluated.

  **return_std**
  : If True, the standard-deviation of the predictive distribution at
    the query points is returned along with the mean.

  **return_cov**
  : If True, the covariance of the joint predictive distribution at
    the query points is returned along with the mean.
* **Returns:**
  **y_mean**
  : Mean of predictive distribution at query points.

  **y_std**
  : Standard deviation of predictive distribution at query points.
    Only returned when `return_std` is True.

  **y_cov**
  : Covariance of joint predictive distribution at query points.
    Only returned when `return_cov` is True.

<!-- !! processed by numpydoc !! -->

#### sample_y(X, n_samples=1, random_state=0)

Draw samples from Gaussian process and evaluate at X.

* **Parameters:**
  **X**
  : Query points where the GP is evaluated.

  **n_samples**
  : Number of samples drawn from the Gaussian process per query point.

  **random_state**
  : Determines random number generation to randomly draw samples.
    Pass an int for reproducible results across multiple function
    calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **y_samples**
  : Values of n_samples samples drawn from Gaussian process and
    evaluated at query points.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_predict_request(\*, return_cov: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', return_std: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [GaussianProcessRegressor](#sklearn.gaussian_process.GaussianProcessRegressor)

Request metadata passed to the `predict` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `predict` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `predict`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **return_cov**
  : Metadata routing for `return_cov` parameter in `predict`.

  **return_std**
  : Metadata routing for `return_std` parameter in `predict`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [GaussianProcessRegressor](#sklearn.gaussian_process.GaussianProcessRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows the ability of the WhiteKernel to estimate the noise level in the data. Moreover, we show the importance of kernel hyperparameters initialization.">  <div class="sphx-glr-thumbnail-title">Ability of Gaussian process regression (GPR) to estimate data noise-level</div>
</div>
* [Ability of Gaussian process regression (GPR) to estimate data noise-level](../../auto_examples/gaussian_process/plot_gpr_noisy.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-noisy-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates differences between a kernel ridge regression and a Gaussian process regression.">  <div class="sphx-glr-thumbnail-title">Comparison of kernel ridge and Gaussian process regression</div>
</div>
* [Comparison of kernel ridge and Gaussian process regression](../../auto_examples/gaussian_process/plot_compare_gpr_krr.md#sphx-glr-auto-examples-gaussian-process-plot-compare-gpr-krr-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example is based on Section 5.4.3 of &quot;Gaussian Processes for Machine Learning&quot; [1]_. It illustrates an example of complex kernel engineering and hyperparameter optimization using gradient ascent on the log-marginal-likelihood. The data consists of the monthly average atmospheric CO2 concentrations (in parts per million by volume (ppm)) collected at the Mauna Loa Observatory in Hawaii, between 1958 and 2001. The objective is to model the CO2 concentration as a function of the time t and extrapolate for years after 2001.">  <div class="sphx-glr-thumbnail-title">Forecasting of CO2 level on Mona Loa dataset using Gaussian process regression (GPR)</div>
</div>
* [Forecasting of CO2 level on Mona Loa dataset using Gaussian process regression (GPR)](../../auto_examples/gaussian_process/plot_gpr_co2.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-co2-py)

<div class="sphx-glr-thumbcontainer" tooltip="A simple one-dimensional regression example computed in two different ways:">  <div class="sphx-glr-thumbnail-title">Gaussian Processes regression: basic introductory example</div>
</div>
* [Gaussian Processes regression: basic introductory example](../../auto_examples/gaussian_process/plot_gpr_noisy_targets.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-noisy-targets-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Gaussian processes for regression and classification tasks on data that are not in fixed-length feature vector form. This is achieved through the use of kernel functions that operates directly on discrete structures such as variable-length sequences, trees, and graphs.">  <div class="sphx-glr-thumbnail-title">Gaussian processes on discrete data structures</div>
</div>
* [Gaussian processes on discrete data structures](../../auto_examples/gaussian_process/plot_gpr_on_structured_data.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-on-structured-data-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the prior and posterior of a GaussianProcessRegressor with different kernels. Mean, standard deviation, and 5 samples are shown for both prior and posterior distributions.">  <div class="sphx-glr-thumbnail-title">Illustration of prior and posterior Gaussian process for different kernels</div>
</div>
* [Illustration of prior and posterior Gaussian process for different kernels](../../auto_examples/gaussian_process/plot_gpr_prior_posterior.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-prior-posterior-py)

<!-- thumbnail-parent-div-close --></div>
