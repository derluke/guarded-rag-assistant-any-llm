# make_union

### sklearn.pipeline.make_union(\*transformers, n_jobs=None, verbose=False)

Construct a [`FeatureUnion`](sklearn.pipeline.FeatureUnion.md#sklearn.pipeline.FeatureUnion) from the given transformers.

This is a shorthand for the [`FeatureUnion`](sklearn.pipeline.FeatureUnion.md#sklearn.pipeline.FeatureUnion) constructor; it does not
require, and does not permit, naming the transformers. Instead, they will
be given names automatically based on their types. It also does not allow
weighting.

* **Parameters:**
  **\*transformers**
  : One or more estimators.

  **n_jobs**
  : Number of jobs to run in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionchanged
    Changed in version v0.20: `n_jobs` default changed from 1 to None.

  **verbose**
  : If True, the time elapsed while fitting each transformer will be
    printed as it is completed.
* **Returns:**
  **f**
  : A [`FeatureUnion`](sklearn.pipeline.FeatureUnion.md#sklearn.pipeline.FeatureUnion) object for concatenating the results of multiple
    transformer objects.

#### SEE ALSO
[`FeatureUnion`](sklearn.pipeline.FeatureUnion.md#sklearn.pipeline.FeatureUnion)
: Class for concatenating the results of multiple transformer objects.

### Examples

```pycon
>>> from sklearn.decomposition import PCA, TruncatedSVD
>>> from sklearn.pipeline import make_union
>>> make_union(PCA(), TruncatedSVD())
 FeatureUnion(transformer_list=[('pca', PCA()),
                               ('truncatedsvd', TruncatedSVD())])
```

<!-- !! processed by numpydoc !! -->
