# chi2_kernel

### sklearn.metrics.pairwise.chi2_kernel(X, Y=None, gamma=1.0)

Compute the exponential chi-squared kernel between X and Y.

The chi-squared kernel is computed between each pair of rows in X and Y.  X
and Y have to be non-negative. This kernel is most commonly applied to
histograms.

The chi-squared kernel is given by:

```text
k(x, y) = exp(-gamma Sum [(x - y)^2 / (x + y)])
```

It can be interpreted as a weighted difference per entry.

Read more in the [User Guide](../metrics.md#chi2-kernel).

* **Parameters:**
  **X**
  : A feature array.

  **Y**
  : An optional second feature array. If `None`, uses `Y=X`.

  **gamma**
  : Scaling parameter of the chi2 kernel.
* **Returns:**
  **kernel**
  : The kernel matrix.

#### SEE ALSO
[`additive_chi2_kernel`](sklearn.metrics.pairwise.additive_chi2_kernel.md#sklearn.metrics.pairwise.additive_chi2_kernel)
: The additive version of this kernel.

[`sklearn.kernel_approximation.AdditiveChi2Sampler`](sklearn.kernel_approximation.AdditiveChi2Sampler.md#sklearn.kernel_approximation.AdditiveChi2Sampler)
: A Fourier approximation to the additive version of this kernel.

### References

* Zhang, J. and Marszalek, M. and Lazebnik, S. and Schmid, C.
  Local features and kernels for classification of texture and object
  categories: A comprehensive study
  International Journal of Computer Vision 2007
  [https://hal.archives-ouvertes.fr/hal-00171412/document](https://hal.archives-ouvertes.fr/hal-00171412/document)

### Examples

```pycon
>>> from sklearn.metrics.pairwise import chi2_kernel
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> chi2_kernel(X, Y)
array([[0.36..., 0.13...],
       [0.13..., 0.36...]])
```

<!-- !! processed by numpydoc !! -->
