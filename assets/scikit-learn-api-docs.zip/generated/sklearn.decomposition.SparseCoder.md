# SparseCoder

### *class* sklearn.decomposition.SparseCoder(dictionary, \*, transform_algorithm='omp', transform_n_nonzero_coefs=None, transform_alpha=None, split_sign=False, n_jobs=None, positive_code=False, transform_max_iter=1000)

Sparse coding.

Finds a sparse representation of data against a fixed, precomputed
dictionary.

Each row of the result is the solution to a sparse coding problem.
The goal is to find a sparse array `code` such that:

```default
X ~= code * dictionary
```

Read more in the [User Guide](../decomposition.md#sparsecoder).

* **Parameters:**
  **dictionary**
  : The dictionary atoms used for sparse coding. Lines are assumed to be
    normalized to unit norm.

  **transform_algorithm**
  : Algorithm used to transform the data:
    - `'lars'`: uses the least angle regression method
      (`linear_model.lars_path`);
    - `'lasso_lars'`: uses Lars to compute the Lasso solution;
    - `'lasso_cd'`: uses the coordinate descent method to compute the
      Lasso solution (linear_model.Lasso). `'lasso_lars'` will be faster if
      the estimated components are sparse;
    - `'omp'`: uses orthogonal matching pursuit to estimate the sparse
      solution;
    - `'threshold'`: squashes to zero all coefficients less than alpha from
      the projection `dictionary * X'`.

  **transform_n_nonzero_coefs**
  : Number of nonzero coefficients to target in each column of the
    solution. This is only used by `algorithm='lars'` and `algorithm='omp'`
    and is overridden by `alpha` in the `omp` case. If `None`, then
    `transform_n_nonzero_coefs=int(n_features / 10)`.

  **transform_alpha**
  : If `algorithm='lasso_lars'` or `algorithm='lasso_cd'`, `alpha` is the
    penalty applied to the L1 norm.
    If `algorithm='threshold'`, `alpha` is the absolute value of the
    threshold below which coefficients will be squashed to zero.
    If `algorithm='omp'`, `alpha` is the tolerance parameter: the value of
    the reconstruction error targeted. In this case, it overrides
    `n_nonzero_coefs`.
    If `None`, default to 1.

  **split_sign**
  : Whether to split the sparse feature vector into the concatenation of
    its negative part and its positive part. This can improve the
    performance of downstream classifiers.

  **n_jobs**
  : Number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **positive_code**
  : Whether to enforce positivity when finding the code.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **transform_max_iter**
  : Maximum number of iterations to perform if `algorithm='lasso_cd'` or
    `lasso_lars`.
    <br/>
    #### Versionadded
    Added in version 0.22.
* **Attributes:**
  [`n_components_`](#sklearn.decomposition.SparseCoder.n_components_)
  : Number of atoms.

  [`n_features_in_`](#sklearn.decomposition.SparseCoder.n_features_in_)
  : Number of features seen during `fit`.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`DictionaryLearning`](sklearn.decomposition.DictionaryLearning.md#sklearn.decomposition.DictionaryLearning)
: Find a dictionary that sparsely encodes data.

[`MiniBatchDictionaryLearning`](sklearn.decomposition.MiniBatchDictionaryLearning.md#sklearn.decomposition.MiniBatchDictionaryLearning)
: A faster, less accurate, version of the dictionary learning algorithm.

[`MiniBatchSparsePCA`](sklearn.decomposition.MiniBatchSparsePCA.md#sklearn.decomposition.MiniBatchSparsePCA)
: Mini-batch Sparse Principal Components Analysis.

[`SparsePCA`](sklearn.decomposition.SparsePCA.md#sklearn.decomposition.SparsePCA)
: Sparse Principal Components Analysis.

[`sparse_encode`](sklearn.decomposition.sparse_encode.md#sklearn.decomposition.sparse_encode)
: Sparse coding where each row of the result is the solution to a sparse coding problem.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.decomposition import SparseCoder
>>> X = np.array([[-1, -1, -1], [0, 0, 3]])
>>> dictionary = np.array(
...     [[0, 1, 0],
...      [-1, -1, 2],
...      [1, 1, 1],
...      [0, 1, 1],
...      [0, 2, 1]],
...    dtype=np.float64
... )
>>> coder = SparseCoder(
...     dictionary=dictionary, transform_algorithm='lasso_lars',
...     transform_alpha=1e-10,
... )
>>> coder.transform(X)
array([[ 0.,  0., -1.,  0.,  0.],
       [ 0.,  1.,  1.,  0.,  0.]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Do nothing and return the estimator unchanged.

This method is just there to implement the usual API and hence
work in pipelines.

* **Parameters:**
  **X**
  : Not used, present for API consistency by convention.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_components_

Number of atoms.

<!-- !! processed by numpydoc !! -->

#### *property* n_features_in_

Number of features seen during `fit`.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X, y=None)

Encode the data as a sparse combination of the dictionary atoms.

Coding method is determined by the object parameter
`transform_algorithm`.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **X_new**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Transform a signal as a sparse combination of Ricker wavelets. This example visually compares different sparse coding methods using the SparseCoder estimator. The Ricker (also known as Mexican hat or the second derivative of a Gaussian) is not a particularly good kernel to represent piecewise constant signals like this one. It can therefore be seen how much adding different widths of atoms matters and it therefore motivates learning the dictionary to best fit your type of signals.">  <div class="sphx-glr-thumbnail-title">Sparse coding with a precomputed dictionary</div>
</div>
* [Sparse coding with a precomputed dictionary](../../auto_examples/decomposition/plot_sparse_coding.md#sphx-glr-auto-examples-decomposition-plot-sparse-coding-py)

<!-- thumbnail-parent-div-close --></div>
