# HistGradientBoostingRegressor

### *class* sklearn.ensemble.HistGradientBoostingRegressor(loss='squared_error', \*, quantile=None, learning_rate=0.1, max_iter=100, max_leaf_nodes=31, max_depth=None, min_samples_leaf=20, l2_regularization=0.0, max_features=1.0, max_bins=255, categorical_features='from_dtype', monotonic_cst=None, interaction_cst=None, warm_start=False, early_stopping='auto', scoring='loss', validation_fraction=0.1, n_iter_no_change=10, tol=1e-07, verbose=0, random_state=None)

Histogram-based Gradient Boosting Regression Tree.

This estimator is much faster than
[`GradientBoostingRegressor`](sklearn.ensemble.GradientBoostingRegressor.md#sklearn.ensemble.GradientBoostingRegressor)
for big datasets (n_samples >= 10 000).

This estimator has native support for missing values (NaNs). During
training, the tree grower learns at each split point whether samples
with missing values should go to the left or right child, based on the
potential gain. When predicting, samples with missing values are
assigned to the left or right child consequently. If no missing values
were encountered for a given feature during training, then samples with
missing values are mapped to whichever child has the most samples.
See [Features in Histogram Gradient Boosting Trees](../../auto_examples/ensemble/plot_hgbt_regression.md#sphx-glr-auto-examples-ensemble-plot-hgbt-regression-py) for a
usecase example of this feature.

This implementation is inspired by
[LightGBM](https://github.com/Microsoft/LightGBM).

Read more in the [User Guide](../ensemble.md#histogram-based-gradient-boosting).

#### Versionadded
Added in version 0.21.

* **Parameters:**
  **loss**
  : The loss function to use in the boosting process. Note that the
    “squared error”, “gamma” and “poisson” losses actually implement
    “half least squares loss”, “half gamma deviance” and “half poisson
    deviance” to simplify the computation of the gradient. Furthermore,
    “gamma” and “poisson” losses internally use a log-link, “gamma”
    requires `y > 0` and “poisson” requires `y >= 0`.
    “quantile” uses the pinball loss.
    <br/>
    #### Versionchanged
    Changed in version 0.23: Added option ‘poisson’.
    <br/>
    #### Versionchanged
    Changed in version 1.1: Added option ‘quantile’.
    <br/>
    #### Versionchanged
    Changed in version 1.3: Added option ‘gamma’.

  **quantile**
  : If loss is “quantile”, this parameter specifies which quantile to be estimated
    and must be between 0 and 1.

  **learning_rate**
  : The learning rate, also known as *shrinkage*. This is used as a
    multiplicative factor for the leaves values. Use `1` for no
    shrinkage.

  **max_iter**
  : The maximum number of iterations of the boosting process, i.e. the
    maximum number of trees.

  **max_leaf_nodes**
  : The maximum number of leaves for each tree. Must be strictly greater
    than 1. If None, there is no maximum limit.

  **max_depth**
  : The maximum depth of each tree. The depth of a tree is the number of
    edges to go from the root to the deepest leaf.
    Depth isn’t constrained by default.

  **min_samples_leaf**
  : The minimum number of samples per leaf. For small datasets with less
    than a few hundred samples, it is recommended to lower this value
    since only very shallow trees would be built.

  **l2_regularization**
  : The L2 regularization parameter penalizing leaves with small hessians.
    Use `0` for no regularization (default).

  **max_features**
  : Proportion of randomly chosen features in each and every node split.
    This is a form of regularization, smaller values make the trees weaker
    learners and might prevent overfitting.
    If interaction constraints from `interaction_cst` are present, only allowed
    features are taken into account for the subsampling.
    <br/>
    #### Versionadded
    Added in version 1.4.

  **max_bins**
  : The maximum number of bins to use for non-missing values. Before
    training, each feature of the input array `X` is binned into
    integer-valued bins, which allows for a much faster training stage.
    Features with a small number of unique values may use less than
    `max_bins` bins. In addition to the `max_bins` bins, one more bin
    is always reserved for missing values. Must be no larger than 255.

  **categorical_features**
  : Indicates the categorical features.
    - None : no feature will be considered categorical.
    - boolean array-like : boolean mask indicating categorical features.
    - integer array-like : integer indices indicating categorical
      features.
    - str array-like: names of categorical features (assuming the training
      data has feature names).
    - `"from_dtype"`: dataframe columns with dtype “category” are
      considered to be categorical features. The input must be an object
      exposing a `__dataframe__` method such as pandas or polars
      DataFrames to use this feature.
    <br/>
    For each categorical feature, there must be at most `max_bins` unique
    categories. Negative values for categorical features encoded as numeric
    dtypes are treated as missing values. All categorical values are
    converted to floating point numbers. This means that categorical values
    of 1.0 and 1 are treated as the same category.
    <br/>
    Read more in the [User Guide](../ensemble.md#categorical-support-gbdt).
    <br/>
    #### Versionadded
    Added in version 0.24.
    <br/>
    #### Versionchanged
    Changed in version 1.2: Added support for feature names.
    <br/>
    #### Versionchanged
    Changed in version 1.4: Added `"from_dtype"` option.
    <br/>
    #### Versionchanged
    Changed in version 1.6: The default value changed from `None` to `"from_dtype"`.

  **monotonic_cst**
  : Monotonic constraint to enforce on each feature are specified using the
    following integer values:
    - 1: monotonic increase
    - 0: no constraint
    - -1: monotonic decrease
    <br/>
    If a dict with str keys, map feature to monotonic constraints by name.
    If an array, the features are mapped to constraints by position. See
    [Using feature names to specify monotonic constraints](../../auto_examples/ensemble/plot_monotonic_constraints.md#monotonic-cst-features-names) for a usage example.
    <br/>
    Read more in the [User Guide](../ensemble.md#monotonic-cst-gbdt).
    <br/>
    #### Versionadded
    Added in version 0.23.
    <br/>
    #### Versionchanged
    Changed in version 1.2: Accept dict of constraints with feature names as keys.

  **interaction_cst**
  : Specify interaction constraints, the sets of features which can
    interact with each other in child node splits.
    <br/>
    Each item specifies the set of feature indices that are allowed
    to interact with each other. If there are more features than
    specified in these constraints, they are treated as if they were
    specified as an additional set.
    <br/>
    The strings “pairwise” and “no_interactions” are shorthands for
    allowing only pairwise or no interactions, respectively.
    <br/>
    For instance, with 5 features in total, `interaction_cst=[{0, 1}]`
    is equivalent to `interaction_cst=[{0, 1}, {2, 3, 4}]`,
    and specifies that each branch of a tree will either only split
    on features 0 and 1 or only split on features 2, 3 and 4.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **warm_start**
  : When set to `True`, reuse the solution of the previous call to fit
    and add more estimators to the ensemble. For results to be valid, the
    estimator should be re-trained on the same data only.
    See [the Glossary](../../glossary.md#term-warm_start).

  **early_stopping**
  : If ‘auto’, early stopping is enabled if the sample size is larger than
    10000. If True, early stopping is enabled, otherwise early stopping is
    disabled.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **scoring**
  : Scoring parameter to use for early stopping. It can be a single
    string (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter)) or a callable (see
    [Callable scorers](../model_evaluation.md#scoring-callable)). If None, the estimator’s default scorer is used. If
    `scoring='loss'`, early stopping is checked w.r.t the loss value.
    Only used if early stopping is performed.

  **validation_fraction**
  : Proportion (or absolute size) of training data to set aside as
    validation data for early stopping. If None, early stopping is done on
    the training data. Only used if early stopping is performed.

  **n_iter_no_change**
  : Used to determine when to “early stop”. The fitting process is
    stopped when none of the last `n_iter_no_change` scores are better
    than the `n_iter_no_change - 1` -th-to-last one, up to some
    tolerance. Only used if early stopping is performed.

  **tol**
  : The absolute tolerance to use when comparing scores during early
    stopping. The higher the tolerance, the more likely we are to early
    stop: higher tolerance means that it will be harder for subsequent
    iterations to be considered an improvement upon the reference score.

  **verbose**
  : The verbosity level. If not zero, print some information about the
    fitting process. `1` prints only summary info, `2` prints info per
    iteration.

  **random_state**
  : Pseudo-random number generator to control the subsampling in the
    binning process, and the train/validation data split if early stopping
    is enabled.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **do_early_stopping_**
  : Indicates whether early stopping is used during training.

  [`n_iter_`](#sklearn.ensemble.HistGradientBoostingRegressor.n_iter_)
  : Number of iterations of the boosting process.

  **n_trees_per_iteration_**
  : The number of tree that are built at each iteration. For regressors,
    this is always 1.

  **train_score_**
  : The scores at each iteration on the training data. The first entry
    is the score of the ensemble before the first iteration. Scores are
    computed according to the `scoring` parameter. If `scoring` is
    not ‘loss’, scores are computed on a subset of at most 10 000
    samples. Empty if no early stopping.

  **validation_score_**
  : The scores at each iteration on the held-out validation data. The
    first entry is the score of the ensemble before the first iteration.
    Scores are computed according to the `scoring` parameter. Empty if
    no early stopping or if `validation_fraction` is None.

  **is_categorical_**
  : Boolean mask for the categorical features. `None` if there are no
    categorical features.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`GradientBoostingRegressor`](sklearn.ensemble.GradientBoostingRegressor.md#sklearn.ensemble.GradientBoostingRegressor)
: Exact gradient boosting method that does not scale as good on datasets with a large number of samples.

[`sklearn.tree.DecisionTreeRegressor`](sklearn.tree.DecisionTreeRegressor.md#sklearn.tree.DecisionTreeRegressor)
: A decision tree regressor.

[`RandomForestRegressor`](sklearn.ensemble.RandomForestRegressor.md#sklearn.ensemble.RandomForestRegressor)
: A meta-estimator that fits a number of decision tree regressors on various sub-samples of the dataset and uses averaging to improve the statistical performance and control over-fitting.

[`AdaBoostRegressor`](sklearn.ensemble.AdaBoostRegressor.md#sklearn.ensemble.AdaBoostRegressor)
: A meta-estimator that begins by fitting a regressor on the original dataset and then fits additional copies of the regressor on the same dataset but where the weights of instances are adjusted according to the error of the current prediction. As such, subsequent regressors focus more on difficult cases.

### Examples

```pycon
>>> from sklearn.ensemble import HistGradientBoostingRegressor
>>> from sklearn.datasets import load_diabetes
>>> X, y = load_diabetes(return_X_y=True)
>>> est = HistGradientBoostingRegressor().fit(X, y)
>>> est.score(X, y)
0.92...
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the gradient boosting model.

* **Parameters:**
  **X**
  : The input samples.

  **y**
  : Target values.

  **sample_weight**
  : Weights of training data.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_iter_

Number of iterations of the boosting process.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict values for X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **y**
  : The predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [HistGradientBoostingRegressor](#sklearn.ensemble.HistGradientBoostingRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [HistGradientBoostingRegressor](#sklearn.ensemble.HistGradientBoostingRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### staged_predict(X)

Predict regression target for each iteration.

This method allows monitoring (i.e. determine error on testing set)
after each stage.

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **X**
  : The input samples.
* **Yields:**
  **y**
  : The predicted values of the input samples, for each iteration.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Polars-engineered lagged features can be used for time series forecasting with HistGradientBoostingRegressor on the Bike Sharing Demand dataset.">  <div class="sphx-glr-thumbnail-title">Lagged features for time series forecasting</div>
</div>
* [Lagged features for time series forecasting](../../auto_examples/applications/plot_time_series_lagged_features.md#sphx-glr-auto-examples-applications-plot-time-series-lagged-features-py)

<div class="sphx-glr-thumbcontainer" tooltip="Demonstrate how model complexity influences both prediction accuracy and computational performance.">  <div class="sphx-glr-thumbnail-title">Model Complexity Influence</div>
</div>
* [Model Complexity Influence](../../auto_examples/applications/plot_model_complexity_influence.md#sphx-glr-auto-examples-applications-plot-model-complexity-influence-py)

<div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the training times and prediction performances of HistGradientBoostingRegressor with different encoding strategies for categorical features. In particular, we will evaluate:">  <div class="sphx-glr-thumbnail-title">Categorical Feature Support in Gradient Boosting</div>
</div>
* [Categorical Feature Support in Gradient Boosting](../../auto_examples/ensemble/plot_gradient_boosting_categorical.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-categorical-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the performance of Random Forest (RF) and Histogram Gradient Boosting (HGBT) models in terms of score and computation time for a regression dataset, though all the concepts here presented apply to classification as well.">  <div class="sphx-glr-thumbnail-title">Comparing Random Forests and Histogram Gradient Boosting models</div>
</div>
* [Comparing Random Forests and Histogram Gradient Boosting models](../../auto_examples/ensemble/plot_forest_hist_grad_boosting_comparison.md#sphx-glr-auto-examples-ensemble-plot-forest-hist-grad-boosting-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="histogram_based_gradient_boosting (HGBT) models may be one of the most useful supervised learning models in scikit-learn. They are based on a modern gradient boosting implementation comparable to LightGBM and XGBoost. As such, HGBT models are more feature rich than and often outperform alternative models like random forests, especially when the number of samples is larger than some ten thousands (see sphx_glr_auto_examples_ensemble_plot_forest_hist_grad_boosting_comparison.py).">  <div class="sphx-glr-thumbnail-title">Features in Histogram Gradient Boosting Trees</div>
</div>
* [Features in Histogram Gradient Boosting Trees](../../auto_examples/ensemble/plot_hgbt_regression.md#sphx-glr-auto-examples-ensemble-plot-hgbt-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates Gradient Boosting to produce a predictive model from an ensemble of weak predictive models. Gradient boosting can be used for regression and classification problems. Here, we will train a model to tackle a diabetes regression task. We will obtain the results from GradientBoostingRegressor with least squares loss and 500 regression trees of depth 4.">  <div class="sphx-glr-thumbnail-title">Gradient Boosting regression</div>
</div>
* [Gradient Boosting regression](../../auto_examples/ensemble/plot_gradient_boosting_regression.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of monotonic constraints on a gradient boosting estimator.">  <div class="sphx-glr-thumbnail-title">Monotonic Constraints</div>
</div>
* [Monotonic Constraints](../../auto_examples/ensemble/plot_monotonic_constraints.md#sphx-glr-auto-examples-ensemble-plot-monotonic-constraints-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how quantile regression can be used to create prediction intervals. See sphx_glr_auto_examples_ensemble_plot_hgbt_regression.py for an example showcasing some other features of HistGradientBoostingRegressor.">  <div class="sphx-glr-thumbnail-title">Prediction Intervals for Gradient Boosting Regression</div>
</div>
* [Prediction Intervals for Gradient Boosting Regression](../../auto_examples/ensemble/plot_gradient_boosting_quantile.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-quantile-py)

<div class="sphx-glr-thumbcontainer" tooltip="Partial dependence plots show the dependence between the target function [2]_ and a set of features of interest, marginalizing over the values of all other features (the complement features). Due to the limits of human perception, the size of the set of features of interest must be small (usually, one or two) thus they are usually chosen among the most important features.">  <div class="sphx-glr-thumbnail-title">Partial Dependence and Individual Conditional Expectation Plots</div>
</div>
* [Partial Dependence and Individual Conditional Expectation Plots](../../auto_examples/inspection/plot_partial_dependence.md#sphx-glr-auto-examples-inspection-plot-partial-dependence-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="The TargetEncoder uses the value of the target to encode each categorical feature. In this example, we will compare three different approaches for handling categorical features: TargetEncoder, OrdinalEncoder, OneHotEncoder and dropping the category.">  <div class="sphx-glr-thumbnail-title">Comparing Target Encoder with Other Encoders</div>
</div>
* [Comparing Target Encoder with Other Encoders](../../auto_examples/preprocessing/plot_target_encoder.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.3! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_3&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.3</div>
</div>
* [Release Highlights for scikit-learn 1.3](../../auto_examples/release_highlights/plot_release_highlights_1_3_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-3-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.2! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_2&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.2</div>
</div>
* [Release Highlights for scikit-learn 1.2](../../auto_examples/release_highlights/plot_release_highlights_1_2_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-2-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are very pleased to announce the release of scikit-learn 1.0! The library has been stable for quite some time, releasing version 1.0 is recognizing that and signalling it to our users. This release does not include any breaking changes apart from the usual two-release deprecation cycle. For the future, we do our best to keep this pattern.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.0</div>
</div>
* [Release Highlights for scikit-learn 1.0](../../auto_examples/release_highlights/plot_release_highlights_1_0_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-0-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<!-- thumbnail-parent-div-close --></div>
