# LassoCV

### *class* sklearn.linear_model.LassoCV(\*, eps=0.001, n_alphas=100, alphas=None, fit_intercept=True, precompute='auto', max_iter=1000, tol=0.0001, copy_X=True, cv=None, verbose=False, n_jobs=None, positive=False, random_state=None, selection='cyclic')

Lasso linear model with iterative fitting along a regularization path.

See glossary entry for [cross-validation estimator](../../glossary.md#term-cross-validation-estimator).

The best model is selected by cross-validation.

The optimization objective for Lasso is:

```default
(1 / (2 * n_samples)) * ||y - Xw||^2_2 + alpha * ||w||_1
```

Read more in the [User Guide](../linear_model.md#lasso).

* **Parameters:**
  **eps**
  : Length of the path. `eps=1e-3` means that
    `alpha_min / alpha_max = 1e-3`.

  **n_alphas**
  : Number of alphas along the regularization path.

  **alphas**
  : List of alphas where to compute the models.
    If `None` alphas are set automatically.

  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to false, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **precompute**
  : Whether to use a precomputed Gram matrix to speed up
    calculations. If set to `'auto'` let us decide. The Gram
    matrix can also be passed as argument.

  **max_iter**
  : The maximum number of iterations.

  **tol**
  : The tolerance for the optimization: if the updates are
    smaller than `tol`, the optimization code checks the
    dual gap for optimality and continues until it is smaller
    than `tol`.

  **copy_X**
  : If `True`, X will be copied; else, it may be overwritten.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross-validation,
    - int, to specify the number of folds.
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For int/None inputs, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value if None changed from 3-fold to 5-fold.

  **verbose**
  : Amount of verbosity.

  **n_jobs**
  : Number of CPUs to use during the cross validation.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **positive**
  : If positive, restrict regression coefficients to be positive.

  **random_state**
  : The seed of the pseudo random number generator that selects a random
    feature to update. Used when `selection` == ‘random’.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **selection**
  : If set to ‘random’, a random coefficient is updated every iteration
    rather than looping over features sequentially by default. This
    (setting to ‘random’) often leads to significantly faster convergence
    especially when tol is higher than 1e-4.
* **Attributes:**
  **alpha_**
  : The amount of penalization chosen by cross validation.

  **coef_**
  : Parameter vector (w in the cost function formula).

  **intercept_**
  : Independent term in decision function.

  **mse_path_**
  : Mean square error for the test set on each fold, varying alpha.

  **alphas_**
  : The grid of alphas used for fitting.

  **dual_gap_**
  : The dual gap at the end of the optimization for the optimal alpha
    (`alpha_`).

  **n_iter_**
  : Number of iterations run by the coordinate descent solver to reach
    the specified tolerance for the optimal alpha.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`lars_path`](sklearn.linear_model.lars_path.md#sklearn.linear_model.lars_path)
: Compute Least Angle Regression or Lasso path using LARS algorithm.

[`lasso_path`](sklearn.linear_model.lasso_path.md#sklearn.linear_model.lasso_path)
: Compute Lasso path with coordinate descent.

[`Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso)
: The Lasso is a linear model that estimates sparse coefficients.

[`LassoLars`](sklearn.linear_model.LassoLars.md#sklearn.linear_model.LassoLars)
: Lasso model fit with Least Angle Regression a.k.a. Lars.

[`LassoCV`](#sklearn.linear_model.LassoCV)
: Lasso linear model with iterative fitting along a regularization path.

[`LassoLarsCV`](sklearn.linear_model.LassoLarsCV.md#sklearn.linear_model.LassoLarsCV)
: Cross-validated Lasso using the LARS algorithm.

### Notes

In `fit`, once the best parameter `alpha` is found through
cross-validation, the model is fit again using the entire training set.

To avoid unnecessary memory duplication the `X` argument of the `fit`
method should be directly passed as a Fortran-contiguous numpy array.

For an example, see [examples/linear_model/plot_lasso_model_selection.py](../../auto_examples/linear_model/plot_lasso_model_selection.md#sphx-glr-auto-examples-linear-model-plot-lasso-model-selection-py).

[`LassoCV`](#sklearn.linear_model.LassoCV) leads to different results than a hyperparameter
search using [`GridSearchCV`](sklearn.model_selection.GridSearchCV.md#sklearn.model_selection.GridSearchCV) with a
[`Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso) model. In [`LassoCV`](#sklearn.linear_model.LassoCV), a model for a given
penalty `alpha` is warm started using the coefficients of the
closest model (trained at the previous iteration) on the
regularization path. It tends to speed up the hyperparameter
search.

### Examples

```pycon
>>> from sklearn.linear_model import LassoCV
>>> from sklearn.datasets import make_regression
>>> X, y = make_regression(noise=4, random_state=0)
>>> reg = LassoCV(cv=5, random_state=0).fit(X, y)
>>> reg.score(X, y)
0.9993...
>>> reg.predict(X[:1,])
array([-78.4951...])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, \*\*params)

Fit Lasso model with coordinate descent.

Fit is on grid of alphas and best alpha estimated by cross-validation.

* **Parameters:**
  **X**
  : Training data. Pass directly as Fortran-contiguous data
    to avoid unnecessary memory duplication. If y is mono-output,
    X can be sparse. Note that large sparse matrices and arrays
    requiring `int64` indices are not accepted.

  **y**
  : Target values.

  **sample_weight**
  : Sample weights used for fitting and evaluation of the weighted
    mean squared error of each cv-fold. Note that the cross validated
    MSE that is finally used to find the best model is the unweighted
    mean over the (weighted) MSEs of each test fold.

  **\*\*params**
  : Parameters to be passed to the CV splitter.
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Returns an instance of fitted model.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.4.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *static* path(X, y, \*, eps=0.001, n_alphas=100, alphas=None, precompute='auto', Xy=None, copy_X=True, coef_init=None, verbose=False, return_n_iter=False, positive=False, \*\*params)

Compute Lasso path with coordinate descent.

The Lasso optimization function varies for mono and multi-outputs.

For mono-output tasks it is:

```default
(1 / (2 * n_samples)) * ||y - Xw||^2_2 + alpha * ||w||_1
```

For multi-output tasks it is:

```default
(1 / (2 * n_samples)) * ||Y - XW||^2_Fro + alpha * ||W||_21
```

Where:

```default
||W||_21 = \sum_i \sqrt{\sum_j w_{ij}^2}
```

i.e. the sum of norm of each row.

Read more in the [User Guide](../linear_model.md#lasso).

* **Parameters:**
  **X**
  : Training data. Pass directly as Fortran-contiguous data to avoid
    unnecessary memory duplication. If `y` is mono-output then `X`
    can be sparse.

  **y**
  : Target values.

  **eps**
  : Length of the path. `eps=1e-3` means that
    `alpha_min / alpha_max = 1e-3`.

  **n_alphas**
  : Number of alphas along the regularization path.

  **alphas**
  : List of alphas where to compute the models.
    If `None` alphas are set automatically.

  **precompute**
  : Whether to use a precomputed Gram matrix to speed up
    calculations. If set to `'auto'` let us decide. The Gram
    matrix can also be passed as argument.

  **Xy**
  : Xy = np.dot(X.T, y) that can be precomputed. It is useful
    only when the Gram matrix is precomputed.

  **copy_X**
  : If `True`, X will be copied; else, it may be overwritten.

  **coef_init**
  : The initial values of the coefficients.

  **verbose**
  : Amount of verbosity.

  **return_n_iter**
  : Whether to return the number of iterations or not.

  **positive**
  : If set to True, forces coefficients to be positive.
    (Only allowed when `y.ndim == 1`).

  **\*\*params**
  : Keyword arguments passed to the coordinate descent solver.
* **Returns:**
  **alphas**
  : The alphas along the path where models are computed.

  **coefs**
  : Coefficients along the path.

  **dual_gaps**
  : The dual gaps at the end of the optimization for each alpha.

  **n_iters**
  : The number of iterations taken by the coordinate descent optimizer to
    reach the specified tolerance for each alpha.

#### SEE ALSO
[`lars_path`](sklearn.linear_model.lars_path.md#sklearn.linear_model.lars_path)
: Compute Least Angle Regression or Lasso path using LARS algorithm.

[`Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso)
: The Lasso is a linear model that estimates sparse coefficients.

[`LassoLars`](sklearn.linear_model.LassoLars.md#sklearn.linear_model.LassoLars)
: Lasso model fit with Least Angle Regression a.k.a. Lars.

[`LassoCV`](#sklearn.linear_model.LassoCV)
: Lasso linear model with iterative fitting along a regularization path.

[`LassoLarsCV`](sklearn.linear_model.LassoLarsCV.md#sklearn.linear_model.LassoLarsCV)
: Cross-validated Lasso using the LARS algorithm.

[`sklearn.decomposition.sparse_encode`](sklearn.decomposition.sparse_encode.md#sklearn.decomposition.sparse_encode)
: Estimator that can be used to transform signals into sparse linear combination of atoms from a fixed.

### Notes

For an example, see
[examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.py](../../auto_examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.md#sphx-glr-auto-examples-linear-model-plot-lasso-lasso-lars-elasticnet-path-py).

To avoid unnecessary memory duplication the X argument of the fit method
should be directly passed as a Fortran-contiguous numpy array.

Note that in certain cases, the Lars solver may be significantly
faster to implement this functionality. In particular, linear
interpolation can be used to retrieve model coefficients between the
values output by lars_path

### Examples

Comparing lasso_path and lars_path with interpolation:

```pycon
>>> import numpy as np
>>> from sklearn.linear_model import lasso_path
>>> X = np.array([[1, 2, 3.1], [2.3, 5.4, 4.3]]).T
>>> y = np.array([1, 2, 3.1])
>>> # Use lasso_path to compute a coefficient path
>>> _, coef_path, _ = lasso_path(X, y, alphas=[5., 1., .5])
>>> print(coef_path)
[[0.         0.         0.46874778]
 [0.2159048  0.4425765  0.23689075]]
```

```pycon
>>> # Now use lars_path and 1D linear interpolation to compute the
>>> # same path
>>> from sklearn.linear_model import lars_path
>>> alphas, active, coef_path_lars = lars_path(X, y, method='lasso')
>>> from scipy import interpolate
>>> coef_path_continuous = interpolate.interp1d(alphas[::-1],
...                                             coef_path_lars[:, ::-1])
>>> print(coef_path_continuous([5., 1., .5]))
[[0.         0.         0.46915237]
 [0.2159048  0.4425765  0.23668876]]
```

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LassoCV](#sklearn.linear_model.LassoCV)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LassoCV](#sklearn.linear_model.LassoCV)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="The present example compares three l1-based regression models on a synthetic signal obtained from sparse and correlated features that are further corrupted with additive gaussian noise:">  <div class="sphx-glr-thumbnail-title">L1-based models for Sparse Signals</div>
</div>
* [L1-based models for Sparse Signals](../../auto_examples/linear_model/plot_lasso_and_elasticnet.md#sphx-glr-auto-examples-linear-model-plot-lasso-and-elasticnet-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example focuses on model selection for Lasso models that are linear models with an L1 penalty for regression problems.">  <div class="sphx-glr-thumbnail-title">Lasso model selection: AIC-BIC / cross-validation</div>
</div>
* [Lasso model selection: AIC-BIC / cross-validation](../../auto_examples/linear_model/plot_lasso_model_selection.md#sphx-glr-auto-examples-linear-model-plot-lasso-model-selection-py)

<!-- thumbnail-parent-div-close --></div>
