# show_versions

### sklearn.show_versions()

Print useful debugging information”

#### Versionadded
Added in version 0.20.

### Examples

```pycon
>>> from sklearn import show_versions
>>> show_versions()  
```

<!-- !! processed by numpydoc !! -->
