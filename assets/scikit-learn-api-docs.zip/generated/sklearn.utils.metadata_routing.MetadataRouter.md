# MetadataRouter

### *class* sklearn.utils.metadata_routing.MetadataRouter(owner)

Stores and handles metadata routing for a router object.

This class is used by router objects to store and handle metadata routing.
Routing information is stored as a dictionary of the form `{"object_name":
RouteMappingPair(method_mapping, routing_info)}`, where `method_mapping`
is an instance of [`MethodMapping`](sklearn.utils.metadata_routing.MethodMapping.md#sklearn.utils.metadata_routing.MethodMapping) and
`routing_info` is either a
[`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) or a
[`MetadataRouter`](#sklearn.utils.metadata_routing.MetadataRouter) instance.

#### Versionadded
Added in version 1.3.

* **Parameters:**
  **owner**
  : The name of the object to which these requests belong.

<!-- !! processed by numpydoc !! -->

#### add(\*, method_mapping, \*\*objs)

Add named objects with their corresponding method mapping.

* **Parameters:**
  **method_mapping**
  : The mapping between the child and the parent’s methods.

  **\*\*objs**
  : A dictionary of objects from which metadata is extracted by calling
    [`get_routing_for_object`](sklearn.utils.metadata_routing.get_routing_for_object.md#sklearn.utils.metadata_routing.get_routing_for_object) on them.
* **Returns:**
  **self**
  : Returns `self`.

<!-- !! processed by numpydoc !! -->

#### add_self_request(obj)

Add `self` (as a consumer) to the routing.

This method is used if the router is also a consumer, and hence the
router itself needs to be included in the routing. The passed object
can be an estimator or a
[`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest).

A router should add itself using this method instead of `add` since it
should be treated differently than the other objects to which metadata
is routed by the router.

* **Parameters:**
  **obj**
  : This is typically the router instance, i.e. `self` in a
    `get_metadata_routing()` implementation. It can also be a
    `MetadataRequest` instance.
* **Returns:**
  **self**
  : Returns `self`.

<!-- !! processed by numpydoc !! -->

#### consumes(method, params)

Check whether the given parameters are consumed by the given method.

#### Versionadded
Added in version 1.4.

* **Parameters:**
  **method**
  : The name of the method to check.

  **params**
  : An iterable of parameters to check.
* **Returns:**
  **consumed**
  : A set of parameters which are consumed by the given method.

<!-- !! processed by numpydoc !! -->

#### route_params(\*, caller, params)

Return the input parameters requested by child objects.

The output of this method is a [`Bunch`](sklearn.utils.Bunch.md#sklearn.utils.Bunch), which includes the
metadata for all methods of each child object that is used in the router’s
`caller` method.

If the router is also a consumer, it also checks for warnings of
`self`’s/consumer’s requested metadata.

* **Parameters:**
  **caller**
  : The name of the method for which the parameters are requested and
    routed. If called inside the [fit](../../glossary.md#term-fit) method of a router, it
    would be `"fit"`.

  **params**
  : A dictionary of provided metadata.
* **Returns:**
  **params**
  : A [`Bunch`](sklearn.utils.Bunch.md#sklearn.utils.Bunch) of the form
    `{"object_name": {"method_name": {params: value}}}` which can be
    used to pass the required metadata to corresponding methods or
    corresponding child objects.

<!-- !! processed by numpydoc !! -->

#### validate_metadata(\*, method, params)

Validate given metadata for a method.

This raises a `TypeError` if some of the passed metadata are not
understood by child objects.

* **Parameters:**
  **method**
  : The name of the method for which the parameters are requested and
    routed. If called inside the [fit](../../glossary.md#term-fit) method of a router, it
    would be `"fit"`.

  **params**
  : A dictionary of provided metadata.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This document shows how you can use the metadata routing mechanism &lt;metadata_routing&gt; in scikit-learn to route metadata to the estimators, scorers, and CV splitters consuming them.">  <div class="sphx-glr-thumbnail-title">Metadata Routing</div>
</div>
* [Metadata Routing](../../auto_examples/miscellaneous/plot_metadata_routing.md#sphx-glr-auto-examples-miscellaneous-plot-metadata-routing-py)

<!-- thumbnail-parent-div-close --></div>
