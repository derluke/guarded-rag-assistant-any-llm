# make_column_transformer

### sklearn.compose.make_column_transformer(\*transformers, remainder='drop', sparse_threshold=0.3, n_jobs=None, verbose=False, verbose_feature_names_out=True, force_int_remainder_cols=True)

Construct a ColumnTransformer from the given transformers.

This is a shorthand for the ColumnTransformer constructor; it does not
require, and does not permit, naming the transformers. Instead, they will
be given names automatically based on their types. It also does not allow
weighting with `transformer_weights`.

Read more in the [User Guide](../compose.md#make-column-transformer).

* **Parameters:**
  **\*transformers**
  : Tuples of the form (transformer, columns) specifying the
    transformer objects to be applied to subsets of the data.
    <br/>
    transformer
    : Estimator must support [fit](../../glossary.md#term-fit) and [transform](../../glossary.md#term-transform).
      Special-cased strings ‘drop’ and ‘passthrough’ are accepted as
      well, to indicate to drop the columns or to pass them through
      untransformed, respectively.
    <br/>
    columns
    : Indexes the data on its second axis. Integers are interpreted as
      positional columns, while strings can reference DataFrame columns
      by name. A scalar string or int should be used where
      `transformer` expects X to be a 1d array-like (vector),
      otherwise a 2d array will be passed to the transformer.
      A callable is passed the input data `X` and can return any of the
      above. To select multiple columns by name or dtype, you can use
      [`make_column_selector`](sklearn.compose.make_column_selector.md#sklearn.compose.make_column_selector).

  **remainder**
  : By default, only the specified columns in `transformers` are
    transformed and combined in the output, and the non-specified
    columns are dropped. (default of `'drop'`).
    By specifying `remainder='passthrough'`, all remaining columns that
    were not specified in `transformers` will be automatically passed
    through. This subset of columns is concatenated with the output of
    the transformers.
    By setting `remainder` to be an estimator, the remaining
    non-specified columns will use the `remainder` estimator. The
    estimator must support [fit](../../glossary.md#term-fit) and [transform](../../glossary.md#term-transform).

  **sparse_threshold**
  : If the transformed output consists of a mix of sparse and dense data,
    it will be stacked as a sparse matrix if the density is lower than this
    value. Use `sparse_threshold=0` to always return dense.
    When the transformed output consists of all sparse or all dense data,
    the stacked result will be sparse or dense, respectively, and this
    keyword will be ignored.

  **n_jobs**
  : Number of jobs to run in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **verbose**
  : If True, the time elapsed while fitting each transformer will be
    printed as it is completed.

  **verbose_feature_names_out**
  : If True, [`ColumnTransformer.get_feature_names_out`](sklearn.compose.ColumnTransformer.md#sklearn.compose.ColumnTransformer.get_feature_names_out) will prefix
    all feature names with the name of the transformer that generated that
    feature.
    If False, [`ColumnTransformer.get_feature_names_out`](sklearn.compose.ColumnTransformer.md#sklearn.compose.ColumnTransformer.get_feature_names_out) will not
    prefix any feature names and will error if feature names are not
    unique.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **force_int_remainder_cols**
  : Force the columns of the last entry of `transformers_`, which
    corresponds to the “remainder” transformer, to always be stored as
    indices (int) rather than column names (str). See description of the
    `ColumnTransformer.transformers_` attribute for details.
    <br/>
    #### NOTE
    If you do not access the list of columns for the remainder columns
    in the `ColumnTransformer.transformers_` fitted attribute,
    you do not need to set this parameter.
    <br/>
    #### Versionadded
    Added in version 1.5.
    <br/>
    #### Versionchanged
    Changed in version 1.7: The default value for `force_int_remainder_cols` will change from
    `True` to `False` in version 1.7.
* **Returns:**
  **ct**
  : Returns a [`ColumnTransformer`](sklearn.compose.ColumnTransformer.md#sklearn.compose.ColumnTransformer) object.

#### SEE ALSO
[`ColumnTransformer`](sklearn.compose.ColumnTransformer.md#sklearn.compose.ColumnTransformer)
: Class that allows combining the outputs of multiple transformer objects used on column subsets of the data into a single feature space.

### Examples

```pycon
>>> from sklearn.preprocessing import StandardScaler, OneHotEncoder
>>> from sklearn.compose import make_column_transformer
>>> make_column_transformer(
...     (StandardScaler(), ['numerical_column']),
...     (OneHotEncoder(), ['categorical_column']))
ColumnTransformer(transformers=[('standardscaler', StandardScaler(...),
                                 ['numerical_column']),
                                ('onehotencoder', OneHotEncoder(...),
                                 ['categorical_column'])])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the training times and prediction performances of HistGradientBoostingRegressor with different encoding strategies for categorical features. In particular, we will evaluate:">  <div class="sphx-glr-thumbnail-title">Categorical Feature Support in Gradient Boosting</div>
</div>
* [Categorical Feature Support in Gradient Boosting](../../auto_examples/ensemble/plot_gradient_boosting_categorical.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-categorical-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates different ways estimators and pipelines can be displayed.">  <div class="sphx-glr-thumbnail-title">Displaying estimators and complex pipelines</div>
</div>
* [Displaying estimators and complex pipelines](../../auto_examples/miscellaneous/plot_estimator_representation.md#sphx-glr-auto-examples-miscellaneous-plot-estimator-representation-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<!-- thumbnail-parent-div-close --></div>
