# VotingClassifier

### *class* sklearn.ensemble.VotingClassifier(estimators, \*, voting='hard', weights=None, n_jobs=None, flatten_transform=True, verbose=False)

Soft Voting/Majority Rule classifier for unfitted estimators.

Read more in the [User Guide](../ensemble.md#voting-classifier).

#### Versionadded
Added in version 0.17.

* **Parameters:**
  **estimators**
  : Invoking the `fit` method on the `VotingClassifier` will fit clones
    of those original estimators that will be stored in the class attribute
    `self.estimators_`. An estimator can be set to `'drop'` using
    [`set_params`](#sklearn.ensemble.VotingClassifier.set_params).
    <br/>
    #### Versionchanged
    Changed in version 0.21: `'drop'` is accepted. Using None was deprecated in 0.22 and
    support was removed in 0.24.

  **voting**
  : If ‘hard’, uses predicted class labels for majority rule voting.
    Else if ‘soft’, predicts the class label based on the argmax of
    the sums of the predicted probabilities, which is recommended for
    an ensemble of well-calibrated classifiers.

  **weights**
  : Sequence of weights (`float` or `int`) to weight the occurrences of
    predicted class labels (`hard` voting) or class probabilities
    before averaging (`soft` voting). Uses uniform weights if `None`.

  **n_jobs**
  : The number of jobs to run in parallel for `fit`.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **flatten_transform**
  : Affects shape of transform output only when voting=’soft’
    If voting=’soft’ and flatten_transform=True, transform method returns
    matrix with shape (n_samples, n_classifiers \* n_classes). If
    flatten_transform=False, it returns
    (n_classifiers, n_samples, n_classes).

  **verbose**
  : If True, the time elapsed while fitting will be printed as it
    is completed.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Attributes:**
  **estimators_**
  : The collection of fitted sub-estimators as defined in `estimators`
    that are not ‘drop’.

  **named_estimators_**
  : Attribute to access any fitted sub-estimators by name.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **le_**
  : Transformer used to encode the labels during fit and decode during
    prediction.

  **classes_**
  : The classes labels.

  [`n_features_in_`](#sklearn.ensemble.VotingClassifier.n_features_in_)
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimators expose such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`VotingRegressor`](sklearn.ensemble.VotingRegressor.md#sklearn.ensemble.VotingRegressor)
: Prediction voting regressor.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.naive_bayes import GaussianNB
>>> from sklearn.ensemble import RandomForestClassifier, VotingClassifier
>>> clf1 = LogisticRegression(random_state=1)
>>> clf2 = RandomForestClassifier(n_estimators=50, random_state=1)
>>> clf3 = GaussianNB()
>>> X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
>>> y = np.array([1, 1, 1, 2, 2, 2])
>>> eclf1 = VotingClassifier(estimators=[
...         ('lr', clf1), ('rf', clf2), ('gnb', clf3)], voting='hard')
>>> eclf1 = eclf1.fit(X, y)
>>> print(eclf1.predict(X))
[1 1 1 2 2 2]
>>> np.array_equal(eclf1.named_estimators_.lr.predict(X),
...                eclf1.named_estimators_['lr'].predict(X))
True
>>> eclf2 = VotingClassifier(estimators=[
...         ('lr', clf1), ('rf', clf2), ('gnb', clf3)],
...         voting='soft')
>>> eclf2 = eclf2.fit(X, y)
>>> print(eclf2.predict(X))
[1 1 1 2 2 2]
```

To drop an estimator, [`set_params`](#sklearn.ensemble.VotingClassifier.set_params) can be used to remove it. Here we
dropped one of the estimators, resulting in 2 fitted estimators:

```pycon
>>> eclf2 = eclf2.set_params(lr='drop')
>>> eclf2 = eclf2.fit(X, y)
>>> len(eclf2.estimators_)
2
```

Setting `flatten_transform=True` with `voting='soft'` flattens output shape of
`transform`:

```pycon
>>> eclf3 = VotingClassifier(estimators=[
...        ('lr', clf1), ('rf', clf2), ('gnb', clf3)],
...        voting='soft', weights=[2,1,1],
...        flatten_transform=True)
>>> eclf3 = eclf3.fit(X, y)
>>> print(eclf3.predict(X))
[1 1 1 2 2 2]
>>> print(eclf3.transform(X).shape)
(6, 6)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*, sample_weight=None, \*\*fit_params)

Fit the estimators.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target values.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted.
    Note that this is supported only if all underlying estimators
    support sample weights.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **\*\*fit_params**
  : Parameters to pass to the underlying estimators.
    <br/>
    #### Versionadded
    Added in version 1.5: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Return class labels or probabilities for each estimator.

Return predictions for X for each estimator.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.5.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get the parameters of an estimator from the ensemble.

Returns the parameters given in the constructor as well as the
estimators contained within the `estimators` parameter.

* **Parameters:**
  **deep**
  : Setting it to True gets the various estimators and the parameters
    of the estimators as well.
* **Returns:**
  **params**
  : Parameter and estimator names mapped to their values or parameter
    names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_features_in_

Number of features seen during [fit](../../glossary.md#term-fit).

<!-- !! processed by numpydoc !! -->

#### *property* named_estimators

Dictionary to access any fitted sub-estimators by name.

* **Returns:**
  [`Bunch`](sklearn.utils.Bunch.md#sklearn.utils.Bunch)

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict class labels for X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **maj**
  : Predicted class labels.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Compute probabilities of possible outcomes for samples in X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **avg**
  : Weighted average probability for each class per sample.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [VotingClassifier](#sklearn.ensemble.VotingClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of an estimator from the ensemble.

Valid parameter keys can be listed with `get_params()`. Note that you
can directly set the parameters of the estimators contained in
`estimators`.

* **Parameters:**
  **\*\*params**
  : Specific parameters using e.g.
    `set_params(parameter_name=new_value)`. In addition, to setting the
    parameters of the estimator, the individual estimator of the
    estimators can also be set, or can be removed by setting them to
    ‘drop’.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [VotingClassifier](#sklearn.ensemble.VotingClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Return class labels or probabilities for X for each estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  probabilities_or_labels
  : If `voting='soft'` and `flatten_transform=True`:
    : returns ndarray of shape (n_samples, n_classifiers \* n_classes),
      being class probabilities calculated by each classifier.
    <br/>
    If `voting='soft' and `flatten_transform=False`:
    : ndarray of shape (n_classifiers, n_samples, n_classes)
    <br/>
    If `voting='hard'`:
    : ndarray of shape (n_samples, n_classifiers), being
      class labels predicted by each classifier.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Plot the class probabilities of the first sample in a toy dataset predicted by three different classifiers and averaged by the VotingClassifier.">  <div class="sphx-glr-thumbnail-title">Plot class probabilities calculated by the VotingClassifier</div>
</div>
* [Plot class probabilities calculated by the VotingClassifier](../../auto_examples/ensemble/plot_voting_probas.md#sphx-glr-auto-examples-ensemble-plot-voting-probas-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision boundaries of a VotingClassifier for two features of the Iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision boundaries of a VotingClassifier</div>
</div>
* [Plot the decision boundaries of a VotingClassifier](../../auto_examples/ensemble/plot_voting_decision_regions.md#sphx-glr-auto-examples-ensemble-plot-voting-decision-regions-py)

<!-- thumbnail-parent-div-close --></div>
