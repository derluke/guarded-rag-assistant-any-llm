# SpectralCoclustering

### *class* sklearn.cluster.SpectralCoclustering(n_clusters=3, \*, svd_method='randomized', n_svd_vecs=None, mini_batch=False, init='k-means++', n_init=10, random_state=None)

Spectral Co-Clustering algorithm (Dhillon, 2001).

Clusters rows and columns of an array `X` to solve the relaxed
normalized cut of the bipartite graph created from `X` as follows:
the edge between row vertex `i` and column vertex `j` has weight
`X[i, j]`.

The resulting bicluster structure is block-diagonal, since each
row and each column belongs to exactly one bicluster.

Supports sparse matrices, as long as they are nonnegative.

Read more in the [User Guide](../biclustering.md#spectral-coclustering).

* **Parameters:**
  **n_clusters**
  : The number of biclusters to find.

  **svd_method**
  : Selects the algorithm for finding singular vectors. May be
    ‘randomized’ or ‘arpack’. If ‘randomized’, use
    [`sklearn.utils.extmath.randomized_svd`](sklearn.utils.extmath.randomized_svd.md#sklearn.utils.extmath.randomized_svd), which may be faster
    for large matrices. If ‘arpack’, use
    [`scipy.sparse.linalg.svds`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.svds.html#scipy.sparse.linalg.svds), which is more accurate, but
    possibly slower in some cases.

  **n_svd_vecs**
  : Number of vectors to use in calculating the SVD. Corresponds
    to `ncv` when `svd_method=arpack` and `n_oversamples` when
    `svd_method` is ‘randomized\`.

  **mini_batch**
  : Whether to use mini-batch k-means, which is faster but may get
    different results.

  **init**
  : Method for initialization of k-means algorithm; defaults to
    ‘k-means++’.

  **n_init**
  : Number of random initializations that are tried with the
    k-means algorithm.
    <br/>
    If mini-batch k-means is used, the best initialization is
    chosen and the algorithm runs once. Otherwise, the algorithm
    is run for each initialization and the best solution chosen.

  **random_state**
  : Used for randomizing the singular value decomposition and the k-means
    initialization. Use an int to make the randomness deterministic.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **rows_**
  : Results of the clustering. `rows[i, r]` is True if
    cluster `i` contains row `r`. Available only after calling `fit`.

  **columns_**
  : Results of the clustering, like `rows`.

  **row_labels_**
  : The bicluster label of each row.

  **column_labels_**
  : The bicluster label of each column.

  [`biclusters_`](#sklearn.cluster.SpectralCoclustering.biclusters_)
  : Convenient way to get row and column indicators together.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`SpectralBiclustering`](sklearn.cluster.SpectralBiclustering.md#sklearn.cluster.SpectralBiclustering)
: Partitions rows and columns under the assumption that the data has an underlying checkerboard structure.

### References

* [Dhillon, Inderjit S, 2001. Co-clustering documents and words using
  bipartite spectral graph partitioning.](https://doi.org/10.1145/502512.502550)

### Examples

```pycon
>>> from sklearn.cluster import SpectralCoclustering
>>> import numpy as np
>>> X = np.array([[1, 1], [2, 1], [1, 0],
...               [4, 7], [3, 5], [3, 6]])
>>> clustering = SpectralCoclustering(n_clusters=2, random_state=0).fit(X)
>>> clustering.row_labels_ 
array([0, 1, 1, 0, 0, 0], dtype=int32)
>>> clustering.column_labels_ 
array([0, 0], dtype=int32)
>>> clustering
SpectralCoclustering(n_clusters=2, random_state=0)
```

<!-- !! processed by numpydoc !! -->

#### *property* biclusters_

Convenient way to get row and column indicators together.

Returns the `rows_` and `columns_` members.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Create a biclustering for X.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : SpectralBiclustering instance.

<!-- !! processed by numpydoc !! -->

#### get_indices(i)

Row and column indices of the `i`’th bicluster.

Only works if `rows_` and `columns_` attributes exist.

* **Parameters:**
  **i**
  : The index of the cluster.
* **Returns:**
  **row_ind**
  : Indices of rows in the dataset that belong to the bicluster.

  **col_ind**
  : Indices of columns in the dataset that belong to the bicluster.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_shape(i)

Shape of the `i`’th bicluster.

* **Parameters:**
  **i**
  : The index of the cluster.
* **Returns:**
  **n_rows**
  : Number of rows in the bicluster.

  **n_cols**
  : Number of columns in the bicluster.

<!-- !! processed by numpydoc !! -->

#### get_submatrix(i, data)

Return the submatrix corresponding to bicluster `i`.

* **Parameters:**
  **i**
  : The index of the cluster.

  **data**
  : The data.
* **Returns:**
  **submatrix**
  : The submatrix corresponding to bicluster `i`.

### Notes

Works with sparse matrices. Only works if `rows_` and
`columns_` attributes exist.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to generate a dataset and bicluster it using the Spectral Co-Clustering algorithm.">  <div class="sphx-glr-thumbnail-title">A demo of the Spectral Co-Clustering algorithm</div>
</div>
* [A demo of the Spectral Co-Clustering algorithm](../../auto_examples/bicluster/plot_spectral_coclustering.md#sphx-glr-auto-examples-bicluster-plot-spectral-coclustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the Spectral Co-clustering algorithm on the twenty newsgroups dataset. The &#x27;comp.os.ms-windows.misc&#x27; category is excluded because it contains many posts containing nothing but data.">  <div class="sphx-glr-thumbnail-title">Biclustering documents with the Spectral Co-clustering algorithm</div>
</div>
* [Biclustering documents with the Spectral Co-clustering algorithm](../../auto_examples/bicluster/plot_bicluster_newsgroups.md#sphx-glr-auto-examples-bicluster-plot-bicluster-newsgroups-py)

<!-- thumbnail-parent-div-close --></div>
