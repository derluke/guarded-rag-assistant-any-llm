# load_diabetes

### sklearn.datasets.load_diabetes(\*, return_X_y=False, as_frame=False, scaled=True)

Load and return the diabetes dataset (regression).

| Samples total   | 442                |
|-----------------|--------------------|
| Dimensionality  | 10                 |
| Features        | real, -.2 < x < .2 |
| Targets         | integer 25 - 346   |

#### NOTE
The meaning of each feature (i.e. `feature_names`) might be unclear
(especially for `ltg`) as the documentation of the original dataset is
not explicit. We provide information that seems correct in regard with
the scientific literature in this field of research.

Read more in the [User Guide](../../datasets/toy_dataset.md#diabetes-dataset).

* **Parameters:**
  **return_X_y**
  : If True, returns `(data, target)` instead of a Bunch object.
    See below for more information about the `data` and `target` object.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **as_frame**
  : If True, the data is a pandas DataFrame including columns with
    appropriate dtypes (numeric). The target is
    a pandas DataFrame or Series depending on the number of target columns.
    If `return_X_y` is True, then (`data`, `target`) will be pandas
    DataFrames or Series as described below.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **scaled**
  : If True, the feature variables are mean centered and scaled by the
    standard deviation times the square root of `n_samples`.
    If False, raw data is returned for the feature variables.
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : The data matrix. If `as_frame=True`, `data` will be a pandas
      DataFrame.
    <br/>
    target: {ndarray, Series} of shape (442,)
    : The regression target. If `as_frame=True`, `target` will be
      a pandas Series.
    <br/>
    feature_names: list
    : The names of the dataset columns.
    <br/>
    frame: DataFrame of shape (442, 11)
    : Only present when `as_frame=True`. DataFrame with `data` and
      `target`.
      <br/>
      #### Versionadded
      Added in version 0.23.
    <br/>
    DESCR: str
    : The full description of the dataset.
    <br/>
    data_filename: str
    : The path to the location of the data.
    <br/>
    target_filename: str
    : The path to the location of the target.

  **(data, target)**
  : Returns a tuple of two ndarray of shape (n_samples, n_features)
    A 2D array with each row representing one sample and each column
    representing the features and/or target of a given sample.
    <br/>
    #### Versionadded
    Added in version 0.18.

### Examples

```pycon
>>> from sklearn.datasets import load_diabetes
>>> diabetes = load_diabetes()
>>> diabetes.target[:3]
array([151.,  75., 141.])
>>> diabetes.data.shape
(442, 10)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Demonstrate how model complexity influences both prediction accuracy and computational performance.">  <div class="sphx-glr-thumbnail-title">Model Complexity Influence</div>
</div>
* [Model Complexity Influence](../../auto_examples/applications/plot_model_complexity_influence.md#sphx-glr-auto-examples-applications-plot-model-complexity-influence-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates Gradient Boosting to produce a predictive model from an ensemble of weak predictive models. Gradient boosting can be used for regression and classification problems. Here, we will train a model to tackle a diabetes regression task. We will obtain the results from GradientBoostingRegressor with least squares loss and 500 regression trees of depth 4.">  <div class="sphx-glr-thumbnail-title">Gradient Boosting regression</div>
</div>
* [Gradient Boosting regression](../../auto_examples/ensemble/plot_gradient_boosting_regression.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="A voting regressor is an ensemble meta-estimator that fits several base regressors, each on the whole dataset. Then it averages the individual predictions to form a final prediction. We will use three different regressors to predict the data: GradientBoostingRegressor, RandomForestRegressor, and LinearRegression). Then the above 3 regressors will be used for the VotingRegressor.">  <div class="sphx-glr-thumbnail-title">Plot individual and voting regression predictions</div>
</div>
* [Plot individual and voting regression predictions](../../auto_examples/ensemble/plot_voting_regressor.md#sphx-glr-auto-examples-ensemble-plot-voting-regressor-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares two approaches for feature selection: SelectFromModel which is based on feature importance, and SequentialFeatureSelector which relies on a greedy approach.">  <div class="sphx-glr-thumbnail-title">Model-based and sequential feature selection</div>
</div>
* [Model-based and sequential feature selection](../../auto_examples/feature_selection/plot_select_from_model_diabetes.md#sphx-glr-auto-examples-feature-selection-plot-select-from-model-diabetes-py)

<div class="sphx-glr-thumbcontainer" tooltip="Missing values can be replaced by the mean, the median or the most frequent value using the basic SimpleImputer.">  <div class="sphx-glr-thumbnail-title">Imputing missing values before building an estimator</div>
</div>
* [Imputing missing values before building an estimator](../../auto_examples/impute/plot_missing_values.md#sphx-glr-auto-examples-impute-plot-missing-values-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example reproduces the example of Fig. 2 of [ZHT2007]_. A LassoLarsIC estimator is fit on a diabetes dataset and the AIC and the BIC criteria are used to select the best model.">  <div class="sphx-glr-thumbnail-title">Lasso model selection via information criteria</div>
</div>
* [Lasso model selection via information criteria](../../auto_examples/linear_model/plot_lasso_lars_ic.md#sphx-glr-auto-examples-linear-model-plot-lasso-lars-ic-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example focuses on model selection for Lasso models that are linear models with an L1 penalty for regression problems.">  <div class="sphx-glr-thumbnail-title">Lasso model selection: AIC-BIC / cross-validation</div>
</div>
* [Lasso model selection: AIC-BIC / cross-validation](../../auto_examples/linear_model/plot_lasso_model_selection.md#sphx-glr-auto-examples-linear-model-plot-lasso-model-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to compute the &quot;paths&quot; of coefficients along the Lasso, Lasso-LARS, and Elastic Net regularization paths. In other words, it shows the relationship between the regularization parameter (alpha) and the coefficients.">  <div class="sphx-glr-thumbnail-title">Lasso, Lasso-LARS, and Elastic Net paths</div>
</div>
* [Lasso, Lasso-LARS, and Elastic Net paths](../../auto_examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.md#sphx-glr-auto-examples-linear-model-plot-lasso-lasso-lars-elasticnet-path-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use the ordinary least squares (OLS) model called LinearRegression in scikit-learn.">  <div class="sphx-glr-thumbnail-title">Ordinary Least Squares Example</div>
</div>
* [Ordinary Least Squares Example](../../auto_examples/linear_model/plot_ols.md#sphx-glr-auto-examples-linear-model-plot-ols-py)

<div class="sphx-glr-thumbcontainer" tooltip="    See also sphx_glr_auto_examples_miscellaneous_plot_roc_curve_visualization_api.py">  <div class="sphx-glr-thumbnail-title">Advanced Plotting With Partial Dependence</div>
</div>
* [Advanced Plotting With Partial Dependence](../../auto_examples/miscellaneous/plot_partial_dependence_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-partial-dependence-visualization-api-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use cross_val_predict together with PredictionErrorDisplay to visualize prediction errors.">  <div class="sphx-glr-thumbnail-title">Plotting Cross-Validated Predictions</div>
</div>
* [Plotting Cross-Validated Predictions](../../auto_examples/model_selection/plot_cv_predict.md#sphx-glr-auto-examples-model-selection-plot-cv-predict-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.2! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_2&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.2</div>
</div>
* [Release Highlights for scikit-learn 1.2](../../auto_examples/release_highlights/plot_release_highlights_1_2_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-2-0-py)

<!-- thumbnail-parent-div-close --></div>
