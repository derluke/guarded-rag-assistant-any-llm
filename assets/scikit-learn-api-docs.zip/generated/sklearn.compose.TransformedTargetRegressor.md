# TransformedTargetRegressor

### *class* sklearn.compose.TransformedTargetRegressor(regressor=None, \*, transformer=None, func=None, inverse_func=None, check_inverse=True)

Meta-estimator to regress on a transformed target.

Useful for applying a non-linear transformation to the target `y` in
regression problems. This transformation can be given as a Transformer
such as the [`QuantileTransformer`](sklearn.preprocessing.QuantileTransformer.md#sklearn.preprocessing.QuantileTransformer) or as a
function and its inverse such as `np.log` and `np.exp`.

The computation during [`fit`](#sklearn.compose.TransformedTargetRegressor.fit) is:

```default
regressor.fit(X, func(y))
```

or:

```default
regressor.fit(X, transformer.transform(y))
```

The computation during [`predict`](#sklearn.compose.TransformedTargetRegressor.predict) is:

```default
inverse_func(regressor.predict(X))
```

or:

```default
transformer.inverse_transform(regressor.predict(X))
```

Read more in the [User Guide](../compose.md#transformed-target-regressor).

#### Versionadded
Added in version 0.20.

* **Parameters:**
  **regressor**
  : Regressor object such as derived from
    [`RegressorMixin`](sklearn.base.RegressorMixin.md#sklearn.base.RegressorMixin). This regressor will
    automatically be cloned each time prior to fitting. If `regressor is
    None`, [`LinearRegression`](sklearn.linear_model.LinearRegression.md#sklearn.linear_model.LinearRegression) is created and used.

  **transformer**
  : Estimator object such as derived from
    [`TransformerMixin`](sklearn.base.TransformerMixin.md#sklearn.base.TransformerMixin). Cannot be set at the same time
    as `func` and `inverse_func`. If `transformer is None` as well as
    `func` and `inverse_func`, the transformer will be an identity
    transformer. Note that the transformer will be cloned during fitting.
    Also, the transformer is restricting `y` to be a numpy array.

  **func**
  : Function to apply to `y` before passing to [`fit`](#sklearn.compose.TransformedTargetRegressor.fit). Cannot be set
    at the same time as `transformer`. If `func is None`, the function used will be
    the identity function. If `func` is set, `inverse_func` also needs to be
    provided. The function needs to return a 2-dimensional array.

  **inverse_func**
  : Function to apply to the prediction of the regressor. Cannot be set at
    the same time as `transformer`. The inverse function is used to return
    predictions to the same space of the original training labels. If
    `inverse_func` is set, `func` also needs to be provided. The inverse
    function needs to return a 2-dimensional array.

  **check_inverse**
  : Whether to check that `transform` followed by `inverse_transform`
    or `func` followed by `inverse_func` leads to the original targets.
* **Attributes:**
  **regressor_**
  : Fitted regressor.

  **transformer_**
  : Transformer used in [`fit`](#sklearn.compose.TransformedTargetRegressor.fit) and [`predict`](#sklearn.compose.TransformedTargetRegressor.predict).

  [`n_features_in_`](#sklearn.compose.TransformedTargetRegressor.n_features_in_)
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`sklearn.preprocessing.FunctionTransformer`](sklearn.preprocessing.FunctionTransformer.md#sklearn.preprocessing.FunctionTransformer)
: Construct a transformer from an arbitrary callable.

### Notes

Internally, the target `y` is always converted into a 2-dimensional array
to be used by scikit-learn transformers. At the time of prediction, the
output will be reshaped to a have the same number of dimensions as `y`.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.linear_model import LinearRegression
>>> from sklearn.compose import TransformedTargetRegressor
>>> tt = TransformedTargetRegressor(regressor=LinearRegression(),
...                                 func=np.log, inverse_func=np.exp)
>>> X = np.arange(4).reshape(-1, 1)
>>> y = np.exp(2 * X).ravel()
>>> tt.fit(X, y)
TransformedTargetRegressor(...)
>>> tt.score(X, y)
1.0
>>> tt.regressor_.coef_
array([2.])
```

For a more detailed example use case refer to
[Effect of transforming the targets in regression model](../../auto_examples/compose/plot_transformed_target.md#sphx-glr-auto-examples-compose-plot-transformed-target-py).

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*\*fit_params)

Fit the model according to the given training data.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target values.

  **\*\*fit_params**
  : - If `enable_metadata_routing=False` (default): Parameters directly passed
      to the `fit` method of the underlying regressor.
    - If `enable_metadata_routing=True`: Parameters safely routed to the `fit`
      method of the underlying regressor.
    <br/>
    #### Versionchanged
    Changed in version 1.6: See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.6.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_features_in_

Number of features seen during [fit](../../glossary.md#term-fit).

<!-- !! processed by numpydoc !! -->

#### predict(X, \*\*predict_params)

Predict using the base regressor, applying inverse.

The regressor is used to predict and the `inverse_func` or
`inverse_transform` is applied before returning the prediction.

* **Parameters:**
  **X**
  : Samples.

  **\*\*predict_params**
  : - If `enable_metadata_routing=False` (default): Parameters directly passed
      to the `predict` method of the underlying regressor.
    - If `enable_metadata_routing=True`: Parameters safely routed to the
      `predict` method of the underlying regressor.
    <br/>
    #### Versionchanged
    Changed in version 1.6: See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing)
    for more details.
* **Returns:**
  **y_hat**
  : Predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [TransformedTargetRegressor](#sklearn.compose.TransformedTargetRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we give an overview of TransformedTargetRegressor. We use two examples to illustrate the benefit of transforming the targets before learning a linear regression model. The first example uses synthetic data while the second example is based on the Ames housing data set.">  <div class="sphx-glr-thumbnail-title">Effect of transforming the targets in regression model</div>
</div>
* [Effect of transforming the targets in regression model](../../auto_examples/compose/plot_transformed_target.md#sphx-glr-auto-examples-compose-plot-transformed-target-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<!-- thumbnail-parent-div-close --></div>
