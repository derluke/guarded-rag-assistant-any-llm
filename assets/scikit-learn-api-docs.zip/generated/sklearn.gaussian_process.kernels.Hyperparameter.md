# Hyperparameter

### *class* sklearn.gaussian_process.kernels.Hyperparameter(name, value_type, bounds, n_elements=1, fixed=None)

A kernel hyperparameter’s specification in form of a namedtuple.

#### Versionadded
Added in version 0.18.

* **Attributes:**
  **name**
  : The name of the hyperparameter. Note that a kernel using a
    hyperparameter with name “x” must have the attributes self.x and
    self.x_bounds

  **value_type**
  : The type of the hyperparameter. Currently, only “numeric”
    hyperparameters are supported.

  **bounds**
  : The lower and upper bound on the parameter. If n_elements>1, a pair
    of 1d array with n_elements each may be given alternatively. If
    the string “fixed” is passed as bounds, the hyperparameter’s value
    cannot be changed.

  **n_elements**
  : The number of elements of the hyperparameter value. Defaults to 1,
    which corresponds to a scalar hyperparameter. n_elements > 1
    corresponds to a hyperparameter which is vector-valued,
    such as, e.g., anisotropic length-scales.

  **fixed**
  : Whether the value of this hyperparameter is fixed, i.e., cannot be
    changed during hyperparameter tuning. If None is passed, the “fixed” is
    derived based on the given bounds.

### Examples

```pycon
>>> from sklearn.gaussian_process.kernels import ConstantKernel
>>> from sklearn.datasets import make_friedman2
>>> from sklearn.gaussian_process import GaussianProcessRegressor
>>> from sklearn.gaussian_process.kernels import Hyperparameter
>>> X, y = make_friedman2(n_samples=50, noise=0, random_state=0)
>>> kernel = ConstantKernel(constant_value=1.0,
...    constant_value_bounds=(0.0, 10.0))
```

We can access each hyperparameter:

```pycon
>>> for hyperparameter in kernel.hyperparameters:
...    print(hyperparameter)
Hyperparameter(name='constant_value', value_type='numeric',
bounds=array([[ 0., 10.]]), n_elements=1, fixed=False)
```

```pycon
>>> params = kernel.get_params()
>>> for key in sorted(params): print(f"{key} : {params[key]}")
constant_value : 1.0
constant_value_bounds : (0.0, 10.0)
```

<!-- !! processed by numpydoc !! -->

#### bounds

Alias for field number 2

<!-- !! processed by numpydoc !! -->

#### count(value, /)

Return number of occurrences of value.

<!-- !! processed by numpydoc !! -->

#### fixed

Alias for field number 4

<!-- !! processed by numpydoc !! -->

#### index(value, start=0, stop=sys.maxsize, /)

Return first index of value.

Raises ValueError if the value is not present.

<!-- !! processed by numpydoc !! -->

#### n_elements

Alias for field number 3

<!-- !! processed by numpydoc !! -->

#### name

Alias for field number 0

<!-- !! processed by numpydoc !! -->

#### value_type

Alias for field number 1

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Gaussian processes for regression and classification tasks on data that are not in fixed-length feature vector form. This is achieved through the use of kernel functions that operates directly on discrete structures such as variable-length sequences, trees, and graphs.">  <div class="sphx-glr-thumbnail-title">Gaussian processes on discrete data structures</div>
</div>
* [Gaussian processes on discrete data structures](../../auto_examples/gaussian_process/plot_gpr_on_structured_data.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-on-structured-data-py)

<!-- thumbnail-parent-div-close --></div>
