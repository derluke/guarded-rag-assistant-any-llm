# fowlkes_mallows_score

### sklearn.metrics.fowlkes_mallows_score(labels_true, labels_pred, \*, sparse=False)

Measure the similarity of two clusterings of a set of points.

#### Versionadded
Added in version 0.18.

The Fowlkes-Mallows index (FMI) is defined as the geometric mean between of
the precision and recall:

```default
FMI = TP / sqrt((TP + FP) * (TP + FN))
```

Where `TP` is the number of **True Positive** (i.e. the number of pairs of
points that belong to the same cluster in both `labels_true` and
`labels_pred`), `FP` is the number of **False Positive** (i.e. the
number of pairs of points that belong to the same cluster in
`labels_pred` but not in `labels_true`) and `FN` is the number of
**False Negative** (i.e. the number of pairs of points that belong to the
same cluster in `labels_true` but not in `labels_pred`).

The score ranges from 0 to 1. A high value indicates a good similarity
between two clusters.

Read more in the [User Guide](../clustering.md#fowlkes-mallows-scores).

* **Parameters:**
  **labels_true**
  : A clustering of the data into disjoint subsets.

  **labels_pred**
  : A clustering of the data into disjoint subsets.

  **sparse**
  : Compute contingency matrix internally with sparse matrix.
* **Returns:**
  **score**
  : The resulting Fowlkes-Mallows score.

### References

### Examples

Perfect labelings are both homogeneous and complete, hence have
score 1.0:

```default
>>> from sklearn.metrics.cluster import fowlkes_mallows_score
>>> fowlkes_mallows_score([0, 0, 1, 1], [0, 0, 1, 1])
np.float64(1.0)
>>> fowlkes_mallows_score([0, 0, 1, 1], [1, 1, 0, 0])
np.float64(1.0)
```

If classes members are completely split across different clusters,
the assignment is totally random, hence the FMI is null:

```default
>>> fowlkes_mallows_score([0, 0, 0, 0], [0, 1, 2, 3])
0.0
```

<!-- !! processed by numpydoc !! -->
