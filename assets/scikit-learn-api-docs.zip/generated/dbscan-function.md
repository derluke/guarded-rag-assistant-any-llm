# dbscan

### sklearn.cluster.dbscan(X, eps=0.5, \*, min_samples=5, metric='minkowski', metric_params=None, algorithm='auto', leaf_size=30, p=2, sample_weight=None, n_jobs=None)

Perform DBSCAN clustering from vector array or distance matrix.

Read more in the [User Guide](../clustering.md#dbscan).

* **Parameters:**
  **X**
  : A feature array, or array of distances between samples if
    `metric='precomputed'`.

  **eps**
  : The maximum distance between two samples for one to be considered
    as in the neighborhood of the other. This is not a maximum bound
    on the distances of points within a cluster. This is the most
    important DBSCAN parameter to choose appropriately for your data set
    and distance function.

  **min_samples**
  : The number of samples (or total weight) in a neighborhood for a point
    to be considered as a core point. This includes the point itself.

  **metric**
  : The metric to use when calculating distance between instances in a
    feature array. If metric is a string or callable, it must be one of
    the options allowed by [`sklearn.metrics.pairwise_distances`](sklearn.metrics.pairwise_distances.md#sklearn.metrics.pairwise_distances) for
    its metric parameter.
    If metric is “precomputed”, X is assumed to be a distance matrix and
    must be square during fit.
    X may be a [sparse graph](../../glossary.md#term-sparse-graph),
    in which case only “nonzero” elements may be considered neighbors.

  **metric_params**
  : Additional keyword arguments for the metric function.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **algorithm**
  : The algorithm to be used by the NearestNeighbors module
    to compute pointwise distances and find nearest neighbors.
    See NearestNeighbors module documentation for details.

  **leaf_size**
  : Leaf size passed to BallTree or cKDTree. This can affect the speed
    of the construction and query, as well as the memory required
    to store the tree. The optimal value depends
    on the nature of the problem.

  **p**
  : The power of the Minkowski metric to be used to calculate distance
    between points.

  **sample_weight**
  : Weight of each sample, such that a sample with a weight of at least
    `min_samples` is by itself a core sample; a sample with negative
    weight may inhibit its eps-neighbor from being core.
    Note that weights are absolute, and default to 1.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search. `None` means
    1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context. `-1` means
    using all processors. See [Glossary](../../glossary.md#term-n_jobs) for more details.
    If precomputed distance are used, parallel execution is not available
    and thus n_jobs will have no effect.
* **Returns:**
  **core_samples**
  : Indices of core samples.

  **labels**
  : Cluster labels for each point.  Noisy samples are given the label -1.

#### SEE ALSO
[`DBSCAN`](sklearn.cluster.DBSCAN.md#sklearn.cluster.DBSCAN)
: An estimator interface for this clustering algorithm.

[`OPTICS`](sklearn.cluster.OPTICS.md#sklearn.cluster.OPTICS)
: A similar estimator interface clustering at multiple values of eps. Our implementation is optimized for memory usage.

### Notes

For an example, see [Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py).

This implementation bulk-computes all neighborhood queries, which increases
the memory complexity to O(n.d) where d is the average number of neighbors,
while original DBSCAN had memory complexity O(n). It may attract a higher
memory complexity when querying these nearest neighborhoods, depending
on the `algorithm`.

One way to avoid the query complexity is to pre-compute sparse
neighborhoods in chunks using
[`NearestNeighbors.radius_neighbors_graph`](sklearn.neighbors.NearestNeighbors.md#sklearn.neighbors.NearestNeighbors.radius_neighbors_graph) with
`mode='distance'`, then using `metric='precomputed'` here.

Another way to reduce memory and computation time is to remove
(near-)duplicate points and use `sample_weight` instead.

[`OPTICS`](sklearn.cluster.OPTICS.md#sklearn.cluster.OPTICS) provides a similar clustering with lower
memory usage.

### References

Ester, M., H. P. Kriegel, J. Sander, and X. Xu, [“A Density-Based
Algorithm for Discovering Clusters in Large Spatial Databases with Noise”](https://www.dbs.ifi.lmu.de/Publikationen/Papers/KDD-96.final.frame.pdf).
In: Proceedings of the 2nd International Conference on Knowledge Discovery
and Data Mining, Portland, OR, AAAI Press, pp. 226-231. 1996

Schubert, E., Sander, J., Ester, M., Kriegel, H. P., & Xu, X. (2017).
[“DBSCAN revisited, revisited: why and how you should (still) use DBSCAN.”](https://doi.org/10.1145/3068335)
ACM Transactions on Database Systems (TODS), 42(3), 19.

### Examples

```pycon
>>> from sklearn.cluster import dbscan
>>> X = [[1, 2], [2, 2], [2, 3], [8, 7], [8, 8], [25, 80]]
>>> core_samples, labels = dbscan(X, eps=3, min_samples=2)
>>> core_samples
array([0, 1, 2, 3, 4])
>>> labels
array([ 0,  0,  0,  1,  1, -1])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="DBSCAN (Density-Based Spatial Clustering of Applications with Noise) finds core samples in regions of high density and expands clusters from them. This algorithm is good for data which contains clusters of similar density.">  <div class="sphx-glr-thumbnail-title">Demo of DBSCAN clustering algorithm</div>
</div>
* [Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this demo we will take a look at cluster.HDBSCAN from the perspective of generalizing the cluster.DBSCAN algorithm. We&#x27;ll compare both algorithms on specific datasets. Finally we&#x27;ll evaluate HDBSCAN&#x27;s sensitivity to certain hyperparameters.">  <div class="sphx-glr-thumbnail-title">Demo of HDBSCAN clustering algorithm</div>
</div>
* [Demo of HDBSCAN clustering algorithm](../../auto_examples/cluster/plot_hdbscan.md#sphx-glr-auto-examples-cluster-plot-hdbscan-py)

<!-- thumbnail-parent-div-close --></div>
