# GroupShuffleSplit

### *class* sklearn.model_selection.GroupShuffleSplit(n_splits=5, \*, test_size=None, train_size=None, random_state=None)

Shuffle-Group(s)-Out cross-validation iterator.

Provides randomized train/test indices to split data according to a
third-party provided group. This group information can be used to encode
arbitrary domain specific stratifications of the samples as integers.

For instance the groups could be the year of collection of the samples
and thus allow for cross-validation against time-based splits.

The difference between [`LeavePGroupsOut`](sklearn.model_selection.LeavePGroupsOut.md#sklearn.model_selection.LeavePGroupsOut) and `GroupShuffleSplit` is that
the former generates splits using all subsets of size `p` unique groups,
whereas `GroupShuffleSplit` generates a user-determined number of random
test splits, each with a user-determined fraction of unique groups.

For example, a less computationally intensive alternative to
`LeavePGroupsOut(p=10)` would be
`GroupShuffleSplit(test_size=10, n_splits=100)`.

Contrary to other cross-validation strategies, the random splits
do not guarantee that test sets across all folds will be mutually exclusive,
and might include overlapping samples. However, this is still very likely for
sizeable datasets.

Note: The parameters `test_size` and `train_size` refer to groups, and
not to samples as in [`ShuffleSplit`](sklearn.model_selection.ShuffleSplit.md#sklearn.model_selection.ShuffleSplit).

Read more in the [User Guide](../cross_validation.md#group-shuffle-split).

For visualisation of cross-validation behaviour and
comparison between common scikit-learn split methods
refer to [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

* **Parameters:**
  **n_splits**
  : Number of re-shuffling & splitting iterations.

  **test_size**
  : If float, should be between 0.0 and 1.0 and represent the proportion
    of groups to include in the test split (rounded up). If int,
    represents the absolute number of test groups. If None, the value is
    set to the complement of the train size. If `train_size` is also None,
    it will be set to 0.2.

  **train_size**
  : If float, should be between 0.0 and 1.0 and represent the
    proportion of the groups to include in the train split. If
    int, represents the absolute number of train groups. If None,
    the value is automatically set to the complement of the test size.

  **random_state**
  : Controls the randomness of the training and testing indices produced.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

#### SEE ALSO
[`ShuffleSplit`](sklearn.model_selection.ShuffleSplit.md#sklearn.model_selection.ShuffleSplit)
: Shuffles samples to create independent test/train sets.

[`LeavePGroupsOut`](sklearn.model_selection.LeavePGroupsOut.md#sklearn.model_selection.LeavePGroupsOut)
: Train set leaves out all possible subsets of `p` groups.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import GroupShuffleSplit
>>> X = np.ones(shape=(8, 2))
>>> y = np.ones(shape=(8, 1))
>>> groups = np.array([1, 1, 2, 2, 2, 3, 3, 3])
>>> print(groups.shape)
(8,)
>>> gss = GroupShuffleSplit(n_splits=2, train_size=.7, random_state=42)
>>> gss.get_n_splits()
2
>>> print(gss)
GroupShuffleSplit(n_splits=2, random_state=42, test_size=None, train_size=0.7)
>>> for i, (train_index, test_index) in enumerate(gss.split(X, y, groups)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}, group={groups[train_index]}")
...     print(f"  Test:  index={test_index}, group={groups[test_index]}")
Fold 0:
  Train: index=[2 3 4 5 6 7], group=[2 2 2 3 3 3]
  Test:  index=[0 1], group=[1 1]
Fold 1:
  Train: index=[0 1 5 6 7], group=[1 1 3 3 3]
  Test:  index=[2 3 4], group=[2 2 2]
```

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X=None, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Always ignored, exists for compatibility.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### set_split_request(\*, groups: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [GroupShuffleSplit](#sklearn.model_selection.GroupShuffleSplit)

Request metadata passed to the `split` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `split` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `split`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **groups**
  : Metadata routing for `groups` parameter in `split`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### split(X, y=None, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : The target variable for supervised learning problems.

  **groups**
  : Group labels for the samples used while splitting the dataset into
    train/test set.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

### Notes

Randomized CV splitters may return different results for each call of
split. You can make the results identical by setting `random_state`
to an integer.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Choosing the right cross-validation object is a crucial part of fitting a model properly. There are many ways to split data into training and test sets in order to avoid model overfitting, to standardize the number of groups in test sets, etc.">  <div class="sphx-glr-thumbnail-title">Visualizing cross-validation behavior in scikit-learn</div>
</div>
* [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

<!-- thumbnail-parent-div-close --></div>
