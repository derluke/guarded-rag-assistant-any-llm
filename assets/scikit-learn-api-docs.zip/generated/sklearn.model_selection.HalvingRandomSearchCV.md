# HalvingRandomSearchCV

### *class* sklearn.model_selection.HalvingRandomSearchCV(estimator, param_distributions, \*, n_candidates='exhaust', factor=3, resource='n_samples', max_resources='auto', min_resources='smallest', aggressive_elimination=False, cv=5, scoring=None, refit=True, error_score=nan, return_train_score=True, random_state=None, n_jobs=None, verbose=0)

Randomized search on hyper parameters.

The search strategy starts evaluating all the candidates with a small
amount of resources and iteratively selects the best candidates, using more
and more resources.

The candidates are sampled at random from the parameter space and the
number of sampled candidates is determined by `n_candidates`.

Read more in the [User guide](../grid_search.md#successive-halving-user-guide).

#### NOTE
This estimator is still **experimental** for now: the predictions
and the API might change without any deprecation cycle. To use it,
you need to explicitly import `enable_halving_search_cv`:

```default
>>> # explicitly require this experimental feature
>>> from sklearn.experimental import enable_halving_search_cv # noqa
>>> # now you can import normally from model_selection
>>> from sklearn.model_selection import HalvingRandomSearchCV
```

* **Parameters:**
  **estimator**
  : This is assumed to implement the scikit-learn estimator interface.
    Either estimator needs to provide a `score` function,
    or `scoring` must be passed.

  **param_distributions**
  : Dictionary with parameters names (`str`) as keys and distributions
    or lists of parameters to try. Distributions must provide a `rvs`
    method for sampling (such as those from scipy.stats.distributions).
    If a list is given, it is sampled uniformly.
    If a list of dicts is given, first a dict is sampled uniformly, and
    then a parameter is sampled using that dict as above.

  **n_candidates**
  : The number of candidate parameters to sample, at the first
    iteration. Using ‘exhaust’ will sample enough candidates so that the
    last iteration uses as many resources as possible, based on
    `min_resources`, `max_resources` and `factor`. In this case,
    `min_resources` cannot be ‘exhaust’.

  **factor**
  : The ‘halving’ parameter, which determines the proportion of candidates
    that are selected for each subsequent iteration. For example,
    `factor=3` means that only one third of the candidates are selected.

  **resource**
  : Defines the resource that increases with each iteration. By default,
    the resource is the number of samples. It can also be set to any
    parameter of the base estimator that accepts positive integer
    values, e.g. ‘n_iterations’ or ‘n_estimators’ for a gradient
    boosting estimator. In this case `max_resources` cannot be ‘auto’
    and must be set explicitly.

  **max_resources**
  : The maximum number of resources that any candidate is allowed to use
    for a given iteration. By default, this is set `n_samples` when
    `resource='n_samples'` (default), else an error is raised.

  **min_resources**
  : The minimum amount of resource that any candidate is allowed to use
    for a given iteration. Equivalently, this defines the amount of
    resources `r0` that are allocated for each candidate at the first
    iteration.
    - ‘smallest’ is a heuristic that sets `r0` to a small value:
      - `n_splits * 2` when `resource='n_samples'` for a regression problem
      - `n_classes * n_splits * 2` when `resource='n_samples'` for a
        classification problem
      - `1` when `resource != 'n_samples'`
    - ‘exhaust’ will set `r0` such that the **last** iteration uses as
      much resources as possible. Namely, the last iteration will use the
      highest value smaller than `max_resources` that is a multiple of
      both `min_resources` and `factor`. In general, using ‘exhaust’
      leads to a more accurate estimator, but is slightly more time
      consuming. ‘exhaust’ isn’t available when `n_candidates='exhaust'`.
    <br/>
    Note that the amount of resources used at each iteration is always a
    multiple of `min_resources`.

  **aggressive_elimination**
  : This is only relevant in cases where there isn’t enough resources to
    reduce the remaining candidates to at most `factor` after the last
    iteration. If `True`, then the search process will ‘replay’ the
    first iteration for as long as needed until the number of candidates
    is small enough. This is `False` by default, which means that the
    last iteration may evaluate more than `factor` candidates. See
    [Aggressive elimination of candidates](../grid_search.md#aggressive-elimination) for more details.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - integer, to specify the number of folds in a `(Stratified)KFold`,
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs, if the estimator is a classifier and `y` is
    either binary or multiclass, [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. In all
    other cases, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used. These splitters are instantiated
    with `shuffle=False` so the splits will be the same across calls.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### NOTE
    Due to implementation details, the folds produced by `cv` must be
    the same across multiple calls to `cv.split()`. For
    built-in `scikit-learn` iterators, this can be achieved by
    deactivating shuffling (`shuffle=False`), or by setting the
    `cv`’s `random_state` parameter to an integer.

  **scoring**
  : A single string (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter)) or a callable
    (see [Callable scorers](../model_evaluation.md#scoring-callable)) to evaluate the predictions on the test set.
    If None, the estimator’s score method is used.

  **refit**
  : If True, refit an estimator using the best found parameters on the
    whole dataset.
    <br/>
    The refitted estimator is made available at the `best_estimator_`
    attribute and permits using `predict` directly on this
    `HalvingRandomSearchCV` instance.

  **error_score**
  : Value to assign to the score if an error occurs in estimator fitting.
    If set to ‘raise’, the error is raised. If a numeric value is given,
    FitFailedWarning is raised. This parameter does not affect the refit
    step, which will always raise the error. Default is `np.nan`.

  **return_train_score**
  : If `False`, the `cv_results_` attribute will not include training
    scores.
    Computing training scores is used to get insights on how different
    parameter settings impact the overfitting/underfitting trade-off.
    However computing the scores on the training set can be computationally
    expensive and is not strictly required to select the parameters that
    yield the best generalization performance.

  **random_state**
  : Pseudo random number generator state used for subsampling the dataset
    when `resources != 'n_samples'`. Also used for random uniform
    sampling from lists of possible values instead of scipy.stats
    distributions.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **n_jobs**
  : Number of jobs to run in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **verbose**
  : Controls the verbosity: the higher, the more messages.
* **Attributes:**
  **n_resources_**
  : The amount of resources used at each iteration.

  **n_candidates_**
  : The number of candidate parameters that were evaluated at each
    iteration.

  **n_remaining_candidates_**
  : The number of candidate parameters that are left after the last
    iteration. It corresponds to `ceil(n_candidates[-1] / factor)`

  **max_resources_**
  : The maximum number of resources that any candidate is allowed to use
    for a given iteration. Note that since the number of resources used at
    each iteration must be a multiple of `min_resources_`, the actual
    number of resources used at the last iteration may be smaller than
    `max_resources_`.

  **min_resources_**
  : The amount of resources that are allocated for each candidate at the
    first iteration.

  **n_iterations_**
  : The actual number of iterations that were run. This is equal to
    `n_required_iterations_` if `aggressive_elimination` is `True`.
    Else, this is equal to `min(n_possible_iterations_,
    n_required_iterations_)`.

  **n_possible_iterations_**
  : The number of iterations that are possible starting with
    `min_resources_` resources and without exceeding
    `max_resources_`.

  **n_required_iterations_**
  : The number of iterations that are required to end up with less than
    `factor` candidates at the last iteration, starting with
    `min_resources_` resources. This will be smaller than
    `n_possible_iterations_` when there isn’t enough resources.

  **cv_results_**
  : A dict with keys as column headers and values as columns, that can be
    imported into a pandas `DataFrame`. It contains lots of information
    for analysing the results of a search.
    Please refer to the [User guide](../grid_search.md#successive-halving-cv-results)
    for details.

  **best_estimator_**
  : Estimator that was chosen by the search, i.e. estimator
    which gave highest score (or smallest loss if specified)
    on the left out data. Not available if `refit=False`.

  **best_score_**
  : Mean cross-validated score of the best_estimator.

  **best_params_**
  : Parameter setting that gave the best results on the hold out data.

  **best_index_**
  : The index (of the `cv_results_` arrays) which corresponds to the best
    candidate parameter setting.
    <br/>
    The dict at `search.cv_results_['params'][search.best_index_]` gives
    the parameter setting for the best model, that gives the highest
    mean score (`search.best_score_`).

  **scorer_**
  : Scorer function used on the held out data to choose the best
    parameters for the model.

  **n_splits_**
  : The number of cross-validation splits (folds/iterations).

  **refit_time_**
  : Seconds used for refitting the best model on the whole dataset.
    <br/>
    This is present only if `refit` is not False.

  **multimetric_**
  : Whether or not the scorers compute several metrics.

  [`classes_`](#sklearn.model_selection.HalvingRandomSearchCV.classes_)
  : Class labels.

  [`n_features_in_`](#sklearn.model_selection.HalvingRandomSearchCV.n_features_in_)
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if
    `best_estimator_` is defined (see the documentation for the `refit`
    parameter for more details) and that `best_estimator_` exposes
    `feature_names_in_` when fit.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`HalvingGridSearchCV`](sklearn.model_selection.HalvingGridSearchCV.md#sklearn.model_selection.HalvingGridSearchCV)
: Search over a grid of parameters using successive halving.

### Notes

The parameters selected are those that maximize the score of the held-out
data, according to the scoring parameter.

All parameter combinations scored with a NaN will share the lowest rank.

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn.ensemble import RandomForestClassifier
>>> from sklearn.experimental import enable_halving_search_cv  # noqa
>>> from sklearn.model_selection import HalvingRandomSearchCV
>>> from scipy.stats import randint
>>> import numpy as np
...
>>> X, y = load_iris(return_X_y=True)
>>> clf = RandomForestClassifier(random_state=0)
>>> np.random.seed(0)
...
>>> param_distributions = {"max_depth": [3, None],
...                        "min_samples_split": randint(2, 11)}
>>> search = HalvingRandomSearchCV(clf, param_distributions,
...                                resource='n_estimators',
...                                max_resources=10,
...                                random_state=0).fit(X, y)
>>> search.best_params_  
{'max_depth': None, 'min_samples_split': 10, 'n_estimators': 9}
```

<!-- !! processed by numpydoc !! -->

#### *property* classes_

Class labels.

Only available when `refit=True` and the estimator is a classifier.

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Call decision_function on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`decision_function`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_score**
  : Result of the decision function for `X` based on the estimator with
    the best found parameters.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, \*\*params)

Run fit with all sets of parameters.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target relative to X for classification or regression;
    None for unsupervised learning.

  **\*\*params**
  : Parameters passed to the `fit` method of the estimator.
* **Returns:**
  **self**
  : Instance of fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.4.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X=None, Xt=None)

Call inverse_transform on the estimator with the best found params.

Only available if the underlying estimator implements
`inverse_transform` and `refit=True`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.

  **Xt**
  : Must fulfill the input assumptions of the
    underlying estimator.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Xt` was deprecated in 1.5 and will be removed in 1.7. Use `X` instead.
* **Returns:**
  **X**
  : Result of the `inverse_transform` function for `Xt` based on the
    estimator with the best found parameters.

<!-- !! processed by numpydoc !! -->

#### *property* n_features_in_

Number of features seen during [fit](../../glossary.md#term-fit).

Only available when `refit=True`.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Call predict on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`predict`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_pred**
  : The predicted labels or values for `X` based on the estimator with
    the best found parameters.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Call predict_log_proba on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`predict_log_proba`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_pred**
  : Predicted class log-probabilities for `X` based on the estimator
    with the best found parameters. The order of the classes
    corresponds to that in the fitted attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Call predict_proba on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`predict_proba`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_pred**
  : Predicted class probabilities for `X` based on the estimator with
    the best found parameters. The order of the classes corresponds
    to that in the fitted attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y=None, \*\*params)

Return the score on the given data, if the estimator has been refit.

This uses the score defined by `scoring` where provided, and the
`best_estimator_.score` method otherwise.

* **Parameters:**
  **X**
  : Input data, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target relative to X for classification or regression;
    None for unsupervised learning.

  **\*\*params**
  : Parameters to be passed to the underlying scorer(s).
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **score**
  : The score defined by `scoring` if provided, and the
    `best_estimator_.score` method otherwise.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Call score_samples on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`score_samples`.

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **X**
  : Data to predict on. Must fulfill input requirements
    of the underlying estimator.
* **Returns:**
  **y_score**
  : The `best_estimator_.score_samples` method.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Call transform on the estimator with the best found parameters.

Only available if the underlying estimator supports `transform` and
`refit=True`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **Xt**
  : `X` transformed in the new space based on the estimator with
    the best found parameters.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows how quantile regression can be used to create prediction intervals. See sphx_glr_auto_examples_ensemble_plot_hgbt_regression.py for an example showcasing some other features of HistGradientBoostingRegressor.">  <div class="sphx-glr-thumbnail-title">Prediction Intervals for Gradient Boosting Regression</div>
</div>
* [Prediction Intervals for Gradient Boosting Regression](../../auto_examples/ensemble/plot_gradient_boosting_quantile.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-quantile-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how a successive halving search (~sklearn.model_selection.HalvingGridSearchCV and HalvingRandomSearchCV) iteratively chooses the best parameter combination out of multiple candidates.">  <div class="sphx-glr-thumbnail-title">Successive Halving Iterations</div>
</div>
* [Successive Halving Iterations](../../auto_examples/model_selection/plot_successive_halving_iterations.md#sphx-glr-auto-examples-model-selection-plot-successive-halving-iterations-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
