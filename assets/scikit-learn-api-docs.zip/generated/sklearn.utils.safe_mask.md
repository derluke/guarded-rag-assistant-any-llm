# safe_mask

### sklearn.utils.safe_mask(X, mask)

Return a mask which is safe to use on X.

* **Parameters:**
  **X**
  : Data on which to apply mask.

  **mask**
  : Mask to be used on X.
* **Returns:**
  **mask**
  : Array that is safe to use on X.

### Examples

```pycon
>>> from sklearn.utils import safe_mask
>>> from scipy.sparse import csr_matrix
>>> data = csr_matrix([[1], [2], [3], [4], [5]])
>>> condition = [False, True, True, False, True]
>>> mask = safe_mask(data, condition)
>>> data[mask].toarray()
array([[2],
       [3],
       [5]])
```

<!-- !! processed by numpydoc !! -->
