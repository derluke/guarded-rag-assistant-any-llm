# mean_pinball_loss

### sklearn.metrics.mean_pinball_loss(y_true, y_pred, \*, sample_weight=None, alpha=0.5, multioutput='uniform_average')

Pinball loss for quantile regression.

Read more in the [User Guide](../model_evaluation.md#pinball-loss).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated target values.

  **sample_weight**
  : Sample weights.

  **alpha**
  : This loss is equivalent to [Mean absolute error](../model_evaluation.md#mean-absolute-error) when `alpha=0.5`,
    `alpha=0.95` is minimized by estimators of the 95th percentile.

  **multioutput**
  : Defines aggregating of multiple output values.
    Array-like value defines weights used to average errors.
    <br/>
    ‘raw_values’ :
    : Returns a full set of errors in case of multioutput input.
    <br/>
    ‘uniform_average’ :
    : Errors of all outputs are averaged with uniform weight.
* **Returns:**
  **loss**
  : If multioutput is ‘raw_values’, then mean absolute error is returned
    for each output separately.
    If multioutput is ‘uniform_average’ or an ndarray of weights, then the
    weighted average of all output errors is returned.
    <br/>
    The pinball loss output is a non-negative floating point. The best
    value is 0.0.

### Examples

```pycon
>>> from sklearn.metrics import mean_pinball_loss
>>> y_true = [1, 2, 3]
>>> mean_pinball_loss(y_true, [0, 2, 3], alpha=0.1)
np.float64(0.03...)
>>> mean_pinball_loss(y_true, [1, 2, 4], alpha=0.1)
np.float64(0.3...)
>>> mean_pinball_loss(y_true, [0, 2, 3], alpha=0.9)
np.float64(0.3...)
>>> mean_pinball_loss(y_true, [1, 2, 4], alpha=0.9)
np.float64(0.03...)
>>> mean_pinball_loss(y_true, y_true, alpha=0.1)
np.float64(0.0)
>>> mean_pinball_loss(y_true, y_true, alpha=0.9)
np.float64(0.0)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Polars-engineered lagged features can be used for time series forecasting with HistGradientBoostingRegressor on the Bike Sharing Demand dataset.">  <div class="sphx-glr-thumbnail-title">Lagged features for time series forecasting</div>
</div>
* [Lagged features for time series forecasting](../../auto_examples/applications/plot_time_series_lagged_features.md#sphx-glr-auto-examples-applications-plot-time-series-lagged-features-py)

<div class="sphx-glr-thumbcontainer" tooltip="histogram_based_gradient_boosting (HGBT) models may be one of the most useful supervised learning models in scikit-learn. They are based on a modern gradient boosting implementation comparable to LightGBM and XGBoost. As such, HGBT models are more feature rich than and often outperform alternative models like random forests, especially when the number of samples is larger than some ten thousands (see sphx_glr_auto_examples_ensemble_plot_forest_hist_grad_boosting_comparison.py).">  <div class="sphx-glr-thumbnail-title">Features in Histogram Gradient Boosting Trees</div>
</div>
* [Features in Histogram Gradient Boosting Trees](../../auto_examples/ensemble/plot_hgbt_regression.md#sphx-glr-auto-examples-ensemble-plot-hgbt-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how quantile regression can be used to create prediction intervals. See sphx_glr_auto_examples_ensemble_plot_hgbt_regression.py for an example showcasing some other features of HistGradientBoostingRegressor.">  <div class="sphx-glr-thumbnail-title">Prediction Intervals for Gradient Boosting Regression</div>
</div>
* [Prediction Intervals for Gradient Boosting Regression](../../auto_examples/ensemble/plot_gradient_boosting_quantile.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-quantile-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are very pleased to announce the release of scikit-learn 1.0! The library has been stable for quite some time, releasing version 1.0 is recognizing that and signalling it to our users. This release does not include any breaking changes apart from the usual two-release deprecation cycle. For the future, we do our best to keep this pattern.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.0</div>
</div>
* [Release Highlights for scikit-learn 1.0](../../auto_examples/release_highlights/plot_release_highlights_1_0_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-0-0-py)

<!-- thumbnail-parent-div-close --></div>
