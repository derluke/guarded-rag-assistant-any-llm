# StandardScaler

### *class* sklearn.preprocessing.StandardScaler(\*, copy=True, with_mean=True, with_std=True)

Standardize features by removing the mean and scaling to unit variance.

The standard score of a sample `x` is calculated as:

```text
z = (x - u) / s
```

where `u` is the mean of the training samples or zero if `with_mean=False`,
and `s` is the standard deviation of the training samples or one if
`with_std=False`.

Centering and scaling happen independently on each feature by computing
the relevant statistics on the samples in the training set. Mean and
standard deviation are then stored to be used on later data using
[`transform`](#sklearn.preprocessing.StandardScaler.transform).

Standardization of a dataset is a common requirement for many
machine learning estimators: they might behave badly if the
individual features do not more or less look like standard normally
distributed data (e.g. Gaussian with 0 mean and unit variance).

For instance many elements used in the objective function of
a learning algorithm (such as the RBF kernel of Support Vector
Machines or the L1 and L2 regularizers of linear models) assume that
all features are centered around 0 and have variance in the same
order. If a feature has a variance that is orders of magnitude larger
than others, it might dominate the objective function and make the
estimator unable to learn from other features correctly as expected.

`StandardScaler` is sensitive to outliers, and the features may scale
differently from each other in the presence of outliers. For an example
visualization, refer to [Compare StandardScaler with other scalers](../../auto_examples/preprocessing/plot_all_scaling.md#plot-all-scaling-standard-scaler-section).

This scaler can also be applied to sparse CSR or CSC matrices by passing
`with_mean=False` to avoid breaking the sparsity structure of the data.

Read more in the [User Guide](../preprocessing.md#preprocessing-scaler).

* **Parameters:**
  **copy**
  : If False, try to avoid a copy and do inplace scaling instead.
    This is not guaranteed to always work inplace; e.g. if the data is
    not a NumPy array or scipy.sparse CSR matrix, a copy may still be
    returned.

  **with_mean**
  : If True, center the data before scaling.
    This does not work (and will raise an exception) when attempted on
    sparse matrices, because centering them entails building a dense
    matrix which in common use cases is likely to be too large to fit in
    memory.

  **with_std**
  : If True, scale the data to unit variance (or equivalently,
    unit standard deviation).
* **Attributes:**
  **scale_**
  : Per feature relative scaling of the data to achieve zero mean and unit
    variance. Generally this is calculated using `np.sqrt(var_)`. If a
    variance is zero, we can’t achieve unit variance, and the data is left
    as-is, giving a scaling factor of 1. `scale_` is equal to `None`
    when `with_std=False`.
    <br/>
    #### Versionadded
    Added in version 0.17: *scale_*

  **mean_**
  : The mean value for each feature in the training set.
    Equal to `None` when `with_mean=False` and `with_std=False`.

  **var_**
  : The variance for each feature in the training set. Used to compute
    `scale_`. Equal to `None` when `with_mean=False` and
    `with_std=False`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_samples_seen_**
  : The number of samples processed by the estimator for each feature.
    If there are no missing samples, the `n_samples_seen` will be an
    integer, otherwise it will be an array of dtype int. If
    `sample_weights` are used it will be a float (if no missing data)
    or an array of dtype float that sums the weights seen so far.
    Will be reset on new calls to fit, but increments across
    `partial_fit` calls.

#### SEE ALSO
[`scale`](sklearn.preprocessing.scale.md#sklearn.preprocessing.scale)
: Equivalent function without the estimator API.

[`PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA)
: Further removes the linear correlation across features with ‘whiten=True’.

### Notes

NaNs are treated as missing values: disregarded in fit, and maintained in
transform.

We use a biased estimator for the standard deviation, equivalent to
`numpy.std(x, ddof=0)`. Note that the choice of `ddof` is unlikely to
affect model performance.

### Examples

```pycon
>>> from sklearn.preprocessing import StandardScaler
>>> data = [[0, 0], [0, 0], [1, 1], [1, 1]]
>>> scaler = StandardScaler()
>>> print(scaler.fit(data))
StandardScaler()
>>> print(scaler.mean_)
[0.5 0.5]
>>> print(scaler.transform(data))
[[-1. -1.]
 [-1. -1.]
 [ 1.  1.]
 [ 1.  1.]]
>>> print(scaler.transform([[2, 2]]))
[[3. 3.]]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Compute the mean and std to be used for later scaling.

* **Parameters:**
  **X**
  : The data used to compute the mean and standard deviation
    used for later scaling along the features axis.

  **y**
  : Ignored.

  **sample_weight**
  : Individual weights for each sample.
    <br/>
    #### Versionadded
    Added in version 0.24: parameter *sample_weight* support to StandardScaler.
* **Returns:**
  **self**
  : Fitted scaler.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Same as input features.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X, copy=None)

Scale back the data to the original representation.

* **Parameters:**
  **X**
  : The data used to scale along the features axis.

  **copy**
  : Copy the input X or not.
* **Returns:**
  **X_tr**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y=None, sample_weight=None)

Online computation of mean and std on X for later scaling.

All of X is processed as a single batch. This is intended for cases
when [`fit`](#sklearn.preprocessing.StandardScaler.fit) is not feasible due to very large number of
`n_samples` or because X is read from a continuous stream.

The algorithm for incremental mean and std is given in Equation 1.5a,b
in Chan, Tony F., Gene H. Golub, and Randall J. LeVeque. “Algorithms
for computing the sample variance: Analysis and recommendations.”
The American Statistician 37.3 (1983): 242-247:

* **Parameters:**
  **X**
  : The data used to compute the mean and standard deviation
    used for later scaling along the features axis.

  **y**
  : Ignored.

  **sample_weight**
  : Individual weights for each sample.
    <br/>
    #### Versionadded
    Added in version 0.24: parameter *sample_weight* support to StandardScaler.
* **Returns:**
  **self**
  : Fitted scaler.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [StandardScaler](#sklearn.preprocessing.StandardScaler)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_inverse_transform_request(\*, copy: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [StandardScaler](#sklearn.preprocessing.StandardScaler)

Request metadata passed to the `inverse_transform` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `inverse_transform` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `inverse_transform`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **copy**
  : Metadata routing for `copy` parameter in `inverse_transform`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [StandardScaler](#sklearn.preprocessing.StandardScaler)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_transform_request(\*, copy: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [StandardScaler](#sklearn.preprocessing.StandardScaler)

Request metadata passed to the `transform` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `transform` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `transform`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **copy**
  : Metadata routing for `copy` parameter in `transform`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### transform(X, copy=None)

Perform standardization by centering and scaling.

* **Parameters:**
  **X**
  : The data used to scale along the features axis.

  **copy**
  : Copy the input X or not.
* **Returns:**
  **X_tr**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is a preprocessed excerpt of the &quot;Labeled Faces in the Wild&quot;, aka LFW_: http://vis-www.cs.umass.edu/lfw/lfw-funneled.tgz (233MB)">  <div class="sphx-glr-thumbnail-title">Faces recognition example using eigenfaces and SVMs</div>
</div>
* [Faces recognition example using eigenfaces and SVMs](../../auto_examples/applications/plot_face_recognition.md#sphx-glr-auto-examples-applications-plot-face-recognition-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing the prediction latency of various scikit-learn estimators.">  <div class="sphx-glr-thumbnail-title">Prediction Latency</div>
</div>
* [Prediction Latency](../../auto_examples/applications/plot_prediction_latency.md#sphx-glr-auto-examples-applications-plot-prediction-latency-py)

<div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the various initialization strategies for K-means in terms of runtime and quality of the results.">  <div class="sphx-glr-thumbnail-title">A demo of K-Means clustering on the handwritten digits data</div>
</div>
* [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different linkage methods for hierarchical clustering on datasets that are &quot;interesting&quot; but still in 2D.">  <div class="sphx-glr-thumbnail-title">Comparing different hierarchical linkage methods on toy datasets</div>
</div>
* [Comparing different hierarchical linkage methods on toy datasets](../../auto_examples/cluster/plot_linkage_comparison.md#sphx-glr-auto-examples-cluster-plot-linkage-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="DBSCAN (Density-Based Spatial Clustering of Applications with Noise) finds core samples in regions of high density and expands clusters from them. This algorithm is good for data which contains clusters of similar density.">  <div class="sphx-glr-thumbnail-title">Demo of DBSCAN clustering algorithm</div>
</div>
* [Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this demo we will take a look at cluster.HDBSCAN from the perspective of generalizing the cluster.DBSCAN algorithm. We&#x27;ll compare both algorithms on specific datasets. Finally we&#x27;ll evaluate HDBSCAN&#x27;s sensitivity to certain hyperparameters.">  <div class="sphx-glr-thumbnail-title">Demo of HDBSCAN clustering algorithm</div>
</div>
* [Demo of HDBSCAN clustering algorithm](../../auto_examples/cluster/plot_hdbscan.md#sphx-glr-auto-examples-cluster-plot-hdbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to apply different preprocessing and feature extraction pipelines to different subsets of features, using ColumnTransformer. This is particularly handy for the case of datasets that contain heterogeneous data types, since we may want to scale the numeric features and one-hot encode the categorical ones.">  <div class="sphx-glr-thumbnail-title">Column Transformer with Mixed Types</div>
</div>
* [Column Transformer with Mixed Types](../../auto_examples/compose/plot_column_transformer_mixed_types.md#sphx-glr-auto-examples-compose-plot-column-transformer-mixed-types-py)

<div class="sphx-glr-thumbcontainer" tooltip="The PCA does an unsupervised dimensionality reduction, while the logistic regression does the prediction.">  <div class="sphx-glr-thumbnail-title">Pipelining: chaining a PCA and a logistic regression</div>
</div>
* [Pipelining: chaining a PCA and a logistic regression](../../auto_examples/compose/plot_digits_pipe.md#sphx-glr-auto-examples-compose-plot-digits-pipe-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares Principal Component Regression (PCR) and Partial Least Squares Regression (PLS) on a toy dataset. Our goal is to illustrate how PLS can outperform PCR when the target is strongly correlated with some directions in the data that have a low variance.">  <div class="sphx-glr-thumbnail-title">Principal Component Regression vs Partial Least Squares Regression</div>
</div>
* [Principal Component Regression vs Partial Least Squares Regression](../../auto_examples/cross_decomposition/plot_pcr_vs_pls.md#sphx-glr-auto-examples-cross-decomposition-plot-pcr-vs-pls-py)

<div class="sphx-glr-thumbcontainer" tooltip="Investigating the Iris dataset, we see that sepal length, petal length and petal width are highly correlated. Sepal width is less redundant. Matrix decomposition techniques can uncover these latent patterns. Applying rotations to the resulting components does not inherently improve the predictive value of the derived latent space, but can help visualise their structure; here, for example, the varimax rotation, which is found by maximizing the squared variances of the weights, finds a structure where the second component only loads positively on sepal width.">  <div class="sphx-glr-thumbnail-title">Factor Analysis (with rotation) to visualize patterns</div>
</div>
* [Factor Analysis (with rotation) to visualize patterns](../../auto_examples/decomposition/plot_varimax_fa.md#sphx-glr-auto-examples-decomposition-plot-varimax-fa-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares two approaches for feature selection: SelectFromModel which is based on feature importance, and SequentialFeatureSelector which relies on a greedy approach.">  <div class="sphx-glr-thumbnail-title">Model-based and sequential feature selection</div>
</div>
* [Model-based and sequential feature selection](../../auto_examples/feature_selection/plot_select_from_model_diabetes.md#sphx-glr-auto-examples-feature-selection-plot-select-from-model-diabetes-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two different bayesian regressors:">  <div class="sphx-glr-thumbnail-title">Comparing Linear Bayesian Regressors</div>
</div>
* [Comparing Linear Bayesian Regressors](../../auto_examples/linear_model/plot_ard.md#sphx-glr-auto-examples-linear-model-plot-ard-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparison of the sparsity (percentage of zero coefficients) of solutions when L1, L2 and Elastic-Net penalty are used for different values of C. We can see that large values of C give more freedom to the model.  Conversely, smaller values of C constrain the model more. In the L1 penalty case, this leads to sparser solutions. As expected, the Elastic-Net penalty sparsity is between that of L1 and L2.">  <div class="sphx-glr-thumbnail-title">L1 Penalty and Sparsity in Logistic Regression</div>
</div>
* [L1 Penalty and Sparsity in Logistic Regression](../../auto_examples/linear_model/plot_logistic_l1_l2_sparsity.md#sphx-glr-auto-examples-linear-model-plot-logistic-l1-l2-sparsity-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example reproduces the example of Fig. 2 of [ZHT2007]_. A LassoLarsIC estimator is fit on a diabetes dataset and the AIC and the BIC criteria are used to select the best model.">  <div class="sphx-glr-thumbnail-title">Lasso model selection via information criteria</div>
</div>
* [Lasso model selection via information criteria](../../auto_examples/linear_model/plot_lasso_lars_ic.md#sphx-glr-auto-examples-linear-model-plot-lasso-lars-ic-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example focuses on model selection for Lasso models that are linear models with an L1 penalty for regression problems.">  <div class="sphx-glr-thumbnail-title">Lasso model selection: AIC-BIC / cross-validation</div>
</div>
* [Lasso model selection: AIC-BIC / cross-validation](../../auto_examples/linear_model/plot_lasso_model_selection.md#sphx-glr-auto-examples-linear-model-plot-lasso-model-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="Here we fit a multinomial logistic regression with L1 penalty on a subset of the MNIST digits classification task. We use the SAGA algorithm for this purpose: this a solver that is fast when the number of samples is significantly larger than the number of features and is able to finely optimize non-smooth objective functions which is the case with the l1-penalty. Test accuracy reaches &gt; 0.8, while weight vectors remains sparse and therefore more easily interpretable.">  <div class="sphx-glr-thumbnail-title">MNIST classification using multinomial logistic + L1</div>
</div>
* [MNIST classification using multinomial logistic + L1](../../auto_examples/linear_model/plot_sparse_logistic_regression_mnist.md#sphx-glr-auto-examples-linear-model-plot-sparse-logistic-regression-mnist-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Poisson, Gamma and Tweedie regression on the French Motor Third-Party Liability Claims dataset, and is inspired by an R tutorial [1]_.">  <div class="sphx-glr-thumbnail-title">Tweedie regression on insurance claims</div>
</div>
* [Tweedie regression on insurance claims](../../auto_examples/linear_model/plot_tweedie_regression_insurance_claims.md#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py)

<div class="sphx-glr-thumbcontainer" tooltip="    See also sphx_glr_auto_examples_miscellaneous_plot_roc_curve_visualization_api.py">  <div class="sphx-glr-thumbnail-title">Advanced Plotting With Partial Dependence</div>
</div>
* [Advanced Plotting With Partial Dependence](../../auto_examples/miscellaneous/plot_partial_dependence_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-partial-dependence-visualization-api-py)

<div class="sphx-glr-thumbcontainer" tooltip="The default configuration for displaying a pipeline in a Jupyter Notebook is &#x27;diagram&#x27; where set_config(display=&#x27;diagram&#x27;). To deactivate HTML representation, use set_config(display=&#x27;text&#x27;).">  <div class="sphx-glr-thumbnail-title">Displaying Pipelines</div>
</div>
* [Displaying Pipelines](../../auto_examples/miscellaneous/plot_pipeline_display.md#sphx-glr-auto-examples-miscellaneous-plot-pipeline-display-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates different ways estimators and pipelines can be displayed.">  <div class="sphx-glr-thumbnail-title">Displaying estimators and complex pipelines</div>
</div>
* [Displaying estimators and complex pipelines](../../auto_examples/miscellaneous/plot_estimator_representation.md#sphx-glr-auto-examples-miscellaneous-plot-estimator-representation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example will demonstrate the set_output API to configure transformers to output pandas DataFrames. set_output can be configured per estimator by calling the set_output method or globally by setting set_config(transform_output=&quot;pandas&quot;). For details, see SLEP018.">  <div class="sphx-glr-thumbnail-title">Introducing the set_output API</div>
</div>
* [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we compare two binary classification multi-threshold metrics: the Receiver Operating Characteristic (ROC) and the Detection Error Tradeoff (DET). For such purpose, we evaluate two different classifiers for the same classification task.">  <div class="sphx-glr-thumbnail-title">Detection error tradeoff (DET) curve</div>
</div>
* [Detection error tradeoff (DET) curve](../../auto_examples/model_selection/plot_det.md#sphx-glr-auto-examples-model-selection-plot-det-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a binary classifier is trained, the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. The default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0. However, this default strategy may not be optimal for the task at hand.">  <div class="sphx-glr-thumbnail-title">Post-hoc tuning the cut-off point of decision function</div>
</div>
* [Post-hoc tuning the cut-off point of decision function](../../auto_examples/model_selection/plot_tuned_decision_threshold.md#sphx-glr-auto-examples-model-selection-plot-tuned-decision-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example comparing nearest neighbors classification with and without Neighborhood Components Analysis.">  <div class="sphx-glr-thumbnail-title">Comparing Nearest Neighbors with and without Neighborhood Components Analysis</div>
</div>
* [Comparing Nearest Neighbors with and without Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_classification.md#sphx-glr-auto-examples-neighbors-plot-nca-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Sample usage of Neighborhood Components Analysis for dimensionality reduction.">  <div class="sphx-glr-thumbnail-title">Dimensionality Reduction with Neighborhood Components Analysis</div>
</div>
* [Dimensionality Reduction with Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_dim_reduction.md#sphx-glr-auto-examples-neighbors-plot-nca-dim-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use KNeighborsClassifier. We train such a classifier on the iris dataset and observe the difference of the decision boundary obtained with regards to the parameter weights.">  <div class="sphx-glr-thumbnail-title">Nearest Neighbors Classification</div>
</div>
* [Nearest Neighbors Classification](../../auto_examples/neighbors/plot_classification.md#sphx-glr-auto-examples-neighbors-plot-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="A comparison of different values for regularization parameter &#x27;alpha&#x27; on synthetic datasets. The plot shows that different alphas yield different decision functions.">  <div class="sphx-glr-thumbnail-title">Varying regularization in Multi-layer Perceptron</div>
</div>
* [Varying regularization in Multi-layer Perceptron](../../auto_examples/neural_networks/plot_mlp_alpha.md#sphx-glr-auto-examples-neural-networks-plot-mlp-alpha-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature 0 (median income in a block) and feature 5 (average house occupancy) of the california_housing_dataset have very different scales and contain some very large outliers. These two characteristics lead to difficulties to visualize the data and, more importantly, they can degrade the predictive performance of many machine learning algorithms. Unscaled data can also slow down or even prevent the convergence of many gradient-based estimators.">  <div class="sphx-glr-thumbnail-title">Compare the effect of different scalers on data with outliers</div>
</div>
* [Compare the effect of different scalers on data with outliers](../../auto_examples/preprocessing/plot_all_scaling.md#sphx-glr-auto-examples-preprocessing-plot-all-scaling-py)

<div class="sphx-glr-thumbcontainer" tooltip="A demonstration of feature discretization on synthetic classification datasets. Feature discretization decomposes each feature into a set of bins, here equally distributed in width. The discrete values are then one-hot encoded, and given to a linear classifier. This preprocessing enables a non-linear behavior even though the classifier is linear.">  <div class="sphx-glr-thumbnail-title">Feature discretization</div>
</div>
* [Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature scaling through standardization, also called Z-score normalization, is an important preprocessing step for many machine learning algorithms. It involves rescaling each feature such that it has a standard deviation of 1 and a mean of 0.">  <div class="sphx-glr-thumbnail-title">Importance of Feature Scaling</div>
</div>
* [Importance of Feature Scaling](../../auto_examples/preprocessing/plot_scaling_importance.md#sphx-glr-auto-examples-preprocessing-plot-scaling-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of the parameters gamma and C of the Radial Basis Function (RBF) kernel SVM.">  <div class="sphx-glr-thumbnail-title">RBF SVM parameters</div>
</div>
* [RBF SVM parameters](../../auto_examples/svm/plot_rbf_parameters.md#sphx-glr-auto-examples-svm-plot-rbf-parameters-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to perform univariate feature selection before running a SVC (support vector classifier) to improve the classification scores. We use the iris dataset (4 features) and add 36 non-informative features. We can find that our model achieves best performance when we select around 10% of features.">  <div class="sphx-glr-thumbnail-title">SVM-Anova: SVM with univariate feature selection</div>
</div>
* [SVM-Anova: SVM with univariate feature selection](../../auto_examples/svm/plot_svm_anova.md#sphx-glr-auto-examples-svm-plot-svm-anova-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.2! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_2&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.2</div>
</div>
* [Release Highlights for scikit-learn 1.2](../../auto_examples/release_highlights/plot_release_highlights_1_2_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-2-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are very pleased to announce the release of scikit-learn 1.0! The library has been stable for quite some time, releasing version 1.0 is recognizing that and signalling it to our users. This release does not include any breaking changes apart from the usual two-release deprecation cycle. For the future, we do our best to keep this pattern.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.0</div>
</div>
* [Release Highlights for scikit-learn 1.0](../../auto_examples/release_highlights/plot_release_highlights_1_0_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-0-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
