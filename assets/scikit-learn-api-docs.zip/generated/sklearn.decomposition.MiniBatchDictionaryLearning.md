# MiniBatchDictionaryLearning

### *class* sklearn.decomposition.MiniBatchDictionaryLearning(n_components=None, \*, alpha=1, max_iter=1000, fit_algorithm='lars', n_jobs=None, batch_size=256, shuffle=True, dict_init=None, transform_algorithm='omp', transform_n_nonzero_coefs=None, transform_alpha=None, verbose=False, split_sign=False, random_state=None, positive_code=False, positive_dict=False, transform_max_iter=1000, callback=None, tol=0.001, max_no_improvement=10)

Mini-batch dictionary learning.

Finds a dictionary (a set of atoms) that performs well at sparsely
encoding the fitted data.

Solves the optimization problem:

```default
(U^*,V^*) = argmin 0.5 || X - U V ||_Fro^2 + alpha * || U ||_1,1
             (U,V)
             with || V_k ||_2 <= 1 for all  0 <= k < n_components
```

||.||_Fro stands for the Frobenius norm and ||.||_1,1 stands for
the entry-wise matrix norm which is the sum of the absolute values
of all the entries in the matrix.

Read more in the [User Guide](../decomposition.md#dictionarylearning).

* **Parameters:**
  **n_components**
  : Number of dictionary elements to extract.

  **alpha**
  : Sparsity controlling parameter.

  **max_iter**
  : Maximum number of iterations over the complete dataset before
    stopping independently of any early stopping criterion heuristics.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **fit_algorithm**
  : The algorithm used:
    - `'lars'`: uses the least angle regression method to solve the lasso
      problem (`linear_model.lars_path`)
    - `'cd'`: uses the coordinate descent method to compute the
      Lasso solution (`linear_model.Lasso`). Lars will be faster if
      the estimated components are sparse.

  **n_jobs**
  : Number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **batch_size**
  : Number of samples in each mini-batch.
    <br/>
    #### Versionchanged
    Changed in version 1.3: The default value of `batch_size` changed from 3 to 256 in version 1.3.

  **shuffle**
  : Whether to shuffle the samples before forming batches.

  **dict_init**
  : Initial value of the dictionary for warm restart scenarios.

  **transform_algorithm**
  : Algorithm used to transform the data:
    - `'lars'`: uses the least angle regression method
      (`linear_model.lars_path`);
    - `'lasso_lars'`: uses Lars to compute the Lasso solution.
    - `'lasso_cd'`: uses the coordinate descent method to compute the
      Lasso solution (`linear_model.Lasso`). `'lasso_lars'` will be faster
      if the estimated components are sparse.
    - `'omp'`: uses orthogonal matching pursuit to estimate the sparse
      solution.
    - `'threshold'`: squashes to zero all coefficients less than alpha from
      the projection `dictionary * X'`.

  **transform_n_nonzero_coefs**
  : Number of nonzero coefficients to target in each column of the
    solution. This is only used by `algorithm='lars'` and
    `algorithm='omp'`. If `None`, then
    `transform_n_nonzero_coefs=int(n_features / 10)`.

  **transform_alpha**
  : If `algorithm='lasso_lars'` or `algorithm='lasso_cd'`, `alpha` is the
    penalty applied to the L1 norm.
    If `algorithm='threshold'`, `alpha` is the absolute value of the
    threshold below which coefficients will be squashed to zero.
    If `None`, defaults to `alpha`.
    <br/>
    #### Versionchanged
    Changed in version 1.2: When None, default value changed from 1.0 to `alpha`.

  **verbose**
  : To control the verbosity of the procedure.

  **split_sign**
  : Whether to split the sparse feature vector into the concatenation of
    its negative part and its positive part. This can improve the
    performance of downstream classifiers.

  **random_state**
  : Used for initializing the dictionary when `dict_init` is not
    specified, randomly shuffling the data when `shuffle` is set to
    `True`, and updating the dictionary. Pass an int for reproducible
    results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **positive_code**
  : Whether to enforce positivity when finding the code.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **positive_dict**
  : Whether to enforce positivity when finding the dictionary.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **transform_max_iter**
  : Maximum number of iterations to perform if `algorithm='lasso_cd'` or
    `'lasso_lars'`.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **callback**
  : A callable that gets invoked at the end of each iteration.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **tol**
  : Control early stopping based on the norm of the differences in the
    dictionary between 2 steps.
    <br/>
    To disable early stopping based on changes in the dictionary, set
    `tol` to 0.0.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **max_no_improvement**
  : Control early stopping based on the consecutive number of mini batches
    that does not yield an improvement on the smoothed cost function.
    <br/>
    To disable convergence detection based on cost function, set
    `max_no_improvement` to None.
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Attributes:**
  **components_**
  : Components extracted from the data.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Number of iterations over the full dataset.

  **n_steps_**
  : Number of mini-batches processed.
    <br/>
    #### Versionadded
    Added in version 1.1.

#### SEE ALSO
[`DictionaryLearning`](sklearn.decomposition.DictionaryLearning.md#sklearn.decomposition.DictionaryLearning)
: Find a dictionary that sparsely encodes data.

[`MiniBatchSparsePCA`](sklearn.decomposition.MiniBatchSparsePCA.md#sklearn.decomposition.MiniBatchSparsePCA)
: Mini-batch Sparse Principal Components Analysis.

[`SparseCoder`](sklearn.decomposition.SparseCoder.md#sklearn.decomposition.SparseCoder)
: Find a sparse representation of data from a fixed, precomputed dictionary.

[`SparsePCA`](sklearn.decomposition.SparsePCA.md#sklearn.decomposition.SparsePCA)
: Sparse Principal Components Analysis.

### References

J. Mairal, F. Bach, J. Ponce, G. Sapiro, 2009: Online dictionary learning
for sparse coding ([https://www.di.ens.fr/~fbach/mairal_icml09.pdf](https://www.di.ens.fr/~fbach/mairal_icml09.pdf))

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.datasets import make_sparse_coded_signal
>>> from sklearn.decomposition import MiniBatchDictionaryLearning
>>> X, dictionary, code = make_sparse_coded_signal(
...     n_samples=30, n_components=15, n_features=20, n_nonzero_coefs=10,
...     random_state=42)
>>> dict_learner = MiniBatchDictionaryLearning(
...     n_components=15, batch_size=3, transform_algorithm='lasso_lars',
...     transform_alpha=0.1, max_iter=20, random_state=42)
>>> X_transformed = dict_learner.fit_transform(X)
```

We can check the level of sparsity of `X_transformed`:

```pycon
>>> np.mean(X_transformed == 0) > 0.5
np.True_
```

We can compare the average squared euclidean norm of the reconstruction
error of the sparse coded signal relative to the squared euclidean norm of
the original signal:

```pycon
>>> X_hat = X_transformed @ dict_learner.components_
>>> np.mean(np.sum((X_hat - X) ** 2, axis=1) / np.sum(X ** 2, axis=1))
np.float64(0.052...)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the model from data in X.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y=None)

Update the model using the data in X as a mini-batch.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Return the instance itself.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Encode the data as a sparse combination of the dictionary atoms.

Coding method is determined by the object parameter
`transform_algorithm`.

* **Parameters:**
  **X**
  : Test data to be transformed, must have the same number of
    features as the data used to train the model.
* **Returns:**
  **X_new**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example applies to olivetti_faces_dataset different unsupervised matrix decomposition (dimension reduction) methods from the module sklearn.decomposition (see the documentation chapter decompositions).">  <div class="sphx-glr-thumbnail-title">Faces dataset decompositions</div>
</div>
* [Faces dataset decompositions](../../auto_examples/decomposition/plot_faces_decomposition.md#sphx-glr-auto-examples-decomposition-plot-faces-decomposition-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example comparing the effect of reconstructing noisy fragments of a raccoon face image using firstly online DictionaryLearning and various transform methods.">  <div class="sphx-glr-thumbnail-title">Image denoising using dictionary learning</div>
</div>
* [Image denoising using dictionary learning](../../auto_examples/decomposition/plot_image_denoising.md#sphx-glr-auto-examples-decomposition-plot-image-denoising-py)

<!-- thumbnail-parent-div-close --></div>
