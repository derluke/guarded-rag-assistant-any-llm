# safe_sqr

### sklearn.utils.safe_sqr(X, \*, copy=True)

Element wise squaring of array-likes and sparse matrices.

* **Parameters:**
  **X**

  **copy**
  : Whether to create a copy of X and operate on it or to perform
    inplace computation (default behaviour).
* **Returns:**
  **X \*\* 2**
  : Return the element-wise square of the input.

### Examples

```pycon
>>> from sklearn.utils import safe_sqr
>>> safe_sqr([1, 2, 3])
array([1, 4, 9])
```

<!-- !! processed by numpydoc !! -->
