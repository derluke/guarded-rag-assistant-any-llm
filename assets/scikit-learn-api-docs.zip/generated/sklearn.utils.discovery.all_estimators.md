# all_estimators

### sklearn.utils.discovery.all_estimators(type_filter=None)

Get a list of all estimators from `sklearn`.

This function crawls the module and gets all classes that inherit
from BaseEstimator. Classes that are defined in test-modules are not
included.

* **Parameters:**
  **type_filter**
  : Which kind of estimators should be returned. If None, no filter is
    applied and all estimators are returned.  Possible values are
    ‘classifier’, ‘regressor’, ‘cluster’ and ‘transformer’ to get
    estimators only of these specific types, or a list of these to
    get the estimators that fit at least one of the types.
* **Returns:**
  **estimators**
  : List of (name, class), where `name` is the class name as string
    and `class` is the actual type of the class.

### Examples

```pycon
>>> from sklearn.utils.discovery import all_estimators
>>> estimators = all_estimators()
>>> type(estimators)
<class 'list'>
>>> type(estimators[0])
<class 'tuple'>
>>> estimators[:2]
[('ARDRegression', <class 'sklearn.linear_model._bayes.ARDRegression'>),
 ('AdaBoostClassifier',
  <class 'sklearn.ensemble._weight_boosting.AdaBoostClassifier'>)]
>>> classifiers = all_estimators(type_filter="classifier")
>>> classifiers[:2]
[('AdaBoostClassifier',
  <class 'sklearn.ensemble._weight_boosting.AdaBoostClassifier'>),
 ('BaggingClassifier', <class 'sklearn.ensemble._bagging.BaggingClassifier'>)]
>>> regressors = all_estimators(type_filter="regressor")
>>> regressors[:2]
[('ARDRegression', <class 'sklearn.linear_model._bayes.ARDRegression'>),
 ('AdaBoostRegressor',
  <class 'sklearn.ensemble._weight_boosting.AdaBoostRegressor'>)]
>>> both = all_estimators(type_filter=["classifier", "regressor"])
>>> both[:2]
[('ARDRegression', <class 'sklearn.linear_model._bayes.ARDRegression'>),
 ('AdaBoostClassifier',
  <class 'sklearn.ensemble._weight_boosting.AdaBoostClassifier'>)]
```

<!-- !! processed by numpydoc !! -->
