# config_context

### sklearn.config_context(\*, assume_finite=None, working_memory=None, print_changed_only=None, display=None, pairwise_dist_chunk_size=None, enable_cython_pairwise_dist=None, array_api_dispatch=None, transform_output=None, enable_metadata_routing=None, skip_parameter_validation=None)

Context manager for global scikit-learn configuration.

* **Parameters:**
  **assume_finite**
  : If True, validation for finiteness will be skipped,
    saving time, but leading to potential crashes. If
    False, validation for finiteness will be performed,
    avoiding error. If None, the existing value won’t change.
    The default value is False.

  **working_memory**
  : If set, scikit-learn will attempt to limit the size of temporary arrays
    to this number of MiB (per job when parallelised), often saving both
    computation time and memory on expensive operations that can be
    performed in chunks. If None, the existing value won’t change.
    The default value is 1024.

  **print_changed_only**
  : If True, only the parameters that were set to non-default
    values will be printed when printing an estimator. For example,
    `print(SVC())` while True will only print ‘SVC()’, but would print
    ‘SVC(C=1.0, cache_size=200, …)’ with all the non-changed parameters
    when False. If None, the existing value won’t change.
    The default value is True.
    <br/>
    #### Versionchanged
    Changed in version 0.23: Default changed from False to True.

  **display**
  : If ‘diagram’, estimators will be displayed as a diagram in a Jupyter
    lab or notebook context. If ‘text’, estimators will be displayed as
    text. If None, the existing value won’t change.
    The default value is ‘diagram’.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **pairwise_dist_chunk_size**
  : The number of row vectors per chunk for the accelerated pairwise-
    distances reduction backend. Default is 256 (suitable for most of
    modern laptops’ caches and architectures).
    <br/>
    Intended for easier benchmarking and testing of scikit-learn internals.
    End users are not expected to benefit from customizing this configuration
    setting.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **enable_cython_pairwise_dist**
  : Use the accelerated pairwise-distances reduction backend when
    possible. Global default: True.
    <br/>
    Intended for easier benchmarking and testing of scikit-learn internals.
    End users are not expected to benefit from customizing this configuration
    setting.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **array_api_dispatch**
  : Use Array API dispatching when inputs follow the Array API standard.
    Default is False.
    <br/>
    See the [User Guide](../array_api.md#array-api) for more details.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **transform_output**
  : Configure output of `transform` and `fit_transform`.
    <br/>
    See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
    for an example on how to use the API.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.2.
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.

  **enable_metadata_routing**
  : Enable metadata routing. By default this feature is disabled.
    <br/>
    Refer to [metadata routing user guide](../../metadata_routing.md#metadata-routing) for more
    details.
    - `True`: Metadata routing is enabled
    - `False`: Metadata routing is disabled, use the old syntax.
    - `None`: Configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.3.

  **skip_parameter_validation**
  : If `True`, disable the validation of the hyper-parameters’ types and values in
    the fit method of estimators and for arguments passed to public helper
    functions. It can save time in some situations but can lead to low level
    crashes and exceptions with confusing error messages.
    <br/>
    Note that for data parameters, such as `X` and `y`, only type validation is
    skipped but validation with `check_array` will continue to run.
    <br/>
    #### Versionadded
    Added in version 1.3.
* **Yields:**
  None.

#### SEE ALSO
[`set_config`](sklearn.set_config.md#sklearn.set_config)
: Set global scikit-learn configuration.

[`get_config`](sklearn.get_config.md#sklearn.get_config)
: Retrieve current values of the global configuration.

### Notes

All settings, not just those presently modified, will be returned to
their previous values when the context manager is exited.

### Examples

```pycon
>>> import sklearn
>>> from sklearn.utils.validation import assert_all_finite
>>> with sklearn.config_context(assume_finite=True):
...     assert_all_finite([float('nan')])
>>> with sklearn.config_context(assume_finite=True):
...     with sklearn.config_context(assume_finite=False):
...         assert_all_finite([float('nan')])
Traceback (most recent call last):
...
ValueError: Input contains NaN...
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example will demonstrate the set_output API to configure transformers to output pandas DataFrames. set_output can be configured per estimator by calling the set_output method or globally by setting set_config(transform_output=&quot;pandas&quot;). For details, see SLEP018.">  <div class="sphx-glr-thumbnail-title">Introducing the set_output API</div>
</div>
* [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)

<!-- thumbnail-parent-div-close --></div>
