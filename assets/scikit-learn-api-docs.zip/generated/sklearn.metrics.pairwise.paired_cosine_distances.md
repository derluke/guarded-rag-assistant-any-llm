# paired_cosine_distances

### sklearn.metrics.pairwise.paired_cosine_distances(X, Y)

Compute the paired cosine distances between X and Y.

Read more in the [User Guide](../metrics.md#metrics).

* **Parameters:**
  **X**
  : An array where each row is a sample and each column is a feature.

  **Y**
  : An array where each row is a sample and each column is a feature.
* **Returns:**
  **distances**
  : Returns the distances between the row vectors of `X`
    and the row vectors of `Y`, where `distances[i]` is the
    distance between `X[i]` and `Y[i]`.

### Notes

The cosine distance is equivalent to the half the squared
euclidean distance if each sample is normalized to unit norm.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import paired_cosine_distances
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> paired_cosine_distances(X, Y)
array([0.5       , 0.18...])
```

<!-- !! processed by numpydoc !! -->
