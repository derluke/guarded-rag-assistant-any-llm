# SGDOneClassSVM

### *class* sklearn.linear_model.SGDOneClassSVM(nu=0.5, fit_intercept=True, max_iter=1000, tol=0.001, shuffle=True, verbose=0, random_state=None, learning_rate='optimal', eta0=0.0, power_t=0.5, warm_start=False, average=False)

Solves linear One-Class SVM using Stochastic Gradient Descent.

This implementation is meant to be used with a kernel approximation
technique (e.g. `sklearn.kernel_approximation.Nystroem`) to obtain results
similar to `sklearn.svm.OneClassSVM` which uses a Gaussian kernel by
default.

Read more in the [User Guide](../sgd.md#sgd-online-one-class-svm).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **nu**
  : The nu parameter of the One Class SVM: an upper bound on the
    fraction of training errors and a lower bound of the fraction of
    support vectors. Should be in the interval (0, 1]. By default 0.5
    will be taken.

  **fit_intercept**
  : Whether the intercept should be estimated or not. Defaults to True.

  **max_iter**
  : The maximum number of passes over the training data (aka epochs).
    It only impacts the behavior in the `fit` method, and not the
    `partial_fit`. Defaults to 1000.
    Values must be in the range `[1, inf)`.

  **tol**
  : The stopping criterion. If it is not None, the iterations will stop
    when (loss > previous_loss - tol). Defaults to 1e-3.
    Values must be in the range `[0.0, inf)`.

  **shuffle**
  : Whether or not the training data should be shuffled after each epoch.
    Defaults to True.

  **verbose**
  : The verbosity level.

  **random_state**
  : The seed of the pseudo random number generator to use when shuffling
    the data.  If int, random_state is the seed used by the random number
    generator; If RandomState instance, random_state is the random number
    generator; If None, the random number generator is the RandomState
    instance used by `np.random`.

  **learning_rate**
  : The learning rate schedule to use with `fit`. (If using `partial_fit`,
    learning rate must be controlled directly).
    - ‘constant’: `eta = eta0`
    - ‘optimal’: `eta = 1.0 / (alpha * (t + t0))`
      where t0 is chosen by a heuristic proposed by Leon Bottou.
    - ‘invscaling’: `eta = eta0 / pow(t, power_t)`
    - ‘adaptive’: eta = eta0, as long as the training keeps decreasing.
      Each time n_iter_no_change consecutive epochs fail to decrease the
      training loss by tol or fail to increase validation score by tol if
      early_stopping is True, the current learning rate is divided by 5.

  **eta0**
  : The initial learning rate for the ‘constant’, ‘invscaling’ or
    ‘adaptive’ schedules. The default value is 0.0 as eta0 is not used by
    the default schedule ‘optimal’.
    Values must be in the range `[0.0, inf)`.

  **power_t**
  : The exponent for inverse scaling learning rate.
    Values must be in the range `(-inf, inf)`.

  **warm_start**
  : When set to True, reuse the solution of the previous call to fit as
    initialization, otherwise, just erase the previous solution.
    See [the Glossary](../../glossary.md#term-warm_start).
    <br/>
    Repeatedly calling fit or partial_fit when warm_start is True can
    result in a different solution than when calling fit a single time
    because of the way the data is shuffled.
    If a dynamic learning rate is used, the learning rate is adapted
    depending on the number of samples already seen. Calling `fit` resets
    this counter, while `partial_fit`  will result in increasing the
    existing counter.

  **average**
  : When set to True, computes the averaged SGD weights and stores the
    result in the `coef_` attribute. If set to an int greater than 1,
    averaging will begin once the total number of samples seen reaches
    average. So `average=10` will begin averaging after seeing 10
    samples.
* **Attributes:**
  **coef_**
  : Weights assigned to the features.

  **offset_**
  : Offset used to define the decision function from the raw scores.
    We have the relation: decision_function = score_samples - offset.

  **n_iter_**
  : The actual number of iterations to reach the stopping criterion.

  **t_**
  : Number of weight updates performed during training.
    Same as `(n_iter_ * n_samples + 1)`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`sklearn.svm.OneClassSVM`](sklearn.svm.OneClassSVM.md#sklearn.svm.OneClassSVM)
: Unsupervised Outlier Detection.

### Notes

This estimator has a linear complexity in the number of training samples
and is thus better suited than the `sklearn.svm.OneClassSVM`
implementation for datasets with a large number of training samples (say
> 10,000).

### Examples

```pycon
>>> import numpy as np
>>> from sklearn import linear_model
>>> X = np.array([[-1, -1], [-2, -1], [1, 1], [2, 1]])
>>> clf = linear_model.SGDOneClassSVM(random_state=42)
>>> clf.fit(X)
SGDOneClassSVM(random_state=42)
```

```pycon
>>> print(clf.predict([[4, 4]]))
[1]
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Signed distance to the separating hyperplane.

Signed distance is positive for an inlier and negative for an
outlier.

* **Parameters:**
  **X**
  : Testing data.
* **Returns:**
  **dec**
  : Decision function values of the samples.

<!-- !! processed by numpydoc !! -->

#### densify()

Convert coefficient matrix to dense array format.

Converts the `coef_` member (back) to a numpy.ndarray. This is the
default format of `coef_` and is required for fitting, so calling
this method is only required on models that have previously been
sparsified; otherwise, it is a no-op.

* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, coef_init=None, offset_init=None, sample_weight=None)

Fit linear One-Class SVM with Stochastic Gradient Descent.

This solves an equivalent optimization problem of the
One-Class SVM primal optimization problem and returns a weight vector
w and an offset rho such that the decision function is given by
<w, x> - rho.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Not used, present for API consistency by convention.

  **coef_init**
  : The initial coefficients to warm-start the optimization.

  **offset_init**
  : The initial offset to warm-start the optimization.

  **sample_weight**
  : Weights applied to individual samples.
    If not provided, uniform weights are assumed. These weights will
    be multiplied with class_weight (passed through the
    constructor) if class_weight is specified.
* **Returns:**
  **self**
  : Returns a fitted instance of self.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None, \*\*kwargs)

Perform fit on X and returns labels for X.

Returns -1 for outliers and 1 for inliers.

* **Parameters:**
  **X**
  : The input samples.

  **y**
  : Not used, present for API consistency by convention.

  **\*\*kwargs**
  : Arguments to be passed to `fit`.
    <br/>
    #### Versionadded
    Added in version 1.4.
* **Returns:**
  **y**
  : 1 for inliers, -1 for outliers.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y=None, sample_weight=None)

Fit linear One-Class SVM with Stochastic Gradient Descent.

* **Parameters:**
  **X**
  : Subset of the training data.

  **y**
  : Not used, present for API consistency by convention.

  **sample_weight**
  : Weights applied to individual samples.
    If not provided, uniform weights are assumed.
* **Returns:**
  **self**
  : Returns a fitted instance of self.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Return labels (1 inlier, -1 outlier) of the samples.

* **Parameters:**
  **X**
  : Testing data.
* **Returns:**
  **y**
  : Labels of the samples.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Raw scoring function of the samples.

* **Parameters:**
  **X**
  : Testing data.
* **Returns:**
  **score_samples**
  : Unshiffted scoring function values of the samples.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, coef_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', offset_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SGDOneClassSVM](#sklearn.linear_model.SGDOneClassSVM)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **coef_init**
  : Metadata routing for `coef_init` parameter in `fit`.

  **offset_init**
  : Metadata routing for `offset_init` parameter in `fit`.

  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SGDOneClassSVM](#sklearn.linear_model.SGDOneClassSVM)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### sparsify()

Convert coefficient matrix to sparse format.

Converts the `coef_` member to a scipy.sparse matrix, which for
L1-regularized models can be much more memory- and storage-efficient
than the usual numpy.ndarray representation.

The `intercept_` member is not converted.

* **Returns:**
  self
  : Fitted estimator.

### Notes

For non-sparse models, i.e. when there are not many zeros in `coef_`,
this may actually *increase* memory usage, so use this method with
care. A rule of thumb is that the number of zero elements, which can
be computed with `(coef_ == 0).sum()`, must be more than 50% for this
to provide significant benefits.

After calling this method, further fitting with the partial_fit
method (if any) will not work until you call densify.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows how to approximate the solution of sklearn.svm.OneClassSVM in the case of an RBF kernel with sklearn.linear_model.SGDOneClassSVM, a Stochastic Gradient Descent (SGD) version of the One-Class SVM. A kernel approximation is first used in order to apply sklearn.linear_model.SGDOneClassSVM which implements a linear One-Class SVM using SGD.">  <div class="sphx-glr-thumbnail-title">One-Class SVM versus One-Class SVM using Stochastic Gradient Descent</div>
</div>
* [One-Class SVM versus One-Class SVM using Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgdocsvm_vs_ocsvm.md#sphx-glr-auto-examples-linear-model-plot-sgdocsvm-vs-ocsvm-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different anomaly detection algorithms on 2D datasets. Datasets contain one or two modes (regions of high density) to illustrate the ability of algorithms to cope with multimodal data.">  <div class="sphx-glr-thumbnail-title">Comparing anomaly detection algorithms for outlier detection on toy datasets</div>
</div>
* [Comparing anomaly detection algorithms for outlier detection on toy datasets](../../auto_examples/miscellaneous/plot_anomaly_comparison.md#sphx-glr-auto-examples-miscellaneous-plot-anomaly-comparison-py)

<!-- thumbnail-parent-div-close --></div>
