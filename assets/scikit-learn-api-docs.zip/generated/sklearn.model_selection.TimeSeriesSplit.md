# TimeSeriesSplit

### *class* sklearn.model_selection.TimeSeriesSplit(n_splits=5, \*, max_train_size=None, test_size=None, gap=0)

Time Series cross-validator.

Provides train/test indices to split time series data samples
that are observed at fixed time intervals, in train/test sets.
In each split, test indices must be higher than before, and thus shuffling
in cross validator is inappropriate.

This cross-validation object is a variation of [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold).
In the kth split, it returns first k folds as train set and the
(k+1)th fold as test set.

Note that unlike standard cross-validation methods, successive
training sets are supersets of those that come before them.

Read more in the [User Guide](../cross_validation.md#time-series-split).

For visualisation of cross-validation behaviour and
comparison between common scikit-learn split methods
refer to [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **n_splits**
  : Number of splits. Must be at least 2.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `n_splits` default value changed from 3 to 5.

  **max_train_size**
  : Maximum size for a single training set.

  **test_size**
  : Used to limit the size of the test set. Defaults to
    `n_samples // (n_splits + 1)`, which is the maximum allowed value
    with `gap=0`.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **gap**
  : Number of samples to exclude from the end of each train set before
    the test set.
    <br/>
    #### Versionadded
    Added in version 0.24.

### Notes

The training set has size `i * n_samples // (n_splits + 1)
+ n_samples % (n_splits + 1)` in the `i` th split,
with a test set of size `n_samples//(n_splits + 1)` by default,
where `n_samples` is the number of samples. Note that this
formula is only valid when `test_size` and `max_train_size` are
left to their default values.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import TimeSeriesSplit
>>> X = np.array([[1, 2], [3, 4], [1, 2], [3, 4], [1, 2], [3, 4]])
>>> y = np.array([1, 2, 3, 4, 5, 6])
>>> tscv = TimeSeriesSplit()
>>> print(tscv)
TimeSeriesSplit(gap=0, max_train_size=None, n_splits=5, test_size=None)
>>> for i, (train_index, test_index) in enumerate(tscv.split(X)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}")
...     print(f"  Test:  index={test_index}")
Fold 0:
  Train: index=[0]
  Test:  index=[1]
Fold 1:
  Train: index=[0 1]
  Test:  index=[2]
Fold 2:
  Train: index=[0 1 2]
  Test:  index=[3]
Fold 3:
  Train: index=[0 1 2 3]
  Test:  index=[4]
Fold 4:
  Train: index=[0 1 2 3 4]
  Test:  index=[5]
>>> # Fix test_size to 2 with 12 samples
>>> X = np.random.randn(12, 2)
>>> y = np.random.randint(0, 2, 12)
>>> tscv = TimeSeriesSplit(n_splits=3, test_size=2)
>>> for i, (train_index, test_index) in enumerate(tscv.split(X)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}")
...     print(f"  Test:  index={test_index}")
Fold 0:
  Train: index=[0 1 2 3 4 5]
  Test:  index=[6 7]
Fold 1:
  Train: index=[0 1 2 3 4 5 6 7]
  Test:  index=[8 9]
Fold 2:
  Train: index=[0 1 2 3 4 5 6 7 8 9]
  Test:  index=[10 11]
>>> # Add in a 2 period gap
>>> tscv = TimeSeriesSplit(n_splits=3, test_size=2, gap=2)
>>> for i, (train_index, test_index) in enumerate(tscv.split(X)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}")
...     print(f"  Test:  index={test_index}")
Fold 0:
  Train: index=[0 1 2 3]
  Test:  index=[6 7]
Fold 1:
  Train: index=[0 1 2 3 4 5]
  Test:  index=[8 9]
Fold 2:
  Train: index=[0 1 2 3 4 5 6 7]
  Test:  index=[10 11]
```

For a more extended example see
[Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py).

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X=None, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Always ignored, exists for compatibility.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### split(X, y=None, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Always ignored, exists for compatibility.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Polars-engineered lagged features can be used for time series forecasting with HistGradientBoostingRegressor on the Bike Sharing Demand dataset.">  <div class="sphx-glr-thumbnail-title">Lagged features for time series forecasting</div>
</div>
* [Lagged features for time series forecasting](../../auto_examples/applications/plot_time_series_lagged_features.md#sphx-glr-auto-examples-applications-plot-time-series-lagged-features-py)

<div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="histogram_based_gradient_boosting (HGBT) models may be one of the most useful supervised learning models in scikit-learn. They are based on a modern gradient boosting implementation comparable to LightGBM and XGBoost. As such, HGBT models are more feature rich than and often outperform alternative models like random forests, especially when the number of samples is larger than some ten thousands (see sphx_glr_auto_examples_ensemble_plot_forest_hist_grad_boosting_comparison.py).">  <div class="sphx-glr-thumbnail-title">Features in Histogram Gradient Boosting Trees</div>
</div>
* [Features in Histogram Gradient Boosting Trees](../../auto_examples/ensemble/plot_hgbt_regression.md#sphx-glr-auto-examples-ensemble-plot-hgbt-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="The present example compares three l1-based regression models on a synthetic signal obtained from sparse and correlated features that are further corrupted with additive gaussian noise:">  <div class="sphx-glr-thumbnail-title">L1-based models for Sparse Signals</div>
</div>
* [L1-based models for Sparse Signals](../../auto_examples/linear_model/plot_lasso_and_elasticnet.md#sphx-glr-auto-examples-linear-model-plot-lasso-and-elasticnet-py)

<div class="sphx-glr-thumbcontainer" tooltip="Choosing the right cross-validation object is a crucial part of fitting a model properly. There are many ways to split data into training and test sets in order to avoid model overfitting, to standardize the number of groups in test sets, etc.">  <div class="sphx-glr-thumbnail-title">Visualizing cross-validation behavior in scikit-learn</div>
</div>
* [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

<!-- thumbnail-parent-div-close --></div>
