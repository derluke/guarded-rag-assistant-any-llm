# BiclusterMixin

### *class* sklearn.base.BiclusterMixin

Mixin class for all bicluster estimators in scikit-learn.

This mixin defines the following functionality:

- `biclusters_` property that returns the row and column indicators;
- `get_indices` method that returns the row and column indices of a bicluster;
- `get_shape` method that returns the shape of a bicluster;
- `get_submatrix` method that returns the submatrix corresponding to a bicluster.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.base import BaseEstimator, BiclusterMixin
>>> class DummyBiClustering(BiclusterMixin, BaseEstimator):
...     def fit(self, X, y=None):
...         self.rows_ = np.ones(shape=(1, X.shape[0]), dtype=bool)
...         self.columns_ = np.ones(shape=(1, X.shape[1]), dtype=bool)
...         return self
>>> X = np.array([[1, 1], [2, 1], [1, 0],
...               [4, 7], [3, 5], [3, 6]])
>>> bicluster = DummyBiClustering().fit(X)
>>> hasattr(bicluster, "biclusters_")
True
>>> bicluster.get_indices(0)
(array([0, 1, 2, 3, 4, 5]), array([0, 1]))
```

<!-- !! processed by numpydoc !! -->

#### *property* biclusters_

Convenient way to get row and column indicators together.

Returns the `rows_` and `columns_` members.

<!-- !! processed by numpydoc !! -->

#### get_indices(i)

Row and column indices of the `i`’th bicluster.

Only works if `rows_` and `columns_` attributes exist.

* **Parameters:**
  **i**
  : The index of the cluster.
* **Returns:**
  **row_ind**
  : Indices of rows in the dataset that belong to the bicluster.

  **col_ind**
  : Indices of columns in the dataset that belong to the bicluster.

<!-- !! processed by numpydoc !! -->

#### get_shape(i)

Shape of the `i`’th bicluster.

* **Parameters:**
  **i**
  : The index of the cluster.
* **Returns:**
  **n_rows**
  : Number of rows in the bicluster.

  **n_cols**
  : Number of columns in the bicluster.

<!-- !! processed by numpydoc !! -->

#### get_submatrix(i, data)

Return the submatrix corresponding to bicluster `i`.

* **Parameters:**
  **i**
  : The index of the cluster.

  **data**
  : The data.
* **Returns:**
  **submatrix**
  : The submatrix corresponding to bicluster `i`.

### Notes

Works with sparse matrices. Only works if `rows_` and
`columns_` attributes exist.

<!-- !! processed by numpydoc !! -->
