# load_sample_images

### sklearn.datasets.load_sample_images()

Load sample images for image manipulation.

Loads both, `china` and `flower`.

Read more in the [User Guide](../../datasets/loading_other_datasets.md#sample-images).

* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    images
    : The two sample image.
    <br/>
    filenames
    : The filenames for the images.
    <br/>
    DESCR
    : The full description of the dataset.

### Examples

To load the data and visualize the images:

```pycon
>>> from sklearn.datasets import load_sample_images
>>> dataset = load_sample_images()     
>>> len(dataset.images)                
2
>>> first_img_data = dataset.images[0] 
>>> first_img_data.shape               
(427, 640, 3)
>>> first_img_data.dtype               
dtype('uint8')
```

<!-- !! processed by numpydoc !! -->
