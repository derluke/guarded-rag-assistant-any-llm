# GraphicalLasso

### *class* sklearn.covariance.GraphicalLasso(alpha=0.01, \*, mode='cd', covariance=None, tol=0.0001, enet_tol=0.0001, max_iter=100, verbose=False, eps=2.220446049250313e-16, assume_centered=False)

Sparse inverse covariance estimation with an l1-penalized estimator.

For a usage example see
[Visualizing the stock market structure](../../auto_examples/applications/plot_stock_market.md#sphx-glr-auto-examples-applications-plot-stock-market-py).

Read more in the [User Guide](../covariance.md#sparse-inverse-covariance).

#### Versionchanged
Changed in version v0.20: GraphLasso has been renamed to GraphicalLasso

* **Parameters:**
  **alpha**
  : The regularization parameter: the higher alpha, the more
    regularization, the sparser the inverse covariance.
    Range is (0, inf].

  **mode**
  : The Lasso solver to use: coordinate descent or LARS. Use LARS for
    very sparse underlying graphs, where p > n. Elsewhere prefer cd
    which is more numerically stable.

  **covariance**
  : If covariance is “precomputed”, the input data in `fit` is assumed
    to be the covariance matrix. If `None`, the empirical covariance
    is estimated from the data `X`.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **tol**
  : The tolerance to declare convergence: if the dual gap goes below
    this value, iterations are stopped. Range is (0, inf].

  **enet_tol**
  : The tolerance for the elastic net solver used to calculate the descent
    direction. This parameter controls the accuracy of the search direction
    for a given column update, not of the overall parameter estimate. Only
    used for mode=’cd’. Range is (0, inf].

  **max_iter**
  : The maximum number of iterations.

  **verbose**
  : If verbose is True, the objective function and dual gap are
    plotted at each iteration.

  **eps**
  : The machine-precision regularization in the computation of the
    Cholesky diagonal factors. Increase this for very ill-conditioned
    systems. Default is `np.finfo(np.float64).eps`.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **assume_centered**
  : If True, data are not centered before computation.
    Useful when working with data whose mean is almost, but not exactly
    zero.
    If False, data are centered before computation.
* **Attributes:**
  **location_**
  : Estimated location, i.e. the estimated mean.

  **covariance_**
  : Estimated covariance matrix

  **precision_**
  : Estimated pseudo inverse matrix.

  **n_iter_**
  : Number of iterations run.

  **costs_**
  : The list of values of the objective function and the dual gap at
    each iteration. Returned only if return_costs is True.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`graphical_lasso`](sklearn.covariance.graphical_lasso.md#sklearn.covariance.graphical_lasso)
: L1-penalized covariance estimator.

[`GraphicalLassoCV`](sklearn.covariance.GraphicalLassoCV.md#sklearn.covariance.GraphicalLassoCV)
: Sparse inverse covariance with cross-validated choice of the l1 penalty.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.covariance import GraphicalLasso
>>> true_cov = np.array([[0.8, 0.0, 0.2, 0.0],
...                      [0.0, 0.4, 0.0, 0.0],
...                      [0.2, 0.0, 0.3, 0.1],
...                      [0.0, 0.0, 0.1, 0.7]])
>>> np.random.seed(0)
>>> X = np.random.multivariate_normal(mean=[0, 0, 0, 0],
...                                   cov=true_cov,
...                                   size=200)
>>> cov = GraphicalLasso().fit(X)
>>> np.around(cov.covariance_, decimals=3)
array([[0.816, 0.049, 0.218, 0.019],
       [0.049, 0.364, 0.017, 0.034],
       [0.218, 0.017, 0.322, 0.093],
       [0.019, 0.034, 0.093, 0.69 ]])
>>> np.around(cov.location_, decimals=3)
array([0.073, 0.04 , 0.038, 0.143])
```

<!-- !! processed by numpydoc !! -->

#### error_norm(comp_cov, norm='frobenius', scaling=True, squared=True)

Compute the Mean Squared Error between two covariance estimators.

* **Parameters:**
  **comp_cov**
  : The covariance to compare with.

  **norm**
  : The type of norm used to compute the error. Available error types:
    - ‘frobenius’ (default): sqrt(tr(A^t.A))
    - ‘spectral’: sqrt(max(eigenvalues(A^t.A))
    where A is the error `(comp_cov - self.covariance_)`.

  **scaling**
  : If True (default), the squared error norm is divided by n_features.
    If False, the squared error norm is not rescaled.

  **squared**
  : Whether to compute the squared error norm or the error norm.
    If True (default), the squared error norm is returned.
    If False, the error norm is returned.
* **Returns:**
  **result**
  : The Mean Squared Error (in the sense of the Frobenius norm) between
    `self` and `comp_cov` covariance estimators.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the GraphicalLasso model to X.

* **Parameters:**
  **X**
  : Data from which to compute the covariance estimate.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_precision()

Getter for the precision matrix.

* **Returns:**
  **precision_**
  : The precision matrix associated to the current covariance object.

<!-- !! processed by numpydoc !! -->

#### mahalanobis(X)

Compute the squared Mahalanobis distances of given observations.

* **Parameters:**
  **X**
  : The observations, the Mahalanobis distances of the which we
    compute. Observations are assumed to be drawn from the same
    distribution than the data used in fit.
* **Returns:**
  **dist**
  : Squared Mahalanobis distances of the observations.

<!-- !! processed by numpydoc !! -->

#### score(X_test, y=None)

Compute the log-likelihood of `X_test` under the estimated Gaussian model.

The Gaussian model is defined by its mean and covariance matrix which are
represented respectively by `self.location_` and `self.covariance_`.

* **Parameters:**
  **X_test**
  : Test data of which we compute the likelihood, where `n_samples` is
    the number of samples and `n_features` is the number of features.
    `X_test` is assumed to be drawn from the same distribution than
    the data used in fit (including centering).

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **res**
  : The log-likelihood of `X_test` with `self.location_` and `self.covariance_`
    as estimators of the Gaussian model mean and covariance matrix respectively.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->
