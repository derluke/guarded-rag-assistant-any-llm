# check_increasing

### sklearn.isotonic.check_increasing(x, y)

Determine whether y is monotonically correlated with x.

y is found increasing or decreasing with respect to x based on a Spearman
correlation test.

* **Parameters:**
  **x**
  : Training data.

  **y**
  : Training target.
* **Returns:**
  **increasing_bool**
  : Whether the relationship is increasing or decreasing.

### Notes

The Spearman correlation coefficient is estimated from the data, and the
sign of the resulting estimate is used as the result.

In the event that the 95% confidence interval based on Fisher transform
spans zero, a warning is raised.

### References

Fisher transformation. Wikipedia.
[https://en.wikipedia.org/wiki/Fisher_transformation](https://en.wikipedia.org/wiki/Fisher_transformation)

### Examples

```pycon
>>> from sklearn.isotonic import check_increasing
>>> x, y = [1, 2, 3, 4, 5], [2, 4, 6, 8, 10]
>>> check_increasing(x, y)
np.True_
>>> y = [10, 8, 6, 4, 2]
>>> check_increasing(x, y)
np.False_
```

<!-- !! processed by numpydoc !! -->
