# adjusted_mutual_info_score

### sklearn.metrics.adjusted_mutual_info_score(labels_true, labels_pred, \*, average_method='arithmetic')

Adjusted Mutual Information between two clusterings.

Adjusted Mutual Information (AMI) is an adjustment of the Mutual
Information (MI) score to account for chance. It accounts for the fact that
the MI is generally higher for two clusterings with a larger number of
clusters, regardless of whether there is actually more information shared.
For two clusterings $U$ and $V$, the AMI is given as:

```default
AMI(U, V) = [MI(U, V) - E(MI(U, V))] / [avg(H(U), H(V)) - E(MI(U, V))]
```

This metric is independent of the absolute values of the labels:
a permutation of the class or cluster label values won’t change the
score value in any way.

This metric is furthermore symmetric: switching $U$ (`label_true`)
with $V$ (`labels_pred`) will return the same score value. This can
be useful to measure the agreement of two independent label assignments
strategies on the same dataset when the real ground truth is not known.

Be mindful that this function is an order of magnitude slower than other
metrics, such as the Adjusted Rand Index.

Read more in the [User Guide](../clustering.md#mutual-info-score).

* **Parameters:**
  **labels_true**
  : A clustering of the data into disjoint subsets, called $U$ in
    the above formula.

  **labels_pred**
  : A clustering of the data into disjoint subsets, called $V$ in
    the above formula.

  **average_method**
  : How to compute the normalizer in the denominator.
    <br/>
    #### Versionadded
    Added in version 0.20.
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default value of `average_method` changed from ‘max’ to
    ‘arithmetic’.
* **Returns:**
  ami: float (upperlimited by 1.0)
  : The AMI returns a value of 1 when the two partitions are identical
    (ie perfectly matched). Random partitions (independent labellings) have
    an expected AMI around 0 on average hence can be negative. The value is
    in adjusted nats (based on the natural logarithm).

#### SEE ALSO
[`adjusted_rand_score`](sklearn.metrics.adjusted_rand_score.md#sklearn.metrics.adjusted_rand_score)
: Adjusted Rand Index.

[`mutual_info_score`](sklearn.metrics.mutual_info_score.md#sklearn.metrics.mutual_info_score)
: Mutual Information (not adjusted for chance).

### References

### Examples

Perfect labelings are both homogeneous and complete, hence have
score 1.0:

```default
>>> from sklearn.metrics.cluster import adjusted_mutual_info_score
>>> adjusted_mutual_info_score([0, 0, 1, 1], [0, 0, 1, 1])
... 
1.0
>>> adjusted_mutual_info_score([0, 0, 1, 1], [1, 1, 0, 0])
... 
1.0
```

If classes members are completely split across different clusters,
the assignment is totally in-complete, hence the AMI is null:

```default
>>> adjusted_mutual_info_score([0, 0, 0, 0], [0, 1, 2, 3])
... 
0.0
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the various initialization strategies for K-means in terms of runtime and quality of the results.">  <div class="sphx-glr-thumbnail-title">A demo of K-Means clustering on the handwritten digits data</div>
</div>
* [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="- a first experiment with fixed &quot;ground truth labels&quot; (and therefore fixed   number of classes) and randomly &quot;predicted labels&quot;; - a second experiment with varying &quot;ground truth labels&quot;, randomly &quot;predicted   labels&quot;. The &quot;predicted labels&quot; have the same number of classes and clusters   as the &quot;ground truth labels&quot;.">  <div class="sphx-glr-thumbnail-title">Adjustment for chance in clustering performance evaluation</div>
</div>
* [Adjustment for chance in clustering performance evaluation](../../auto_examples/cluster/plot_adjusted_for_chance_measures.md#sphx-glr-auto-examples-cluster-plot-adjusted-for-chance-measures-py)

<div class="sphx-glr-thumbcontainer" tooltip="DBSCAN (Density-Based Spatial Clustering of Applications with Noise) finds core samples in regions of high density and expands clusters from them. This algorithm is good for data which contains clusters of similar density.">  <div class="sphx-glr-thumbnail-title">Demo of DBSCAN clustering algorithm</div>
</div>
* [Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="Reference: Brendan J. Frey and Delbert Dueck, &quot;Clustering by Passing Messages Between Data Points&quot;, Science Feb. 2007">  <div class="sphx-glr-thumbnail-title">Demo of affinity propagation clustering algorithm</div>
</div>
* [Demo of affinity propagation clustering algorithm](../../auto_examples/cluster/plot_affinity_propagation.md#sphx-glr-auto-examples-cluster-plot-affinity-propagation-py)

<!-- thumbnail-parent-div-close --></div>
