# BernoulliNB

### *class* sklearn.naive_bayes.BernoulliNB(\*, alpha=1.0, force_alpha=True, binarize=0.0, fit_prior=True, class_prior=None)

Naive Bayes classifier for multivariate Bernoulli models.

Like MultinomialNB, this classifier is suitable for discrete data. The
difference is that while MultinomialNB works with occurrence counts,
BernoulliNB is designed for binary/boolean features.

Read more in the [User Guide](../naive_bayes.md#bernoulli-naive-bayes).

* **Parameters:**
  **alpha**
  : Additive (Laplace/Lidstone) smoothing parameter
    (set alpha=0 and force_alpha=True, for no smoothing).

  **force_alpha**
  : If False and alpha is less than 1e-10, it will set alpha to
    1e-10. If True, alpha will remain unchanged. This may cause
    numerical errors if alpha is too close to 0.
    <br/>
    #### Versionadded
    Added in version 1.2.
    <br/>
    #### Versionchanged
    Changed in version 1.4: The default value of `force_alpha` changed to `True`.

  **binarize**
  : Threshold for binarizing (mapping to booleans) of sample features.
    If None, input is presumed to already consist of binary vectors.

  **fit_prior**
  : Whether to learn class prior probabilities or not.
    If false, a uniform prior will be used.

  **class_prior**
  : Prior probabilities of the classes. If specified, the priors are not
    adjusted according to the data.
* **Attributes:**
  **class_count_**
  : Number of samples encountered for each class during fitting. This
    value is weighted by the sample weight when provided.

  **class_log_prior_**
  : Log probability of each class (smoothed).

  **classes_**
  : Class labels known to the classifier

  **feature_count_**
  : Number of samples encountered for each (class, feature)
    during fitting. This value is weighted by the sample weight when
    provided.

  **feature_log_prob_**
  : Empirical log probability of features given a class, P(x_i|y).

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`CategoricalNB`](sklearn.naive_bayes.CategoricalNB.md#sklearn.naive_bayes.CategoricalNB)
: Naive Bayes classifier for categorical features.

[`ComplementNB`](sklearn.naive_bayes.ComplementNB.md#sklearn.naive_bayes.ComplementNB)
: The Complement Naive Bayes classifier described in Rennie et al. (2003).

[`GaussianNB`](sklearn.naive_bayes.GaussianNB.md#sklearn.naive_bayes.GaussianNB)
: Gaussian Naive Bayes (GaussianNB).

[`MultinomialNB`](sklearn.naive_bayes.MultinomialNB.md#sklearn.naive_bayes.MultinomialNB)
: Naive Bayes classifier for multinomial models.

### References

C.D. Manning, P. Raghavan and H. Schuetze (2008). Introduction to
Information Retrieval. Cambridge University Press, pp. 234-265.
[https://nlp.stanford.edu/IR-book/html/htmledition/the-bernoulli-model-1.html](https://nlp.stanford.edu/IR-book/html/htmledition/the-bernoulli-model-1.html)

A. McCallum and K. Nigam (1998). A comparison of event models for naive
Bayes text classification. Proc. AAAI/ICML-98 Workshop on Learning for
Text Categorization, pp. 41-48.

V. Metsis, I. Androutsopoulos and G. Paliouras (2006). Spam filtering with
naive Bayes – Which naive Bayes? 3rd Conf. on Email and Anti-Spam (CEAS).

### Examples

```pycon
>>> import numpy as np
>>> rng = np.random.RandomState(1)
>>> X = rng.randint(5, size=(6, 100))
>>> Y = np.array([1, 2, 3, 4, 4, 5])
>>> from sklearn.naive_bayes import BernoulliNB
>>> clf = BernoulliNB()
>>> clf.fit(X, Y)
BernoulliNB()
>>> print(clf.predict(X[2:3]))
[3]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit Naive Bayes classifier according to X, y.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target values.

  **sample_weight**
  : Weights applied to individual samples (1. for unweighted).
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y, classes=None, sample_weight=None)

Incremental fit on a batch of samples.

This method is expected to be called several times consecutively
on different chunks of a dataset so as to implement out-of-core
or online learning.

This is especially useful when the whole dataset is too big to fit in
memory at once.

This method has some performance overhead hence it is better to call
partial_fit on chunks of data that are as large as possible
(as long as fitting in the memory budget) to hide the overhead.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target values.

  **classes**
  : List of all the classes that can possibly appear in the y vector.
    <br/>
    Must be provided at the first call to partial_fit, can be omitted
    in subsequent calls.

  **sample_weight**
  : Weights applied to individual samples (1. for unweighted).
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Perform classification on an array of test vectors X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **C**
  : Predicted target values for X.

<!-- !! processed by numpydoc !! -->

#### predict_joint_log_proba(X)

Return joint log probability estimates for the test vector X.

For each row x of X and class y, the joint log probability is given by
`log P(x, y) = log P(y) + log P(x|y),`
where `log P(y)` is the class prior probability and `log P(x|y)` is
the class-conditional probability.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **C**
  : Returns the joint log-probability of the samples for each class in
    the model. The columns correspond to the classes in sorted
    order, as they appear in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Return log-probability estimates for the test vector X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **C**
  : Returns the log-probability of the samples for each class in
    the model. The columns correspond to the classes in sorted
    order, as they appear in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Return probability estimates for the test vector X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **C**
  : Returns the probability of the samples for each class in
    the model. The columns correspond to the classes in sorted
    order, as they appear in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BernoulliNB](#sklearn.naive_bayes.BernoulliNB)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, classes: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BernoulliNB](#sklearn.naive_bayes.BernoulliNB)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **classes**
  : Metadata routing for `classes` parameter in `partial_fit`.

  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BernoulliNB](#sklearn.naive_bayes.BernoulliNB)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="RandomTreesEmbedding provides a way to map data to a very high-dimensional, sparse representation, which might be beneficial for classification. The mapping is completely unsupervised and very efficient.">  <div class="sphx-glr-thumbnail-title">Hashing feature transformation using Totally Random Trees</div>
</div>
* [Hashing feature transformation using Totally Random Trees](../../auto_examples/ensemble/plot_random_forest_embedding.md#sphx-glr-auto-examples-ensemble-plot-random-forest-embedding-py)

<!-- thumbnail-parent-div-close --></div>
