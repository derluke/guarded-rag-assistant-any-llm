# non_negative_factorization

### sklearn.decomposition.non_negative_factorization(X, W=None, H=None, n_components='auto', \*, init=None, update_H=True, solver='cd', beta_loss='frobenius', tol=0.0001, max_iter=200, alpha_W=0.0, alpha_H='same', l1_ratio=0.0, random_state=None, verbose=0, shuffle=False)

Compute Non-negative Matrix Factorization (NMF).

Find two non-negative matrices (W, H) whose product approximates the non-
negative matrix X. This factorization can be used for example for
dimensionality reduction, source separation or topic extraction.

The objective function is:

$$
L(W, H) &= 0.5 * ||X - WH||_{loss}^2

        &+ alpha\_W * l1\_ratio * n\_features * ||vec(W)||_1

        &+ alpha\_H * l1\_ratio * n\_samples * ||vec(H)||_1

        &+ 0.5 * alpha\_W * (1 - l1\_ratio) * n\_features * ||W||_{Fro}^2

        &+ 0.5 * alpha\_H * (1 - l1\_ratio) * n\_samples * ||H||_{Fro}^2,
$$

where $||A||_{Fro}^2 = \sum_{i,j} A_{ij}^2$ (Frobenius norm) and
$||vec(A)||_1 = \sum_{i,j} abs(A_{ij})$ (Elementwise L1 norm)

The generic norm $||X - WH||_{loss}^2$ may represent
the Frobenius norm or another supported beta-divergence loss.
The choice between options is controlled by the `beta_loss` parameter.

The regularization terms are scaled by `n_features` for `W` and by `n_samples` for
`H` to keep their impact balanced with respect to one another and to the data fit
term as independent as possible of the size `n_samples` of the training set.

The objective function is minimized with an alternating minimization of W
and H. If H is given and update_H=False, it solves for W only.

Note that the transformed data is named W and the components matrix is named H. In
the NMF literature, the naming convention is usually the opposite since the data
matrix X is transposed.

* **Parameters:**
  **X**
  : Constant matrix.

  **W**
  : If `init='custom'`, it is used as initial guess for the solution.
    If `update_H=False`, it is initialised as an array of zeros, unless
    `solver='mu'`, then it is filled with values calculated by
    `np.sqrt(X.mean() / self._n_components)`.
    If `None`, uses the initialisation method specified in `init`.

  **H**
  : If `init='custom'`, it is used as initial guess for the solution.
    If `update_H=False`, it is used as a constant, to solve for W only.
    If `None`, uses the initialisation method specified in `init`.

  **n_components**
  : Number of components. If `None`, all features are kept.
    If `n_components='auto'`, the number of components is automatically inferred
    from `W` or `H` shapes.
    <br/>
    #### Versionchanged
    Changed in version 1.4: Added `'auto'` value.
    <br/>
    #### Versionchanged
    Changed in version 1.6: Default value changed from `None` to `'auto'`.

  **init**
  : Method used to initialize the procedure.
    <br/>
    Valid options:
    - None: ‘nndsvda’ if n_components < n_features, otherwise ‘random’.
    - ‘random’: non-negative random matrices, scaled with:
      `sqrt(X.mean() / n_components)`
    - ‘nndsvd’: Nonnegative Double Singular Value Decomposition (NNDSVD)
      initialization (better for sparseness)
    - ‘nndsvda’: NNDSVD with zeros filled with the average of X
      (better when sparsity is not desired)
    - ‘nndsvdar’: NNDSVD with zeros filled with small random values
      (generally faster, less accurate alternative to NNDSVDa
      for when sparsity is not desired)
    - ‘custom’: If `update_H=True`, use custom matrices W and H which must both
      be provided. If `update_H=False`, then only custom matrix H is used.
    <br/>
    #### Versionchanged
    Changed in version 0.23: The default value of `init` changed from ‘random’ to None in 0.23.
    <br/>
    #### Versionchanged
    Changed in version 1.1: When `init=None` and n_components is less than n_samples and n_features
    defaults to `nndsvda` instead of `nndsvd`.

  **update_H**
  : Set to True, both W and H will be estimated from initial guesses.
    Set to False, only W will be estimated.

  **solver**
  : Numerical solver to use:
    - ‘cd’ is a Coordinate Descent solver that uses Fast Hierarchical
      Alternating Least Squares (Fast HALS).
    - ‘mu’ is a Multiplicative Update solver.
    <br/>
    #### Versionadded
    Added in version 0.17: Coordinate Descent solver.
    <br/>
    #### Versionadded
    Added in version 0.19: Multiplicative Update solver.

  **beta_loss**
  : Beta divergence to be minimized, measuring the distance between X
    and the dot product WH. Note that values different from ‘frobenius’
    (or 2) and ‘kullback-leibler’ (or 1) lead to significantly slower
    fits. Note that for beta_loss <= 0 (or ‘itakura-saito’), the input
    matrix X cannot contain zeros. Used only in ‘mu’ solver.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **tol**
  : Tolerance of the stopping condition.

  **max_iter**
  : Maximum number of iterations before timing out.

  **alpha_W**
  : Constant that multiplies the regularization terms of `W`. Set it to zero
    (default) to have no regularization on `W`.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **alpha_H**
  : Constant that multiplies the regularization terms of `H`. Set it to zero to
    have no regularization on `H`. If “same” (default), it takes the same value as
    `alpha_W`.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **l1_ratio**
  : The regularization mixing parameter, with 0 <= l1_ratio <= 1.
    For l1_ratio = 0 the penalty is an elementwise L2 penalty
    (aka Frobenius Norm).
    For l1_ratio = 1 it is an elementwise L1 penalty.
    For 0 < l1_ratio < 1, the penalty is a combination of L1 and L2.

  **random_state**
  : Used for NMF initialisation (when `init` == ‘nndsvdar’ or
    ‘random’), and in Coordinate Descent. Pass an int for reproducible
    results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **verbose**
  : The verbosity level.

  **shuffle**
  : If true, randomize the order of coordinates in the CD solver.
* **Returns:**
  **W**
  : Solution to the non-negative least squares problem.

  **H**
  : Solution to the non-negative least squares problem.

  **n_iter**
  : Actual number of iterations.

### References

### Examples

```pycon
>>> import numpy as np
>>> X = np.array([[1,1], [2, 1], [3, 1.2], [4, 1], [5, 0.8], [6, 1]])
>>> from sklearn.decomposition import non_negative_factorization
>>> W, H, n_iter = non_negative_factorization(
...     X, n_components=2, init='random', random_state=0)
```

<!-- !! processed by numpydoc !! -->
