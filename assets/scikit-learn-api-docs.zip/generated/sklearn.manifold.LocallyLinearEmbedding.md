# LocallyLinearEmbedding

### *class* sklearn.manifold.LocallyLinearEmbedding(\*, n_neighbors=5, n_components=2, reg=0.001, eigen_solver='auto', tol=1e-06, max_iter=100, method='standard', hessian_tol=0.0001, modified_tol=1e-12, neighbors_algorithm='auto', random_state=None, n_jobs=None)

Locally Linear Embedding.

Read more in the [User Guide](../manifold.md#locally-linear-embedding).

* **Parameters:**
  **n_neighbors**
  : Number of neighbors to consider for each point.

  **n_components**
  : Number of coordinates for the manifold.

  **reg**
  : Regularization constant, multiplies the trace of the local covariance
    matrix of the distances.

  **eigen_solver**
  : The solver used to compute the eigenvectors. The available options are:
    - `'auto'` : algorithm will attempt to choose the best method for input
      data.
    - `'arpack'` : use arnoldi iteration in shift-invert mode. For this
      method, M may be a dense matrix, sparse matrix, or general linear
      operator.
    - `'dense'`  : use standard dense matrix operations for the eigenvalue
      decomposition. For this method, M must be an array or matrix type.
      This method should be avoided for large problems.
    <br/>
    #### WARNING
    ARPACK can be unstable for some problems.  It is best to try several
    random seeds in order to check results.

  **tol**
  : Tolerance for ‘arpack’ method
    Not used if eigen_solver==’dense’.

  **max_iter**
  : Maximum number of iterations for the arpack solver.
    Not used if eigen_solver==’dense’.

  **method**
  : - `standard`: use the standard locally linear embedding algorithm. see
      reference [[1]](#r62e36dd1b056-1)
    - `hessian`: use the Hessian eigenmap method. This method requires
      `n_neighbors > n_components * (1 + (n_components + 1) / 2`. see
      reference [[2]](#r62e36dd1b056-2)
    - `modified`: use the modified locally linear embedding algorithm.
      see reference [[3]](#r62e36dd1b056-3)
    - `ltsa`: use local tangent space alignment algorithm. see
      reference [[4]](#r62e36dd1b056-4)

  **hessian_tol**
  : Tolerance for Hessian eigenmapping method.
    Only used if `method == 'hessian'`.

  **modified_tol**
  : Tolerance for modified LLE method.
    Only used if `method == 'modified'`.

  **neighbors_algorithm**
  : Algorithm to use for nearest neighbors search, passed to
    [`NearestNeighbors`](sklearn.neighbors.NearestNeighbors.md#sklearn.neighbors.NearestNeighbors) instance.

  **random_state**
  : Determines the random number generator when
    `eigen_solver` == ‘arpack’. Pass an int for reproducible results
    across multiple function calls. See [Glossary](../../glossary.md#term-random_state).

  **n_jobs**
  : The number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **embedding_**
  : Stores the embedding vectors

  **reconstruction_error_**
  : Reconstruction error associated with `embedding_`

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **nbrs_**
  : Stores nearest neighbors instance, including BallTree or KDtree
    if applicable.

#### SEE ALSO
[`SpectralEmbedding`](sklearn.manifold.SpectralEmbedding.md#sklearn.manifold.SpectralEmbedding)
: Spectral embedding for non-linear dimensionality reduction.

[`TSNE`](sklearn.manifold.TSNE.md#sklearn.manifold.TSNE)
: Distributed Stochastic Neighbor Embedding.

### References

### Examples

```pycon
>>> from sklearn.datasets import load_digits
>>> from sklearn.manifold import LocallyLinearEmbedding
>>> X, _ = load_digits(return_X_y=True)
>>> X.shape
(1797, 64)
>>> embedding = LocallyLinearEmbedding(n_components=2)
>>> X_transformed = embedding.fit_transform(X[:100])
>>> X_transformed.shape
(100, 2)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Compute the embedding vectors for data X.

* **Parameters:**
  **X**
  : Training set.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : Fitted `LocallyLinearEmbedding` class instance.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Compute the embedding vectors for data X and transform X.

* **Parameters:**
  **X**
  : Training set.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **X_new**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform new points into embedding space.

* **Parameters:**
  **X**
  : Training set.
* **Returns:**
  **X_new**
  : Returns the instance itself.

### Notes

Because of scaling performed by this method, it is discouraged to use
it together with methods that are not scale-invariant (like SVMs).

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example employs several unsupervised learning techniques to extract the stock market structure from variations in historical quotes.">  <div class="sphx-glr-thumbnail-title">Visualizing the stock market structure</div>
</div>
* [Visualizing the stock market structure](../../auto_examples/applications/plot_stock_market.md#sphx-glr-auto-examples-applications-plot-stock-market-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of dimensionality reduction on the S-curve dataset with various manifold learning methods.">  <div class="sphx-glr-thumbnail-title">Comparison of Manifold Learning methods</div>
</div>
* [Comparison of Manifold Learning methods](../../auto_examples/manifold/plot_compare_methods.md#sphx-glr-auto-examples-manifold-plot-compare-methods-py)

<div class="sphx-glr-thumbcontainer" tooltip="An application of the different manifold techniques on a spherical data-set. Here one can see the use of dimensionality reduction in order to gain some intuition regarding the manifold learning methods. Regarding the dataset, the poles are cut from the sphere, as well as a thin slice down its side. This enables the manifold learning techniques to &#x27;spread it open&#x27; whilst projecting it onto two dimensions.">  <div class="sphx-glr-thumbnail-title">Manifold Learning methods on a severed sphere</div>
</div>
* [Manifold Learning methods on a severed sphere](../../auto_examples/manifold/plot_manifold_sphere.md#sphx-glr-auto-examples-manifold-plot-manifold-sphere-py)

<div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<!-- thumbnail-parent-div-close --></div>
