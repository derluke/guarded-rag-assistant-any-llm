# load_breast_cancer

### sklearn.datasets.load_breast_cancer(\*, return_X_y=False, as_frame=False)

Load and return the breast cancer wisconsin dataset (classification).

The breast cancer dataset is a classic and very easy binary classification
dataset.

| Classes           | 2              |
|-------------------|----------------|
| Samples per class | 212(M),357(B)  |
| Samples total     | 569            |
| Dimensionality    | 30             |
| Features          | real, positive |

The copy of UCI ML Breast Cancer Wisconsin (Diagnostic) dataset is
downloaded from:
[https://archive.ics.uci.edu/dataset/17/breast+cancer+wisconsin+diagnostic](https://archive.ics.uci.edu/dataset/17/breast+cancer+wisconsin+diagnostic)

Read more in the [User Guide](../../datasets/toy_dataset.md#breast-cancer-dataset).

* **Parameters:**
  **return_X_y**
  : If True, returns `(data, target)` instead of a Bunch object.
    See below for more information about the `data` and `target` object.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **as_frame**
  : If True, the data is a pandas DataFrame including columns with
    appropriate dtypes (numeric). The target is
    a pandas DataFrame or Series depending on the number of target columns.
    If `return_X_y` is True, then (`data`, `target`) will be pandas
    DataFrames or Series as described below.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : The data matrix. If `as_frame=True`, `data` will be a pandas
      DataFrame.
    <br/>
    target
    : The classification target. If `as_frame=True`, `target` will be
      a pandas Series.
    <br/>
    feature_names
    : The names of the dataset columns.
    <br/>
    target_names
    : The names of target classes.
    <br/>
    frame
    : Only present when `as_frame=True`. DataFrame with `data` and
      `target`.
      <br/>
      #### Versionadded
      Added in version 0.23.
    <br/>
    DESCR
    : The full description of the dataset.
    <br/>
    filename
    : The path to the location of the data.
      <br/>
      #### Versionadded
      Added in version 0.20.

  **(data, target)**
  : A tuple of two ndarrays by default. The first contains a 2D ndarray of
    shape (569, 30) with each row representing one sample and each column
    representing the features. The second ndarray of shape (569,) contains
    the target samples.  If `as_frame=True`, both arrays are pandas objects,
    i.e. `X` a dataframe and `y` a series.
    <br/>
    #### Versionadded
    Added in version 0.18.

### Examples

Let’s say you are interested in the samples 10, 50, and 85, and want to
know their class name.

```pycon
>>> from sklearn.datasets import load_breast_cancer
>>> data = load_breast_cancer()
>>> data.target[[10, 50, 85]]
array([0, 1, 0])
>>> list(data.target_names)
[np.str_('malignant'), np.str_('benign')]
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares two approaches for feature selection: SelectFromModel which is based on feature importance, and SequentialFeatureSelector which relies on a greedy approach.">  <div class="sphx-glr-thumbnail-title">Model-based and sequential feature selection</div>
</div>
* [Model-based and sequential feature selection](../../auto_examples/feature_selection/plot_select_from_model_diabetes.md#sphx-glr-auto-examples-feature-selection-plot-select-from-model-diabetes-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we compute the permutation_importance of the features to a trained RandomForestClassifier using the breast_cancer_dataset. The model can easily get about 97% accuracy on a test dataset. Because this dataset contains multicollinear features, the permutation importance shows that none of the features are important, in contradiction with the high test accuracy.">  <div class="sphx-glr-thumbnail-title">Permutation Importance with Multicollinear or Correlated Features</div>
</div>
* [Permutation Importance with Multicollinear or Correlated Features](../../auto_examples/inspection/plot_permutation_importance_multicollinear.md#sphx-glr-auto-examples-inspection-plot-permutation-importance-multicollinear-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of a varying threshold on self-training. The breast_cancer dataset is loaded, and labels are deleted such that only 50 out of 569 samples have labels. A SelfTrainingClassifier is fitted on this dataset, with varying thresholds.">  <div class="sphx-glr-thumbnail-title">Effect of varying threshold for self-training</div>
</div>
* [Effect of varying threshold for self-training](../../auto_examples/semi_supervised/plot_self_training_varying_threshold.md#sphx-glr-auto-examples-semi-supervised-plot-self-training-varying-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="The DecisionTreeClassifier provides parameters such as min_samples_leaf and max_depth to prevent a tree from overfiting. Cost complexity pruning provides another option to control the size of a tree. In DecisionTreeClassifier, this pruning technique is parameterized by the cost complexity parameter, ccp_alpha. Greater values of ccp_alpha increase the number of nodes pruned. Here we only show the effect of ccp_alpha on regularizing the trees and how to choose a ccp_alpha based on validation scores.">  <div class="sphx-glr-thumbnail-title">Post pruning decision trees with cost complexity pruning</div>
</div>
* [Post pruning decision trees with cost complexity pruning](../../auto_examples/tree/plot_cost_complexity_pruning.md#sphx-glr-auto-examples-tree-plot-cost-complexity-pruning-py)

<!-- thumbnail-parent-div-close --></div>
