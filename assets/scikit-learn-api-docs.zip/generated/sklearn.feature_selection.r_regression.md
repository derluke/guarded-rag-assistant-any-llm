# r_regression

### sklearn.feature_selection.r_regression(X, y, \*, center=True, force_finite=True)

Compute Pearson’s r for each features and the target.

Pearson’s r is also known as the Pearson correlation coefficient.

Linear model for testing the individual effect of each of many regressors.
This is a scoring function to be used in a feature selection procedure, not
a free standing feature selection procedure.

The cross correlation between each regressor and the target is computed
as:

```default
E[(X[:, i] - mean(X[:, i])) * (y - mean(y))] / (std(X[:, i]) * std(y))
```

For more on usage see the [User Guide](../feature_selection.md#univariate-feature-selection).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **X**
  : The data matrix.

  **y**
  : The target vector.

  **center**
  : Whether or not to center the data matrix `X` and the target vector `y`.
    By default, `X` and `y` will be centered.

  **force_finite**
  : Whether or not to force the Pearson’s R correlation to be finite.
    In the particular case where some features in `X` or the target `y`
    are constant, the Pearson’s R correlation is not defined. When
    `force_finite=False`, a correlation of `np.nan` is returned to
    acknowledge this case. When `force_finite=True`, this value will be
    forced to a minimal correlation of `0.0`.
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Returns:**
  **correlation_coefficient**
  : Pearson’s R correlation coefficients of features.

#### SEE ALSO
[`f_regression`](sklearn.feature_selection.f_regression.md#sklearn.feature_selection.f_regression)
: Univariate linear regression tests returning f-statistic and p-values.

[`mutual_info_regression`](sklearn.feature_selection.mutual_info_regression.md#sklearn.feature_selection.mutual_info_regression)
: Mutual information for a continuous target.

[`f_classif`](sklearn.feature_selection.f_classif.md#sklearn.feature_selection.f_classif)
: ANOVA F-value between label/feature for classification tasks.

[`chi2`](sklearn.feature_selection.chi2.md#sklearn.feature_selection.chi2)
: Chi-squared stats of non-negative features for classification tasks.

### Examples

```pycon
>>> from sklearn.datasets import make_regression
>>> from sklearn.feature_selection import r_regression
>>> X, y = make_regression(
...     n_samples=50, n_features=3, n_informative=1, noise=1e-4, random_state=42
... )
>>> r_regression(X, y)
array([-0.15...,  1.        , -0.22...])
```

<!-- !! processed by numpydoc !! -->
