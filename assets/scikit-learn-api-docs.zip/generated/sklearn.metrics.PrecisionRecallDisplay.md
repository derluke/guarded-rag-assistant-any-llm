# PrecisionRecallDisplay

### *class* sklearn.metrics.PrecisionRecallDisplay(precision, recall, \*, average_precision=None, estimator_name=None, pos_label=None, prevalence_pos_label=None)

Precision Recall visualization.

It is recommend to use
[`from_estimator`](#sklearn.metrics.PrecisionRecallDisplay.from_estimator) or
[`from_predictions`](#sklearn.metrics.PrecisionRecallDisplay.from_predictions) to create
a [`PrecisionRecallDisplay`](#sklearn.metrics.PrecisionRecallDisplay). All parameters are
stored as attributes.

Read more in the [User Guide](../../visualizations.md#visualizations).

* **Parameters:**
  **precision**
  : Precision values.

  **recall**
  : Recall values.

  **average_precision**
  : Average precision. If None, the average precision is not shown.

  **estimator_name**
  : Name of estimator. If None, then the estimator name is not shown.

  **pos_label**
  : The class considered as the positive class. If None, the class will not
    be shown in the legend.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **prevalence_pos_label**
  : The prevalence of the positive label. It is used for plotting the
    chance level line. If None, the chance level line will not be plotted
    even if `plot_chance_level` is set to True when plotting.
    <br/>
    #### Versionadded
    Added in version 1.3.
* **Attributes:**
  **line_**
  : Precision recall curve.

  **chance_level_**
  : The chance level line. It is `None` if the chance level is not plotted.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **ax_**
  : Axes with precision recall curve.

  **figure_**
  : Figure containing the curve.

#### SEE ALSO
[`precision_recall_curve`](sklearn.metrics.precision_recall_curve.md#sklearn.metrics.precision_recall_curve)
: Compute precision-recall pairs for different probability thresholds.

[`PrecisionRecallDisplay.from_estimator`](#sklearn.metrics.PrecisionRecallDisplay.from_estimator)
: Plot Precision Recall Curve given a binary classifier.

[`PrecisionRecallDisplay.from_predictions`](#sklearn.metrics.PrecisionRecallDisplay.from_predictions)
: Plot Precision Recall Curve using predictions from a binary classifier.

### Notes

The average precision (cf. [`average_precision_score`](sklearn.metrics.average_precision_score.md#sklearn.metrics.average_precision_score)) in
scikit-learn is computed without any interpolation. To be consistent with
this metric, the precision-recall curve is plotted without any
interpolation as well (step-wise style).

You can change this style by passing the keyword argument
`drawstyle="default"` in [`plot`](#sklearn.metrics.PrecisionRecallDisplay.plot), [`from_estimator`](#sklearn.metrics.PrecisionRecallDisplay.from_estimator), or
[`from_predictions`](#sklearn.metrics.PrecisionRecallDisplay.from_predictions). However, the curve will not be strictly
consistent with the reported average precision.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import (precision_recall_curve,
...                              PrecisionRecallDisplay)
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.svm import SVC
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(X, y,
...                                                     random_state=0)
>>> clf = SVC(random_state=0)
>>> clf.fit(X_train, y_train)
SVC(random_state=0)
>>> predictions = clf.predict(X_test)
>>> precision, recall, _ = precision_recall_curve(y_test, predictions)
>>> disp = PrecisionRecallDisplay(precision=precision, recall=recall)
>>> disp.plot()
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-PrecisionRecallDisplay-1.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_estimator(estimator, X, y, \*, sample_weight=None, pos_label=None, drop_intermediate=False, response_method='auto', name=None, ax=None, plot_chance_level=False, chance_level_kw=None, despine=False, \*\*kwargs)

Plot precision-recall curve given an estimator and some data.

* **Parameters:**
  **estimator**
  : Fitted classifier or a fitted [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)
    in which the last estimator is a classifier.

  **X**
  : Input values.

  **y**
  : Target values.

  **sample_weight**
  : Sample weights.

  **pos_label**
  : The class considered as the positive class when computing the
    precision and recall metrics. By default, `estimators.classes_[1]`
    is considered as the positive class.

  **drop_intermediate**
  : Whether to drop some suboptimal thresholds which would not appear
    on a plotted precision-recall curve. This is useful in order to
    create lighter precision-recall curves.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **response_method**
  : Specifies whether to use [predict_proba](../../glossary.md#term-predict_proba) or
    [decision_function](../../glossary.md#term-decision_function) as the target response. If set to ‘auto’,
    [predict_proba](../../glossary.md#term-predict_proba) is tried first and if it does not exist
    [decision_function](../../glossary.md#term-decision_function) is tried next.

  **name**
  : Name for labeling curve. If `None`, no name is used.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is created.

  **plot_chance_level**
  : Whether to plot the chance level. The chance level is the prevalence
    of the positive label computed from the data passed during
    [`from_estimator`](#sklearn.metrics.PrecisionRecallDisplay.from_estimator) or [`from_predictions`](#sklearn.metrics.PrecisionRecallDisplay.from_predictions) call.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **chance_level_kw**
  : Keyword arguments to be passed to matplotlib’s `plot` for rendering
    the chance level line.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **despine**
  : Whether to remove the top and right spines from the plot.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **\*\*kwargs**
  : Keyword arguments to be passed to matplotlib’s `plot`.
* **Returns:**
  **display**

#### SEE ALSO
[`PrecisionRecallDisplay.from_predictions`](#sklearn.metrics.PrecisionRecallDisplay.from_predictions)
: Plot precision-recall curve using estimated probabilities or output of decision function.

### Notes

The average precision (cf. [`average_precision_score`](sklearn.metrics.average_precision_score.md#sklearn.metrics.average_precision_score))
in scikit-learn is computed without any interpolation. To be consistent
with this metric, the precision-recall curve is plotted without any
interpolation as well (step-wise style).

You can change this style by passing the keyword argument
`drawstyle="default"`. However, the curve will not be strictly
consistent with the reported average precision.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import PrecisionRecallDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.linear_model import LogisticRegression
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...         X, y, random_state=0)
>>> clf = LogisticRegression()
>>> clf.fit(X_train, y_train)
LogisticRegression()
>>> PrecisionRecallDisplay.from_estimator(
...    clf, X_test, y_test)
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-PrecisionRecallDisplay-2.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_predictions(y_true, y_pred, \*, sample_weight=None, pos_label=None, drop_intermediate=False, name=None, ax=None, plot_chance_level=False, chance_level_kw=None, despine=False, \*\*kwargs)

Plot precision-recall curve given binary class predictions.

* **Parameters:**
  **y_true**
  : True binary labels.

  **y_pred**
  : Estimated probabilities or output of decision function.

  **sample_weight**
  : Sample weights.

  **pos_label**
  : The class considered as the positive class when computing the
    precision and recall metrics.

  **drop_intermediate**
  : Whether to drop some suboptimal thresholds which would not appear
    on a plotted precision-recall curve. This is useful in order to
    create lighter precision-recall curves.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **name**
  : Name for labeling curve. If `None`, name will be set to
    `"Classifier"`.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is created.

  **plot_chance_level**
  : Whether to plot the chance level. The chance level is the prevalence
    of the positive label computed from the data passed during
    [`from_estimator`](#sklearn.metrics.PrecisionRecallDisplay.from_estimator) or [`from_predictions`](#sklearn.metrics.PrecisionRecallDisplay.from_predictions) call.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **chance_level_kw**
  : Keyword arguments to be passed to matplotlib’s `plot` for rendering
    the chance level line.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **despine**
  : Whether to remove the top and right spines from the plot.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **\*\*kwargs**
  : Keyword arguments to be passed to matplotlib’s `plot`.
* **Returns:**
  **display**

#### SEE ALSO
[`PrecisionRecallDisplay.from_estimator`](#sklearn.metrics.PrecisionRecallDisplay.from_estimator)
: Plot precision-recall curve using an estimator.

### Notes

The average precision (cf. [`average_precision_score`](sklearn.metrics.average_precision_score.md#sklearn.metrics.average_precision_score))
in scikit-learn is computed without any interpolation. To be consistent
with this metric, the precision-recall curve is plotted without any
interpolation as well (step-wise style).

You can change this style by passing the keyword argument
`drawstyle="default"`. However, the curve will not be strictly
consistent with the reported average precision.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import PrecisionRecallDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.linear_model import LogisticRegression
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...         X, y, random_state=0)
>>> clf = LogisticRegression()
>>> clf.fit(X_train, y_train)
LogisticRegression()
>>> y_pred = clf.predict_proba(X_test)[:, 1]
>>> PrecisionRecallDisplay.from_predictions(
...    y_test, y_pred)
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-PrecisionRecallDisplay-3.*)
<!-- !! processed by numpydoc !! -->

#### plot(ax=None, \*, name=None, plot_chance_level=False, chance_level_kw=None, despine=False, \*\*kwargs)

Plot visualization.

Extra keyword arguments will be passed to matplotlib’s `plot`.

* **Parameters:**
  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **name**
  : Name of precision recall curve for labeling. If `None`, use
    `estimator_name` if not `None`, otherwise no labeling is shown.

  **plot_chance_level**
  : Whether to plot the chance level. The chance level is the prevalence
    of the positive label computed from the data passed during
    [`from_estimator`](#sklearn.metrics.PrecisionRecallDisplay.from_estimator) or [`from_predictions`](#sklearn.metrics.PrecisionRecallDisplay.from_predictions) call.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **chance_level_kw**
  : Keyword arguments to be passed to matplotlib’s `plot` for rendering
    the chance level line.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **despine**
  : Whether to remove the top and right spines from the plot.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **\*\*kwargs**
  : Keyword arguments to be passed to matplotlib’s `plot`.
* **Returns:**
  **display**
  : Object that stores computed values.

### Notes

The average precision (cf. [`average_precision_score`](sklearn.metrics.average_precision_score.md#sklearn.metrics.average_precision_score))
in scikit-learn is computed without any interpolation. To be consistent
with this metric, the precision-recall curve is plotted without any
interpolation as well (step-wise style).

You can change this style by passing the keyword argument
`drawstyle="default"`. However, the curve will not be strictly
consistent with the reported average precision.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<!-- thumbnail-parent-div-close --></div>
