# lars_path_gram

### sklearn.linear_model.lars_path_gram(Xy, Gram, \*, n_samples, max_iter=500, alpha_min=0, method='lar', copy_X=True, eps=2.220446049250313e-16, copy_Gram=True, verbose=0, return_path=True, return_n_iter=False, positive=False)

The lars_path in the sufficient stats mode.

The optimization objective for the case method=’lasso’ is:

```default
(1 / (2 * n_samples)) * ||y - Xw||^2_2 + alpha * ||w||_1
```

in the case of method=’lar’, the objective function is only known in
the form of an implicit equation (see discussion in [[1]](#r34229eeff553-1)).

Read more in the [User Guide](../linear_model.md#least-angle-regression).

* **Parameters:**
  **Xy**
  : `Xy = X.T @ y`.

  **Gram**
  : `Gram = X.T @ X`.

  **n_samples**
  : Equivalent size of sample.

  **max_iter**
  : Maximum number of iterations to perform, set to infinity for no limit.

  **alpha_min**
  : Minimum correlation along the path. It corresponds to the
    regularization parameter alpha parameter in the Lasso.

  **method**
  : Specifies the returned model. Select `'lar'` for Least Angle
    Regression, `'lasso'` for the Lasso.

  **copy_X**
  : If `False`, `X` is overwritten.

  **eps**
  : The machine-precision regularization in the computation of the
    Cholesky diagonal factors. Increase this for very ill-conditioned
    systems. Unlike the `tol` parameter in some iterative
    optimization-based algorithms, this parameter does not control
    the tolerance of the optimization.

  **copy_Gram**
  : If `False`, `Gram` is overwritten.

  **verbose**
  : Controls output verbosity.

  **return_path**
  : If `return_path==True` returns the entire path, else returns only the
    last point of the path.

  **return_n_iter**
  : Whether to return the number of iterations.

  **positive**
  : Restrict coefficients to be >= 0.
    This option is only allowed with method ‘lasso’. Note that the model
    coefficients will not converge to the ordinary-least-squares solution
    for small values of alpha. Only coefficients up to the smallest alpha
    value (`alphas_[alphas_ > 0.].min()` when `fit_path=True`) reached by
    the stepwise Lars-Lasso algorithm are typically in congruence with the
    solution of the coordinate descent lasso_path function.
* **Returns:**
  **alphas**
  : Maximum of covariances (in absolute value) at each iteration.
    `n_alphas` is either `max_iter`, `n_features` or the
    number of nodes in the path with `alpha >= alpha_min`, whichever
    is smaller.

  **active**
  : Indices of active variables at the end of the path.

  **coefs**
  : Coefficients along the path.

  **n_iter**
  : Number of iterations run. Returned only if `return_n_iter` is set
    to True.

#### SEE ALSO
[`lars_path_gram`](#sklearn.linear_model.lars_path_gram)
: Compute LARS path.

[`lasso_path`](sklearn.linear_model.lasso_path.md#sklearn.linear_model.lasso_path)
: Compute Lasso path with coordinate descent.

[`LassoLars`](sklearn.linear_model.LassoLars.md#sklearn.linear_model.LassoLars)
: Lasso model fit with Least Angle Regression a.k.a. Lars.

[`Lars`](sklearn.linear_model.Lars.md#sklearn.linear_model.Lars)
: Least Angle Regression model a.k.a. LAR.

[`LassoLarsCV`](sklearn.linear_model.LassoLarsCV.md#sklearn.linear_model.LassoLarsCV)
: Cross-validated Lasso, using the LARS algorithm.

[`LarsCV`](sklearn.linear_model.LarsCV.md#sklearn.linear_model.LarsCV)
: Cross-validated Least Angle Regression model.

[`sklearn.decomposition.sparse_encode`](sklearn.decomposition.sparse_encode.md#sklearn.decomposition.sparse_encode)
: Sparse coding.

### References

### Examples

```pycon
>>> from sklearn.linear_model import lars_path_gram
>>> from sklearn.datasets import make_regression
>>> X, y, true_coef = make_regression(
...    n_samples=100, n_features=5, n_informative=2, coef=True, random_state=0
... )
>>> true_coef
array([ 0.        ,  0.        ,  0.        , 97.9..., 45.7...])
>>> alphas, _, estimated_coef = lars_path_gram(X.T @ y, X.T @ X, n_samples=100)
>>> alphas.shape
(3,)
>>> estimated_coef
array([[ 0.     ,  0.     ,  0.     ],
       [ 0.     ,  0.     ,  0.     ],
       [ 0.     ,  0.     ,  0.     ],
       [ 0.     , 46.96..., 97.99...],
       [ 0.     ,  0.     , 45.70...]])
```

<!-- !! processed by numpydoc !! -->
