# AdaBoostRegressor

### *class* sklearn.ensemble.AdaBoostRegressor(estimator=None, \*, n_estimators=50, learning_rate=1.0, loss='linear', random_state=None)

An AdaBoost regressor.

An AdaBoost [1] regressor is a meta-estimator that begins by fitting a
regressor on the original dataset and then fits additional copies of the
regressor on the same dataset but where the weights of instances are
adjusted according to the error of the current prediction. As such,
subsequent regressors focus more on difficult cases.

This class implements the algorithm known as AdaBoost.R2 [2].

Read more in the [User Guide](../ensemble.md#adaboost).

#### Versionadded
Added in version 0.14.

* **Parameters:**
  **estimator**
  : The base estimator from which the boosted ensemble is built.
    If `None`, then the base estimator is
    [`DecisionTreeRegressor`](sklearn.tree.DecisionTreeRegressor.md#sklearn.tree.DecisionTreeRegressor) initialized with
    `max_depth=3`.
    <br/>
    #### Versionadded
    Added in version 1.2: `base_estimator` was renamed to `estimator`.

  **n_estimators**
  : The maximum number of estimators at which boosting is terminated.
    In case of perfect fit, the learning procedure is stopped early.
    Values must be in the range `[1, inf)`.

  **learning_rate**
  : Weight applied to each regressor at each boosting iteration. A higher
    learning rate increases the contribution of each regressor. There is
    a trade-off between the `learning_rate` and `n_estimators` parameters.
    Values must be in the range `(0.0, inf)`.

  **loss**
  : The loss function to use when updating the weights after each
    boosting iteration.

  **random_state**
  : Controls the random seed given at each `estimator` at each
    boosting iteration.
    Thus, it is only used when `estimator` exposes a `random_state`.
    In addition, it controls the bootstrap of the weights used to train the
    `estimator` at each boosting iteration.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **estimator_**
  : The base estimator from which the ensemble is grown.
    <br/>
    #### Versionadded
    Added in version 1.2: `base_estimator_` was renamed to `estimator_`.

  **estimators_**
  : The collection of fitted sub-estimators.

  **estimator_weights_**
  : Weights for each estimator in the boosted ensemble.

  **estimator_errors_**
  : Regression error for each estimator in the boosted ensemble.

  [`feature_importances_`](#sklearn.ensemble.AdaBoostRegressor.feature_importances_)
  : The impurity-based feature importances.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`AdaBoostClassifier`](sklearn.ensemble.AdaBoostClassifier.md#sklearn.ensemble.AdaBoostClassifier)
: An AdaBoost classifier.

[`GradientBoostingRegressor`](sklearn.ensemble.GradientBoostingRegressor.md#sklearn.ensemble.GradientBoostingRegressor)
: Gradient Boosting Classification Tree.

[`sklearn.tree.DecisionTreeRegressor`](sklearn.tree.DecisionTreeRegressor.md#sklearn.tree.DecisionTreeRegressor)
: A decision tree regressor.

### References

### Examples

```pycon
>>> from sklearn.ensemble import AdaBoostRegressor
>>> from sklearn.datasets import make_regression
>>> X, y = make_regression(n_features=4, n_informative=2,
...                        random_state=0, shuffle=False)
>>> regr = AdaBoostRegressor(random_state=0, n_estimators=100)
>>> regr.fit(X, y)
AdaBoostRegressor(n_estimators=100, random_state=0)
>>> regr.predict([[0, 0, 0, 0]])
array([4.7972...])
>>> regr.score(X, y)
0.9771...
```

For a detailed example of utilizing [`AdaBoostRegressor`](#sklearn.ensemble.AdaBoostRegressor)
to fit a sequence of decision trees as weak learners, please refer to
[Decision Tree Regression with AdaBoost](../../auto_examples/ensemble/plot_adaboost_regression.md#sphx-glr-auto-examples-ensemble-plot-adaboost-regression-py).

<!-- !! processed by numpydoc !! -->

#### *property* feature_importances_

The impurity-based feature importances.

The higher, the more important the feature.
The importance of a feature is computed as the (normalized)
total reduction of the criterion brought by that feature.  It is also
known as the Gini importance.

Warning: impurity-based feature importances can be misleading for
high cardinality features (many unique values). See
[`sklearn.inspection.permutation_importance`](sklearn.inspection.permutation_importance.md#sklearn.inspection.permutation_importance) as an alternative.

* **Returns:**
  **feature_importances_**
  : The feature importances.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Build a boosted classifier/regressor from the training set (X, y).

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.

  **y**
  : The target values.

  **sample_weight**
  : Sample weights. If None, the sample weights are initialized to
    1 / n_samples.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Raise `NotImplementedError`.

This estimator does not support metadata routing yet.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict regression value for X.

The predicted regression value of an input sample is computed
as the weighted median prediction of the regressors in the ensemble.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.
* **Returns:**
  **y**
  : The predicted regression values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [AdaBoostRegressor](#sklearn.ensemble.AdaBoostRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [AdaBoostRegressor](#sklearn.ensemble.AdaBoostRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### staged_predict(X)

Return staged predictions for X.

The predicted regression value of an input sample is computed
as the weighted median prediction of the regressors in the ensemble.

This generator method yields the ensemble prediction after each
iteration of boosting and therefore allows monitoring, such as to
determine the prediction on a test set after each boost.

* **Parameters:**
  **X**
  : The training input samples.
* **Yields:**
  **y**
  : The predicted regression values.

<!-- !! processed by numpydoc !! -->

#### staged_score(X, y, sample_weight=None)

Return staged scores for X, y.

This generator method yields the ensemble score after each iteration of
boosting and therefore allows monitoring, such as to determine the
score on a test set after each boost.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrix can be CSC, CSR, COO,
    DOK, or LIL. COO, DOK, and LIL are converted to CSR.

  **y**
  : Labels for X.

  **sample_weight**
  : Sample weights.
* **Yields:**
  **z**

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A decision tree is boosted using the AdaBoost.R2 [1]_ algorithm on a 1D sinusoidal dataset with a small amount of Gaussian noise. 299 boosts (300 decision trees) is compared with a single decision tree regressor. As the number of boosts is increased the regressor can fit more detail.">  <div class="sphx-glr-thumbnail-title">Decision Tree Regression with AdaBoost</div>
</div>
* [Decision Tree Regression with AdaBoost](../../auto_examples/ensemble/plot_adaboost_regression.md#sphx-glr-auto-examples-ensemble-plot-adaboost-regression-py)

<!-- thumbnail-parent-div-close --></div>
