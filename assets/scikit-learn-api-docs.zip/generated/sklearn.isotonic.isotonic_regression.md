# isotonic_regression

### sklearn.isotonic.isotonic_regression(y, \*, sample_weight=None, y_min=None, y_max=None, increasing=True)

Solve the isotonic regression model.

Read more in the [User Guide](../isotonic.md#isotonic).

* **Parameters:**
  **y**
  : The data.

  **sample_weight**
  : Weights on each point of the regression.
    If None, weight is set to 1 (equal weights).

  **y_min**
  : Lower bound on the lowest predicted value (the minimum value may
    still be higher). If not set, defaults to -inf.

  **y_max**
  : Upper bound on the highest predicted value (the maximum may still be
    lower). If not set, defaults to +inf.

  **increasing**
  : Whether to compute `y_` is increasing (if set to True) or decreasing
    (if set to False).
* **Returns:**
  **y_**
  : Isotonic fit of y.

### References

“Active set algorithms for isotonic regression; A unifying framework”
by Michael J. Best and Nilotpal Chakravarti, section 3.

### Examples

```pycon
>>> from sklearn.isotonic import isotonic_regression
>>> isotonic_regression([5, 3, 1, 2, 8, 10, 7, 9, 6, 4])
array([2.75   , 2.75   , 2.75   , 2.75   , 7.33...,
       7.33..., 7.33..., 7.33..., 7.33..., 7.33...])
```

<!-- !! processed by numpydoc !! -->
