# v_measure_score

### sklearn.metrics.v_measure_score(labels_true, labels_pred, \*, beta=1.0)

V-measure cluster labeling given a ground truth.

This score is identical to [`normalized_mutual_info_score`](sklearn.metrics.normalized_mutual_info_score.md#sklearn.metrics.normalized_mutual_info_score) with
the `'arithmetic'` option for averaging.

The V-measure is the harmonic mean between homogeneity and completeness:

```default
v = (1 + beta) * homogeneity * completeness
     / (beta * homogeneity + completeness)
```

This metric is independent of the absolute values of the labels:
a permutation of the class or cluster label values won’t change the
score value in any way.

This metric is furthermore symmetric: switching `label_true` with
`label_pred` will return the same score value. This can be useful to
measure the agreement of two independent label assignments strategies
on the same dataset when the real ground truth is not known.

Read more in the [User Guide](../clustering.md#homogeneity-completeness).

* **Parameters:**
  **labels_true**
  : Ground truth class labels to be used as a reference.

  **labels_pred**
  : Cluster labels to evaluate.

  **beta**
  : Ratio of weight attributed to `homogeneity` vs `completeness`.
    If `beta` is greater than 1, `completeness` is weighted more
    strongly in the calculation. If `beta` is less than 1,
    `homogeneity` is weighted more strongly.
* **Returns:**
  **v_measure**
  : Score between 0.0 and 1.0. 1.0 stands for perfectly complete labeling.

#### SEE ALSO
[`homogeneity_score`](sklearn.metrics.homogeneity_score.md#sklearn.metrics.homogeneity_score)
: Homogeneity metric of cluster labeling.

[`completeness_score`](sklearn.metrics.completeness_score.md#sklearn.metrics.completeness_score)
: Completeness metric of cluster labeling.

[`normalized_mutual_info_score`](sklearn.metrics.normalized_mutual_info_score.md#sklearn.metrics.normalized_mutual_info_score)
: Normalized Mutual Information.

### References

### Examples

Perfect labelings are both homogeneous and complete, hence have score 1.0:

```default
>>> from sklearn.metrics.cluster import v_measure_score
>>> v_measure_score([0, 0, 1, 1], [0, 0, 1, 1])
np.float64(1.0)
>>> v_measure_score([0, 0, 1, 1], [1, 1, 0, 0])
np.float64(1.0)
```

Labelings that assign all classes members to the same clusters
are complete but not homogeneous, hence penalized:

```default
>>> print("%.6f" % v_measure_score([0, 0, 1, 2], [0, 0, 1, 1]))
0.8...
>>> print("%.6f" % v_measure_score([0, 1, 2, 3], [0, 0, 1, 1]))
0.66...
```

Labelings that have pure clusters with members coming from the same
classes are homogeneous but un-necessary splits harm completeness
and thus penalize V-measure as well:

```default
>>> print("%.6f" % v_measure_score([0, 0, 1, 1], [0, 0, 1, 2]))
0.8...
>>> print("%.6f" % v_measure_score([0, 0, 1, 1], [0, 1, 2, 3]))
0.66...
```

If classes members are completely split across different clusters,
the assignment is totally incomplete, hence the V-Measure is null:

```default
>>> print("%.6f" % v_measure_score([0, 0, 0, 0], [0, 1, 2, 3]))
0.0...
```

Clusters that include samples from totally different classes totally
destroy the homogeneity of the labeling, hence:

```default
>>> print("%.6f" % v_measure_score([0, 0, 1, 1], [0, 0, 0, 0]))
0.0...
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the Spectral Co-clustering algorithm on the twenty newsgroups dataset. The &#x27;comp.os.ms-windows.misc&#x27; category is excluded because it contains many posts containing nothing but data.">  <div class="sphx-glr-thumbnail-title">Biclustering documents with the Spectral Co-clustering algorithm</div>
</div>
* [Biclustering documents with the Spectral Co-clustering algorithm](../../auto_examples/bicluster/plot_bicluster_newsgroups.md#sphx-glr-auto-examples-bicluster-plot-bicluster-newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the various initialization strategies for K-means in terms of runtime and quality of the results.">  <div class="sphx-glr-thumbnail-title">A demo of K-Means clustering on the handwritten digits data</div>
</div>
* [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="- a first experiment with fixed &quot;ground truth labels&quot; (and therefore fixed   number of classes) and randomly &quot;predicted labels&quot;; - a second experiment with varying &quot;ground truth labels&quot;, randomly &quot;predicted   labels&quot;. The &quot;predicted labels&quot; have the same number of classes and clusters   as the &quot;ground truth labels&quot;.">  <div class="sphx-glr-thumbnail-title">Adjustment for chance in clustering performance evaluation</div>
</div>
* [Adjustment for chance in clustering performance evaluation](../../auto_examples/cluster/plot_adjusted_for_chance_measures.md#sphx-glr-auto-examples-cluster-plot-adjusted-for-chance-measures-py)

<div class="sphx-glr-thumbcontainer" tooltip="DBSCAN (Density-Based Spatial Clustering of Applications with Noise) finds core samples in regions of high density and expands clusters from them. This algorithm is good for data which contains clusters of similar density.">  <div class="sphx-glr-thumbnail-title">Demo of DBSCAN clustering algorithm</div>
</div>
* [Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="Reference: Brendan J. Frey and Delbert Dueck, &quot;Clustering by Passing Messages Between Data Points&quot;, Science Feb. 2007">  <div class="sphx-glr-thumbnail-title">Demo of affinity propagation clustering algorithm</div>
</div>
* [Demo of affinity propagation clustering algorithm](../../auto_examples/cluster/plot_affinity_propagation.md#sphx-glr-auto-examples-cluster-plot-affinity-propagation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how the scikit-learn API can be used to cluster documents by topics using a Bag of Words approach.">  <div class="sphx-glr-thumbnail-title">Clustering text documents using k-means</div>
</div>
* [Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.3! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_3&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.3</div>
</div>
* [Release Highlights for scikit-learn 1.3](../../auto_examples/release_highlights/plot_release_highlights_1_3_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-3-0-py)

<!-- thumbnail-parent-div-close --></div>
