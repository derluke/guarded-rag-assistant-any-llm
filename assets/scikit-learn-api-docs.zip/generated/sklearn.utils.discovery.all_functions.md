# all_functions

### sklearn.utils.discovery.all_functions()

Get a list of all functions from `sklearn`.

* **Returns:**
  **functions**
  : List of (name, function), where `name` is the function name as
    string and `function` is the actual function.

### Examples

```pycon
>>> from sklearn.utils.discovery import all_functions
>>> functions = all_functions()
>>> name, function = functions[0]
>>> name
'accuracy_score'
```

<!-- !! processed by numpydoc !! -->
