# estimator_checks_generator

### sklearn.utils.estimator_checks.estimator_checks_generator(estimator, \*, legacy: [bool](https://docs.python.org/3/library/functions.html#bool) = True, expected_failed_checks: [dict](https://docs.python.org/3/library/stdtypes.html#dict)[[str](https://docs.python.org/3/library/stdtypes.html#str), [str](https://docs.python.org/3/library/stdtypes.html#str)] | [None](https://docs.python.org/3/library/constants.html#None) = None, mark: Literal['xfail', 'skip', None] = None)

Iteratively yield all check callables for an estimator.

#### Versionadded
Added in version 1.6.

* **Parameters:**
  **estimator**
  : Estimator instance for which to generate checks.

  **legacy**
  : Whether to include legacy checks. Over time we remove checks from this category
    and move them into their specific category.

  **expected_failed_checks**
  : Dictionary of the form {check_name: reason} for checks that are expected to
    fail.

  **mark**
  : Whether to mark the checks that are expected to fail as
    xfail(`pytest.mark.xfail`) or skip. Marking a test as “skip” is done via
    wrapping the check in a function that raises a
    `SkipTest` exception.
* **Returns:**
  **estimator_checks_generator**
  : Generator that yields (estimator, check) tuples.

<!-- !! processed by numpydoc !! -->
