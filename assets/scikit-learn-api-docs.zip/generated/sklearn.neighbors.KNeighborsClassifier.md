# KNeighborsClassifier

### *class* sklearn.neighbors.KNeighborsClassifier(n_neighbors=5, \*, weights='uniform', algorithm='auto', leaf_size=30, p=2, metric='minkowski', metric_params=None, n_jobs=None)

Classifier implementing the k-nearest neighbors vote.

Read more in the [User Guide](../neighbors.md#classification).

* **Parameters:**
  **n_neighbors**
  : Number of neighbors to use by default for [`kneighbors`](#sklearn.neighbors.KNeighborsClassifier.kneighbors) queries.

  **weights**
  : Weight function used in prediction.  Possible values:
    - ‘uniform’ : uniform weights.  All points in each neighborhood
      are weighted equally.
    - ‘distance’ : weight points by the inverse of their distance.
      in this case, closer neighbors of a query point will have a
      greater influence than neighbors which are further away.
    - [callable] : a user-defined function which accepts an
      array of distances, and returns an array of the same shape
      containing the weights.
    <br/>
    Refer to the example entitled
    [Nearest Neighbors Classification](../../auto_examples/neighbors/plot_classification.md#sphx-glr-auto-examples-neighbors-plot-classification-py)
    showing the impact of the `weights` parameter on the decision
    boundary.

  **algorithm**
  : Algorithm used to compute the nearest neighbors:
    - ‘ball_tree’ will use [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree)
    - ‘kd_tree’ will use [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree)
    - ‘brute’ will use a brute-force search.
    - ‘auto’ will attempt to decide the most appropriate algorithm
      based on the values passed to [`fit`](#sklearn.neighbors.KNeighborsClassifier.fit) method.
    <br/>
    Note: fitting on sparse input will override the setting of
    this parameter, using brute force.

  **leaf_size**
  : Leaf size passed to BallTree or KDTree.  This can affect the
    speed of the construction and query, as well as the memory
    required to store the tree.  The optimal value depends on the
    nature of the problem.

  **p**
  : Power parameter for the Minkowski metric. When p = 1, this is equivalent
    to using manhattan_distance (l1), and euclidean_distance (l2) for p = 2.
    For arbitrary p, minkowski_distance (l_p) is used. This parameter is expected
    to be positive.

  **metric**
  : Metric to use for distance computation. Default is “minkowski”, which
    results in the standard Euclidean distance when p = 2. See the
    documentation of [scipy.spatial.distance](https://docs.scipy.org/doc/scipy/reference/spatial.distance.html) and
    the metrics listed in
    [`distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics) for valid metric
    values.
    <br/>
    If metric is “precomputed”, X is assumed to be a distance matrix and
    must be square during fit. X may be a [sparse graph](../../glossary.md#term-sparse-graph), in which
    case only “nonzero” elements may be considered neighbors.
    <br/>
    If metric is a callable function, it takes two arrays representing 1D
    vectors as inputs and must return one value indicating the distance
    between those vectors. This works for Scipy’s metrics, but is less
    efficient than passing the metric name as a string.

  **metric_params**
  : Additional keyword arguments for the metric function.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    Doesn’t affect [`fit`](#sklearn.neighbors.KNeighborsClassifier.fit) method.
* **Attributes:**
  **classes_**
  : Class labels known to the classifier

  **effective_metric_**
  : The distance metric used. It will be same as the `metric` parameter
    or a synonym of it, e.g. ‘euclidean’ if the `metric` parameter set to
    ‘minkowski’ and `p` parameter set to 2.

  **effective_metric_params_**
  : Additional keyword arguments for the metric function. For most metrics
    will be same with `metric_params` parameter, but may also contain the
    `p` parameter value if the `effective_metric_` attribute is set to
    ‘minkowski’.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_samples_fit_**
  : Number of samples in the fitted data.

  **outputs_2d_**
  : False when `y`’s shape is (n_samples, ) or (n_samples, 1) during fit
    otherwise True.

#### SEE ALSO
[`RadiusNeighborsClassifier`](sklearn.neighbors.RadiusNeighborsClassifier.md#sklearn.neighbors.RadiusNeighborsClassifier)
: Classifier based on neighbors within a fixed radius.

[`KNeighborsRegressor`](sklearn.neighbors.KNeighborsRegressor.md#sklearn.neighbors.KNeighborsRegressor)
: Regression based on k-nearest neighbors.

[`RadiusNeighborsRegressor`](sklearn.neighbors.RadiusNeighborsRegressor.md#sklearn.neighbors.RadiusNeighborsRegressor)
: Regression based on neighbors within a fixed radius.

[`NearestNeighbors`](sklearn.neighbors.NearestNeighbors.md#sklearn.neighbors.NearestNeighbors)
: Unsupervised learner for implementing neighbor searches.

### Notes

See [Nearest Neighbors](../neighbors.md#neighbors) in the online documentation
for a discussion of the choice of `algorithm` and `leaf_size`.

#### WARNING
Regarding the Nearest Neighbors algorithms, if it is found that two
neighbors, neighbor `k+1` and `k`, have identical distances
but different labels, the results will depend on the ordering of the
training data.

[https://en.wikipedia.org/wiki/K-nearest_neighbor_algorithm](https://en.wikipedia.org/wiki/K-nearest_neighbor_algorithm)

### Examples

```pycon
>>> X = [[0], [1], [2], [3]]
>>> y = [0, 0, 1, 1]
>>> from sklearn.neighbors import KNeighborsClassifier
>>> neigh = KNeighborsClassifier(n_neighbors=3)
>>> neigh.fit(X, y)
KNeighborsClassifier(...)
>>> print(neigh.predict([[1.1]]))
[0]
>>> print(neigh.predict_proba([[0.9]]))
[[0.666... 0.333...]]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit the k-nearest neighbors classifier from the training dataset.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.
* **Returns:**
  **self**
  : The fitted k-nearest neighbors classifier.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### kneighbors(X=None, n_neighbors=None, return_distance=True)

Find the K-neighbors of a point.

Returns indices of and distances to the neighbors of each point.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.

  **n_neighbors**
  : Number of neighbors required for each sample. The default is the
    value passed to the constructor.

  **return_distance**
  : Whether or not to return the distances.
* **Returns:**
  **neigh_dist**
  : Array representing the lengths to points, only present if
    return_distance=True.

  **neigh_ind**
  : Indices of the nearest points in the population matrix.

### Examples

In the following example, we construct a NearestNeighbors
class from an array representing our data set and ask who’s
the closest point to [1,1,1]

```pycon
>>> samples = [[0., 0., 0.], [0., .5, 0.], [1., 1., .5]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(n_neighbors=1)
>>> neigh.fit(samples)
NearestNeighbors(n_neighbors=1)
>>> print(neigh.kneighbors([[1., 1., 1.]]))
(array([[0.5]]), array([[2]]))
```

As you can see, it returns [[0.5]], and [[2]], which means that the
element is at distance 0.5 and is the third element of samples
(indexes start at 0). You can also query for multiple points:

```pycon
>>> X = [[0., 1., 0.], [1., 0., 1.]]
>>> neigh.kneighbors(X, return_distance=False)
array([[1],
       [2]]...)
```

<!-- !! processed by numpydoc !! -->

#### kneighbors_graph(X=None, n_neighbors=None, mode='connectivity')

Compute the (weighted) graph of k-Neighbors for points in X.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.
    For `metric='precomputed'` the shape should be
    (n_queries, n_indexed). Otherwise the shape should be
    (n_queries, n_features).

  **n_neighbors**
  : Number of neighbors for each sample. The default is the value
    passed to the constructor.

  **mode**
  : Type of returned matrix: ‘connectivity’ will return the
    connectivity matrix with ones and zeros, in ‘distance’ the
    edges are distances between points, type of distance
    depends on the selected metric parameter in
    NearestNeighbors class.
* **Returns:**
  **A**
  : `n_samples_fit` is the number of samples in the fitted data.
    `A[i, j]` gives the weight of the edge connecting `i` to `j`.
    The matrix is of CSR format.

#### SEE ALSO
[`NearestNeighbors.radius_neighbors_graph`](sklearn.neighbors.NearestNeighbors.md#sklearn.neighbors.NearestNeighbors.radius_neighbors_graph)
: Compute the (weighted) graph of Neighbors for points in X.

### Examples

```pycon
>>> X = [[0], [3], [1]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(n_neighbors=2)
>>> neigh.fit(X)
NearestNeighbors(n_neighbors=2)
>>> A = neigh.kneighbors_graph(X)
>>> A.toarray()
array([[1., 0., 1.],
       [0., 1., 1.],
       [1., 0., 1.]])
```

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict the class labels for the provided data.

* **Parameters:**
  **X**
  : Test samples. If `None`, predictions for all indexed points are
    returned; in this case, points are not considered their own
    neighbors.
* **Returns:**
  **y**
  : Class labels for each data sample.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Return probability estimates for the test data X.

* **Parameters:**
  **X**
  : Test samples. If `None`, predictions for all indexed points are
    returned; in this case, points are not considered their own
    neighbors.
* **Returns:**
  **p**
  : The class probabilities of the input samples. Classes are ordered
    by lexicographic order.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples. If `None`, predictions for all indexed points are
    used; in this case, points are not considered their own
    neighbors. This means that `knn.fit(X, y).score(None, y)`
    implicitly performs a leave-one-out cross-validation procedure
    and is equivalent to `cross_val_score(knn, X, y, cv=LeaveOneOut())`
    but typically much faster.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [KNeighborsClassifier](#sklearn.neighbors.KNeighborsClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision boundaries of a VotingClassifier for two features of the Iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision boundaries of a VotingClassifier</div>
</div>
* [Plot the decision boundaries of a VotingClassifier](../../auto_examples/ensemble/plot_voting_decision_regions.md#sphx-glr-auto-examples-ensemble-plot-voting-decision-regions-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to precompute the k nearest neighbors before using them in KNeighborsClassifier. KNeighborsClassifier can compute the nearest neighbors internally, but precomputing them can have several benefits, such as finer parameter control, caching for multiple use, or custom implementations.">  <div class="sphx-glr-thumbnail-title">Caching nearest neighbors</div>
</div>
* [Caching nearest neighbors](../../auto_examples/neighbors/plot_caching_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-plot-caching-nearest-neighbors-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example comparing nearest neighbors classification with and without Neighborhood Components Analysis.">  <div class="sphx-glr-thumbnail-title">Comparing Nearest Neighbors with and without Neighborhood Components Analysis</div>
</div>
* [Comparing Nearest Neighbors with and without Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_classification.md#sphx-glr-auto-examples-neighbors-plot-nca-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Sample usage of Neighborhood Components Analysis for dimensionality reduction.">  <div class="sphx-glr-thumbnail-title">Dimensionality Reduction with Neighborhood Components Analysis</div>
</div>
* [Dimensionality Reduction with Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_dim_reduction.md#sphx-glr-auto-examples-neighbors-plot-nca-dim-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use KNeighborsClassifier. We train such a classifier on the iris dataset and observe the difference of the decision boundary obtained with regards to the parameter weights.">  <div class="sphx-glr-thumbnail-title">Nearest Neighbors Classification</div>
</div>
* [Nearest Neighbors Classification](../../auto_examples/neighbors/plot_classification.md#sphx-glr-auto-examples-neighbors-plot-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature scaling through standardization, also called Z-score normalization, is an important preprocessing step for many machine learning algorithms. It involves rescaling each feature such that it has a standard deviation of 1 and a mean of 0.">  <div class="sphx-glr-thumbnail-title">Importance of Feature Scaling</div>
</div>
* [Importance of Feature Scaling](../../auto_examples/preprocessing/plot_scaling_importance.md#sphx-glr-auto-examples-preprocessing-plot-scaling-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
