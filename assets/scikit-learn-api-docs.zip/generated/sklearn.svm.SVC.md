# SVC

### *class* sklearn.svm.SVC(\*, C=1.0, kernel='rbf', degree=3, gamma='scale', coef0=0.0, shrinking=True, probability=False, tol=0.001, cache_size=200, class_weight=None, verbose=False, max_iter=-1, decision_function_shape='ovr', break_ties=False, random_state=None)

C-Support Vector Classification.

The implementation is based on libsvm. The fit time scales at least
quadratically with the number of samples and may be impractical
beyond tens of thousands of samples. For large datasets
consider using [`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC) or
[`SGDClassifier`](sklearn.linear_model.SGDClassifier.md#sklearn.linear_model.SGDClassifier) instead, possibly after a
[`Nystroem`](sklearn.kernel_approximation.Nystroem.md#sklearn.kernel_approximation.Nystroem) transformer or
other [Kernel Approximation](../kernel_approximation.md#kernel-approximation).

The multiclass support is handled according to a one-vs-one scheme.

For details on the precise mathematical formulation of the provided
kernel functions and how `gamma`, `coef0` and `degree` affect each
other, see the corresponding section in the narrative documentation:
[Kernel functions](../svm.md#svm-kernels).

To learn how to tune SVC’s hyperparameters, see the following example:
[Nested versus non-nested cross-validation](../../auto_examples/model_selection/plot_nested_cross_validation_iris.md#sphx-glr-auto-examples-model-selection-plot-nested-cross-validation-iris-py)

Read more in the [User Guide](../svm.md#svm-classification).

* **Parameters:**
  **C**
  : Regularization parameter. The strength of the regularization is
    inversely proportional to C. Must be strictly positive. The penalty
    is a squared l2 penalty. For an intuitive visualization of the effects
    of scaling the regularization parameter C, see
    [Scaling the regularization parameter for SVCs](../../auto_examples/svm/plot_svm_scale_c.md#sphx-glr-auto-examples-svm-plot-svm-scale-c-py).

  **kernel**
  : Specifies the kernel type to be used in the algorithm. If
    none is given, ‘rbf’ will be used. If a callable is given it is used to
    pre-compute the kernel matrix from data matrices; that matrix should be
    an array of shape `(n_samples, n_samples)`. For an intuitive
    visualization of different kernel types see
    [Plot classification boundaries with different SVM Kernels](../../auto_examples/svm/plot_svm_kernels.md#sphx-glr-auto-examples-svm-plot-svm-kernels-py).

  **degree**
  : Degree of the polynomial kernel function (‘poly’).
    Must be non-negative. Ignored by all other kernels.

  **gamma**
  : Kernel coefficient for ‘rbf’, ‘poly’ and ‘sigmoid’.
    - if `gamma='scale'` (default) is passed then it uses
      1 / (n_features \* X.var()) as value of gamma,
    - if ‘auto’, uses 1 / n_features
    - if float, must be non-negative.
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default value of `gamma` changed from ‘auto’ to ‘scale’.

  **coef0**
  : Independent term in kernel function.
    It is only significant in ‘poly’ and ‘sigmoid’.

  **shrinking**
  : Whether to use the shrinking heuristic.
    See the [User Guide](../svm.md#shrinking-svm).

  **probability**
  : Whether to enable probability estimates. This must be enabled prior
    to calling `fit`, will slow down that method as it internally uses
    5-fold cross-validation, and `predict_proba` may be inconsistent with
    `predict`. Read more in the [User Guide](../svm.md#scores-probabilities).

  **tol**
  : Tolerance for stopping criterion.

  **cache_size**
  : Specify the size of the kernel cache (in MB).

  **class_weight**
  : Set the parameter C of class i to class_weight[i]\*C for
    SVC. If not given, all classes are supposed to have
    weight one.
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`.

  **verbose**
  : Enable verbose output. Note that this setting takes advantage of a
    per-process runtime setting in libsvm that, if enabled, may not work
    properly in a multithreaded context.

  **max_iter**
  : Hard limit on iterations within solver, or -1 for no limit.

  **decision_function_shape**
  : Whether to return a one-vs-rest (‘ovr’) decision function of shape
    (n_samples, n_classes) as all other classifiers, or the original
    one-vs-one (‘ovo’) decision function of libsvm which has shape
    (n_samples, n_classes \* (n_classes - 1) / 2). However, note that
    internally, one-vs-one (‘ovo’) is always used as a multi-class strategy
    to train models; an ovr matrix is only constructed from the ovo matrix.
    The parameter is ignored for binary classification.
    <br/>
    #### Versionchanged
    Changed in version 0.19: decision_function_shape is ‘ovr’ by default.
    <br/>
    #### Versionadded
    Added in version 0.17: *decision_function_shape=’ovr’* is recommended.
    <br/>
    #### Versionchanged
    Changed in version 0.17: Deprecated *decision_function_shape=’ovo’ and None*.

  **break_ties**
  : If true, `decision_function_shape='ovr'`, and number of classes > 2,
    [predict](../../glossary.md#term-predict) will break ties according to the confidence values of
    [decision_function](../../glossary.md#term-decision_function); otherwise the first class among the tied
    classes is returned. Please note that breaking ties comes at a
    relatively high computational cost compared to a simple predict. See
    [SVM Tie Breaking Example](../../auto_examples/svm/plot_svm_tie_breaking.md#sphx-glr-auto-examples-svm-plot-svm-tie-breaking-py) for an
    example of its usage with `decision_function_shape='ovr'`.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **random_state**
  : Controls the pseudo random number generation for shuffling the data for
    probability estimates. Ignored when `probability` is False.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **class_weight_**
  : Multipliers of parameter C for each class.
    Computed based on the `class_weight` parameter.

  **classes_**
  : The classes labels.

  [`coef_`](#sklearn.svm.SVC.coef_)
  : Weights assigned to the features when `kernel="linear"`.

  **dual_coef_**
  : Dual coefficients of the support vector in the decision
    function (see [Mathematical formulation](../sgd.md#sgd-mathematical-formulation)), multiplied by
    their targets.
    For multiclass, coefficient for all 1-vs-1 classifiers.
    The layout of the coefficients in the multiclass case is somewhat
    non-trivial. See the [multi-class section of the User Guide](../svm.md#svm-multi-class) for details.

  **fit_status_**
  : 0 if correctly fitted, 1 otherwise (will raise warning)

  **intercept_**
  : Constants in decision function.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Number of iterations run by the optimization routine to fit the model.
    The shape of this attribute depends on the number of models optimized
    which in turn depends on the number of classes.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **support_**
  : Indices of support vectors.

  **support_vectors_**
  : Support vectors. An empty array if kernel is precomputed.

  [`n_support_`](#sklearn.svm.SVC.n_support_)
  : Number of support vectors for each class.

  [`probA_`](#sklearn.svm.SVC.probA_)
  : Parameter learned in Platt scaling when `probability=True`.

  [`probB_`](#sklearn.svm.SVC.probB_)
  : Parameter learned in Platt scaling when `probability=True`.

  **shape_fit_**
  : Array dimensions of training vector `X`.

#### SEE ALSO
[`SVR`](sklearn.svm.SVR.md#sklearn.svm.SVR)
: Support Vector Machine for Regression implemented using libsvm.

[`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC)
: Scalable Linear Support Vector Machine for classification implemented using liblinear. Check the See Also section of LinearSVC for more comparison element.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.pipeline import make_pipeline
>>> from sklearn.preprocessing import StandardScaler
>>> X = np.array([[-1, -1], [-2, -1], [1, 1], [2, 1]])
>>> y = np.array([1, 1, 2, 2])
>>> from sklearn.svm import SVC
>>> clf = make_pipeline(StandardScaler(), SVC(gamma='auto'))
>>> clf.fit(X, y)
Pipeline(steps=[('standardscaler', StandardScaler()),
                ('svc', SVC(gamma='auto'))])
```

```pycon
>>> print(clf.predict([[-0.8, -1]]))
[1]
```

For a comaprison of the SVC with other classifiers see:
[Plot classification probability](../../auto_examples/classification/plot_classification_probability.md#sphx-glr-auto-examples-classification-plot-classification-probability-py).

<!-- !! processed by numpydoc !! -->

#### *property* coef_

Weights assigned to the features when `kernel="linear"`.

* **Returns:**
  ndarray of shape (n_features, n_classes)

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Evaluate the decision function for the samples in X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X**
  : Returns the decision function of the sample for each class
    in the model.
    If decision_function_shape=’ovr’, the shape is (n_samples,
    n_classes).

### Notes

If decision_function_shape=’ovo’, the function values are proportional
to the distance of the samples X to the separating hyperplane. If the
exact distances are required, divide the function values by the norm of
the weight vector (`coef_`). See also [this question](https://stats.stackexchange.com/questions/14876/interpreting-distance-from-hyperplane-in-svm) for further details.
If decision_function_shape=’ovr’, the decision function is a monotonic
transformation of ovo decision function.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the SVM model according to the given training data.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples
    and `n_features` is the number of features.
    For kernel=”precomputed”, the expected shape of X is
    (n_samples, n_samples).

  **y**
  : Target values (class labels in classification, real numbers in
    regression).

  **sample_weight**
  : Per-sample weights. Rescale C per sample. Higher weights
    force the classifier to put more emphasis on these points.
* **Returns:**
  **self**
  : Fitted estimator.

### Notes

If X and y are not C-ordered and contiguous arrays of np.float64 and
X is not a scipy.sparse.csr_matrix, X and/or y may be copied.

If X is a dense array, then the other methods will not support sparse
matrices as input.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_support_

Number of support vectors for each class.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Perform classification on samples in X.

For an one-class model, +1 or -1 is returned.

* **Parameters:**
  **X**
  : For kernel=”precomputed”, the expected shape of X is
    (n_samples_test, n_samples_train).
* **Returns:**
  **y_pred**
  : Class labels for samples in X.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Compute log probabilities of possible outcomes for samples in X.

The model need to have probability information computed at training
time: fit with attribute `probability` set to True.

* **Parameters:**
  **X**
  : For kernel=”precomputed”, the expected shape of X is
    (n_samples_test, n_samples_train).
* **Returns:**
  **T**
  : Returns the log-probabilities of the sample for each class in
    the model. The columns correspond to the classes in sorted
    order, as they appear in the attribute [classes_](../../glossary.md#term-classes_).

### Notes

The probability model is created using cross validation, so
the results can be slightly different than those obtained by
predict. Also, it will produce meaningless results on very small
datasets.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Compute probabilities of possible outcomes for samples in X.

The model needs to have probability information computed at training
time: fit with attribute `probability` set to True.

* **Parameters:**
  **X**
  : For kernel=”precomputed”, the expected shape of X is
    (n_samples_test, n_samples_train).
* **Returns:**
  **T**
  : Returns the probability of the sample for each class in
    the model. The columns correspond to the classes in sorted
    order, as they appear in the attribute [classes_](../../glossary.md#term-classes_).

### Notes

The probability model is created using cross validation, so
the results can be slightly different than those obtained by
predict. Also, it will produce meaningless results on very small
datasets.

<!-- !! processed by numpydoc !! -->

#### *property* probA_

Parameter learned in Platt scaling when `probability=True`.

* **Returns:**
  ndarray of shape  (n_classes \* (n_classes - 1) / 2)

<!-- !! processed by numpydoc !! -->

#### *property* probB_

Parameter learned in Platt scaling when `probability=True`.

* **Returns:**
  ndarray of shape  (n_classes \* (n_classes - 1) / 2)

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SVC](#sklearn.svm.SVC)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SVC](#sklearn.svm.SVC)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is a preprocessed excerpt of the &quot;Labeled Faces in the Wild&quot;, aka LFW_: http://vis-www.cs.umass.edu/lfw/lfw-funneled.tgz (233MB)">  <div class="sphx-glr-thumbnail-title">Faces recognition example using eigenfaces and SVMs</div>
</div>
* [Faces recognition example using eigenfaces and SVMs](../../auto_examples/applications/plot_face_recognition.md#sphx-glr-auto-examples-applications-plot-face-recognition-py)

<div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the classification probability for different classifiers. We use a 3 class dataset, and we classify it with a Support Vector classifier, L1 and L2 penalized logistic regression (multinomial multiclass), a One-Vs-Rest version with logistic regression, and Gaussian process classification.">  <div class="sphx-glr-thumbnail-title">Plot classification probability</div>
</div>
* [Plot classification probability](../../auto_examples/classification/plot_classification_probability.md#sphx-glr-auto-examples-classification-plot-classification-probability-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how scikit-learn can be used to recognize images of hand-written digits, from 0-9.">  <div class="sphx-glr-thumbnail-title">Recognizing hand-written digits</div>
</div>
* [Recognizing hand-written digits](../../auto_examples/classification/plot_digits_classification.md#sphx-glr-auto-examples-classification-plot-digits-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="In many real-world examples, there are many ways to extract features from a dataset. Often it is beneficial to combine several methods to obtain good performance. This example shows how to use FeatureUnion to combine features obtained by PCA and univariate selection.">  <div class="sphx-glr-thumbnail-title">Concatenating multiple feature extraction methods</div>
</div>
* [Concatenating multiple feature extraction methods](../../auto_examples/compose/plot_feature_union.md#sphx-glr-auto-examples-compose-plot-feature-union-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision boundaries of a VotingClassifier for two features of the Iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision boundaries of a VotingClassifier</div>
</div>
* [Plot the decision boundaries of a VotingClassifier](../../auto_examples/ensemble/plot_voting_decision_regions.md#sphx-glr-auto-examples-ensemble-plot-voting-decision-regions-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of PolynomialCountSketch to efficiently generate polynomial kernel feature-space approximations. This is used to train linear classifiers that approximate the accuracy of kernelized ones.">  <div class="sphx-glr-thumbnail-title">Scalable learning with polynomial kernel approximation</div>
</div>
* [Scalable learning with polynomial kernel approximation](../../auto_examples/kernel_approximation/plot_scalable_poly_kernels.md#sphx-glr-auto-examples-kernel-approximation-plot-scalable-poly-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="The default configuration for displaying a pipeline in a Jupyter Notebook is &#x27;diagram&#x27; where set_config(display=&#x27;diagram&#x27;). To deactivate HTML representation, use set_config(display=&#x27;text&#x27;).">  <div class="sphx-glr-thumbnail-title">Displaying Pipelines</div>
</div>
* [Displaying Pipelines](../../auto_examples/miscellaneous/plot_pipeline_display.md#sphx-glr-auto-examples-miscellaneous-plot-pipeline-display-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example illustrating the approximation of the feature map of an RBF kernel.">  <div class="sphx-glr-thumbnail-title">Explicit feature map approximation for RBF kernels</div>
</div>
* [Explicit feature map approximation for RBF kernels](../../auto_examples/miscellaneous/plot_kernel_approximation.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-approximation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example simulates a multi-label document classification problem. The dataset is generated randomly based on the following process:">  <div class="sphx-glr-thumbnail-title">Multilabel classification</div>
</div>
* [Multilabel classification](../../auto_examples/miscellaneous/plot_multilabel.md#sphx-glr-auto-examples-miscellaneous-plot-multilabel-py)

<div class="sphx-glr-thumbcontainer" tooltip="ROC Curve with Visualization API">  <div class="sphx-glr-thumbnail-title">ROC Curve with Visualization API</div>
</div>
* [ROC Curve with Visualization API](../../auto_examples/miscellaneous/plot_roc_curve_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-roc-curve-visualization-api-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares the parameter search performed by HalvingGridSearchCV and GridSearchCV.">  <div class="sphx-glr-thumbnail-title">Comparison between grid search and successive halving</div>
</div>
* [Comparison between grid search and successive halving](../../auto_examples/model_selection/plot_successive_halving_heatmap.md#sphx-glr-auto-examples-model-selection-plot-successive-halving-heatmap-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of confusion matrix usage to evaluate the quality of the output of a classifier on the iris data set. The diagonal elements represent the number of points for which the predicted label is equal to the true label, while off-diagonal elements are those that are mislabeled by the classifier. The higher the diagonal values of the confusion matrix the better, indicating many correct predictions.">  <div class="sphx-glr-thumbnail-title">Confusion matrix</div>
</div>
* [Confusion matrix](../../auto_examples/model_selection/plot_confusion_matrix.md#sphx-glr-auto-examples-model-selection-plot-confusion-matrix-py)

<div class="sphx-glr-thumbcontainer" tooltip="This examples shows how a classifier is optimized by cross-validation, which is done using the GridSearchCV object on a development set that comprises only half of the available labeled data.">  <div class="sphx-glr-thumbnail-title">Custom refit strategy of a grid search with cross-validation</div>
</div>
* [Custom refit strategy of a grid search with cross-validation](../../auto_examples/model_selection/plot_grid_search_digits.md#sphx-glr-auto-examples-model-selection-plot-grid-search-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares non-nested and nested cross-validation strategies on a classifier of the iris data set. Nested cross-validation (CV) is often used to train a model in which hyperparameters also need to be optimized. Nested CV estimates the generalization error of the underlying model and its (hyper)parameter search. Choosing the parameters that maximize non-nested CV biases the model to the dataset, yielding an overly-optimistic score.">  <div class="sphx-glr-thumbnail-title">Nested versus non-nested cross-validation</div>
</div>
* [Nested versus non-nested cross-validation](../../auto_examples/model_selection/plot_nested_cross_validation_iris.md#sphx-glr-auto-examples-model-selection-plot-nested-cross-validation-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we show how to use the class LearningCurveDisplay to easily plot learning curves. In addition, we give an interpretation to the learning curves obtained for a naive Bayes and SVM classifiers.">  <div class="sphx-glr-thumbnail-title">Plotting Learning Curves and Checking Models' Scalability</div>
</div>
* [Plotting Learning Curves and Checking Models’ Scalability](../../auto_examples/model_selection/plot_learning_curve.md#sphx-glr-auto-examples-model-selection-plot-learning-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents how to estimate and visualize the variance of the Receiver Operating Characteristic (ROC) metric using cross-validation.">  <div class="sphx-glr-thumbnail-title">Receiver Operating Characteristic (ROC) with cross validation</div>
</div>
* [Receiver Operating Characteristic (ROC) with cross validation](../../auto_examples/model_selection/plot_roc_crossval.md#sphx-glr-auto-examples-model-selection-plot-roc-crossval-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to statistically compare the performance of models trained and evaluated using GridSearchCV.">  <div class="sphx-glr-thumbnail-title">Statistical comparison of models using grid search</div>
</div>
* [Statistical comparison of models using grid search](../../auto_examples/model_selection/plot_grid_search_stats.md#sphx-glr-auto-examples-model-selection-plot-grid-search-stats-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the use of permutation_test_score to evaluate the significance of a cross-validated score using permutations.">  <div class="sphx-glr-thumbnail-title">Test with permutations the significance of a classification score</div>
</div>
* [Test with permutations the significance of a classification score](../../auto_examples/model_selection/plot_permutation_tests_for_classification.md#sphx-glr-auto-examples-model-selection-plot-permutation-tests-for-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="A demonstration of feature discretization on synthetic classification datasets. Feature discretization decomposes each feature into a set of bins, here equally distributed in width. The discrete values are then one-hot encoded, and given to a linear classifier. This preprocessing enables a non-linear behavior even though the classifier is linear.">  <div class="sphx-glr-thumbnail-title">Feature discretization</div>
</div>
* [Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="A comparison for the decision boundaries generated on the iris dataset by Label Spreading, Self-training and SVM.">  <div class="sphx-glr-thumbnail-title">Decision boundary of semi-supervised classifiers versus SVM on the Iris dataset</div>
</div>
* [Decision boundary of semi-supervised classifiers versus SVM on the Iris dataset](../../auto_examples/semi_supervised/plot_semi_supervised_versus_svm_iris.md#sphx-glr-auto-examples-semi-supervised-plot-semi-supervised-versus-svm-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of a varying threshold on self-training. The breast_cancer dataset is loaded, and labels are deleted such that only 50 out of 569 samples have labels. A SelfTrainingClassifier is fitted on this dataset, with varying thresholds.">  <div class="sphx-glr-thumbnail-title">Effect of varying threshold for self-training</div>
</div>
* [Effect of varying threshold for self-training](../../auto_examples/semi_supervised/plot_self_training_varying_threshold.md#sphx-glr-auto-examples-semi-supervised-plot-self-training-varying-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="SVCs aim to find a hyperplane that effectively separates the classes in their training data by maximizing the margin between the outermost data points of each class. This is achieved by finding the best weight vector w that defines the decision boundary hyperplane and minimizes the sum of hinge losses for misclassified samples, as measured by the hinge_loss function. By default, regularization is applied with the parameter C=1, which allows for a certain degree of misclassification tolerance.">  <div class="sphx-glr-thumbnail-title">Plot classification boundaries with different SVM Kernels</div>
</div>
* [Plot classification boundaries with different SVM Kernels](../../auto_examples/svm/plot_svm_kernels.md#sphx-glr-auto-examples-svm-plot-svm-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparison of different linear SVM classifiers on a 2D projection of the iris dataset. We only consider the first 2 features of this dataset:">  <div class="sphx-glr-thumbnail-title">Plot different SVM classifiers in the iris dataset</div>
</div>
* [Plot different SVM classifiers in the iris dataset](../../auto_examples/svm/plot_iris_svc.md#sphx-glr-auto-examples-svm-plot-iris-svc-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of the parameters gamma and C of the Radial Basis Function (RBF) kernel SVM.">  <div class="sphx-glr-thumbnail-title">RBF SVM parameters</div>
</div>
* [RBF SVM parameters](../../auto_examples/svm/plot_rbf_parameters.md#sphx-glr-auto-examples-svm-plot-rbf-parameters-py)

<div class="sphx-glr-thumbcontainer" tooltip="A small value of C includes more/all the observations, allowing the margins to be calculated using all the data in the area.">  <div class="sphx-glr-thumbnail-title">SVM Margins Example</div>
</div>
* [SVM Margins Example](../../auto_examples/svm/plot_svm_margin.md#sphx-glr-auto-examples-svm-plot-svm-margin-py)

<div class="sphx-glr-thumbcontainer" tooltip="The two plots differ only in the area in the middle where the classes are tied. If break_ties=False, all input in that area would be classified as one class, whereas if break_ties=True, the tie-breaking mechanism will create a non-convex decision boundary in that area.">  <div class="sphx-glr-thumbnail-title">SVM Tie Breaking Example</div>
</div>
* [SVM Tie Breaking Example](../../auto_examples/svm/plot_svm_tie_breaking.md#sphx-glr-auto-examples-svm-plot-svm-tie-breaking-py)

<div class="sphx-glr-thumbcontainer" tooltip="Simple usage of Support Vector Machines to classify a sample. It will plot the decision surface and the support vectors.">  <div class="sphx-glr-thumbnail-title">SVM with custom kernel</div>
</div>
* [SVM with custom kernel](../../auto_examples/svm/plot_custom_kernel.md#sphx-glr-auto-examples-svm-plot-custom-kernel-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to perform univariate feature selection before running a SVC (support vector classifier) to improve the classification scores. We use the iris dataset (4 features) and add 36 non-informative features. We can find that our model achieves best performance when we select around 10% of features.">  <div class="sphx-glr-thumbnail-title">SVM-Anova: SVM with univariate feature selection</div>
</div>
* [SVM-Anova: SVM with univariate feature selection](../../auto_examples/svm/plot_svm_anova.md#sphx-glr-auto-examples-svm-plot-svm-anova-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the maximum margin separating hyperplane within a two-class separable dataset using a Support Vector Machine classifier with linear kernel.">  <div class="sphx-glr-thumbnail-title">SVM: Maximum margin separating hyperplane</div>
</div>
* [SVM: Maximum margin separating hyperplane](../../auto_examples/svm/plot_separating_hyperplane.md#sphx-glr-auto-examples-svm-plot-separating-hyperplane-py)

<div class="sphx-glr-thumbcontainer" tooltip="Find the optimal separating hyperplane using an SVC for classes that are unbalanced.">  <div class="sphx-glr-thumbnail-title">SVM: Separating hyperplane for unbalanced classes</div>
</div>
* [SVM: Separating hyperplane for unbalanced classes](../../auto_examples/svm/plot_separating_hyperplane_unbalanced.md#sphx-glr-auto-examples-svm-plot-separating-hyperplane-unbalanced-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot decision function of a weighted dataset, where the size of points is proportional to its weight.">  <div class="sphx-glr-thumbnail-title">SVM: Weighted samples</div>
</div>
* [SVM: Weighted samples](../../auto_examples/svm/plot_weighted_samples.md#sphx-glr-auto-examples-svm-plot-weighted-samples-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
