# make_checkerboard

### sklearn.datasets.make_checkerboard(shape, n_clusters, \*, noise=0.0, minval=10, maxval=100, shuffle=True, random_state=None)

Generate an array with block checkerboard structure for biclustering.

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **shape**
  : The shape of the result.

  **n_clusters**
  : The number of row and column clusters.

  **noise**
  : The standard deviation of the gaussian noise.

  **minval**
  : Minimum value of a bicluster.

  **maxval**
  : Maximum value of a bicluster.

  **shuffle**
  : Shuffle the samples.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : The generated array.

  **rows**
  : The indicators for cluster membership of each row.

  **cols**
  : The indicators for cluster membership of each column.

#### SEE ALSO
[`make_biclusters`](sklearn.datasets.make_biclusters.md#sklearn.datasets.make_biclusters)
: Generate an array with constant block diagonal structure for biclustering.

### References

### Examples

```pycon
>>> from sklearn.datasets import make_checkerboard
>>> data, rows, columns = make_checkerboard(shape=(300, 300), n_clusters=10,
...                                         random_state=42)
>>> data.shape
(300, 300)
>>> rows.shape
(100, 300)
>>> columns.shape
(100, 300)
>>> print(rows[0][:5], columns[0][:5])
[False False False  True False] [False False False False False]
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to generate a checkerboard dataset and bicluster it using the SpectralBiclustering algorithm. The spectral biclustering algorithm is specifically designed to cluster data by simultaneously considering both the rows (samples) and columns (features) of a matrix. It aims to identify patterns not only between samples but also within subsets of samples, allowing for the detection of localized structure within the data. This makes spectral biclustering particularly well-suited for datasets where the order or arrangement of features is fixed, such as in images, time series, or genomes.">  <div class="sphx-glr-thumbnail-title">A demo of the Spectral Biclustering algorithm</div>
</div>
* [A demo of the Spectral Biclustering algorithm](../../auto_examples/bicluster/plot_spectral_biclustering.md#sphx-glr-auto-examples-bicluster-plot-spectral-biclustering-py)

<!-- thumbnail-parent-div-close --></div>
