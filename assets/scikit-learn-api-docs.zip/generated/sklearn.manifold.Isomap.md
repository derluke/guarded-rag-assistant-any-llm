# Isomap

### *class* sklearn.manifold.Isomap(\*, n_neighbors=5, radius=None, n_components=2, eigen_solver='auto', tol=0, max_iter=None, path_method='auto', neighbors_algorithm='auto', n_jobs=None, metric='minkowski', p=2, metric_params=None)

Isomap Embedding.

Non-linear dimensionality reduction through Isometric Mapping

Read more in the [User Guide](../manifold.md#isomap).

* **Parameters:**
  **n_neighbors**
  : Number of neighbors to consider for each point. If `n_neighbors` is an int,
    then `radius` must be `None`.

  **radius**
  : Limiting distance of neighbors to return. If `radius` is a float,
    then `n_neighbors` must be set to `None`.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **n_components**
  : Number of coordinates for the manifold.

  **eigen_solver**
  : ‘auto’ : Attempt to choose the most efficient solver
    for the given problem.
    <br/>
    ‘arpack’ : Use Arnoldi decomposition to find the eigenvalues
    and eigenvectors.
    <br/>
    ‘dense’ : Use a direct solver (i.e. LAPACK)
    for the eigenvalue decomposition.

  **tol**
  : Convergence tolerance passed to arpack or lobpcg.
    not used if eigen_solver == ‘dense’.

  **max_iter**
  : Maximum number of iterations for the arpack solver.
    not used if eigen_solver == ‘dense’.

  **path_method**
  : Method to use in finding shortest path.
    <br/>
    ‘auto’ : attempt to choose the best algorithm automatically.
    <br/>
    ‘FW’ : Floyd-Warshall algorithm.
    <br/>
    ‘D’ : Dijkstra’s algorithm.

  **neighbors_algorithm**
  : Algorithm to use for nearest neighbors search,
    passed to neighbors.NearestNeighbors instance.

  **n_jobs**
  : The number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **metric**
  : The metric to use when calculating distance between instances in a
    feature array. If metric is a string or callable, it must be one of
    the options allowed by [`sklearn.metrics.pairwise_distances`](sklearn.metrics.pairwise_distances.md#sklearn.metrics.pairwise_distances) for
    its metric parameter.
    If metric is “precomputed”, X is assumed to be a distance matrix and
    must be square. X may be a [Glossary](../../glossary.md#term-sparse-graph).
    <br/>
    #### Versionadded
    Added in version 0.22.

  **p**
  : Parameter for the Minkowski metric from
    sklearn.metrics.pairwise.pairwise_distances. When p = 1, this is
    equivalent to using manhattan_distance (l1), and euclidean_distance
    (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **metric_params**
  : Additional keyword arguments for the metric function.
    <br/>
    #### Versionadded
    Added in version 0.22.
* **Attributes:**
  **embedding_**
  : Stores the embedding vectors.

  **kernel_pca_**
  : [`KernelPCA`](sklearn.decomposition.KernelPCA.md#sklearn.decomposition.KernelPCA) object used to implement the
    embedding.

  **nbrs_**
  : Stores nearest neighbors instance, including BallTree or KDtree
    if applicable.

  **dist_matrix_**
  : Stores the geodesic distance matrix of training data.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`sklearn.decomposition.PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA)
: Principal component analysis that is a linear dimensionality reduction method.

[`sklearn.decomposition.KernelPCA`](sklearn.decomposition.KernelPCA.md#sklearn.decomposition.KernelPCA)
: Non-linear dimensionality reduction using kernels and PCA.

[`MDS`](sklearn.manifold.MDS.md#sklearn.manifold.MDS)
: Manifold learning using multidimensional scaling.

[`TSNE`](sklearn.manifold.TSNE.md#sklearn.manifold.TSNE)
: T-distributed Stochastic Neighbor Embedding.

[`LocallyLinearEmbedding`](sklearn.manifold.LocallyLinearEmbedding.md#sklearn.manifold.LocallyLinearEmbedding)
: Manifold learning using Locally Linear Embedding.

[`SpectralEmbedding`](sklearn.manifold.SpectralEmbedding.md#sklearn.manifold.SpectralEmbedding)
: Spectral embedding for non-linear dimensionality.

### References

### Examples

```pycon
>>> from sklearn.datasets import load_digits
>>> from sklearn.manifold import Isomap
>>> X, _ = load_digits(return_X_y=True)
>>> X.shape
(1797, 64)
>>> embedding = Isomap(n_components=2)
>>> X_transformed = embedding.fit_transform(X[:100])
>>> X_transformed.shape
(100, 2)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Compute the embedding vectors for data X.

* **Parameters:**
  **X**
  : Sample data, shape = (n_samples, n_features), in the form of a
    numpy array, sparse matrix, precomputed tree, or NearestNeighbors
    object.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns a fitted instance of self.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Fit the model from data in X and transform X.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **X_new**
  : X transformed in the new space.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### reconstruction_error()

Compute the reconstruction error for the embedding.

* **Returns:**
  **reconstruction_error**
  : Reconstruction error.

### Notes

The cost function of an isomap embedding is

`E = frobenius_norm[K(D) - K(D_fit)] / n_samples`

Where D is the matrix of distances for the input data X,
D_fit is the matrix of distances for the output embedding X_fit,
and K is the isomap kernel:

`K(D) = -0.5 * (I - 1/n_samples) * D^2 * (I - 1/n_samples)`

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform X.

This is implemented by linking the points X into the graph of geodesic
distances of the training data. First the `n_neighbors` nearest
neighbors of X are found in the training data, and from these the
shortest geodesic distances from each point in X to each point in
the training data are computed in order to construct the kernel.
The embedding of X is the projection of this kernel onto the
embedding vectors of the training set.

* **Parameters:**
  **X**
  : If neighbors_algorithm=’precomputed’, X is assumed to be a
    distance matrix or a sparse graph of shape
    (n_queries, n_samples_fit).
* **Returns:**
  **X_new**
  : X transformed in the new space.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An illustration of dimensionality reduction on the S-curve dataset with various manifold learning methods.">  <div class="sphx-glr-thumbnail-title">Comparison of Manifold Learning methods</div>
</div>
* [Comparison of Manifold Learning methods](../../auto_examples/manifold/plot_compare_methods.md#sphx-glr-auto-examples-manifold-plot-compare-methods-py)

<div class="sphx-glr-thumbcontainer" tooltip="An application of the different manifold techniques on a spherical data-set. Here one can see the use of dimensionality reduction in order to gain some intuition regarding the manifold learning methods. Regarding the dataset, the poles are cut from the sphere, as well as a thin slice down its side. This enables the manifold learning techniques to &#x27;spread it open&#x27; whilst projecting it onto two dimensions.">  <div class="sphx-glr-thumbnail-title">Manifold Learning methods on a severed sphere</div>
</div>
* [Manifold Learning methods on a severed sphere](../../auto_examples/manifold/plot_manifold_sphere.md#sphx-glr-auto-examples-manifold-plot-manifold-sphere-py)

<div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
