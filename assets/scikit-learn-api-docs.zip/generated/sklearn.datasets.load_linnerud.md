# load_linnerud

### sklearn.datasets.load_linnerud(\*, return_X_y=False, as_frame=False)

Load and return the physical exercise Linnerud dataset.

This dataset is suitable for multi-output regression tasks.

| Samples total   | 20                           |
|-----------------|------------------------------|
| Dimensionality  | 3 (for both data and target) |
| Features        | integer                      |
| Targets         | integer                      |

Read more in the [User Guide](../../datasets/toy_dataset.md#linnerrud-dataset).

* **Parameters:**
  **return_X_y**
  : If True, returns `(data, target)` instead of a Bunch object.
    See below for more information about the `data` and `target` object.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **as_frame**
  : If True, the data is a pandas DataFrame including columns with
    appropriate dtypes (numeric, string or categorical). The target is
    a pandas DataFrame or Series depending on the number of target columns.
    If `return_X_y` is True, then (`data`, `target`) will be pandas
    DataFrames or Series as described below.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : The data matrix. If `as_frame=True`, `data` will be a pandas
      DataFrame.
    <br/>
    target: {ndarray, dataframe} of shape (20, 3)
    : The regression targets. If `as_frame=True`, `target` will be
      a pandas DataFrame.
    <br/>
    feature_names: list
    : The names of the dataset columns.
    <br/>
    target_names: list
    : The names of the target columns.
    <br/>
    frame: DataFrame of shape (20, 6)
    : Only present when `as_frame=True`. DataFrame with `data` and
      `target`.
      <br/>
      #### Versionadded
      Added in version 0.23.
    <br/>
    DESCR: str
    : The full description of the dataset.
    <br/>
    data_filename: str
    : The path to the location of the data.
    <br/>
    target_filename: str
    : The path to the location of the target.
      <br/>
      #### Versionadded
      Added in version 0.20.

  **(data, target)**
  : Returns a tuple of two ndarrays or dataframe of shape
    `(20, 3)`. Each row represents one sample and each column represents the
    features in `X` and a target in `y` of a given sample.
    <br/>
    #### Versionadded
    Added in version 0.18.

### Examples

```pycon
>>> from sklearn.datasets import load_linnerud
>>> linnerud = load_linnerud()
>>> linnerud.data.shape
(20, 3)
>>> linnerud.target.shape
(20, 3)
```

<!-- !! processed by numpydoc !! -->
