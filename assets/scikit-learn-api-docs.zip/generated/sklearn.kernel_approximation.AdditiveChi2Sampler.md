# AdditiveChi2Sampler

### *class* sklearn.kernel_approximation.AdditiveChi2Sampler(\*, sample_steps=2, sample_interval=None)

Approximate feature map for additive chi2 kernel.

Uses sampling the fourier transform of the kernel characteristic
at regular intervals.

Since the kernel that is to be approximated is additive, the components of
the input vectors can be treated separately.  Each entry in the original
space is transformed into 2\*sample_steps-1 features, where sample_steps is
a parameter of the method. Typical values of sample_steps include 1, 2 and
3.

Optimal choices for the sampling interval for certain data ranges can be
computed (see the reference). The default values should be reasonable.

Read more in the [User Guide](../kernel_approximation.md#additive-chi-kernel-approx).

* **Parameters:**
  **sample_steps**
  : Gives the number of (complex) sampling points.

  **sample_interval**
  : Sampling interval. Must be specified when sample_steps not in {1,2,3}.
* **Attributes:**
  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`SkewedChi2Sampler`](sklearn.kernel_approximation.SkewedChi2Sampler.md#sklearn.kernel_approximation.SkewedChi2Sampler)
: A Fourier-approximation to a non-additive variant of the chi squared kernel.

[`sklearn.metrics.pairwise.chi2_kernel`](sklearn.metrics.pairwise.chi2_kernel.md#sklearn.metrics.pairwise.chi2_kernel)
: The exact chi squared kernel.

[`sklearn.metrics.pairwise.additive_chi2_kernel`](sklearn.metrics.pairwise.additive_chi2_kernel.md#sklearn.metrics.pairwise.additive_chi2_kernel)
: The exact additive chi squared kernel.

### Notes

This estimator approximates a slightly different version of the additive
chi squared kernel then `metric.additive_chi2` computes.

This estimator is stateless and does not need to be fitted. However, we
recommend to call [`fit_transform`](#sklearn.kernel_approximation.AdditiveChi2Sampler.fit_transform) instead of [`transform`](#sklearn.kernel_approximation.AdditiveChi2Sampler.transform), as
parameter validation is only performed in [`fit`](#sklearn.kernel_approximation.AdditiveChi2Sampler.fit).

### References

See [“Efficient additive kernels via explicit feature maps”](http://www.robots.ox.ac.uk/~vedaldi/assets/pubs/vedaldi11efficient.pdf)
A. Vedaldi and A. Zisserman, Pattern Analysis and Machine Intelligence,
2011

### Examples

```pycon
>>> from sklearn.datasets import load_digits
>>> from sklearn.linear_model import SGDClassifier
>>> from sklearn.kernel_approximation import AdditiveChi2Sampler
>>> X, y = load_digits(return_X_y=True)
>>> chi2sampler = AdditiveChi2Sampler(sample_steps=2)
>>> X_transformed = chi2sampler.fit_transform(X, y)
>>> clf = SGDClassifier(max_iter=5, random_state=0, tol=1e-3)
>>> clf.fit(X_transformed, y)
SGDClassifier(max_iter=5, random_state=0)
>>> clf.score(X_transformed, y)
0.9499...
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Only validates estimator’s parameters.

This method allows to: (i) validate the estimator’s parameters and
(ii) be consistent with the scikit-learn transformer API.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Target values (None for unsupervised transformations).
* **Returns:**
  **self**
  : Returns the transformer.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in [`fit`](#sklearn.kernel_approximation.AdditiveChi2Sampler.fit).
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Apply approximate feature map to X.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.
* **Returns:**
  **X_new**
  : Whether the return value is an array or sparse matrix depends on
    the type of the input X.

<!-- !! processed by numpydoc !! -->
