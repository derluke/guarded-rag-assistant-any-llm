# FastICA

### *class* sklearn.decomposition.FastICA(n_components=None, \*, algorithm='parallel', whiten='unit-variance', fun='logcosh', fun_args=None, max_iter=200, tol=0.0001, w_init=None, whiten_solver='svd', random_state=None)

FastICA: a fast algorithm for Independent Component Analysis.

The implementation is based on [[1]](#r44c805292efc-1).

Read more in the [User Guide](../decomposition.md#ica).

* **Parameters:**
  **n_components**
  : Number of components to use. If None is passed, all are used.

  **algorithm**
  : Specify which algorithm to use for FastICA.

  **whiten**
  : Specify the whitening strategy to use.
    - If ‘arbitrary-variance’, a whitening with variance
      arbitrary is used.
    - If ‘unit-variance’, the whitening matrix is rescaled to ensure that
      each recovered source has unit variance.
    - If False, the data is already considered to be whitened, and no
      whitening is performed.
    <br/>
    #### Versionchanged
    Changed in version 1.3: The default value of `whiten` changed to ‘unit-variance’ in 1.3.

  **fun**
  : The functional form of the G function used in the
    approximation to neg-entropy. Could be either ‘logcosh’, ‘exp’,
    or ‘cube’.
    You can also provide your own function. It should return a tuple
    containing the value of the function, and of its derivative, in the
    point. The derivative should be averaged along its last dimension.
    Example:
    ```default
    def my_g(x):
        return x ** 3, (3 * x ** 2).mean(axis=-1)
    ```

  **fun_args**
  : Arguments to send to the functional form.
    If empty or None and if fun=’logcosh’, fun_args will take value
    {‘alpha’ : 1.0}.

  **max_iter**
  : Maximum number of iterations during fit.

  **tol**
  : A positive scalar giving the tolerance at which the
    un-mixing matrix is considered to have converged.

  **w_init**
  : Initial un-mixing array. If `w_init=None`, then an array of values
    drawn from a normal distribution is used.

  **whiten_solver**
  : The solver to use for whitening.
    - “svd” is more stable numerically if the problem is degenerate, and
      often faster when `n_samples <= n_features`.
    - “eigh” is generally more memory efficient when
      `n_samples >= n_features`, and can be faster when
      `n_samples >= 50 * n_features`.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **random_state**
  : Used to initialize `w_init` when not specified, with a
    normal distribution. Pass an int, for reproducible results
    across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **components_**
  : The linear operator to apply to the data to get the independent
    sources. This is equal to the unmixing matrix when `whiten` is
    False, and equal to `np.dot(unmixing_matrix, self.whitening_)` when
    `whiten` is True.

  **mixing_**
  : The pseudo-inverse of `components_`. It is the linear operator
    that maps independent sources to the data.

  **mean_**
  : The mean over features. Only set if `self.whiten` is True.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : If the algorithm is “deflation”, n_iter is the
    maximum number of iterations run across all components. Else
    they are just the number of iterations taken to converge.

  **whitening_**
  : Only set if whiten is ‘True’. This is the pre-whitening matrix
    that projects data onto the first `n_components` principal components.

#### SEE ALSO
[`PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA)
: Principal component analysis (PCA).

[`IncrementalPCA`](sklearn.decomposition.IncrementalPCA.md#sklearn.decomposition.IncrementalPCA)
: Incremental principal components analysis (IPCA).

[`KernelPCA`](sklearn.decomposition.KernelPCA.md#sklearn.decomposition.KernelPCA)
: Kernel Principal component analysis (KPCA).

[`MiniBatchSparsePCA`](sklearn.decomposition.MiniBatchSparsePCA.md#sklearn.decomposition.MiniBatchSparsePCA)
: Mini-batch Sparse Principal Components Analysis.

[`SparsePCA`](sklearn.decomposition.SparsePCA.md#sklearn.decomposition.SparsePCA)
: Sparse Principal Components Analysis (SparsePCA).

### References

### Examples

```pycon
>>> from sklearn.datasets import load_digits
>>> from sklearn.decomposition import FastICA
>>> X, _ = load_digits(return_X_y=True)
>>> transformer = FastICA(n_components=7,
...         random_state=0,
...         whiten='unit-variance')
>>> X_transformed = transformer.fit_transform(X)
>>> X_transformed.shape
(1797, 7)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the model to X.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Fit the model and recover the sources from X.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **X_new**
  : Estimated sources obtained by transforming the data with the
    estimated unmixing matrix.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X, copy=True)

Transform the sources back to the mixed data (apply mixing matrix).

* **Parameters:**
  **X**
  : Sources, where `n_samples` is the number of samples
    and `n_components` is the number of components.

  **copy**
  : If False, data passed to fit are overwritten. Defaults to True.
* **Returns:**
  **X_new**
  : Reconstructed data obtained with the mixing matrix.

<!-- !! processed by numpydoc !! -->

#### set_inverse_transform_request(\*, copy: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [FastICA](#sklearn.decomposition.FastICA)

Request metadata passed to the `inverse_transform` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `inverse_transform` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `inverse_transform`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **copy**
  : Metadata routing for `copy` parameter in `inverse_transform`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_transform_request(\*, copy: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [FastICA](#sklearn.decomposition.FastICA)

Request metadata passed to the `transform` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `transform` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `transform`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **copy**
  : Metadata routing for `copy` parameter in `transform`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### transform(X, copy=True)

Recover the sources from X (apply the unmixing matrix).

* **Parameters:**
  **X**
  : Data to transform, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **copy**
  : If False, data passed to fit can be overwritten. Defaults to True.
* **Returns:**
  **X_new**
  : Estimated sources obtained by transforming the data with the
    estimated unmixing matrix.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An example of estimating sources from noisy data.">  <div class="sphx-glr-thumbnail-title">Blind source separation using FastICA</div>
</div>
* [Blind source separation using FastICA](../../auto_examples/decomposition/plot_ica_blind_source_separation.md#sphx-glr-auto-examples-decomposition-plot-ica-blind-source-separation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example applies to olivetti_faces_dataset different unsupervised matrix decomposition (dimension reduction) methods from the module sklearn.decomposition (see the documentation chapter decompositions).">  <div class="sphx-glr-thumbnail-title">Faces dataset decompositions</div>
</div>
* [Faces dataset decompositions](../../auto_examples/decomposition/plot_faces_decomposition.md#sphx-glr-auto-examples-decomposition-plot-faces-decomposition-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates visually in the feature space a comparison by results using two different component analysis techniques.">  <div class="sphx-glr-thumbnail-title">FastICA on 2D point clouds</div>
</div>
* [FastICA on 2D point clouds](../../auto_examples/decomposition/plot_ica_vs_pca.md#sphx-glr-auto-examples-decomposition-plot-ica-vs-pca-py)

<!-- thumbnail-parent-div-close --></div>
