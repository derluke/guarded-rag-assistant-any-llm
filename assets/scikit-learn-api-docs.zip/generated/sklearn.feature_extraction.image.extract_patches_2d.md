# extract_patches_2d

### sklearn.feature_extraction.image.extract_patches_2d(image, patch_size, \*, max_patches=None, random_state=None)

Reshape a 2D image into a collection of patches.

The resulting patches are allocated in a dedicated array.

Read more in the [User Guide](../feature_extraction.md#image-feature-extraction).

* **Parameters:**
  **image**
  : The original image data. For color images, the last dimension specifies
    the channel: a RGB image would have `n_channels=3`.

  **patch_size**
  : The dimensions of one patch.

  **max_patches**
  : The maximum number of patches to extract. If `max_patches` is a float
    between 0 and 1, it is taken to be a proportion of the total number
    of patches. If `max_patches` is None it corresponds to the total number
    of patches that can be extracted.

  **random_state**
  : Determines the random number generator used for random sampling when
    `max_patches` is not None. Use an int to make the randomness
    deterministic.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **patches**
  : The collection of patches extracted from the image, where `n_patches`
    is either `max_patches` or the total number of patches that can be
    extracted.

### Examples

```pycon
>>> from sklearn.datasets import load_sample_image
>>> from sklearn.feature_extraction import image
>>> # Use the array data from the first image in this dataset:
>>> one_image = load_sample_image("china.jpg")
>>> print('Image shape: {}'.format(one_image.shape))
Image shape: (427, 640, 3)
>>> patches = image.extract_patches_2d(one_image, (2, 2))
>>> print('Patches shape: {}'.format(patches.shape))
Patches shape: (272214, 2, 2, 3)
>>> # Here are just two of these patches:
>>> print(patches[1])
[[[174 201 231]
  [174 201 231]]
 [[173 200 230]
  [173 200 230]]]
>>> print(patches[800])
[[[187 214 243]
  [188 215 244]]
 [[187 214 243]
  [188 215 244]]]
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example uses a large dataset of faces to learn a set of 20 x 20 images patches that constitute faces.">  <div class="sphx-glr-thumbnail-title">Online learning of a dictionary of parts of faces</div>
</div>
* [Online learning of a dictionary of parts of faces](../../auto_examples/cluster/plot_dict_face_patches.md#sphx-glr-auto-examples-cluster-plot-dict-face-patches-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example comparing the effect of reconstructing noisy fragments of a raccoon face image using firstly online DictionaryLearning and various transform methods.">  <div class="sphx-glr-thumbnail-title">Image denoising using dictionary learning</div>
</div>
* [Image denoising using dictionary learning](../../auto_examples/decomposition/plot_image_denoising.md#sphx-glr-auto-examples-decomposition-plot-image-denoising-py)

<!-- thumbnail-parent-div-close --></div>
