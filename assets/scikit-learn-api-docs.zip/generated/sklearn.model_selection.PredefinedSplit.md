# PredefinedSplit

### *class* sklearn.model_selection.PredefinedSplit(test_fold)

Predefined split cross-validator.

Provides train/test indices to split data into train/test sets using a
predefined scheme specified by the user with the `test_fold` parameter.

Read more in the [User Guide](../cross_validation.md#predefined-split).

#### Versionadded
Added in version 0.16.

* **Parameters:**
  **test_fold**
  : The entry `test_fold[i]` represents the index of the test set that
    sample `i` belongs to. It is possible to exclude sample `i` from
    any test set (i.e. include sample `i` in every training set) by
    setting `test_fold[i]` equal to -1.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import PredefinedSplit
>>> X = np.array([[1, 2], [3, 4], [1, 2], [3, 4]])
>>> y = np.array([0, 0, 1, 1])
>>> test_fold = [0, 1, -1, 1]
>>> ps = PredefinedSplit(test_fold)
>>> ps.get_n_splits()
2
>>> print(ps)
PredefinedSplit(test_fold=array([ 0,  1, -1,  1]))
>>> for i, (train_index, test_index) in enumerate(ps.split()):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}")
...     print(f"  Test:  index={test_index}")
Fold 0:
  Train: index=[1 2 3]
  Test:  index=[0]
Fold 1:
  Train: index=[0 2]
  Test:  index=[1 3]
```

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X=None, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Always ignored, exists for compatibility.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### split(X=None, y=None, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Always ignored, exists for compatibility.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

<!-- !! processed by numpydoc !! -->
