# mean_squared_error

### sklearn.metrics.mean_squared_error(y_true, y_pred, \*, sample_weight=None, multioutput='uniform_average')

Mean squared error regression loss.

Read more in the [User Guide](../model_evaluation.md#mean-squared-error).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated target values.

  **sample_weight**
  : Sample weights.

  **multioutput**
  : Defines aggregating of multiple output values.
    Array-like value defines weights used to average errors.
    <br/>
    ‘raw_values’ :
    : Returns a full set of errors in case of multioutput input.
    <br/>
    ‘uniform_average’ :
    : Errors of all outputs are averaged with uniform weight.
* **Returns:**
  **loss**
  : A non-negative floating point value (the best value is 0.0), or an
    array of floating point values, one for each individual target.

### Examples

```pycon
>>> from sklearn.metrics import mean_squared_error
>>> y_true = [3, -0.5, 2, 7]
>>> y_pred = [2.5, 0.0, 2, 8]
>>> mean_squared_error(y_true, y_pred)
0.375
>>> y_true = [[0.5, 1],[-1, 1],[7, -6]]
>>> y_pred = [[0, 2],[-1, 2],[8, -5]]
>>> mean_squared_error(y_true, y_pred)
0.708...
>>> mean_squared_error(y_true, y_pred, multioutput='raw_values')
array([0.41666667, 1.        ])
>>> mean_squared_error(y_true, y_pred, multioutput=[0.3, 0.7])
0.825...
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Demonstrate how model complexity influences both prediction accuracy and computational performance.">  <div class="sphx-glr-thumbnail-title">Model Complexity Influence</div>
</div>
* [Model Complexity Influence](../../auto_examples/applications/plot_model_complexity_influence.md#sphx-glr-auto-examples-applications-plot-model-complexity-influence-py)

<div class="sphx-glr-thumbcontainer" tooltip="Gradient Boosting is an ensemble technique that combines multiple weak learners, typically decision trees, to create a robust and powerful predictive model. It does so in an iterative fashion, where each new stage (tree) corrects the errors of the previous ones.">  <div class="sphx-glr-thumbnail-title">Early stopping in Gradient Boosting</div>
</div>
* [Early stopping in Gradient Boosting](../../auto_examples/ensemble/plot_gradient_boosting_early_stopping.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-early-stopping-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates Gradient Boosting to produce a predictive model from an ensemble of weak predictive models. Gradient boosting can be used for regression and classification problems. Here, we will train a model to tackle a diabetes regression task. We will obtain the results from GradientBoostingRegressor with least squares loss and 500 regression trees of depth 4.">  <div class="sphx-glr-thumbnail-title">Gradient Boosting regression</div>
</div>
* [Gradient Boosting regression](../../auto_examples/ensemble/plot_gradient_boosting_regression.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how quantile regression can be used to create prediction intervals. See sphx_glr_auto_examples_ensemble_plot_hgbt_regression.py for an example showcasing some other features of HistGradientBoostingRegressor.">  <div class="sphx-glr-thumbnail-title">Prediction Intervals for Gradient Boosting Regression</div>
</div>
* [Prediction Intervals for Gradient Boosting Regression](../../auto_examples/ensemble/plot_gradient_boosting_quantile.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-quantile-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use the ordinary least squares (OLS) model called LinearRegression in scikit-learn.">  <div class="sphx-glr-thumbnail-title">Ordinary Least Squares Example</div>
</div>
* [Ordinary Least Squares Example](../../auto_examples/linear_model/plot_ols.md#sphx-glr-auto-examples-linear-model-plot-ols-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how quantile regression can predict non-trivial conditional quantiles.">  <div class="sphx-glr-thumbnail-title">Quantile regression</div>
</div>
* [Quantile regression](../../auto_examples/linear_model/plot_quantile_regression.md#sphx-glr-auto-examples-linear-model-plot-quantile-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="A model that overfits learns the training data too well, capturing both the underlying patterns and the noise in the data. However, when applied to unseen data, the learned associations may not hold. We normally detect this when we apply our trained predictions to the test data and see the statistical performance drop significantly compared to the training data.">  <div class="sphx-glr-thumbnail-title">Ridge coefficients as a function of the L2 Regularization</div>
</div>
* [Ridge coefficients as a function of the L2 Regularization](../../auto_examples/linear_model/plot_ridge_coeffs.md#sphx-glr-auto-examples-linear-model-plot-ridge-coeffs-py)

<div class="sphx-glr-thumbcontainer" tooltip="Here a sine function is fit with a polynomial of order 3, for values close to zero.">  <div class="sphx-glr-thumbnail-title">Robust linear estimator fitting</div>
</div>
* [Robust linear estimator fitting](../../auto_examples/linear_model/plot_robust_fit.md#sphx-glr-auto-examples-linear-model-plot-robust-fit-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Poisson, Gamma and Tweedie regression on the French Motor Third-Party Liability Claims dataset, and is inspired by an R tutorial [1]_.">  <div class="sphx-glr-thumbnail-title">Tweedie regression on insurance claims</div>
</div>
* [Tweedie regression on insurance claims](../../auto_examples/linear_model/plot_tweedie_regression_insurance_claims.md#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py)

<!-- thumbnail-parent-div-close --></div>
