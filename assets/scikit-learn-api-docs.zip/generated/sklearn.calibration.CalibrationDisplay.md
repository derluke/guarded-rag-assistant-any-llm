# CalibrationDisplay

### *class* sklearn.calibration.CalibrationDisplay(prob_true, prob_pred, y_prob, \*, estimator_name=None, pos_label=None)

Calibration curve (also known as reliability diagram) visualization.

It is recommended to use
[`from_estimator`](#sklearn.calibration.CalibrationDisplay.from_estimator) or
[`from_predictions`](#sklearn.calibration.CalibrationDisplay.from_predictions)
to create a `CalibrationDisplay`. All parameters are stored as attributes.

Read more about calibration in the [User Guide](../calibration.md#calibration) and
more about the scikit-learn visualization API in [Visualizations](../../visualizations.md#visualizations).

For an example on how to use the visualization, see
[Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **prob_true**
  : The proportion of samples whose class is the positive class (fraction
    of positives), in each bin.

  **prob_pred**
  : The mean predicted probability in each bin.

  **y_prob**
  : Probability estimates for the positive class, for each sample.

  **estimator_name**
  : Name of estimator. If None, the estimator name is not shown.

  **pos_label**
  : The positive class when computing the calibration curve.
    By default, `pos_label` is set to `estimators.classes_[1]` when using
    `from_estimator` and set to 1 when using `from_predictions`.
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Attributes:**
  **line_**
  : Calibration curve.

  **ax_**
  : Axes with calibration curve.

  **figure_**
  : Figure containing the curve.

#### SEE ALSO
[`calibration_curve`](sklearn.calibration.calibration_curve.md#sklearn.calibration.calibration_curve)
: Compute true and predicted probabilities for a calibration curve.

[`CalibrationDisplay.from_predictions`](#sklearn.calibration.CalibrationDisplay.from_predictions)
: Plot calibration curve using true and predicted labels.

[`CalibrationDisplay.from_estimator`](#sklearn.calibration.CalibrationDisplay.from_estimator)
: Plot calibration curve using an estimator and data.

### Examples

```pycon
>>> from sklearn.datasets import make_classification
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.calibration import calibration_curve, CalibrationDisplay
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, random_state=0)
>>> clf = LogisticRegression(random_state=0)
>>> clf.fit(X_train, y_train)
LogisticRegression(random_state=0)
>>> y_prob = clf.predict_proba(X_test)[:, 1]
>>> prob_true, prob_pred = calibration_curve(y_test, y_prob, n_bins=10)
>>> disp = CalibrationDisplay(prob_true, prob_pred, y_prob)
>>> disp.plot()
<...>
```

<!-- !! processed by numpydoc !! -->

#### *classmethod* from_estimator(estimator, X, y, \*, n_bins=5, strategy='uniform', pos_label=None, name=None, ref_line=True, ax=None, \*\*kwargs)

Plot calibration curve using a binary classifier and data.

A calibration curve, also known as a reliability diagram, uses inputs
from a binary classifier and plots the average predicted probability
for each bin against the fraction of positive classes, on the
y-axis.

Extra keyword arguments will be passed to
[`matplotlib.pyplot.plot`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.plot.html#matplotlib.pyplot.plot).

Read more about calibration in the [User Guide](../calibration.md#calibration) and
more about the scikit-learn visualization API in [Visualizations](../../visualizations.md#visualizations).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **estimator**
  : Fitted classifier or a fitted [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)
    in which the last estimator is a classifier. The classifier must
    have a [predict_proba](../../glossary.md#term-predict_proba) method.

  **X**
  : Input values.

  **y**
  : Binary target values.

  **n_bins**
  : Number of bins to discretize the [0, 1] interval into when
    calculating the calibration curve. A bigger number requires more
    data.

  **strategy**
  : Strategy used to define the widths of the bins.
    - `'uniform'`: The bins have identical widths.
    - `'quantile'`: The bins have the same number of samples and depend
      on predicted probabilities.

  **pos_label**
  : The positive class when computing the calibration curve.
    By default, `estimators.classes_[1]` is considered as the
    positive class.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **name**
  : Name for labeling curve. If `None`, the name of the estimator is
    used.

  **ref_line**
  : If `True`, plots a reference line representing a perfectly
    calibrated classifier.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **\*\*kwargs**
  : Keyword arguments to be passed to [`matplotlib.pyplot.plot`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.plot.html#matplotlib.pyplot.plot).
* **Returns:**
  **display**
  : Object that stores computed values.

#### SEE ALSO
[`CalibrationDisplay.from_predictions`](#sklearn.calibration.CalibrationDisplay.from_predictions)
: Plot calibration curve using true and predicted labels.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.calibration import CalibrationDisplay
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, random_state=0)
>>> clf = LogisticRegression(random_state=0)
>>> clf.fit(X_train, y_train)
LogisticRegression(random_state=0)
>>> disp = CalibrationDisplay.from_estimator(clf, X_test, y_test)
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-calibration-CalibrationDisplay-1.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_predictions(y_true, y_prob, \*, n_bins=5, strategy='uniform', pos_label=None, name=None, ref_line=True, ax=None, \*\*kwargs)

Plot calibration curve using true labels and predicted probabilities.

Calibration curve, also known as reliability diagram, uses inputs
from a binary classifier and plots the average predicted probability
for each bin against the fraction of positive classes, on the
y-axis.

Extra keyword arguments will be passed to
[`matplotlib.pyplot.plot`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.plot.html#matplotlib.pyplot.plot).

Read more about calibration in the [User Guide](../calibration.md#calibration) and
more about the scikit-learn visualization API in [Visualizations](../../visualizations.md#visualizations).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **y_true**
  : True labels.

  **y_prob**
  : The predicted probabilities of the positive class.

  **n_bins**
  : Number of bins to discretize the [0, 1] interval into when
    calculating the calibration curve. A bigger number requires more
    data.

  **strategy**
  : Strategy used to define the widths of the bins.
    - `'uniform'`: The bins have identical widths.
    - `'quantile'`: The bins have the same number of samples and depend
      on predicted probabilities.

  **pos_label**
  : The positive class when computing the calibration curve.
    By default `pos_label` is set to 1.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **name**
  : Name for labeling curve.

  **ref_line**
  : If `True`, plots a reference line representing a perfectly
    calibrated classifier.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **\*\*kwargs**
  : Keyword arguments to be passed to [`matplotlib.pyplot.plot`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.plot.html#matplotlib.pyplot.plot).
* **Returns:**
  **display**
  : Object that stores computed values.

#### SEE ALSO
[`CalibrationDisplay.from_estimator`](#sklearn.calibration.CalibrationDisplay.from_estimator)
: Plot calibration curve using an estimator and data.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.calibration import CalibrationDisplay
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, random_state=0)
>>> clf = LogisticRegression(random_state=0)
>>> clf.fit(X_train, y_train)
LogisticRegression(random_state=0)
>>> y_prob = clf.predict_proba(X_test)[:, 1]
>>> disp = CalibrationDisplay.from_predictions(y_test, y_prob)
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-calibration-CalibrationDisplay-2.*)
<!-- !! processed by numpydoc !! -->

#### plot(\*, ax=None, name=None, ref_line=True, \*\*kwargs)

Plot visualization.

Extra keyword arguments will be passed to
[`matplotlib.pyplot.plot`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.plot.html#matplotlib.pyplot.plot).

* **Parameters:**
  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **name**
  : Name for labeling curve. If `None`, use `estimator_name` if
    not `None`, otherwise no labeling is shown.

  **ref_line**
  : If `True`, plots a reference line representing a perfectly
    calibrated classifier.

  **\*\*kwargs**
  : Keyword arguments to be passed to [`matplotlib.pyplot.plot`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.plot.html#matplotlib.pyplot.plot).
* **Returns:**
  **display**
  : Object that stores computed values.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Well calibrated classifiers are probabilistic classifiers for which the output of predict_proba can be directly interpreted as a confidence level. For instance, a well calibrated (binary) classifier should classify the samples such that for the samples to which it gave a predict_proba value close to 0.8, approximately 80% actually belong to the positive class.">  <div class="sphx-glr-thumbnail-title">Comparison of Calibration of Classifiers</div>
</div>
* [Comparison of Calibration of Classifiers](../../auto_examples/calibration/plot_compare_calibration.md#sphx-glr-auto-examples-calibration-plot-compare-calibration-py)

<div class="sphx-glr-thumbcontainer" tooltip="When performing classification one often wants to predict not only the class label, but also the associated probability. This probability gives some kind of confidence on the prediction. This example demonstrates how to visualize how well calibrated the predicted probabilities are using calibration curves, also known as reliability diagrams. Calibration of an uncalibrated classifier will also be demonstrated.">  <div class="sphx-glr-thumbnail-title">Probability Calibration curves</div>
</div>
* [Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py)

<!-- thumbnail-parent-div-close --></div>
