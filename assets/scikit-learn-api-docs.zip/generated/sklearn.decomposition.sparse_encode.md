# sparse_encode

### sklearn.decomposition.sparse_encode(X, dictionary, \*, gram=None, cov=None, algorithm='lasso_lars', n_nonzero_coefs=None, alpha=None, copy_cov=True, init=None, max_iter=1000, n_jobs=None, check_input=True, verbose=0, positive=False)

Sparse coding.

Each row of the result is the solution to a sparse coding problem.
The goal is to find a sparse array `code` such that:

```default
X ~= code * dictionary
```

Read more in the [User Guide](../decomposition.md#sparsecoder).

* **Parameters:**
  **X**
  : Data matrix.

  **dictionary**
  : The dictionary matrix against which to solve the sparse coding of
    the data. Some of the algorithms assume normalized rows for meaningful
    output.

  **gram**
  : Precomputed Gram matrix, `dictionary * dictionary'`.

  **cov**
  : Precomputed covariance, `dictionary' * X`.

  **algorithm**
  : The algorithm used:
    * `'lars'`: uses the least angle regression method
      (`linear_model.lars_path`);
    * `'lasso_lars'`: uses Lars to compute the Lasso solution;
    * `'lasso_cd'`: uses the coordinate descent method to compute the
      Lasso solution (`linear_model.Lasso`). lasso_lars will be faster if
      the estimated components are sparse;
    * `'omp'`: uses orthogonal matching pursuit to estimate the sparse
      solution;
    * `'threshold'`: squashes to zero all coefficients less than
      regularization from the projection `dictionary * data'`.

  **n_nonzero_coefs**
  : Number of nonzero coefficients to target in each column of the
    solution. This is only used by `algorithm='lars'` and `algorithm='omp'`
    and is overridden by `alpha` in the `omp` case. If `None`, then
    `n_nonzero_coefs=int(n_features / 10)`.

  **alpha**
  : If `algorithm='lasso_lars'` or `algorithm='lasso_cd'`, `alpha` is the
    penalty applied to the L1 norm.
    If `algorithm='threshold'`, `alpha` is the absolute value of the
    threshold below which coefficients will be squashed to zero.
    If `algorithm='omp'`, `alpha` is the tolerance parameter: the value of
    the reconstruction error targeted. In this case, it overrides
    `n_nonzero_coefs`.
    If `None`, default to 1.

  **copy_cov**
  : Whether to copy the precomputed covariance matrix; if `False`, it may
    be overwritten.

  **init**
  : Initialization value of the sparse codes. Only used if
    `algorithm='lasso_cd'`.

  **max_iter**
  : Maximum number of iterations to perform if `algorithm='lasso_cd'` or
    `'lasso_lars'`.

  **n_jobs**
  : Number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **check_input**
  : If `False`, the input arrays X and dictionary will not be checked.

  **verbose**
  : Controls the verbosity; the higher, the more messages.

  **positive**
  : Whether to enforce positivity when finding the encoding.
    <br/>
    #### Versionadded
    Added in version 0.20.
* **Returns:**
  **code**
  : The sparse codes.

#### SEE ALSO
[`sklearn.linear_model.lars_path`](sklearn.linear_model.lars_path.md#sklearn.linear_model.lars_path)
: Compute Least Angle Regression or Lasso path using LARS algorithm.

[`sklearn.linear_model.orthogonal_mp`](sklearn.linear_model.orthogonal_mp.md#sklearn.linear_model.orthogonal_mp)
: Solves Orthogonal Matching Pursuit problems.

[`sklearn.linear_model.Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso)
: Train Linear Model with L1 prior as regularizer.

[`SparseCoder`](sklearn.decomposition.SparseCoder.md#sklearn.decomposition.SparseCoder)
: Find a sparse representation of data from a fixed precomputed dictionary.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.decomposition import sparse_encode
>>> X = np.array([[-1, -1, -1], [0, 0, 3]])
>>> dictionary = np.array(
...     [[0, 1, 0],
...      [-1, -1, 2],
...      [1, 1, 1],
...      [0, 1, 1],
...      [0, 2, 1]],
...    dtype=np.float64
... )
>>> sparse_encode(X, dictionary, alpha=1e-10)
array([[ 0.,  0., -1.,  0.,  0.],
       [ 0.,  1.,  1.,  0.,  0.]])
```

<!-- !! processed by numpydoc !! -->
