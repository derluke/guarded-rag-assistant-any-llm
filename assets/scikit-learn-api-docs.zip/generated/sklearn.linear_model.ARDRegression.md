# ARDRegression

### *class* sklearn.linear_model.ARDRegression(\*, max_iter=300, tol=0.001, alpha_1=1e-06, alpha_2=1e-06, lambda_1=1e-06, lambda_2=1e-06, compute_score=False, threshold_lambda=10000.0, fit_intercept=True, copy_X=True, verbose=False)

Bayesian ARD regression.

Fit the weights of a regression model, using an ARD prior. The weights of
the regression model are assumed to be in Gaussian distributions.
Also estimate the parameters lambda (precisions of the distributions of the
weights) and alpha (precision of the distribution of the noise).
The estimation is done by an iterative procedures (Evidence Maximization)

Read more in the [User Guide](../linear_model.md#bayesian-regression).

* **Parameters:**
  **max_iter**
  : Maximum number of iterations.
    <br/>
    #### Versionchanged
    Changed in version 1.3.

  **tol**
  : Stop the algorithm if w has converged.

  **alpha_1**
  : Hyper-parameter : shape parameter for the Gamma distribution prior
    over the alpha parameter.

  **alpha_2**
  : Hyper-parameter : inverse scale parameter (rate parameter) for the
    Gamma distribution prior over the alpha parameter.

  **lambda_1**
  : Hyper-parameter : shape parameter for the Gamma distribution prior
    over the lambda parameter.

  **lambda_2**
  : Hyper-parameter : inverse scale parameter (rate parameter) for the
    Gamma distribution prior over the lambda parameter.

  **compute_score**
  : If True, compute the objective function at each step of the model.

  **threshold_lambda**
  : Threshold for removing (pruning) weights with high precision from
    the computation.

  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to false, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **copy_X**
  : If True, X will be copied; else, it may be overwritten.

  **verbose**
  : Verbose mode when fitting the model.
* **Attributes:**
  **coef_**
  : Coefficients of the regression model (mean of distribution)

  **alpha_**
  : estimated precision of the noise.

  **lambda_**
  : estimated precisions of the weights.

  **sigma_**
  : estimated variance-covariance matrix of the weights

  **scores_**
  : if computed, value of the objective function (to be maximized)

  **n_iter_**
  : The actual number of iterations to reach the stopping criterion.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **intercept_**
  : Independent term in decision function. Set to 0.0 if
    `fit_intercept = False`.

  **X_offset_**
  : If `fit_intercept=True`, offset subtracted for centering data to a
    zero mean. Set to np.zeros(n_features) otherwise.

  **X_scale_**
  : Set to np.ones(n_features).

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`BayesianRidge`](sklearn.linear_model.BayesianRidge.md#sklearn.linear_model.BayesianRidge)
: Bayesian ridge regression.

### Notes

For an example, see [examples/linear_model/plot_ard.py](../../auto_examples/linear_model/plot_ard.md#sphx-glr-auto-examples-linear-model-plot-ard-py).

### References

D. J. C. MacKay, Bayesian nonlinear modeling for the prediction
competition, ASHRAE Transactions, 1994.

R. Salakhutdinov, Lecture notes on Statistical Machine Learning,
[http://www.utstat.toronto.edu/~rsalakhu/sta4273/notes/Lecture2.pdf#page=15](http://www.utstat.toronto.edu/~rsalakhu/sta4273/notes/Lecture2.pdf#page=15)
Their beta is our `self.alpha_`
Their alpha is our `self.lambda_`
ARD is a little different than the slide: only dimensions/features for
which `self.lambda_ < self.threshold_lambda` are kept and the rest are
discarded.

### Examples

```pycon
>>> from sklearn import linear_model
>>> clf = linear_model.ARDRegression()
>>> clf.fit([[0,0], [1, 1], [2, 2]], [0, 1, 2])
ARDRegression()
>>> clf.predict([[1, 1]])
array([1.])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit the model according to the given training data and parameters.

Iterative procedure to maximize the evidence

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target values (integers). Will be cast to X’s dtype if necessary.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X, return_std=False)

Predict using the linear model.

In addition to the mean of the predictive distribution, also its
standard deviation can be returned.

* **Parameters:**
  **X**
  : Samples.

  **return_std**
  : Whether to return the standard deviation of posterior prediction.
* **Returns:**
  **y_mean**
  : Mean of predictive distribution of query points.

  **y_std**
  : Standard deviation of predictive distribution of query points.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_predict_request(\*, return_std: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [ARDRegression](#sklearn.linear_model.ARDRegression)

Request metadata passed to the `predict` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `predict` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `predict`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **return_std**
  : Metadata routing for `return_std` parameter in `predict`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [ARDRegression](#sklearn.linear_model.ARDRegression)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares two different bayesian regressors:">  <div class="sphx-glr-thumbnail-title">Comparing Linear Bayesian Regressors</div>
</div>
* [Comparing Linear Bayesian Regressors](../../auto_examples/linear_model/plot_ard.md#sphx-glr-auto-examples-linear-model-plot-ard-py)

<div class="sphx-glr-thumbcontainer" tooltip="The present example compares three l1-based regression models on a synthetic signal obtained from sparse and correlated features that are further corrupted with additive gaussian noise:">  <div class="sphx-glr-thumbnail-title">L1-based models for Sparse Signals</div>
</div>
* [L1-based models for Sparse Signals](../../auto_examples/linear_model/plot_lasso_and_elasticnet.md#sphx-glr-auto-examples-linear-model-plot-lasso-and-elasticnet-py)

<!-- thumbnail-parent-div-close --></div>
