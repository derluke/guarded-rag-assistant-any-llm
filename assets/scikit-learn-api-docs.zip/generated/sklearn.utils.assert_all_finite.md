# assert_all_finite

### sklearn.utils.assert_all_finite(X, \*, allow_nan=False, estimator_name=None, input_name='')

Throw a ValueError if X contains NaN or infinity.

* **Parameters:**
  **X**
  : The input data.

  **allow_nan**
  : If True, do not throw error when `X` contains NaN.

  **estimator_name**
  : The estimator name, used to construct the error message.

  **input_name**
  : The data name used to construct the error message. In particular
    if `input_name` is “X” and the data has NaN values and
    allow_nan is False, the error message will link to the imputer
    documentation.

### Examples

```pycon
>>> from sklearn.utils import assert_all_finite
>>> import numpy as np
>>> array = np.array([1, np.inf, np.nan, 4])
>>> try:
...     assert_all_finite(array)
...     print("Test passed: Array contains only finite values.")
... except ValueError:
...     print("Test failed: Array contains non-finite values.")
Test failed: Array contains non-finite values.
```

<!-- !! processed by numpydoc !! -->
