# ConvergenceWarning

### *exception* sklearn.exceptions.ConvergenceWarning

Custom warning to capture convergence problems

#### Versionchanged
Changed in version 0.18: Moved from sklearn.utils.

<!-- !! processed by numpydoc !! -->
