# OneHotEncoder

### *class* sklearn.preprocessing.OneHotEncoder(\*, categories='auto', drop=None, sparse_output=True, dtype=<class 'numpy.float64'>, handle_unknown='error', min_frequency=None, max_categories=None, feature_name_combiner='concat')

Encode categorical features as a one-hot numeric array.

The input to this transformer should be an array-like of integers or
strings, denoting the values taken on by categorical (discrete) features.
The features are encoded using a one-hot (aka ‘one-of-K’ or ‘dummy’)
encoding scheme. This creates a binary column for each category and
returns a sparse matrix or dense array (depending on the `sparse_output`
parameter).

By default, the encoder derives the categories based on the unique values
in each feature. Alternatively, you can also specify the `categories`
manually.

This encoding is needed for feeding categorical data to many scikit-learn
estimators, notably linear models and SVMs with the standard kernels.

Note: a one-hot encoding of y labels should use a LabelBinarizer
instead.

Read more in the [User Guide](../preprocessing.md#preprocessing-categorical-features).
For a comparison of different encoders, refer to:
[Comparing Target Encoder with Other Encoders](../../auto_examples/preprocessing/plot_target_encoder.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-py).

* **Parameters:**
  **categories**
  : Categories (unique values) per feature:
    - ‘auto’ : Determine categories automatically from the training data.
    - list : `categories[i]` holds the categories expected in the ith
      column. The passed categories should not mix strings and numeric
      values within a single feature, and should be sorted in case of
      numeric values.
    <br/>
    The used categories can be found in the `categories_` attribute.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **drop**
  : Specifies a methodology to use to drop one of the categories per
    feature. This is useful in situations where perfectly collinear
    features cause problems, such as when feeding the resulting data
    into an unregularized linear regression model.
    <br/>
    However, dropping one category breaks the symmetry of the original
    representation and can therefore induce a bias in downstream models,
    for instance for penalized linear classification or regression models.
    - None : retain all features (the default).
    - ‘first’ : drop the first category in each feature. If only one
      category is present, the feature will be dropped entirely.
    - ‘if_binary’ : drop the first category in each feature with two
      categories. Features with 1 or more than 2 categories are
      left intact.
    - array : `drop[i]` is the category in feature `X[:, i]` that
      should be dropped.
    <br/>
    When `max_categories` or `min_frequency` is configured to group
    infrequent categories, the dropping behavior is handled after the
    grouping.
    <br/>
    #### Versionadded
    Added in version 0.21: The parameter `drop` was added in 0.21.
    <br/>
    #### Versionchanged
    Changed in version 0.23: The option `drop='if_binary'` was added in 0.23.
    <br/>
    #### Versionchanged
    Changed in version 1.1: Support for dropping infrequent categories.

  **sparse_output**
  : When `True`, it returns a [`scipy.sparse.csr_matrix`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csr_matrix.html#scipy.sparse.csr_matrix),
    i.e. a sparse matrix in “Compressed Sparse Row” (CSR) format.
    <br/>
    #### Versionadded
    Added in version 1.2: `sparse` was renamed to `sparse_output`

  **dtype**
  : Desired dtype of output.

  **handle_unknown**
  : Specifies the way unknown categories are handled during [`transform`](#sklearn.preprocessing.OneHotEncoder.transform).
    - ‘error’ : Raise an error if an unknown category is present during transform.
    - ‘ignore’ : When an unknown category is encountered during
      transform, the resulting one-hot encoded columns for this feature
      will be all zeros. In the inverse transform, an unknown category
      will be denoted as None.
    - ‘infrequent_if_exist’ : When an unknown category is encountered
      during transform, the resulting one-hot encoded columns for this
      feature will map to the infrequent category if it exists. The
      infrequent category will be mapped to the last position in the
      encoding. During inverse transform, an unknown category will be
      mapped to the category denoted `'infrequent'` if it exists. If the
      `'infrequent'` category does not exist, then [`transform`](#sklearn.preprocessing.OneHotEncoder.transform) and
      [`inverse_transform`](#sklearn.preprocessing.OneHotEncoder.inverse_transform) will handle an unknown category as with
      `handle_unknown='ignore'`. Infrequent categories exist based on
      `min_frequency` and `max_categories`. Read more in the
      [User Guide](../preprocessing.md#encoder-infrequent-categories).
    - ‘warn’ : When an unknown category is encountered during transform
      a warning is issued, and the encoding then proceeds as described for
      `handle_unknown="infrequent_if_exist"`.
    <br/>
    #### Versionchanged
    Changed in version 1.1: `'infrequent_if_exist'` was added to automatically handle unknown
    categories and infrequent categories.
    <br/>
    #### Versionadded
    Added in version 1.6: The option `"warn"` was added in 1.6.

  **min_frequency**
  : Specifies the minimum frequency below which a category will be
    considered infrequent.
    - If `int`, categories with a smaller cardinality will be considered
      infrequent.
    - If `float`, categories with a smaller cardinality than
      `min_frequency * n_samples`  will be considered infrequent.
    <br/>
    #### Versionadded
    Added in version 1.1: Read more in the [User Guide](../preprocessing.md#encoder-infrequent-categories).

  **max_categories**
  : Specifies an upper limit to the number of output features for each input
    feature when considering infrequent categories. If there are infrequent
    categories, `max_categories` includes the category representing the
    infrequent categories along with the frequent categories. If `None`,
    there is no limit to the number of output features.
    <br/>
    #### Versionadded
    Added in version 1.1: Read more in the [User Guide](../preprocessing.md#encoder-infrequent-categories).

  **feature_name_combiner**
  : Callable with signature `def callable(input_feature, category)` that returns a
    string. This is used to create feature names to be returned by
    [`get_feature_names_out`](#sklearn.preprocessing.OneHotEncoder.get_feature_names_out).
    <br/>
    `"concat"` concatenates encoded feature name and category with
    `feature + "_" + str(category)`.E.g. feature X with values 1, 6, 7 create
    feature names `X_1, X_6, X_7`.
    <br/>
    #### Versionadded
    Added in version 1.3.
* **Attributes:**
  **categories_**
  : The categories of each feature determined during fitting
    (in order of the features in X and corresponding with the output
    of `transform`). This includes the category specified in `drop`
    (if any).

  **drop_idx_**
  : - `drop_idx_[i]` is the index in `categories_[i]` of the category
      to be dropped for each feature.
    - `drop_idx_[i] = None` if no category is to be dropped from the
      feature with index `i`, e.g. when `drop='if_binary'` and the
      feature isn’t binary.
    - `drop_idx_ = None` if all the transformed features will be
      retained.
    <br/>
    If infrequent categories are enabled by setting `min_frequency` or
    `max_categories` to a non-default value and `drop_idx[i]` corresponds
    to a infrequent category, then the entire infrequent category is
    dropped.
    <br/>
    #### Versionchanged
    Changed in version 0.23: Added the possibility to contain `None` values.

  [`infrequent_categories_`](#sklearn.preprocessing.OneHotEncoder.infrequent_categories_)
  : Infrequent categories for each feature.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 1.0.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **feature_name_combiner**
  : Callable with signature `def callable(input_feature, category)` that returns a
    string. This is used to create feature names to be returned by
    [`get_feature_names_out`](#sklearn.preprocessing.OneHotEncoder.get_feature_names_out).
    <br/>
    #### Versionadded
    Added in version 1.3.

#### SEE ALSO
[`OrdinalEncoder`](sklearn.preprocessing.OrdinalEncoder.md#sklearn.preprocessing.OrdinalEncoder)
: Performs an ordinal (integer) encoding of the categorical features.

[`TargetEncoder`](sklearn.preprocessing.TargetEncoder.md#sklearn.preprocessing.TargetEncoder)
: Encodes categorical features using the target.

[`sklearn.feature_extraction.DictVectorizer`](sklearn.feature_extraction.DictVectorizer.md#sklearn.feature_extraction.DictVectorizer)
: Performs a one-hot encoding of dictionary items (also handles string-valued features).

[`sklearn.feature_extraction.FeatureHasher`](sklearn.feature_extraction.FeatureHasher.md#sklearn.feature_extraction.FeatureHasher)
: Performs an approximate one-hot encoding of dictionary items or strings.

[`LabelBinarizer`](sklearn.preprocessing.LabelBinarizer.md#sklearn.preprocessing.LabelBinarizer)
: Binarizes labels in a one-vs-all fashion.

[`MultiLabelBinarizer`](sklearn.preprocessing.MultiLabelBinarizer.md#sklearn.preprocessing.MultiLabelBinarizer)
: Transforms between iterable of iterables and a multilabel format, e.g. a (samples x classes) binary matrix indicating the presence of a class label.

### Examples

Given a dataset with two features, we let the encoder find the unique
values per feature and transform the data to a binary one-hot encoding.

```pycon
>>> from sklearn.preprocessing import OneHotEncoder
```

One can discard categories not seen during `fit`:

```pycon
>>> enc = OneHotEncoder(handle_unknown='ignore')
>>> X = [['Male', 1], ['Female', 3], ['Female', 2]]
>>> enc.fit(X)
OneHotEncoder(handle_unknown='ignore')
>>> enc.categories_
[array(['Female', 'Male'], dtype=object), array([1, 2, 3], dtype=object)]
>>> enc.transform([['Female', 1], ['Male', 4]]).toarray()
array([[1., 0., 1., 0., 0.],
       [0., 1., 0., 0., 0.]])
>>> enc.inverse_transform([[0, 1, 1, 0, 0], [0, 0, 0, 1, 0]])
array([['Male', 1],
       [None, 2]], dtype=object)
>>> enc.get_feature_names_out(['gender', 'group'])
array(['gender_Female', 'gender_Male', 'group_1', 'group_2', 'group_3'], ...)
```

One can always drop the first column for each feature:

```pycon
>>> drop_enc = OneHotEncoder(drop='first').fit(X)
>>> drop_enc.categories_
[array(['Female', 'Male'], dtype=object), array([1, 2, 3], dtype=object)]
>>> drop_enc.transform([['Female', 1], ['Male', 2]]).toarray()
array([[0., 0., 0.],
       [1., 1., 0.]])
```

Or drop a column for feature only having 2 categories:

```pycon
>>> drop_binary_enc = OneHotEncoder(drop='if_binary').fit(X)
>>> drop_binary_enc.transform([['Female', 1], ['Male', 2]]).toarray()
array([[0., 1., 0., 0.],
       [1., 0., 1., 0.]])
```

One can change the way feature names are created.

```pycon
>>> def custom_combiner(feature, category):
...     return str(feature) + "_" + type(category).__name__ + "_" + str(category)
>>> custom_fnames_enc = OneHotEncoder(feature_name_combiner=custom_combiner).fit(X)
>>> custom_fnames_enc.get_feature_names_out()
array(['x0_str_Female', 'x0_str_Male', 'x1_int_1', 'x1_int_2', 'x1_int_3'],
      dtype=object)
```

Infrequent categories are enabled by setting `max_categories` or `min_frequency`.

```pycon
>>> import numpy as np
>>> X = np.array([["a"] * 5 + ["b"] * 20 + ["c"] * 10 + ["d"] * 3], dtype=object).T
>>> ohe = OneHotEncoder(max_categories=3, sparse_output=False).fit(X)
>>> ohe.infrequent_categories_
[array(['a', 'd'], dtype=object)]
>>> ohe.transform([["a"], ["b"]])
array([[0., 0., 1.],
       [1., 0., 0.]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit OneHotEncoder to X.

* **Parameters:**
  **X**
  : The data to determine the categories of each feature.

  **y**
  : Ignored. This parameter exists only for compatibility with
    [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline).
* **Returns:**
  self
  : Fitted encoder.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* infrequent_categories_

Infrequent categories for each feature.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Convert the data back to the original representation.

When unknown categories are encountered (all zeros in the
one-hot encoding), `None` is used to represent this category. If the
feature with the unknown category has a dropped category, the dropped
category will be its inverse.

For a given input feature, if there is an infrequent category,
‘infrequent_sklearn’ will be used to represent the infrequent category.

* **Parameters:**
  **X**
  : The transformed data.
* **Returns:**
  **X_tr**
  : Inverse transformed array.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform X using one-hot encoding.

If `sparse_output=True` (default), it returns an instance of
[`scipy.sparse._csr.csr_matrix`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csr_matrix.html#scipy.sparse.csr_matrix) (CSR format).

If there are infrequent categories for a feature, set by specifying
`max_categories` or `min_frequency`, the infrequent categories are
grouped into a single category.

* **Parameters:**
  **X**
  : The data to encode.
* **Returns:**
  **X_out**
  : Transformed input. If `sparse_output=True`, a sparse matrix will be
    returned.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to apply different preprocessing and feature extraction pipelines to different subsets of features, using ColumnTransformer. This is particularly handy for the case of datasets that contain heterogeneous data types, since we may want to scale the numeric features and one-hot encode the categorical ones.">  <div class="sphx-glr-thumbnail-title">Column Transformer with Mixed Types</div>
</div>
* [Column Transformer with Mixed Types](../../auto_examples/compose/plot_column_transformer_mixed_types.md#sphx-glr-auto-examples-compose-plot-column-transformer-mixed-types-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the training times and prediction performances of HistGradientBoostingRegressor with different encoding strategies for categorical features. In particular, we will evaluate:">  <div class="sphx-glr-thumbnail-title">Categorical Feature Support in Gradient Boosting</div>
</div>
* [Categorical Feature Support in Gradient Boosting](../../auto_examples/ensemble/plot_gradient_boosting_categorical.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-categorical-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="Transform your features into a higher dimensional, sparse space. Then train a linear model on these features.">  <div class="sphx-glr-thumbnail-title">Feature transformations with ensembles of trees</div>
</div>
* [Feature transformations with ensembles of trees](../../auto_examples/ensemble/plot_feature_transformation.md#sphx-glr-auto-examples-ensemble-plot-feature-transformation-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Partial dependence plots show the dependence between the target function [2]_ and a set of features of interest, marginalizing over the values of all other features (the complement features). Due to the limits of human perception, the size of the set of features of interest must be small (usually, one or two) thus they are usually chosen among the most important features.">  <div class="sphx-glr-thumbnail-title">Partial Dependence and Individual Conditional Expectation Plots</div>
</div>
* [Partial Dependence and Individual Conditional Expectation Plots](../../auto_examples/inspection/plot_partial_dependence.md#sphx-glr-auto-examples-inspection-plot-partial-dependence-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Poisson, Gamma and Tweedie regression on the French Motor Third-Party Liability Claims dataset, and is inspired by an R tutorial [1]_.">  <div class="sphx-glr-thumbnail-title">Tweedie regression on insurance claims</div>
</div>
* [Tweedie regression on insurance claims](../../auto_examples/linear_model/plot_tweedie_regression_insurance_claims.md#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py)

<div class="sphx-glr-thumbcontainer" tooltip="The default configuration for displaying a pipeline in a Jupyter Notebook is &#x27;diagram&#x27; where set_config(display=&#x27;diagram&#x27;). To deactivate HTML representation, use set_config(display=&#x27;text&#x27;).">  <div class="sphx-glr-thumbnail-title">Displaying Pipelines</div>
</div>
* [Displaying Pipelines](../../auto_examples/miscellaneous/plot_pipeline_display.md#sphx-glr-auto-examples-miscellaneous-plot-pipeline-display-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates different ways estimators and pipelines can be displayed.">  <div class="sphx-glr-thumbnail-title">Displaying estimators and complex pipelines</div>
</div>
* [Displaying estimators and complex pipelines](../../auto_examples/miscellaneous/plot_estimator_representation.md#sphx-glr-auto-examples-miscellaneous-plot-estimator-representation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example will demonstrate the set_output API to configure transformers to output pandas DataFrames. set_output can be configured per estimator by calling the set_output method or globally by setting set_config(transform_output=&quot;pandas&quot;). For details, see SLEP018.">  <div class="sphx-glr-thumbnail-title">Introducing the set_output API</div>
</div>
* [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)

<div class="sphx-glr-thumbcontainer" tooltip="The TargetEncoder uses the value of the target to encode each categorical feature. In this example, we will compare three different approaches for handling categorical features: TargetEncoder, OrdinalEncoder, OneHotEncoder and dropping the category.">  <div class="sphx-glr-thumbnail-title">Comparing Target Encoder with Other Encoders</div>
</div>
* [Comparing Target Encoder with Other Encoders](../../auto_examples/preprocessing/plot_target_encoder.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are very pleased to announce the release of scikit-learn 1.0! The library has been stable for quite some time, releasing version 1.0 is recognizing that and signalling it to our users. This release does not include any breaking changes apart from the usual two-release deprecation cycle. For the future, we do our best to keep this pattern.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.0</div>
</div>
* [Release Highlights for scikit-learn 1.0](../../auto_examples/release_highlights/plot_release_highlights_1_0_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-0-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<!-- thumbnail-parent-div-close --></div>
