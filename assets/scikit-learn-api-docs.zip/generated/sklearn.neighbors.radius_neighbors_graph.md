# radius_neighbors_graph

### sklearn.neighbors.radius_neighbors_graph(X, radius, \*, mode='connectivity', metric='minkowski', p=2, metric_params=None, include_self=False, n_jobs=None)

Compute the (weighted) graph of Neighbors for points in X.

Neighborhoods are restricted the points at a distance lower than
radius.

Read more in the [User Guide](../neighbors.md#unsupervised-neighbors).

* **Parameters:**
  **X**
  : Sample data.

  **radius**
  : Radius of neighborhoods.

  **mode**
  : Type of returned matrix: ‘connectivity’ will return the connectivity
    matrix with ones and zeros, and ‘distance’ will return the distances
    between neighbors according to the given metric.

  **metric**
  : Metric to use for distance computation. Default is “minkowski”, which
    results in the standard Euclidean distance when p = 2. See the
    documentation of [scipy.spatial.distance](https://docs.scipy.org/doc/scipy/reference/spatial.distance.html) and
    the metrics listed in
    [`distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics) for valid metric
    values.

  **p**
  : Power parameter for the Minkowski metric. When p = 1, this is
    equivalent to using manhattan_distance (l1), and euclidean_distance
    (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.

  **metric_params**
  : Additional keyword arguments for the metric function.

  **include_self**
  : Whether or not to mark each sample as the first nearest neighbor to
    itself. If ‘auto’, then True is used for mode=’connectivity’ and False
    for mode=’distance’.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Returns:**
  **A**
  : Graph where A[i, j] is assigned the weight of edge that connects
    i to j. The matrix is of CSR format.

#### SEE ALSO
[`kneighbors_graph`](sklearn.neighbors.kneighbors_graph.md#sklearn.neighbors.kneighbors_graph)
: Compute the weighted graph of k-neighbors for points in X.

### Examples

```pycon
>>> X = [[0], [3], [1]]
>>> from sklearn.neighbors import radius_neighbors_graph
>>> A = radius_neighbors_graph(X, 1.5, mode='connectivity',
...                            include_self=True)
>>> A.toarray()
array([[1., 0., 1.],
       [0., 1., 0.],
       [1., 0., 1.]])
```

<!-- !! processed by numpydoc !! -->
