# fetch_20newsgroups

### sklearn.datasets.fetch_20newsgroups(\*, data_home=None, subset='train', categories=None, shuffle=True, random_state=42, remove=(), download_if_missing=True, return_X_y=False, n_retries=3, delay=1.0)

Load the filenames and data from the 20 newsgroups dataset (classification).

Download it if necessary.

| Classes        | 20    |
|----------------|-------|
| Samples total  | 18846 |
| Dimensionality | 1     |
| Features       | text  |

Read more in the [User Guide](../../datasets/real_world.md#newsgroups-dataset).

* **Parameters:**
  **data_home**
  : Specify a download and cache folder for the datasets. If None,
    all scikit-learn data is stored in ‘~/scikit_learn_data’ subfolders.

  **subset**
  : Select the dataset to load: ‘train’ for the training set, ‘test’
    for the test set, ‘all’ for both, with shuffled ordering.

  **categories**
  : If None (default), load all the categories.
    If not None, list of category names to load (other categories
    ignored).

  **shuffle**
  : Whether or not to shuffle the data: might be important for models that
    make the assumption that the samples are independent and identically
    distributed (i.i.d.), such as stochastic gradient descent.

  **random_state**
  : Determines random number generation for dataset shuffling. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **remove**
  : May contain any subset of (‘headers’, ‘footers’, ‘quotes’). Each of
    these are kinds of text that will be detected and removed from the
    newsgroup posts, preventing classifiers from overfitting on
    metadata.
    <br/>
    ‘headers’ removes newsgroup headers, ‘footers’ removes blocks at the
    ends of posts that look like signatures, and ‘quotes’ removes lines
    that appear to be quoting another post.
    <br/>
    ‘headers’ follows an exact standard; the other filters are not always
    correct.

  **download_if_missing**
  : If False, raise an OSError if the data is not locally available
    instead of trying to download the data from the source site.

  **return_X_y**
  : If True, returns `(data.data, data.target)` instead of a Bunch
    object.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **n_retries**
  : Number of retries when HTTP errors are encountered.
    <br/>
    #### Versionadded
    Added in version 1.5.

  **delay**
  : Number of seconds between retries.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **bunch**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : The data list to learn.
    <br/>
    target: ndarray of shape (n_samples,)
    : The target labels.
    <br/>
    filenames: list of shape (n_samples,)
    : The path to the location of the data.
    <br/>
    DESCR: str
    : The full description of the dataset.
    <br/>
    target_names: list of shape (n_classes,)
    : The names of target classes.

  **(data, target)**
  : A tuple of two ndarrays. The first contains a 2D array of shape
    (n_samples, n_classes) with each row representing one sample and each
    column representing the features. The second array of shape
    (n_samples,) contains the target samples.
    <br/>
    #### Versionadded
    Added in version 0.22.

### Examples

```pycon
>>> from sklearn.datasets import fetch_20newsgroups
>>> cats = ['alt.atheism', 'sci.space']
>>> newsgroups_train = fetch_20newsgroups(subset='train', categories=cats)
>>> list(newsgroups_train.target_names)
['alt.atheism', 'sci.space']
>>> newsgroups_train.filenames.shape
(1073,)
>>> newsgroups_train.target.shape
(1073,)
>>> newsgroups_train.target[:10]
array([0, 1, 1, 1, 0, 1, 1, 0, 0, 0])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This is an example of applying NMF and LatentDirichletAllocation on a corpus of documents and extract additive models of the topic structure of the corpus.  The output is a plot of topics, each represented as bar plot using top few words based on weights.">  <div class="sphx-glr-thumbnail-title">Topic extraction with Non-negative Matrix Factorization and Latent Dirichlet Allocation</div>
</div>
* [Topic extraction with Non-negative Matrix Factorization and Latent Dirichlet Allocation](../../auto_examples/applications/plot_topics_extraction_with_nmf_lda.md#sphx-glr-auto-examples-applications-plot-topics-extraction-with-nmf-lda-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the Spectral Co-clustering algorithm on the twenty newsgroups dataset. The &#x27;comp.os.ms-windows.misc&#x27; category is excluded because it contains many posts containing nothing but data.">  <div class="sphx-glr-thumbnail-title">Biclustering documents with the Spectral Co-clustering algorithm</div>
</div>
* [Biclustering documents with the Spectral Co-clustering algorithm](../../auto_examples/bicluster/plot_bicluster_newsgroups.md#sphx-glr-auto-examples-bicluster-plot-bicluster-newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="Datasets can often contain components that require different feature extraction and processing pipelines. This scenario might occur when:">  <div class="sphx-glr-thumbnail-title">Column Transformer with Heterogeneous Data Sources</div>
</div>
* [Column Transformer with Heterogeneous Data Sources](../../auto_examples/compose/plot_column_transformer.md#sphx-glr-auto-examples-compose-plot-column-transformer-py)

<div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is 20newsgroups_dataset which will be automatically downloaded, cached and reused for the document classification example.">  <div class="sphx-glr-thumbnail-title">Sample pipeline for text feature extraction and evaluation</div>
</div>
* [Sample pipeline for text feature extraction and evaluation](../../auto_examples/model_selection/plot_grid_search_text_feature_extraction.md#sphx-glr-auto-examples-model-selection-plot-grid-search-text-feature-extraction-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, semi-supervised classifiers are trained on the 20 newsgroups dataset (which will be automatically downloaded).">  <div class="sphx-glr-thumbnail-title">Semi-supervised Classification on a Text Dataset</div>
</div>
* [Semi-supervised Classification on a Text Dataset](../../auto_examples/semi_supervised/plot_semi_supervised_newsgroups.md#sphx-glr-auto-examples-semi-supervised-plot-semi-supervised-newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how the scikit-learn API can be used to cluster documents by topics using a Bag of Words approach.">  <div class="sphx-glr-thumbnail-title">Clustering text documents using k-means</div>
</div>
* [Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we illustrate text vectorization, which is the process of representing non-numerical input data (such as dictionaries or text documents) as vectors of real numbers.">  <div class="sphx-glr-thumbnail-title">FeatureHasher and DictVectorizer Comparison</div>
</div>
* [FeatureHasher and DictVectorizer Comparison](../../auto_examples/text/plot_hashing_vs_dict_vectorizer.md#sphx-glr-auto-examples-text-plot-hashing-vs-dict-vectorizer-py)

<!-- thumbnail-parent-div-close --></div>
