# is_classifier

### sklearn.base.is_classifier(estimator)

Return True if the given estimator is (probably) a classifier.

* **Parameters:**
  **estimator**
  : Estimator object to test.
* **Returns:**
  **out**
  : True if estimator is a classifier and False otherwise.

### Examples

```pycon
>>> from sklearn.base import is_classifier
>>> from sklearn.cluster import KMeans
>>> from sklearn.svm import SVC, SVR
>>> classifier = SVC()
>>> regressor = SVR()
>>> kmeans = KMeans()
>>> is_classifier(classifier)
True
>>> is_classifier(regressor)
False
>>> is_classifier(kmeans)
False
```

<!-- !! processed by numpydoc !! -->
