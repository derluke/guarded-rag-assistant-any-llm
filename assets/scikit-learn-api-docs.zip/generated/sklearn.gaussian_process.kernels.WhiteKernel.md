# WhiteKernel

### *class* sklearn.gaussian_process.kernels.WhiteKernel(noise_level=1.0, noise_level_bounds=(1e-05, 100000.0))

White kernel.

The main use-case of this kernel is as part of a sum-kernel where it
explains the noise of the signal as independently and identically
normally-distributed. The parameter noise_level equals the variance of this
noise.

$$
k(x_1, x_2) = noise\_level \text{ if } x_i == x_j \text{ else } 0

$$

Read more in the [User Guide](../gaussian_process.md#gp-kernels).

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **noise_level**
  : Parameter controlling the noise level (variance)

  **noise_level_bounds**
  : The lower and upper bound on ‘noise_level’.
    If set to “fixed”, ‘noise_level’ cannot be changed during
    hyperparameter tuning.

### Examples

```pycon
>>> from sklearn.datasets import make_friedman2
>>> from sklearn.gaussian_process import GaussianProcessRegressor
>>> from sklearn.gaussian_process.kernels import DotProduct, WhiteKernel
>>> X, y = make_friedman2(n_samples=500, noise=0, random_state=0)
>>> kernel = DotProduct() + WhiteKernel(noise_level=0.5)
>>> gpr = GaussianProcessRegressor(kernel=kernel,
...         random_state=0).fit(X, y)
>>> gpr.score(X, y)
0.3680...
>>> gpr.predict(X[:2,:], return_std=True)
(array([653.0..., 592.1... ]), array([316.6..., 316.6...]))
```

<!-- !! processed by numpydoc !! -->

#### \_\_call_\_(X, Y=None, eval_gradient=False)

Return the kernel k(X, Y) and optionally its gradient.

* **Parameters:**
  **X**
  : Left argument of the returned kernel k(X, Y)

  **Y**
  : Right argument of the returned kernel k(X, Y). If None, k(X, X)
    is evaluated instead.

  **eval_gradient**
  : Determines whether the gradient with respect to the log of
    the kernel hyperparameter is computed.
    Only supported when Y is None.
* **Returns:**
  **K**
  : Kernel k(X, Y)

  **K_gradient**
  : The gradient of the kernel k(X, X) with respect to the log of the
    hyperparameter of the kernel. Only returned when eval_gradient
    is True.

<!-- !! processed by numpydoc !! -->

#### *property* bounds

Returns the log-transformed bounds on the theta.

* **Returns:**
  **bounds**
  : The log-transformed bounds on the kernel’s hyperparameters theta

<!-- !! processed by numpydoc !! -->

#### clone_with_theta(theta)

Returns a clone of self with given hyperparameters theta.

* **Parameters:**
  **theta**
  : The hyperparameters

<!-- !! processed by numpydoc !! -->

#### diag(X)

Returns the diagonal of the kernel k(X, X).

The result of this method is identical to np.diag(self(X)); however,
it can be evaluated more efficiently since only the diagonal is
evaluated.

* **Parameters:**
  **X**
  : Argument to the kernel.
* **Returns:**
  **K_diag**
  : Diagonal of kernel k(X, X)

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters of this kernel.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* hyperparameters

Returns a list of all hyperparameter specifications.

<!-- !! processed by numpydoc !! -->

#### is_stationary()

Returns whether the kernel is stationary.

<!-- !! processed by numpydoc !! -->

#### *property* n_dims

Returns the number of non-fixed hyperparameters of the kernel.

<!-- !! processed by numpydoc !! -->

#### *property* requires_vector_input

Whether the kernel works only on fixed-length feature vectors.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this kernel.

The method works on simple kernels as well as on nested kernels.
The latter have parameters of the form `<component>__<parameter>`
so that it’s possible to update each component of a nested object.

* **Returns:**
  self

<!-- !! processed by numpydoc !! -->

#### *property* theta

Returns the (flattened, log-transformed) non-fixed hyperparameters.

Note that theta are typically the log-transformed values of the
kernel’s hyperparameters as this representation of the search space
is more amenable for hyperparameter search, as hyperparameters like
length-scales naturally live on a log-scale.

* **Returns:**
  **theta**
  : The non-fixed, log-transformed hyperparameters of the kernel

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows the ability of the WhiteKernel to estimate the noise level in the data. Moreover, we show the importance of kernel hyperparameters initialization.">  <div class="sphx-glr-thumbnail-title">Ability of Gaussian process regression (GPR) to estimate data noise-level</div>
</div>
* [Ability of Gaussian process regression (GPR) to estimate data noise-level](../../auto_examples/gaussian_process/plot_gpr_noisy.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-noisy-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates differences between a kernel ridge regression and a Gaussian process regression.">  <div class="sphx-glr-thumbnail-title">Comparison of kernel ridge and Gaussian process regression</div>
</div>
* [Comparison of kernel ridge and Gaussian process regression](../../auto_examples/gaussian_process/plot_compare_gpr_krr.md#sphx-glr-auto-examples-gaussian-process-plot-compare-gpr-krr-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example is based on Section 5.4.3 of &quot;Gaussian Processes for Machine Learning&quot; [1]_. It illustrates an example of complex kernel engineering and hyperparameter optimization using gradient ascent on the log-marginal-likelihood. The data consists of the monthly average atmospheric CO2 concentrations (in parts per million by volume (ppm)) collected at the Mauna Loa Observatory in Hawaii, between 1958 and 2001. The objective is to model the CO2 concentration as a function of the time t and extrapolate for years after 2001.">  <div class="sphx-glr-thumbnail-title">Forecasting of CO2 level on Mona Loa dataset using Gaussian process regression (GPR)</div>
</div>
* [Forecasting of CO2 level on Mona Loa dataset using Gaussian process regression (GPR)](../../auto_examples/gaussian_process/plot_gpr_co2.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-co2-py)

<!-- thumbnail-parent-div-close --></div>
