# max_error

### sklearn.metrics.max_error(y_true, y_pred)

The max_error metric calculates the maximum residual error.

Read more in the [User Guide](../model_evaluation.md#max-error).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated target values.
* **Returns:**
  **max_error**
  : A positive floating point value (the best value is 0.0).

### Examples

```pycon
>>> from sklearn.metrics import max_error
>>> y_true = [3, 2, 7, 1]
>>> y_pred = [4, 2, 7, 1]
>>> max_error(y_true, y_pred)
np.int64(1)
```

<!-- !! processed by numpydoc !! -->
