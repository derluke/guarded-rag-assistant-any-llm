# SpectralEmbedding

### *class* sklearn.manifold.SpectralEmbedding(n_components=2, \*, affinity='nearest_neighbors', gamma=None, random_state=None, eigen_solver=None, eigen_tol='auto', n_neighbors=None, n_jobs=None)

Spectral embedding for non-linear dimensionality reduction.

Forms an affinity matrix given by the specified function and
applies spectral decomposition to the corresponding graph laplacian.
The resulting transformation is given by the value of the
eigenvectors for each data point.

Note : Laplacian Eigenmaps is the actual algorithm implemented here.

Read more in the [User Guide](../manifold.md#spectral-embedding).

* **Parameters:**
  **n_components**
  : The dimension of the projected subspace.

  **affinity**
  : How to construct the affinity matrix.
    : - ‘nearest_neighbors’ : construct the affinity matrix by computing a
        graph of nearest neighbors.
      - ‘rbf’ : construct the affinity matrix by computing a radial basis
        function (RBF) kernel.
      - ‘precomputed’ : interpret `X` as a precomputed affinity matrix.
      - ‘precomputed_nearest_neighbors’ : interpret `X` as a sparse graph
        of precomputed nearest neighbors, and constructs the affinity matrix
        by selecting the `n_neighbors` nearest neighbors.
      - callable : use passed in function as affinity
        the function takes in data matrix (n_samples, n_features)
        and return affinity matrix (n_samples, n_samples).

  **gamma**
  : Kernel coefficient for rbf kernel. If None, gamma will be set to
    1/n_features.

  **random_state**
  : A pseudo random number generator used for the initialization
    of the lobpcg eigen vectors decomposition when `eigen_solver ==
    'amg'`, and for the K-Means initialization. Use an int to make
    the results deterministic across calls (See
    [Glossary](../../glossary.md#term-random_state)).
    <br/>
    #### NOTE
    When using `eigen_solver == 'amg'`,
    it is necessary to also fix the global numpy seed with
    `np.random.seed(int)` to get deterministic results. See
    [https://github.com/pyamg/pyamg/issues/139](https://github.com/pyamg/pyamg/issues/139) for further
    information.

  **eigen_solver**
  : The eigenvalue decomposition strategy to use. AMG requires pyamg
    to be installed. It can be faster on very large, sparse problems.
    If None, then `'arpack'` is used.

  **eigen_tol**
  : Stopping criterion for eigendecomposition of the Laplacian matrix.
    If `eigen_tol="auto"` then the passed tolerance will depend on the
    `eigen_solver`:
    - If `eigen_solver="arpack"`, then `eigen_tol=0.0`;
    - If `eigen_solver="lobpcg"` or `eigen_solver="amg"`, then
      `eigen_tol=None` which configures the underlying `lobpcg` solver to
      automatically resolve the value according to their heuristics. See,
      [`scipy.sparse.linalg.lobpcg`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.lobpcg.html#scipy.sparse.linalg.lobpcg) for details.
    <br/>
    Note that when using `eigen_solver="lobpcg"` or `eigen_solver="amg"`
    values of `tol<1e-5` may lead to convergence issues and should be
    avoided.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **n_neighbors**
  : Number of nearest neighbors for nearest_neighbors graph building.
    If None, n_neighbors will be set to max(n_samples/10, 1).

  **n_jobs**
  : The number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **embedding_**
  : Spectral embedding of the training matrix.

  **affinity_matrix_**
  : Affinity_matrix constructed from samples or precomputed.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_neighbors_**
  : Number of nearest neighbors effectively used.

#### SEE ALSO
[`Isomap`](sklearn.manifold.Isomap.md#sklearn.manifold.Isomap)
: Non-linear dimensionality reduction through Isometric Mapping.

### References

- [A Tutorial on Spectral Clustering, 2007
  Ulrike von Luxburg](https://doi.org/10.1007/s11222-007-9033-z)
- [On Spectral Clustering: Analysis and an algorithm, 2001
  Andrew Y. Ng, Michael I. Jordan, Yair Weiss](https://citeseerx.ist.psu.edu/doc_view/pid/796c5d6336fc52aa84db575fb821c78918b65f58)
- [Normalized cuts and image segmentation, 2000
  Jianbo Shi, Jitendra Malik](https://doi.org/10.1109/34.868688)

### Examples

```pycon
>>> from sklearn.datasets import load_digits
>>> from sklearn.manifold import SpectralEmbedding
>>> X, _ = load_digits(return_X_y=True)
>>> X.shape
(1797, 64)
>>> embedding = SpectralEmbedding(n_components=2)
>>> X_transformed = embedding.fit_transform(X[:100])
>>> X_transformed.shape
(100, 2)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the model from data in X.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.
    <br/>
    If affinity is “precomputed”
    X : {array-like, sparse matrix}, shape (n_samples, n_samples),
    Interpret X as precomputed adjacency graph computed from
    samples.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Fit the model from data in X and transform X.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.
    <br/>
    If affinity is “precomputed”
    X : {array-like, sparse matrix} of shape (n_samples, n_samples),
    Interpret X as precomputed adjacency graph computed from
    samples.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **X_new**
  : Spectral embedding of the training matrix.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An illustration of various linkage option for agglomerative clustering on a 2D embedding of the digits dataset.">  <div class="sphx-glr-thumbnail-title">Various Agglomerative Clustering on a 2D embedding of digits</div>
</div>
* [Various Agglomerative Clustering on a 2D embedding of digits](../../auto_examples/cluster/plot_digits_linkage.md#sphx-glr-auto-examples-cluster-plot-digits-linkage-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of dimensionality reduction on the S-curve dataset with various manifold learning methods.">  <div class="sphx-glr-thumbnail-title">Comparison of Manifold Learning methods</div>
</div>
* [Comparison of Manifold Learning methods](../../auto_examples/manifold/plot_compare_methods.md#sphx-glr-auto-examples-manifold-plot-compare-methods-py)

<div class="sphx-glr-thumbcontainer" tooltip="An application of the different manifold techniques on a spherical data-set. Here one can see the use of dimensionality reduction in order to gain some intuition regarding the manifold learning methods. Regarding the dataset, the poles are cut from the sphere, as well as a thin slice down its side. This enables the manifold learning techniques to &#x27;spread it open&#x27; whilst projecting it onto two dimensions.">  <div class="sphx-glr-thumbnail-title">Manifold Learning methods on a severed sphere</div>
</div>
* [Manifold Learning methods on a severed sphere](../../auto_examples/manifold/plot_manifold_sphere.md#sphx-glr-auto-examples-manifold-plot-manifold-sphere-py)

<div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<!-- thumbnail-parent-div-close --></div>
