# IsolationForest

### *class* sklearn.ensemble.IsolationForest(\*, n_estimators=100, max_samples='auto', contamination='auto', max_features=1.0, bootstrap=False, n_jobs=None, random_state=None, verbose=0, warm_start=False)

Isolation Forest Algorithm.

Return the anomaly score of each sample using the IsolationForest algorithm

The IsolationForest ‘isolates’ observations by randomly selecting a feature
and then randomly selecting a split value between the maximum and minimum
values of the selected feature.

Since recursive partitioning can be represented by a tree structure, the
number of splittings required to isolate a sample is equivalent to the path
length from the root node to the terminating node.

This path length, averaged over a forest of such random trees, is a
measure of normality and our decision function.

Random partitioning produces noticeably shorter paths for anomalies.
Hence, when a forest of random trees collectively produce shorter path
lengths for particular samples, they are highly likely to be anomalies.

Read more in the [User Guide](../outlier_detection.md#isolation-forest).

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **n_estimators**
  : The number of base estimators in the ensemble.

  **max_samples**
  : The number of samples to draw from X to train each base estimator.
    - If int, then draw `max_samples` samples.
    - If float, then draw `max_samples * X.shape[0]` samples.
    - If “auto”, then `max_samples=min(256, n_samples)`.
    <br/>
    If max_samples is larger than the number of samples provided,
    all samples will be used for all trees (no sampling).

  **contamination**
  : The amount of contamination of the data set, i.e. the proportion
    of outliers in the data set. Used when fitting to define the threshold
    on the scores of the samples.
    - If ‘auto’, the threshold is determined as in the
      original paper.
    - If float, the contamination should be in the range (0, 0.5].
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default value of `contamination` changed from 0.1
    to `'auto'`.

  **max_features**
  : The number of features to draw from X to train each base estimator.
    - If int, then draw `max_features` features.
    - If float, then draw `max(1, int(max_features * n_features_in_))` features.
    <br/>
    Note: using a float number less than 1.0 or integer less than number of
    features will enable feature subsampling and leads to a longer runtime.

  **bootstrap**
  : If True, individual trees are fit on random subsets of the training
    data sampled with replacement. If False, sampling without replacement
    is performed.

  **n_jobs**
  : The number of jobs to run in parallel for [`fit`](#sklearn.ensemble.IsolationForest.fit). `None` means 1
    unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context. `-1` means using
    all processors. See [Glossary](../../glossary.md#term-n_jobs) for more details.

  **random_state**
  : Controls the pseudo-randomness of the selection of the feature
    and split values for each branching step and each tree in the forest.
    <br/>
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **verbose**
  : Controls the verbosity of the tree building process.

  **warm_start**
  : When set to `True`, reuse the solution of the previous call to fit
    and add more estimators to the ensemble, otherwise, just fit a whole
    new forest. See [the Glossary](../../glossary.md#term-warm_start).
    <br/>
    #### Versionadded
    Added in version 0.21.
* **Attributes:**
  **estimator_**
  : The child estimator template used to create the collection of
    fitted sub-estimators.
    <br/>
    #### Versionadded
    Added in version 1.2: `base_estimator_` was renamed to `estimator_`.

  **estimators_**
  : The collection of fitted sub-estimators.

  **estimators_features_**
  : The subset of drawn features for each base estimator.

  [`estimators_samples_`](#sklearn.ensemble.IsolationForest.estimators_samples_)
  : The subset of drawn samples for each base estimator.

  **max_samples_**
  : The actual number of samples.

  **offset_**
  : Offset used to define the decision function from the raw scores. We
    have the relation: `decision_function = score_samples - offset_`.
    `offset_` is defined as follows. When the contamination parameter is
    set to “auto”, the offset is equal to -0.5 as the scores of inliers are
    close to 0 and the scores of outliers are close to -1. When a
    contamination parameter different than “auto” is provided, the offset
    is defined in such a way we obtain the expected number of outliers
    (samples with decision function < 0) in training.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`sklearn.covariance.EllipticEnvelope`](sklearn.covariance.EllipticEnvelope.md#sklearn.covariance.EllipticEnvelope)
: An object for detecting outliers in a Gaussian distributed dataset.

[`sklearn.svm.OneClassSVM`](sklearn.svm.OneClassSVM.md#sklearn.svm.OneClassSVM)
: Unsupervised Outlier Detection. Estimate the support of a high-dimensional distribution. The implementation is based on libsvm.

[`sklearn.neighbors.LocalOutlierFactor`](sklearn.neighbors.LocalOutlierFactor.md#sklearn.neighbors.LocalOutlierFactor)
: Unsupervised Outlier Detection using Local Outlier Factor (LOF).

### Notes

The implementation is based on an ensemble of ExtraTreeRegressor. The
maximum depth of each tree is set to `ceil(log_2(n))` where
$n$ is the number of samples used to build the tree
(see (Liu et al., 2008) for more details).

### References

### Examples

```pycon
>>> from sklearn.ensemble import IsolationForest
>>> X = [[-1.1], [0.3], [0.5], [100]]
>>> clf = IsolationForest(random_state=0).fit(X)
>>> clf.predict([[0.1], [0], [90]])
array([ 1,  1, -1])
```

For an example of using isolation forest for anomaly detection see
[IsolationForest example](../../auto_examples/ensemble/plot_isolation_forest.md#sphx-glr-auto-examples-ensemble-plot-isolation-forest-py).

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Average anomaly score of X of the base classifiers.

The anomaly score of an input sample is computed as
the mean anomaly score of the trees in the forest.

The measure of normality of an observation given a tree is the depth
of the leaf containing this observation, which is equivalent to
the number of splittings required to isolate this point. In case of
several observations n_left in the leaf, the average path length of
a n_left samples isolation tree is added.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **scores**
  : The anomaly score of the input samples.
    The lower, the more abnormal. Negative scores represent outliers,
    positive scores represent inliers.

### Notes

The decision_function method can be parallelized by setting a joblib context.
This inherently does NOT use the `n_jobs` parameter initialized in the class,
which is used during `fit`. This is because, calculating the score may
actually be faster without parallelization for a small number of samples,
such as for 1000 samples or less.
The user can set the number of jobs in the joblib context to control the
number of parallel jobs.

```python
from joblib import parallel_backend

# Note, we use threading here as the decision_function method is
# not CPU bound.
with parallel_backend("threading", n_jobs=4):
    model.decision_function(X)
```

<!-- !! processed by numpydoc !! -->

#### *property* estimators_samples_

The subset of drawn samples for each base estimator.

Returns a dynamically generated list of indices identifying
the samples used for fitting each member of the ensemble, i.e.,
the in-bag samples.

Note: the list is re-created at each call to the property in order
to reduce the object memory footprint by not storing the sampling
data. Thus fetching the property may be slower than expected.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Fit estimator.

* **Parameters:**
  **X**
  : The input samples. Use `dtype=np.float32` for maximum
    efficiency. Sparse matrices are also supported, use sparse
    `csc_matrix` for maximum efficiency.

  **y**
  : Not used, present for API consistency by convention.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None, \*\*kwargs)

Perform fit on X and returns labels for X.

Returns -1 for outliers and 1 for inliers.

* **Parameters:**
  **X**
  : The input samples.

  **y**
  : Not used, present for API consistency by convention.

  **\*\*kwargs**
  : Arguments to be passed to `fit`.
    <br/>
    #### Versionadded
    Added in version 1.4.
* **Returns:**
  **y**
  : 1 for inliers, -1 for outliers.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.5.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict if a particular sample is an outlier or not.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **is_inlier**
  : For each observation, tells whether or not (+1 or -1) it should
    be considered as an inlier according to the fitted model.

### Notes

The predict method can be parallelized by setting a joblib context. This
inherently does NOT use the `n_jobs` parameter initialized in the class,
which is used during `fit`. This is because, predict may actually be faster
without parallelization for a small number of samples,
such as for 1000 samples or less. The user can set the
number of jobs in the joblib context to control the number of parallel jobs.

```python
from joblib import parallel_backend

# Note, we use threading here as the predict method is not CPU bound.
with parallel_backend("threading", n_jobs=4):
    model.predict(X)
```

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Opposite of the anomaly score defined in the original paper.

The anomaly score of an input sample is computed as
the mean anomaly score of the trees in the forest.

The measure of normality of an observation given a tree is the depth
of the leaf containing this observation, which is equivalent to
the number of splittings required to isolate this point. In case of
several observations n_left in the leaf, the average path length of
a n_left samples isolation tree is added.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **scores**
  : The anomaly score of the input samples.
    The lower, the more abnormal.

### Notes

The score function method can be parallelized by setting a joblib context. This
inherently does NOT use the `n_jobs` parameter initialized in the class,
which is used during `fit`. This is because, calculating the score may
actually be faster without parallelization for a small number of samples,
such as for 1000 samples or less.
The user can set the number of jobs in the joblib context to control the
number of parallel jobs.

```python
from joblib import parallel_backend

# Note, we use threading here as the score_samples method is not CPU bound.
with parallel_backend("threading", n_jobs=4):
    model.score(X)
```

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [IsolationForest](#sklearn.ensemble.IsolationForest)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An example using IsolationForest for anomaly detection.">  <div class="sphx-glr-thumbnail-title">IsolationForest example</div>
</div>
* [IsolationForest example](../../auto_examples/ensemble/plot_isolation_forest.md#sphx-glr-auto-examples-ensemble-plot-isolation-forest-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different anomaly detection algorithms on 2D datasets. Datasets contain one or two modes (regions of high density) to illustrate the ability of algorithms to cope with multimodal data.">  <div class="sphx-glr-thumbnail-title">Comparing anomaly detection algorithms for outlier detection on toy datasets</div>
</div>
* [Comparing anomaly detection algorithms for outlier detection on toy datasets](../../auto_examples/miscellaneous/plot_anomaly_comparison.md#sphx-glr-auto-examples-miscellaneous-plot-anomaly-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<!-- thumbnail-parent-div-close --></div>
