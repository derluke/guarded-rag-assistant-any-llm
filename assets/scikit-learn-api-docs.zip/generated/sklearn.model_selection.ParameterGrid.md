# ParameterGrid

### *class* sklearn.model_selection.ParameterGrid(param_grid)

Grid of parameters with a discrete number of values for each.

Can be used to iterate over parameter value combinations with the
Python built-in function iter.
The order of the generated parameter combinations is deterministic.

Read more in the [User Guide](../grid_search.md#grid-search).

* **Parameters:**
  **param_grid**
  : The parameter grid to explore, as a dictionary mapping estimator
    parameters to sequences of allowed values.
    <br/>
    An empty dict signifies default parameters.
    <br/>
    A sequence of dicts signifies a sequence of grids to search, and is
    useful to avoid exploring parameter combinations that make no sense
    or have no effect. See the examples below.

#### SEE ALSO
[`GridSearchCV`](sklearn.model_selection.GridSearchCV.md#sklearn.model_selection.GridSearchCV)
: Uses [`ParameterGrid`](#sklearn.model_selection.ParameterGrid) to perform a full parallelized parameter search.

### Examples

```pycon
>>> from sklearn.model_selection import ParameterGrid
>>> param_grid = {'a': [1, 2], 'b': [True, False]}
>>> list(ParameterGrid(param_grid)) == (
...    [{'a': 1, 'b': True}, {'a': 1, 'b': False},
...     {'a': 2, 'b': True}, {'a': 2, 'b': False}])
True
```

```pycon
>>> grid = [{'kernel': ['linear']}, {'kernel': ['rbf'], 'gamma': [1, 10]}]
>>> list(ParameterGrid(grid)) == [{'kernel': 'linear'},
...                               {'kernel': 'rbf', 'gamma': 1},
...                               {'kernel': 'rbf', 'gamma': 10}]
True
>>> ParameterGrid(grid)[1] == {'kernel': 'rbf', 'gamma': 1}
True
```

<!-- !! processed by numpydoc !! -->
