# paired_distances

### sklearn.metrics.pairwise.paired_distances(X, Y, \*, metric='euclidean', \*\*kwds)

Compute the paired distances between X and Y.

Compute the distances between (X[0], Y[0]), (X[1], Y[1]), etc…

Read more in the [User Guide](../metrics.md#metrics).

* **Parameters:**
  **X**
  : Array 1 for distance computation.

  **Y**
  : Array 2 for distance computation.

  **metric**
  : The metric to use when calculating distance between instances in a
    feature array. If metric is a string, it must be one of the options
    specified in PAIRED_DISTANCES, including “euclidean”,
    “manhattan”, or “cosine”.
    Alternatively, if metric is a callable function, it is called on each
    pair of instances (rows) and the resulting value recorded. The callable
    should take two arrays from `X` as input and return a value indicating
    the distance between them.

  **\*\*kwds**
  : Unused parameters.
* **Returns:**
  **distances**
  : Returns the distances between the row vectors of `X`
    and the row vectors of `Y`.

#### SEE ALSO
[`sklearn.metrics.pairwise_distances`](sklearn.metrics.pairwise_distances.md#sklearn.metrics.pairwise_distances)
: Computes the distance between every pair of samples.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import paired_distances
>>> X = [[0, 1], [1, 1]]
>>> Y = [[0, 1], [2, 1]]
>>> paired_distances(X, Y)
array([0., 1.])
```

<!-- !! processed by numpydoc !! -->
