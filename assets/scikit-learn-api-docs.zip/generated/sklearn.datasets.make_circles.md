# make_circles

### sklearn.datasets.make_circles(n_samples=100, \*, shuffle=True, noise=None, random_state=None, factor=0.8)

Make a large circle containing a smaller circle in 2d.

A simple toy dataset to visualize clustering and classification
algorithms.

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **n_samples**
  : If int, it is the total number of points generated.
    For odd numbers, the inner circle will have one point more than the
    outer circle.
    If two-element tuple, number of points in outer circle and inner
    circle.
    <br/>
    #### Versionchanged
    Changed in version 0.23: Added two-element tuple.

  **shuffle**
  : Whether to shuffle the samples.

  **noise**
  : Standard deviation of Gaussian noise added to the data.

  **random_state**
  : Determines random number generation for dataset shuffling and noise.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **factor**
  : Scale factor between inner and outer circle in the range `[0, 1)`.
* **Returns:**
  **X**
  : The generated samples.

  **y**
  : The integer labels (0 or 1) for class membership of each sample.

### Examples

```pycon
>>> from sklearn.datasets import make_circles
>>> X, y = make_circles(random_state=42)
>>> X.shape
(100, 2)
>>> y.shape
(100,)
>>> list(y[:5])
[np.int64(1), np.int64(1), np.int64(1), np.int64(0), np.int64(0)]
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different linkage methods for hierarchical clustering on datasets that are &quot;interesting&quot; but still in 2D.">  <div class="sphx-glr-thumbnail-title">Comparing different hierarchical linkage methods on toy datasets</div>
</div>
* [Comparing different hierarchical linkage methods on toy datasets](../../auto_examples/cluster/plot_linkage_comparison.md#sphx-glr-auto-examples-cluster-plot-linkage-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows the difference between the Principal Components Analysis (~sklearn.decomposition.PCA) and its kernelized version (~sklearn.decomposition.KernelPCA).">  <div class="sphx-glr-thumbnail-title">Kernel PCA</div>
</div>
* [Kernel PCA](../../auto_examples/decomposition/plot_kernel_pca.md#sphx-glr-auto-examples-decomposition-plot-kernel-pca-py)

<div class="sphx-glr-thumbcontainer" tooltip="RandomTreesEmbedding provides a way to map data to a very high-dimensional, sparse representation, which might be beneficial for classification. The mapping is completely unsupervised and very efficient.">  <div class="sphx-glr-thumbnail-title">Hashing feature transformation using Totally Random Trees</div>
</div>
* [Hashing feature transformation using Totally Random Trees](../../auto_examples/ensemble/plot_random_forest_embedding.md#sphx-glr-auto-examples-ensemble-plot-random-forest-embedding-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of t-SNE on the two concentric circles and the S-curve datasets for different perplexity values.">  <div class="sphx-glr-thumbnail-title">t-SNE: The effect of various perplexity values on the shape</div>
</div>
* [t-SNE: The effect of various perplexity values on the shape](../../auto_examples/manifold/plot_t_sne_perplexity.md#sphx-glr-auto-examples-manifold-plot-t-sne-perplexity-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example visualizes some training loss curves for different stochastic learning strategies, including SGD and Adam. Because of time-constraints, we use several small datasets, for which L-BFGS might be more suitable. The general trend shown in these examples seems to carry over to larger datasets, however.">  <div class="sphx-glr-thumbnail-title">Compare Stochastic learning strategies for MLPClassifier</div>
</div>
* [Compare Stochastic learning strategies for MLPClassifier](../../auto_examples/neural_networks/plot_mlp_training_curves.md#sphx-glr-auto-examples-neural-networks-plot-mlp-training-curves-py)

<div class="sphx-glr-thumbcontainer" tooltip="A comparison of different values for regularization parameter &#x27;alpha&#x27; on synthetic datasets. The plot shows that different alphas yield different decision functions.">  <div class="sphx-glr-thumbnail-title">Varying regularization in Multi-layer Perceptron</div>
</div>
* [Varying regularization in Multi-layer Perceptron](../../auto_examples/neural_networks/plot_mlp_alpha.md#sphx-glr-auto-examples-neural-networks-plot-mlp-alpha-py)

<div class="sphx-glr-thumbcontainer" tooltip="A demonstration of feature discretization on synthetic classification datasets. Feature discretization decomposes each feature into a set of bins, here equally distributed in width. The discrete values are then one-hot encoded, and given to a linear classifier. This preprocessing enables a non-linear behavior even though the classifier is linear.">  <div class="sphx-glr-thumbnail-title">Feature discretization</div>
</div>
* [Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of LabelPropagation learning a complex internal structure to demonstrate &quot;manifold learning&quot;. The outer circle should be labeled &quot;red&quot; and the inner circle &quot;blue&quot;. Because both label groups lie inside their own distinct shape, we can see that the labels propagate correctly around the circle.">  <div class="sphx-glr-thumbnail-title">Label Propagation learning a complex structure</div>
</div>
* [Label Propagation learning a complex structure](../../auto_examples/semi_supervised/plot_label_propagation_structure.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-structure-py)

<!-- thumbnail-parent-div-close --></div>
