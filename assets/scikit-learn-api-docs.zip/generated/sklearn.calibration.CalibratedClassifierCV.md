# CalibratedClassifierCV

### *class* sklearn.calibration.CalibratedClassifierCV(estimator=None, \*, method='sigmoid', cv=None, n_jobs=None, ensemble='auto')

Probability calibration with isotonic regression or logistic regression.

This class uses cross-validation to both estimate the parameters of a
classifier and subsequently calibrate a classifier. With default
`ensemble=True`, for each cv split it
fits a copy of the base estimator to the training subset, and calibrates it
using the testing subset. For prediction, predicted probabilities are
averaged across these individual calibrated classifiers. When
`ensemble=False`, cross-validation is used to obtain unbiased predictions,
via [`cross_val_predict`](sklearn.model_selection.cross_val_predict.md#sklearn.model_selection.cross_val_predict), which are then
used for calibration. For prediction, the base estimator, trained using all
the data, is used. This is the prediction method implemented when
`probabilities=True` for [`SVC`](sklearn.svm.SVC.md#sklearn.svm.SVC) and [`NuSVC`](sklearn.svm.NuSVC.md#sklearn.svm.NuSVC)
estimators (see [User Guide](../svm.md#scores-probabilities) for details).

Already fitted classifiers can be calibrated by wrapping the model in a
[`FrozenEstimator`](sklearn.frozen.FrozenEstimator.md#sklearn.frozen.FrozenEstimator). In this case all provided
data is used for calibration. The user has to take care manually that data
for model fitting and calibration are disjoint.

The calibration is based on the [decision_function](../../glossary.md#term-decision_function) method of the
`estimator` if it exists, else on [predict_proba](../../glossary.md#term-predict_proba).

Read more in the [User Guide](../calibration.md#calibration).
In order to learn more on the CalibratedClassifierCV class, see the
following calibration examples:
[Probability calibration of classifiers](../../auto_examples/calibration/plot_calibration.md#sphx-glr-auto-examples-calibration-plot-calibration-py),
[Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py), and
[Probability Calibration for 3-class classification](../../auto_examples/calibration/plot_calibration_multiclass.md#sphx-glr-auto-examples-calibration-plot-calibration-multiclass-py).

* **Parameters:**
  **estimator**
  : The classifier whose output need to be calibrated to provide more
    accurate `predict_proba` outputs. The default classifier is
    a [`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC).
    <br/>
    #### Versionadded
    Added in version 1.2.

  **method**
  : The method to use for calibration. Can be ‘sigmoid’ which
    corresponds to Platt’s method (i.e. a logistic regression model) or
    ‘isotonic’ which is a non-parametric approach. It is not advised to
    use isotonic calibration with too few calibration samples
    `(<<1000)` since it tends to overfit.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross-validation,
    - integer, to specify the number of folds.
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs, if `y` is binary or multiclass,
    [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. If `y` is
    neither binary nor multiclass, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold)
    is used.
    <br/>
    Refer to the [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value if None changed from 3-fold to 5-fold.
    <br/>
    #### Versionchanged
    Changed in version 1.6: `"prefit"` is deprecated. Use [`FrozenEstimator`](sklearn.frozen.FrozenEstimator.md#sklearn.frozen.FrozenEstimator)
    instead.

  **n_jobs**
  : Number of jobs to run in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors.
    <br/>
    Base estimator clones are fitted in parallel across cross-validation
    iterations. Therefore parallelism happens only when `cv != "prefit"`.
    <br/>
    See [Glossary](../../glossary.md#term-n_jobs) for more details.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **ensemble**
  : Determines how the calibrator is fitted.
    <br/>
    “auto” will use `False` if the `estimator` is a
    [`FrozenEstimator`](sklearn.frozen.FrozenEstimator.md#sklearn.frozen.FrozenEstimator), and `True` otherwise.
    <br/>
    If `True`, the `estimator` is fitted using training data, and
    calibrated using testing data, for each `cv` fold. The final estimator
    is an ensemble of `n_cv` fitted classifier and calibrator pairs, where
    `n_cv` is the number of cross-validation folds. The output is the
    average predicted probabilities of all pairs.
    <br/>
    If `False`, `cv` is used to compute unbiased predictions, via
    [`cross_val_predict`](sklearn.model_selection.cross_val_predict.md#sklearn.model_selection.cross_val_predict), which are then
    used for calibration. At prediction time, the classifier used is the
    `estimator` trained on all the data.
    Note that this method is also internally implemented  in
    [`sklearn.svm`](../../api/sklearn.svm.md#module-sklearn.svm) estimators with the `probabilities=True` parameter.
    <br/>
    #### Versionadded
    Added in version 0.24.
    <br/>
    #### Versionchanged
    Changed in version 1.6: `"auto"` option is added and is the default.
* **Attributes:**
  **classes_**
  : The class labels.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **calibrated_classifiers_**
  : The list of classifier and calibrator pairs.
    - When `ensemble=True`, `n_cv` fitted `estimator` and calibrator pairs.
      `n_cv` is the number of cross-validation folds.
    - When `ensemble=False`, the `estimator`, fitted on all the data, and fitted
      calibrator.
    <br/>
    #### Versionchanged
    Changed in version 0.24: Single calibrated classifier case when `ensemble=False`.

#### SEE ALSO
[`calibration_curve`](sklearn.calibration.calibration_curve.md#sklearn.calibration.calibration_curve)
: Compute true and predicted probabilities for a calibration curve.

### References

### Examples

```pycon
>>> from sklearn.datasets import make_classification
>>> from sklearn.naive_bayes import GaussianNB
>>> from sklearn.calibration import CalibratedClassifierCV
>>> X, y = make_classification(n_samples=100, n_features=2,
...                            n_redundant=0, random_state=42)
>>> base_clf = GaussianNB()
>>> calibrated_clf = CalibratedClassifierCV(base_clf, cv=3)
>>> calibrated_clf.fit(X, y)
CalibratedClassifierCV(...)
>>> len(calibrated_clf.calibrated_classifiers_)
3
>>> calibrated_clf.predict_proba(X)[:5, :]
array([[0.110..., 0.889...],
       [0.072..., 0.927...],
       [0.928..., 0.071...],
       [0.928..., 0.071...],
       [0.071..., 0.928...]])
>>> from sklearn.model_selection import train_test_split
>>> X, y = make_classification(n_samples=100, n_features=2,
...                            n_redundant=0, random_state=42)
>>> X_train, X_calib, y_train, y_calib = train_test_split(
...        X, y, random_state=42
... )
>>> base_clf = GaussianNB()
>>> base_clf.fit(X_train, y_train)
GaussianNB()
>>> from sklearn.frozen import FrozenEstimator
>>> calibrated_clf = CalibratedClassifierCV(FrozenEstimator(base_clf))
>>> calibrated_clf.fit(X_calib, y_calib)
CalibratedClassifierCV(...)
>>> len(calibrated_clf.calibrated_classifiers_)
1
>>> calibrated_clf.predict_proba([[-0.5, 0.5]])
array([[0.936..., 0.063...]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, \*\*fit_params)

Fit the calibrated model.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted.

  **\*\*fit_params**
  : Parameters to pass to the `fit` method of the underlying
    classifier.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict the target of new samples.

The predicted class is the class that has the highest probability,
and can thus be different from the prediction of the uncalibrated classifier.

* **Parameters:**
  **X**
  : The samples, as accepted by `estimator.predict`.
* **Returns:**
  **C**
  : The predicted class.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Calibrated probabilities of classification.

This function returns calibrated probabilities of classification
according to each class on an array of test vectors X.

* **Parameters:**
  **X**
  : The samples, as accepted by `estimator.predict_proba`.
* **Returns:**
  **C**
  : The predicted probas.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [CalibratedClassifierCV](#sklearn.calibration.CalibratedClassifierCV)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [CalibratedClassifierCV](#sklearn.calibration.CalibratedClassifierCV)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="When performing classification one often wants to predict not only the class label, but also the associated probability. This probability gives some kind of confidence on the prediction. This example demonstrates how to visualize how well calibrated the predicted probabilities are using calibration curves, also known as reliability diagrams. Calibration of an uncalibrated classifier will also be demonstrated.">  <div class="sphx-glr-thumbnail-title">Probability Calibration curves</div>
</div>
* [Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how sigmoid calibration changes predicted probabilities for a 3-class classification problem. Illustrated is the standard 2-simplex, where the three corners correspond to the three classes. Arrows point from the probability vectors predicted by an uncalibrated classifier to the probability vectors predicted by the same classifier after sigmoid calibration on a hold-out validation set. Colors indicate the true class of an instance (red: class 1, green: class 2, blue: class 3).">  <div class="sphx-glr-thumbnail-title">Probability Calibration for 3-class classification</div>
</div>
* [Probability Calibration for 3-class classification](../../auto_examples/calibration/plot_calibration_multiclass.md#sphx-glr-auto-examples-calibration-plot-calibration-multiclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="When performing classification you often want to predict not only the class label, but also the associated probability. This probability gives you some kind of confidence on the prediction. However, not all classifiers provide well-calibrated probabilities, some being over-confident while others being under-confident. Thus, a separate calibration of predicted probabilities is often desirable as a postprocessing. This example illustrates two different methods for this calibration and evaluates the quality of the returned probabilities using Brier&#x27;s score (see https://en.wikipedia.org/wiki/Brier_score).">  <div class="sphx-glr-thumbnail-title">Probability calibration of classifiers</div>
</div>
* [Probability calibration of classifiers](../../auto_examples/calibration/plot_calibration.md#sphx-glr-auto-examples-calibration-plot-calibration-py)

<div class="sphx-glr-thumbcontainer" tooltip="This examples showcases some use cases of FrozenEstimator.">  <div class="sphx-glr-thumbnail-title">Examples of Using FrozenEstimator</div>
</div>
* [Examples of Using FrozenEstimator](../../auto_examples/frozen/plot_frozen_examples.md#sphx-glr-auto-examples-frozen-plot-frozen-examples-py)

<!-- thumbnail-parent-div-close --></div>
