# SpectralClustering

### *class* sklearn.cluster.SpectralClustering(n_clusters=8, \*, eigen_solver=None, n_components=None, random_state=None, n_init=10, gamma=1.0, affinity='rbf', n_neighbors=10, eigen_tol='auto', assign_labels='kmeans', degree=3, coef0=1, kernel_params=None, n_jobs=None, verbose=False)

Apply clustering to a projection of the normalized Laplacian.

In practice Spectral Clustering is very useful when the structure of
the individual clusters is highly non-convex, or more generally when
a measure of the center and spread of the cluster is not a suitable
description of the complete cluster, such as when clusters are
nested circles on the 2D plane.

If the affinity matrix is the adjacency matrix of a graph, this method
can be used to find normalized graph cuts [[1]](#r5f6cbeb1558e-1), [[2]](#r5f6cbeb1558e-2).

When calling `fit`, an affinity matrix is constructed using either
a kernel function such the Gaussian (aka RBF) kernel with Euclidean
distance `d(X, X)`:

```default
np.exp(-gamma * d(X,X) ** 2)
```

or a k-nearest neighbors connectivity matrix.

Alternatively, a user-provided affinity matrix can be specified by
setting `affinity='precomputed'`.

Read more in the [User Guide](../clustering.md#spectral-clustering).

* **Parameters:**
  **n_clusters**
  : The dimension of the projection subspace.

  **eigen_solver**
  : The eigenvalue decomposition strategy to use. AMG requires pyamg
    to be installed. It can be faster on very large, sparse problems,
    but may also lead to instabilities. If None, then `'arpack'` is
    used. See [[4]](#r5f6cbeb1558e-4) for more details regarding `'lobpcg'`.

  **n_components**
  : Number of eigenvectors to use for the spectral embedding. If None,
    defaults to `n_clusters`.

  **random_state**
  : A pseudo random number generator used for the initialization
    of the lobpcg eigenvectors decomposition when `eigen_solver ==
    'amg'`, and for the K-Means initialization. Use an int to make
    the results deterministic across calls (See
    [Glossary](../../glossary.md#term-random_state)).
    <br/>
    #### NOTE
    When using `eigen_solver == 'amg'`,
    it is necessary to also fix the global numpy seed with
    `np.random.seed(int)` to get deterministic results. See
    [https://github.com/pyamg/pyamg/issues/139](https://github.com/pyamg/pyamg/issues/139) for further
    information.

  **n_init**
  : Number of time the k-means algorithm will be run with different
    centroid seeds. The final results will be the best output of n_init
    consecutive runs in terms of inertia. Only used if
    `assign_labels='kmeans'`.

  **gamma**
  : Kernel coefficient for rbf, poly, sigmoid, laplacian and chi2 kernels.
    Ignored for `affinity='nearest_neighbors'`, `affinity='precomputed'`
    or `affinity='precomputed_nearest_neighbors'`.

  **affinity**
  : How to construct the affinity matrix.
    : - ‘nearest_neighbors’: construct the affinity matrix by computing a
        graph of nearest neighbors.
      - ‘rbf’: construct the affinity matrix using a radial basis function
        (RBF) kernel.
      - ‘precomputed’: interpret `X` as a precomputed affinity matrix,
        where larger values indicate greater similarity between instances.
      - ‘precomputed_nearest_neighbors’: interpret `X` as a sparse graph
        of precomputed distances, and construct a binary affinity matrix
        from the `n_neighbors` nearest neighbors of each instance.
      - one of the kernels supported by
        [`pairwise_kernels`](sklearn.metrics.pairwise.pairwise_kernels.md#sklearn.metrics.pairwise.pairwise_kernels).
    <br/>
    Only kernels that produce similarity scores (non-negative values that
    increase with similarity) should be used. This property is not checked
    by the clustering algorithm.

  **n_neighbors**
  : Number of neighbors to use when constructing the affinity matrix using
    the nearest neighbors method. Ignored for `affinity='rbf'`.

  **eigen_tol**
  : Stopping criterion for eigen decomposition of the Laplacian matrix.
    If `eigen_tol="auto"` then the passed tolerance will depend on the
    `eigen_solver`:
    - If `eigen_solver="arpack"`, then `eigen_tol=0.0`;
    - If `eigen_solver="lobpcg"` or `eigen_solver="amg"`, then
      `eigen_tol=None` which configures the underlying `lobpcg` solver to
      automatically resolve the value according to their heuristics. See,
      [`scipy.sparse.linalg.lobpcg`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.lobpcg.html#scipy.sparse.linalg.lobpcg) for details.
    <br/>
    Note that when using `eigen_solver="lobpcg"` or `eigen_solver="amg"`
    values of `tol<1e-5` may lead to convergence issues and should be
    avoided.
    <br/>
    #### Versionadded
    Added in version 1.2: Added ‘auto’ option.

  **assign_labels**
  : The strategy for assigning labels in the embedding space. There are two
    ways to assign labels after the Laplacian embedding. k-means is a
    popular choice, but it can be sensitive to initialization.
    Discretization is another approach which is less sensitive to random
    initialization [[3]](#r5f6cbeb1558e-3).
    The cluster_qr method [[5]](#r5f6cbeb1558e-5) directly extract clusters from eigenvectors
    in spectral clustering. In contrast to k-means and discretization, cluster_qr
    has no tuning parameters and runs no iterations, yet may outperform
    k-means and discretization in terms of both quality and speed.
    <br/>
    #### Versionchanged
    Changed in version 1.1: Added new labeling method ‘cluster_qr’.

  **degree**
  : Degree of the polynomial kernel. Ignored by other kernels.

  **coef0**
  : Zero coefficient for polynomial and sigmoid kernels.
    Ignored by other kernels.

  **kernel_params**
  : Parameters (keyword arguments) and values for kernel passed as
    callable object. Ignored by other kernels.

  **n_jobs**
  : The number of parallel jobs to run when `affinity='nearest_neighbors'`
    or `affinity='precomputed_nearest_neighbors'`. The neighbors search
    will be done in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **verbose**
  : Verbosity mode.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  **affinity_matrix_**
  : Affinity matrix used for clustering. Available only after calling
    `fit`.

  **labels_**
  : Labels of each point

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`sklearn.cluster.KMeans`](sklearn.cluster.KMeans.md#sklearn.cluster.KMeans)
: K-Means clustering.

[`sklearn.cluster.DBSCAN`](sklearn.cluster.DBSCAN.md#sklearn.cluster.DBSCAN)
: Density-Based Spatial Clustering of Applications with Noise.

### Notes

A distance matrix for which 0 indicates identical elements and high values
indicate very dissimilar elements can be transformed into an affinity /
similarity matrix that is well-suited for the algorithm by
applying the Gaussian (aka RBF, heat) kernel:

```default
np.exp(- dist_matrix ** 2 / (2. * delta ** 2))
```

where `delta` is a free parameter representing the width of the Gaussian
kernel.

An alternative is to take a symmetric version of the k-nearest neighbors
connectivity matrix of the points.

If the pyamg package is installed, it is used: this greatly
speeds up computation.

### References

### Examples

```pycon
>>> from sklearn.cluster import SpectralClustering
>>> import numpy as np
>>> X = np.array([[1, 1], [2, 1], [1, 0],
...               [4, 7], [3, 5], [3, 6]])
>>> clustering = SpectralClustering(n_clusters=2,
...         assign_labels='discretize',
...         random_state=0).fit(X)
>>> clustering.labels_
array([1, 1, 1, 0, 0, 0])
>>> clustering
SpectralClustering(assign_labels='discretize', n_clusters=2,
    random_state=0)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Perform spectral clustering from features, or affinity matrix.

* **Parameters:**
  **X**
  : Training instances to cluster, similarities / affinities between
    instances if `affinity='precomputed'`, or distances between
    instances if `affinity='precomputed_nearest_neighbors`. If a
    sparse matrix is provided in a format other than `csr_matrix`,
    `csc_matrix`, or `coo_matrix`, it will be converted into a
    sparse `csr_matrix`.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : A fitted instance of the estimator.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None)

Perform spectral clustering on `X` and return cluster labels.

* **Parameters:**
  **X**
  : Training instances to cluster, similarities / affinities between
    instances if `affinity='precomputed'`, or distances between
    instances if `affinity='precomputed_nearest_neighbors`. If a
    sparse matrix is provided in a format other than `csr_matrix`,
    `csc_matrix`, or `coo_matrix`, it will be converted into a
    sparse `csr_matrix`.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **labels**
  : Cluster labels.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<!-- thumbnail-parent-div-close --></div>
