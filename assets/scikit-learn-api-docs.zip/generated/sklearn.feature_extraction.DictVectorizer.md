# DictVectorizer

### *class* sklearn.feature_extraction.DictVectorizer(\*, dtype=<class 'numpy.float64'>, separator='=', sparse=True, sort=True)

Transforms lists of feature-value mappings to vectors.

This transformer turns lists of mappings (dict-like objects) of feature
names to feature values into Numpy arrays or scipy.sparse matrices for use
with scikit-learn estimators.

When feature values are strings, this transformer will do a binary one-hot
(aka one-of-K) coding: one boolean-valued feature is constructed for each
of the possible string values that the feature can take on. For instance,
a feature “f” that can take on the values “ham” and “spam” will become two
features in the output, one signifying “f=ham”, the other “f=spam”.

If a feature value is a sequence or set of strings, this transformer
will iterate over the values and will count the occurrences of each string
value.

However, note that this transformer will only do a binary one-hot encoding
when feature values are of type string. If categorical features are
represented as numeric values such as int or iterables of strings, the
DictVectorizer can be followed by
[`OneHotEncoder`](sklearn.preprocessing.OneHotEncoder.md#sklearn.preprocessing.OneHotEncoder) to complete
binary one-hot encoding.

Features that do not occur in a sample (mapping) will have a zero value
in the resulting array/matrix.

For an efficiency comparison of the different feature extractors, see
[FeatureHasher and DictVectorizer Comparison](../../auto_examples/text/plot_hashing_vs_dict_vectorizer.md#sphx-glr-auto-examples-text-plot-hashing-vs-dict-vectorizer-py).

Read more in the [User Guide](../feature_extraction.md#dict-feature-extraction).

* **Parameters:**
  **dtype**
  : The type of feature values. Passed to Numpy array/scipy.sparse matrix
    constructors as the dtype argument.

  **separator**
  : Separator string used when constructing new features for one-hot
    coding.

  **sparse**
  : Whether transform should produce scipy.sparse matrices.

  **sort**
  : Whether `feature_names_` and `vocabulary_` should be
    sorted when fitting.
* **Attributes:**
  **vocabulary_**
  : A dictionary mapping feature names to feature indices.

  **feature_names_**
  : A list of length n_features containing the feature names (e.g., “f=ham”
    and “f=spam”).

#### SEE ALSO
[`FeatureHasher`](sklearn.feature_extraction.FeatureHasher.md#sklearn.feature_extraction.FeatureHasher)
: Performs vectorization using only a hash function.

[`sklearn.preprocessing.OrdinalEncoder`](sklearn.preprocessing.OrdinalEncoder.md#sklearn.preprocessing.OrdinalEncoder)
: Handles nominal/categorical features encoded as columns of arbitrary data types.

### Examples

```pycon
>>> from sklearn.feature_extraction import DictVectorizer
>>> v = DictVectorizer(sparse=False)
>>> D = [{'foo': 1, 'bar': 2}, {'foo': 3, 'baz': 1}]
>>> X = v.fit_transform(D)
>>> X
array([[2., 0., 1.],
       [0., 1., 3.]])
>>> v.inverse_transform(X) == [{'bar': 2.0, 'foo': 1.0},
...                            {'baz': 1.0, 'foo': 3.0}]
True
>>> v.transform({'foo': 4, 'unseen_feature': 3})
array([[0., 0., 4.]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Learn a list of feature name -> indices mappings.

* **Parameters:**
  **X**
  : Dict(s) or Mapping(s) from feature names (arbitrary Python
    objects) to feature values (strings or convertible to dtype).
    <br/>
    #### Versionchanged
    Changed in version 0.24: Accepts multiple string values for one categorical feature.

  **y**
  : Ignored parameter.
* **Returns:**
  **self**
  : DictVectorizer class instance.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Learn a list of feature name -> indices mappings and transform X.

Like fit(X) followed by transform(X), but does not require
materializing X in memory.

* **Parameters:**
  **X**
  : Dict(s) or Mapping(s) from feature names (arbitrary Python
    objects) to feature values (strings or convertible to dtype).
    <br/>
    #### Versionchanged
    Changed in version 0.24: Accepts multiple string values for one categorical feature.

  **y**
  : Ignored parameter.
* **Returns:**
  **Xa**
  : Feature vectors; always 2-d.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X, dict_type=<class 'dict'>)

Transform array or sparse matrix X back to feature mappings.

X must have been produced by this DictVectorizer’s transform or
fit_transform method; it may only have passed through transformers
that preserve the number of features and their order.

In the case of one-hot/one-of-K coding, the constructed feature
names and values are returned rather than the original ones.

* **Parameters:**
  **X**
  : Sample matrix.

  **dict_type**
  : Constructor for feature mappings. Must conform to the
    collections.Mapping API.
* **Returns:**
  **D**
  : Feature mappings for the samples in X.

<!-- !! processed by numpydoc !! -->

#### restrict(support, indices=False)

Restrict the features to those in support using feature selection.

This function modifies the estimator in-place.

* **Parameters:**
  **support**
  : Boolean mask or list of indices (as returned by the get_support
    member of feature selectors).

  **indices**
  : Whether support is a list of indices.
* **Returns:**
  **self**
  : DictVectorizer class instance.

### Examples

```pycon
>>> from sklearn.feature_extraction import DictVectorizer
>>> from sklearn.feature_selection import SelectKBest, chi2
>>> v = DictVectorizer()
>>> D = [{'foo': 1, 'bar': 2}, {'foo': 3, 'baz': 1}]
>>> X = v.fit_transform(D)
>>> support = SelectKBest(chi2, k=2).fit(X, [0, 1])
>>> v.get_feature_names_out()
array(['bar', 'baz', 'foo'], ...)
>>> v.restrict(support.get_support())
DictVectorizer()
>>> v.get_feature_names_out()
array(['bar', 'foo'], ...)
```

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform feature->value dicts to array or sparse matrix.

Named features not encountered during fit or fit_transform will be
silently ignored.

* **Parameters:**
  **X**
  : Dict(s) or Mapping(s) from feature names (arbitrary Python
    objects) to feature values (strings or convertible to dtype).
* **Returns:**
  **Xa**
  : Feature vectors; always 2-d.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Datasets can often contain components that require different feature extraction and processing pipelines. This scenario might occur when:">  <div class="sphx-glr-thumbnail-title">Column Transformer with Heterogeneous Data Sources</div>
</div>
* [Column Transformer with Heterogeneous Data Sources](../../auto_examples/compose/plot_column_transformer.md#sphx-glr-auto-examples-compose-plot-column-transformer-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we illustrate text vectorization, which is the process of representing non-numerical input data (such as dictionaries or text documents) as vectors of real numbers.">  <div class="sphx-glr-thumbnail-title">FeatureHasher and DictVectorizer Comparison</div>
</div>
* [FeatureHasher and DictVectorizer Comparison](../../auto_examples/text/plot_hashing_vs_dict_vectorizer.md#sphx-glr-auto-examples-text-plot-hashing-vs-dict-vectorizer-py)

<!-- thumbnail-parent-div-close --></div>
