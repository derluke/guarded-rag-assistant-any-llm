# export_text

### sklearn.tree.export_text(decision_tree, \*, feature_names=None, class_names=None, max_depth=10, spacing=3, decimals=2, show_weights=False)

Build a text report showing the rules of a decision tree.

Note that backwards compatibility may not be supported.

* **Parameters:**
  **decision_tree**
  : The decision tree estimator to be exported.
    It can be an instance of
    DecisionTreeClassifier or DecisionTreeRegressor.

  **feature_names**
  : An array containing the feature names.
    If None generic names will be used (“feature_0”, “feature_1”, …).

  **class_names**
  : Names of each of the target classes in ascending numerical order.
    Only relevant for classification and not supported for multi-output.
    - if `None`, the class names are delegated to `decision_tree.classes_`;
    - otherwise, `class_names` will be used as class names instead of
      `decision_tree.classes_`. The length of `class_names` must match
      the length of `decision_tree.classes_`.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **max_depth**
  : Only the first max_depth levels of the tree are exported.
    Truncated branches will be marked with “…”.

  **spacing**
  : Number of spaces between edges. The higher it is, the wider the result.

  **decimals**
  : Number of decimal digits to display.

  **show_weights**
  : If true the classification weights will be exported on each leaf.
    The classification weights are the number of samples each class.
* **Returns:**
  **report**
  : Text summary of all the rules in the decision tree.

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn.tree import DecisionTreeClassifier
>>> from sklearn.tree import export_text
>>> iris = load_iris()
>>> X = iris['data']
>>> y = iris['target']
>>> decision_tree = DecisionTreeClassifier(random_state=0, max_depth=2)
>>> decision_tree = decision_tree.fit(X, y)
>>> r = export_text(decision_tree, feature_names=iris['feature_names'])
>>> print(r)
|--- petal width (cm) <= 0.80
|   |--- class: 0
|--- petal width (cm) >  0.80
|   |--- petal width (cm) <= 1.75
|   |   |--- class: 1
|   |--- petal width (cm) >  1.75
|   |   |--- class: 2
```

<!-- !! processed by numpydoc !! -->
