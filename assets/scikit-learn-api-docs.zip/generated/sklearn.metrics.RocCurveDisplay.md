# RocCurveDisplay

### *class* sklearn.metrics.RocCurveDisplay(\*, fpr, tpr, roc_auc=None, estimator_name=None, pos_label=None)

ROC Curve visualization.

It is recommend to use
[`from_estimator`](#sklearn.metrics.RocCurveDisplay.from_estimator) or
[`from_predictions`](#sklearn.metrics.RocCurveDisplay.from_predictions) to create
a [`RocCurveDisplay`](#sklearn.metrics.RocCurveDisplay). All parameters are
stored as attributes.

Read more in the [User Guide](../../visualizations.md#visualizations).

* **Parameters:**
  **fpr**
  : False positive rate.

  **tpr**
  : True positive rate.

  **roc_auc**
  : Area under ROC curve. If None, the roc_auc score is not shown.

  **estimator_name**
  : Name of estimator. If None, the estimator name is not shown.

  **pos_label**
  : The class considered as the positive class when computing the roc auc
    metrics. By default, `estimators.classes_[1]` is considered
    as the positive class.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  **line_**
  : ROC Curve.

  **chance_level_**
  : The chance level line. It is `None` if the chance level is not plotted.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **ax_**
  : Axes with ROC Curve.

  **figure_**
  : Figure containing the curve.

#### SEE ALSO
[`roc_curve`](sklearn.metrics.roc_curve.md#sklearn.metrics.roc_curve)
: Compute Receiver operating characteristic (ROC) curve.

[`RocCurveDisplay.from_estimator`](#sklearn.metrics.RocCurveDisplay.from_estimator)
: Plot Receiver Operating Characteristic (ROC) curve given an estimator and some data.

[`RocCurveDisplay.from_predictions`](#sklearn.metrics.RocCurveDisplay.from_predictions)
: Plot Receiver Operating Characteristic (ROC) curve given the true and predicted values.

[`roc_auc_score`](sklearn.metrics.roc_auc_score.md#sklearn.metrics.roc_auc_score)
: Compute the area under the ROC curve.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> import numpy as np
>>> from sklearn import metrics
>>> y = np.array([0, 0, 1, 1])
>>> pred = np.array([0.1, 0.4, 0.35, 0.8])
>>> fpr, tpr, thresholds = metrics.roc_curve(y, pred)
>>> roc_auc = metrics.auc(fpr, tpr)
>>> display = metrics.RocCurveDisplay(fpr=fpr, tpr=tpr, roc_auc=roc_auc,
...                                   estimator_name='example estimator')
>>> display.plot()
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-RocCurveDisplay-1.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_estimator(estimator, X, y, \*, sample_weight=None, drop_intermediate=True, response_method='auto', pos_label=None, name=None, ax=None, plot_chance_level=False, chance_level_kw=None, despine=False, \*\*kwargs)

Create a ROC Curve display from an estimator.

* **Parameters:**
  **estimator**
  : Fitted classifier or a fitted [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)
    in which the last estimator is a classifier.

  **X**
  : Input values.

  **y**
  : Target values.

  **sample_weight**
  : Sample weights.

  **drop_intermediate**
  : Whether to drop some suboptimal thresholds which would not appear
    on a plotted ROC curve. This is useful in order to create lighter
    ROC curves.

  **response_method**
  : Specifies whether to use [predict_proba](../../glossary.md#term-predict_proba) or
    [decision_function](../../glossary.md#term-decision_function) as the target response. If set to ‘auto’,
    [predict_proba](../../glossary.md#term-predict_proba) is tried first and if it does not exist
    [decision_function](../../glossary.md#term-decision_function) is tried next.

  **pos_label**
  : The class considered as the positive class when computing the roc auc
    metrics. By default, `estimators.classes_[1]` is considered
    as the positive class.

  **name**
  : Name of ROC Curve for labeling. If `None`, use the name of the
    estimator.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is created.

  **plot_chance_level**
  : Whether to plot the chance level.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **chance_level_kw**
  : Keyword arguments to be passed to matplotlib’s `plot` for rendering
    the chance level line.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **despine**
  : Whether to remove the top and right spines from the plot.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **\*\*kwargs**
  : Keyword arguments to be passed to matplotlib’s `plot`.
* **Returns:**
  **display**
  : The ROC Curve display.

#### SEE ALSO
[`roc_curve`](sklearn.metrics.roc_curve.md#sklearn.metrics.roc_curve)
: Compute Receiver operating characteristic (ROC) curve.

[`RocCurveDisplay.from_predictions`](#sklearn.metrics.RocCurveDisplay.from_predictions)
: ROC Curve visualization given the probabilities of scores of a classifier.

[`roc_auc_score`](sklearn.metrics.roc_auc_score.md#sklearn.metrics.roc_auc_score)
: Compute the area under the ROC curve.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import RocCurveDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.svm import SVC
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, random_state=0)
>>> clf = SVC(random_state=0).fit(X_train, y_train)
>>> RocCurveDisplay.from_estimator(
...    clf, X_test, y_test)
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-RocCurveDisplay-2.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_predictions(y_true, y_pred, \*, sample_weight=None, drop_intermediate=True, pos_label=None, name=None, ax=None, plot_chance_level=False, chance_level_kw=None, despine=False, \*\*kwargs)

Plot ROC curve given the true and predicted values.

Read more in the [User Guide](../../visualizations.md#visualizations).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **y_true**
  : True labels.

  **y_pred**
  : Target scores, can either be probability estimates of the positive
    class, confidence values, or non-thresholded measure of decisions
    (as returned by “decision_function” on some classifiers).

  **sample_weight**
  : Sample weights.

  **drop_intermediate**
  : Whether to drop some suboptimal thresholds which would not appear
    on a plotted ROC curve. This is useful in order to create lighter
    ROC curves.

  **pos_label**
  : The label of the positive class. When `pos_label=None`, if `y_true`
    is in {-1, 1} or {0, 1}, `pos_label` is set to 1, otherwise an
    error will be raised.

  **name**
  : Name of ROC curve for labeling. If `None`, name will be set to
    `"Classifier"`.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **plot_chance_level**
  : Whether to plot the chance level.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **chance_level_kw**
  : Keyword arguments to be passed to matplotlib’s `plot` for rendering
    the chance level line.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **despine**
  : Whether to remove the top and right spines from the plot.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **\*\*kwargs**
  : Additional keywords arguments passed to matplotlib `plot` function.
* **Returns:**
  **display**
  : Object that stores computed values.

#### SEE ALSO
[`roc_curve`](sklearn.metrics.roc_curve.md#sklearn.metrics.roc_curve)
: Compute Receiver operating characteristic (ROC) curve.

[`RocCurveDisplay.from_estimator`](#sklearn.metrics.RocCurveDisplay.from_estimator)
: ROC Curve visualization given an estimator and some data.

[`roc_auc_score`](sklearn.metrics.roc_auc_score.md#sklearn.metrics.roc_auc_score)
: Compute the area under the ROC curve.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import RocCurveDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.svm import SVC
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, random_state=0)
>>> clf = SVC(random_state=0).fit(X_train, y_train)
>>> y_pred = clf.decision_function(X_test)
>>> RocCurveDisplay.from_predictions(
...    y_test, y_pred)
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-RocCurveDisplay-3.*)
<!-- !! processed by numpydoc !! -->

#### plot(ax=None, \*, name=None, plot_chance_level=False, chance_level_kw=None, despine=False, \*\*kwargs)

Plot visualization.

Extra keyword arguments will be passed to matplotlib’s `plot`.

* **Parameters:**
  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **name**
  : Name of ROC Curve for labeling. If `None`, use `estimator_name` if
    not `None`, otherwise no labeling is shown.

  **plot_chance_level**
  : Whether to plot the chance level.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **chance_level_kw**
  : Keyword arguments to be passed to matplotlib’s `plot` for rendering
    the chance level line.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **despine**
  : Whether to remove the top and right spines from the plot.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **\*\*kwargs**
  : Keyword arguments to be passed to matplotlib’s `plot`.
* **Returns:**
  **display**
  : Object that stores computed values.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="Transform your features into a higher dimensional, sparse space. Then train a linear model on these features.">  <div class="sphx-glr-thumbnail-title">Feature transformations with ensembles of trees</div>
</div>
* [Feature transformations with ensembles of trees](../../auto_examples/ensemble/plot_feature_transformation.md#sphx-glr-auto-examples-ensemble-plot-feature-transformation-py)

<div class="sphx-glr-thumbcontainer" tooltip="ROC Curve with Visualization API">  <div class="sphx-glr-thumbnail-title">ROC Curve with Visualization API</div>
</div>
* [ROC Curve with Visualization API](../../auto_examples/miscellaneous/plot_roc_curve_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-roc-curve-visualization-api-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we compare two binary classification multi-threshold metrics: the Receiver Operating Characteristic (ROC) and the Detection Error Tradeoff (DET). For such purpose, we evaluate two different classifiers for the same classification task.">  <div class="sphx-glr-thumbnail-title">Detection error tradeoff (DET) curve</div>
</div>
* [Detection error tradeoff (DET) curve](../../auto_examples/model_selection/plot_det.md#sphx-glr-auto-examples-model-selection-plot-det-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents how to estimate and visualize the variance of the Receiver Operating Characteristic (ROC) metric using cross-validation.">  <div class="sphx-glr-thumbnail-title">Receiver Operating Characteristic (ROC) with cross validation</div>
</div>
* [Receiver Operating Characteristic (ROC) with cross validation](../../auto_examples/model_selection/plot_roc_crossval.md#sphx-glr-auto-examples-model-selection-plot-roc-crossval-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example describes the use of the Receiver Operating Characteristic (ROC) metric to evaluate the quality of multiclass classifiers.">  <div class="sphx-glr-thumbnail-title">Multiclass Receiver Operating Characteristic (ROC)</div>
</div>
* [Multiclass Receiver Operating Characteristic (ROC)](../../auto_examples/model_selection/plot_roc.md#sphx-glr-auto-examples-model-selection-plot-roc-py)

<div class="sphx-glr-thumbcontainer" tooltip="ROC Curve with Visualization API">  <div class="sphx-glr-thumbnail-title">ROC Curve with Visualization API</div>
</div>
* [ROC Curve with Visualization API](../../auto_examples/miscellaneous/plot_roc_curve_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-roc-curve-visualization-api-py)

<!-- thumbnail-parent-div-close --></div>
