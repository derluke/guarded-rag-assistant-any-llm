# rbf_kernel

### sklearn.metrics.pairwise.rbf_kernel(X, Y=None, gamma=None)

Compute the rbf (gaussian) kernel between X and Y.

```text
K(x, y) = exp(-gamma ||x-y||^2)
```

for each pair of rows x in X and y in Y.

Read more in the [User Guide](../metrics.md#rbf-kernel).

* **Parameters:**
  **X**
  : A feature array.

  **Y**
  : An optional second feature array. If `None`, uses `Y=X`.

  **gamma**
  : If None, defaults to 1.0 / n_features.
* **Returns:**
  **kernel**
  : The RBF kernel.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import rbf_kernel
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> rbf_kernel(X, Y)
array([[0.71..., 0.51...],
       [0.51..., 0.71...]])
```

<!-- !! processed by numpydoc !! -->
