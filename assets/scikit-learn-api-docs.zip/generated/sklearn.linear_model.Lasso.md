# Lasso

### *class* sklearn.linear_model.Lasso(alpha=1.0, \*, fit_intercept=True, precompute=False, copy_X=True, max_iter=1000, tol=0.0001, warm_start=False, positive=False, random_state=None, selection='cyclic')

Linear Model trained with L1 prior as regularizer (aka the Lasso).

The optimization objective for Lasso is:

```default
(1 / (2 * n_samples)) * ||y - Xw||^2_2 + alpha * ||w||_1
```

Technically the Lasso model is optimizing the same objective function as
the Elastic Net with `l1_ratio=1.0` (no L2 penalty).

Read more in the [User Guide](../linear_model.md#lasso).

* **Parameters:**
  **alpha**
  : Constant that multiplies the L1 term, controlling regularization
    strength. `alpha` must be a non-negative float i.e. in `[0, inf)`.
    <br/>
    When `alpha = 0`, the objective is equivalent to ordinary least
    squares, solved by the [`LinearRegression`](sklearn.linear_model.LinearRegression.md#sklearn.linear_model.LinearRegression) object. For numerical
    reasons, using `alpha = 0` with the `Lasso` object is not advised.
    Instead, you should use the [`LinearRegression`](sklearn.linear_model.LinearRegression.md#sklearn.linear_model.LinearRegression) object.

  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to False, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **precompute**
  : Whether to use a precomputed Gram matrix to speed up
    calculations. The Gram matrix can also be passed as argument.
    For sparse input this option is always `False` to preserve sparsity.

  **copy_X**
  : If `True`, X will be copied; else, it may be overwritten.

  **max_iter**
  : The maximum number of iterations.

  **tol**
  : The tolerance for the optimization: if the updates are
    smaller than `tol`, the optimization code checks the
    dual gap for optimality and continues until it is smaller
    than `tol`, see Notes below.

  **warm_start**
  : When set to True, reuse the solution of the previous call to fit as
    initialization, otherwise, just erase the previous solution.
    See [the Glossary](../../glossary.md#term-warm_start).

  **positive**
  : When set to `True`, forces the coefficients to be positive.

  **random_state**
  : The seed of the pseudo random number generator that selects a random
    feature to update. Used when `selection` == ‘random’.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **selection**
  : If set to ‘random’, a random coefficient is updated every iteration
    rather than looping over features sequentially by default. This
    (setting to ‘random’) often leads to significantly faster convergence
    especially when tol is higher than 1e-4.
* **Attributes:**
  **coef_**
  : Parameter vector (w in the cost function formula).

  **dual_gap_**
  : Given param alpha, the dual gaps at the end of the optimization,
    same shape as each observation of y.

  [`sparse_coef_`](#sklearn.linear_model.Lasso.sparse_coef_)
  : Sparse representation of the fitted `coef_`.

  **intercept_**
  : Independent term in decision function.

  **n_iter_**
  : Number of iterations run by the coordinate descent solver to reach
    the specified tolerance.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`lars_path`](sklearn.linear_model.lars_path.md#sklearn.linear_model.lars_path)
: Regularization path using LARS.

[`lasso_path`](sklearn.linear_model.lasso_path.md#sklearn.linear_model.lasso_path)
: Regularization path using Lasso.

[`LassoLars`](sklearn.linear_model.LassoLars.md#sklearn.linear_model.LassoLars)
: Lasso Path along the regularization parameter using LARS algorithm.

[`LassoCV`](sklearn.linear_model.LassoCV.md#sklearn.linear_model.LassoCV)
: Lasso alpha parameter by cross-validation.

[`LassoLarsCV`](sklearn.linear_model.LassoLarsCV.md#sklearn.linear_model.LassoLarsCV)
: Lasso least angle parameter algorithm by cross-validation.

[`sklearn.decomposition.sparse_encode`](sklearn.decomposition.sparse_encode.md#sklearn.decomposition.sparse_encode)
: Sparse coding array estimator.

### Notes

The algorithm used to fit the model is coordinate descent.

To avoid unnecessary memory duplication the X argument of the fit method
should be directly passed as a Fortran-contiguous numpy array.

Regularization improves the conditioning of the problem and
reduces the variance of the estimates. Larger values specify stronger
regularization. Alpha corresponds to `1 / (2C)` in other linear
models such as [`LogisticRegression`](sklearn.linear_model.LogisticRegression.md#sklearn.linear_model.LogisticRegression) or
[`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC). If an array is passed, penalties are
assumed to be specific to the targets. Hence they must correspond in
number.

The precise stopping criteria based on `tol` are the following: First, check that
that maximum coordinate update, i.e. $\max_j |w_j^{new} - w_j^{old}|$
is smaller than `tol` times the maximum absolute coefficient, $\max_j |w_j|$.
If so, then additionally check whether the dual gap is smaller than `tol` times
$||y||_2^2 / n_{\text{samples}}$.

The target can be a 2-dimensional array, resulting in the optimization of the
following objective:

```default
(1 / (2 * n_samples)) * ||Y - XW||^2_F + alpha * ||W||_11
```

where $||W||_{1,1}$ is the sum of the magnitude of the matrix coefficients.
It should not be confused with [`MultiTaskLasso`](sklearn.linear_model.MultiTaskLasso.md#sklearn.linear_model.MultiTaskLasso) which
instead penalizes the $L_{2,1}$ norm of the coefficients, yielding row-wise
sparsity in the coefficients.

### Examples

```pycon
>>> from sklearn import linear_model
>>> clf = linear_model.Lasso(alpha=0.1)
>>> clf.fit([[0,0], [1, 1], [2, 2]], [0, 1, 2])
Lasso(alpha=0.1)
>>> print(clf.coef_)
[0.85 0.  ]
>>> print(clf.intercept_)
0.15...
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, check_input=True)

Fit model with coordinate descent.

* **Parameters:**
  **X**
  : Data.
    <br/>
    Note that large sparse matrices and arrays requiring `int64`
    indices are not accepted.

  **y**
  : Target. Will be cast to X’s dtype if necessary.

  **sample_weight**
  : Sample weights. Internally, the `sample_weight` vector will be
    rescaled to sum to `n_samples`.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you do.
* **Returns:**
  **self**
  : Fitted estimator.

### Notes

Coordinate descent is an algorithm that considers each column of
data at a time hence it will automatically convert the X input
as a Fortran-contiguous numpy array if necessary.

To avoid memory re-allocation it is advised to allocate the
initial data in memory directly using that format.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *static* path(X, y, \*, l1_ratio=0.5, eps=0.001, n_alphas=100, alphas=None, precompute='auto', Xy=None, copy_X=True, coef_init=None, verbose=False, return_n_iter=False, positive=False, check_input=True, \*\*params)

Compute elastic net path with coordinate descent.

The elastic net optimization function varies for mono and multi-outputs.

For mono-output tasks it is:

```default
1 / (2 * n_samples) * ||y - Xw||^2_2
+ alpha * l1_ratio * ||w||_1
+ 0.5 * alpha * (1 - l1_ratio) * ||w||^2_2
```

For multi-output tasks it is:

```default
(1 / (2 * n_samples)) * ||Y - XW||_Fro^2
+ alpha * l1_ratio * ||W||_21
+ 0.5 * alpha * (1 - l1_ratio) * ||W||_Fro^2
```

Where:

```default
||W||_21 = \sum_i \sqrt{\sum_j w_{ij}^2}
```

i.e. the sum of norm of each row.

Read more in the [User Guide](../linear_model.md#elastic-net).

* **Parameters:**
  **X**
  : Training data. Pass directly as Fortran-contiguous data to avoid
    unnecessary memory duplication. If `y` is mono-output then `X`
    can be sparse.

  **y**
  : Target values.

  **l1_ratio**
  : Number between 0 and 1 passed to elastic net (scaling between
    l1 and l2 penalties). `l1_ratio=1` corresponds to the Lasso.

  **eps**
  : Length of the path. `eps=1e-3` means that
    `alpha_min / alpha_max = 1e-3`.

  **n_alphas**
  : Number of alphas along the regularization path.

  **alphas**
  : List of alphas where to compute the models.
    If None alphas are set automatically.

  **precompute**
  : Whether to use a precomputed Gram matrix to speed up
    calculations. If set to `'auto'` let us decide. The Gram
    matrix can also be passed as argument.

  **Xy**
  : Xy = np.dot(X.T, y) that can be precomputed. It is useful
    only when the Gram matrix is precomputed.

  **copy_X**
  : If `True`, X will be copied; else, it may be overwritten.

  **coef_init**
  : The initial values of the coefficients.

  **verbose**
  : Amount of verbosity.

  **return_n_iter**
  : Whether to return the number of iterations or not.

  **positive**
  : If set to True, forces coefficients to be positive.
    (Only allowed when `y.ndim == 1`).

  **check_input**
  : If set to False, the input validation checks are skipped (including the
    Gram matrix when provided). It is assumed that they are handled
    by the caller.

  **\*\*params**
  : Keyword arguments passed to the coordinate descent solver.
* **Returns:**
  **alphas**
  : The alphas along the path where models are computed.

  **coefs**
  : Coefficients along the path.

  **dual_gaps**
  : The dual gaps at the end of the optimization for each alpha.

  **n_iters**
  : The number of iterations taken by the coordinate descent optimizer to
    reach the specified tolerance for each alpha.
    (Is returned when `return_n_iter` is set to True).

#### SEE ALSO
[`MultiTaskElasticNet`](sklearn.linear_model.MultiTaskElasticNet.md#sklearn.linear_model.MultiTaskElasticNet)
: Multi-task ElasticNet model trained with L1/L2 mixed-norm     as regularizer.

[`MultiTaskElasticNetCV`](sklearn.linear_model.MultiTaskElasticNetCV.md#sklearn.linear_model.MultiTaskElasticNetCV)
: Multi-task L1/L2 ElasticNet with built-in cross-validation.

[`ElasticNet`](sklearn.linear_model.ElasticNet.md#sklearn.linear_model.ElasticNet)
: Linear regression with combined L1 and L2 priors as regularizer.

[`ElasticNetCV`](sklearn.linear_model.ElasticNetCV.md#sklearn.linear_model.ElasticNetCV)
: Elastic Net model with iterative fitting along a regularization path.

### Notes

For an example, see
[examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.py](../../auto_examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.md#sphx-glr-auto-examples-linear-model-plot-lasso-lasso-lars-elasticnet-path-py).

### Examples

```pycon
>>> from sklearn.linear_model import enet_path
>>> from sklearn.datasets import make_regression
>>> X, y, true_coef = make_regression(
...    n_samples=100, n_features=5, n_informative=2, coef=True, random_state=0
... )
>>> true_coef
array([ 0.        ,  0.        ,  0.        , 97.9..., 45.7...])
>>> alphas, estimated_coef, _ = enet_path(X, y, n_alphas=3)
>>> alphas.shape
(3,)
>>> estimated_coef
 array([[ 0.        ,  0.78...,  0.56...],
        [ 0.        ,  1.12...,  0.61...],
        [-0.        , -2.12..., -1.12...],
        [ 0.        , 23.04..., 88.93...],
        [ 0.        , 10.63..., 41.56...]])
```

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [Lasso](#sklearn.linear_model.Lasso)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [Lasso](#sklearn.linear_model.Lasso)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### *property* sparse_coef_

Sparse representation of the fitted `coef_`.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows the reconstruction of an image from a set of parallel projections, acquired along different angles. Such a dataset is acquired in computed tomography (CT).">  <div class="sphx-glr-thumbnail-title">Compressive sensing: tomography reconstruction with L1 prior (Lasso)</div>
</div>
* [Compressive sensing: tomography reconstruction with L1 prior (Lasso)](../../auto_examples/applications/plot_tomography_l1_reconstruction.md#sphx-glr-auto-examples-applications-plot-tomography-l1-reconstruction-py)

<div class="sphx-glr-thumbcontainer" tooltip="The multi-task lasso allows to fit multiple regression problems jointly enforcing the selected features to be the same across tasks. This example simulates sequential measurements, each task is a time instant, and the relevant features vary in amplitude over time while being the same. The multi-task lasso imposes that features that are selected at one time point are select for all time point. This makes feature selection by the Lasso more stable.">  <div class="sphx-glr-thumbnail-title">Joint feature selection with multi-task Lasso</div>
</div>
* [Joint feature selection with multi-task Lasso](../../auto_examples/linear_model/plot_multi_task_lasso_support.md#sphx-glr-auto-examples-linear-model-plot-multi-task-lasso-support-py)

<div class="sphx-glr-thumbcontainer" tooltip="The present example compares three l1-based regression models on a synthetic signal obtained from sparse and correlated features that are further corrupted with additive gaussian noise:">  <div class="sphx-glr-thumbnail-title">L1-based models for Sparse Signals</div>
</div>
* [L1-based models for Sparse Signals](../../auto_examples/linear_model/plot_lasso_and_elasticnet.md#sphx-glr-auto-examples-linear-model-plot-lasso-and-elasticnet-py)

<div class="sphx-glr-thumbcontainer" tooltip="We show that linear_model.Lasso provides the same results for dense and sparse data and that in the case of sparse data the speed is improved.">  <div class="sphx-glr-thumbnail-title">Lasso on dense and sparse data</div>
</div>
* [Lasso on dense and sparse data](../../auto_examples/linear_model/plot_lasso_dense_vs_sparse_data.md#sphx-glr-auto-examples-linear-model-plot-lasso-dense-vs-sparse-data-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use the ordinary least squares (OLS) model called LinearRegression in scikit-learn.">  <div class="sphx-glr-thumbnail-title">Ordinary Least Squares Example</div>
</div>
* [Ordinary Least Squares Example](../../auto_examples/linear_model/plot_ols.md#sphx-glr-auto-examples-linear-model-plot-ols-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<!-- thumbnail-parent-div-close --></div>
