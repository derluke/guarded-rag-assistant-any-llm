# Parallel

### *class* sklearn.utils.parallel.Parallel(n_jobs=default(None), backend=default(None), return_as='list', verbose=default(0), timeout=None, pre_dispatch='2 \* n_jobs', batch_size='auto', temp_folder=default(None), max_nbytes=default('1M'), mmap_mode=default('r'), prefer=default(None), require=default(None))

Tweak of [`joblib.Parallel`](https://joblib.readthedocs.io/en/latest/generated/joblib.Parallel.html#joblib.Parallel) that propagates the scikit-learn configuration.

This subclass of [`joblib.Parallel`](https://joblib.readthedocs.io/en/latest/generated/joblib.Parallel.html#joblib.Parallel) ensures that the active configuration
(thread-local) of scikit-learn is propagated to the parallel workers for the
duration of the execution of the parallel tasks.

The API does not change and you can refer to [`joblib.Parallel`](https://joblib.readthedocs.io/en/latest/generated/joblib.Parallel.html#joblib.Parallel)
documentation for more details.

#### Versionadded
Added in version 1.3.

<!-- !! processed by numpydoc !! -->

#### \_\_call_\_(iterable)

Dispatch the tasks and return the results.

* **Parameters:**
  **iterable**
  : Iterable containing tuples of (delayed_function, args, kwargs) that should
    be consumed.
* **Returns:**
  **results**
  : List of results of the tasks.

<!-- !! processed by numpydoc !! -->

#### dispatch_next()

Dispatch more data for parallel processing

This method is meant to be called concurrently by the multiprocessing
callback. We rely on the thread-safety of dispatch_one_batch to protect
against concurrent consumption of the unprotected iterator.

<!-- !! processed by numpydoc !! -->

#### dispatch_one_batch(iterator)

Prefetch the tasks for the next batch and dispatch them.

The effective size of the batch is computed here.
If there are no more jobs to dispatch, return False, else return True.

The iterator consumption and dispatching is protected by the same
lock so calling this function should be thread safe.

<!-- !! processed by numpydoc !! -->

#### format(obj, indent=0)

Return the formatted representation of the object.

<!-- !! processed by numpydoc !! -->

#### print_progress()

Display the process of the parallel execution only a fraction
of time, controlled by self.verbose.

<!-- !! processed by numpydoc !! -->
