# inplace_row_scale

### sklearn.utils.sparsefuncs.inplace_row_scale(X, scale)

Inplace row scaling of a CSR or CSC matrix.

Scale each row of the data matrix by multiplying with specific scale
provided by the caller assuming a (n_samples, n_features) shape.

* **Parameters:**
  **X**
  : Matrix to be scaled. It should be of CSR or CSC format.

  **scale**
  : Array of precomputed sample-wise values to use for scaling.

### Examples

```pycon
>>> from sklearn.utils import sparsefuncs
>>> from scipy import sparse
>>> import numpy as np
>>> indptr = np.array([0, 2, 3, 4, 5])
>>> indices = np.array([0, 1, 2, 3, 3])
>>> data = np.array([8, 1, 2, 5, 6])
>>> scale = np.array([2, 3, 4, 5])
>>> csr = sparse.csr_matrix((data, indices, indptr))
>>> csr.todense()
matrix([[8, 1, 0, 0],
        [0, 0, 2, 0],
        [0, 0, 0, 5],
        [0, 0, 0, 6]])
>>> sparsefuncs.inplace_row_scale(csr, scale)
>>> csr.todense()
 matrix([[16,  2,  0,  0],
         [ 0,  0,  6,  0],
         [ 0,  0,  0, 20],
         [ 0,  0,  0, 30]])
```

<!-- !! processed by numpydoc !! -->
