# FeatureUnion

### *class* sklearn.pipeline.FeatureUnion(transformer_list, \*, n_jobs=None, transformer_weights=None, verbose=False, verbose_feature_names_out=True)

Concatenates results of multiple transformer objects.

This estimator applies a list of transformer objects in parallel to the
input data, then concatenates the results. This is useful to combine
several feature extraction mechanisms into a single transformer.

Parameters of the transformers may be set using its name and the parameter
name separated by a ‘_\_’. A transformer may be replaced entirely by
setting the parameter with its name to another transformer, removed by
setting to ‘drop’ or disabled by setting to ‘passthrough’ (features are
passed without transformation).

Read more in the [User Guide](../compose.md#feature-union).

#### Versionadded
Added in version 0.13.

* **Parameters:**
  **transformer_list**
  : List of transformer objects to be applied to the data. The first
    half of each tuple is the name of the transformer. The transformer can
    be ‘drop’ for it to be ignored or can be ‘passthrough’ for features to
    be passed unchanged.
    <br/>
    #### Versionadded
    Added in version 1.1: Added the option `"passthrough"`.
    <br/>
    #### Versionchanged
    Changed in version 0.22: Deprecated `None` as a transformer in favor of ‘drop’.

  **n_jobs**
  : Number of jobs to run in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionchanged
    Changed in version v0.20: `n_jobs` default changed from 1 to None

  **transformer_weights**
  : Multiplicative weights for features per transformer.
    Keys are transformer names, values the weights.
    Raises ValueError if key not present in `transformer_list`.

  **verbose**
  : If True, the time elapsed while fitting each transformer will be
    printed as it is completed.

  **verbose_feature_names_out**
  : If True, [`get_feature_names_out`](#sklearn.pipeline.FeatureUnion.get_feature_names_out) will prefix all feature names
    with the name of the transformer that generated that feature.
    If False, [`get_feature_names_out`](#sklearn.pipeline.FeatureUnion.get_feature_names_out) will not prefix any feature
    names and will error if feature names are not unique.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Attributes:**
  **named_transformers**
  : Dictionary-like object, with the following attributes.
    Read-only attribute to access any transformer parameter by user
    given name. Keys are transformer names and values are
    transformer parameters.
    <br/>
    #### Versionadded
    Added in version 1.2.

  [`n_features_in_`](#sklearn.pipeline.FeatureUnion.n_features_in_)
  : Number of features seen during [fit](../../glossary.md#term-fit).

  [`feature_names_in_`](#sklearn.pipeline.FeatureUnion.feature_names_in_)
  : Names of features seen during [fit](../../glossary.md#term-fit).

#### SEE ALSO
[`make_union`](sklearn.pipeline.make_union.md#sklearn.pipeline.make_union)
: Convenience function for simplified feature union construction.

### Examples

```pycon
>>> from sklearn.pipeline import FeatureUnion
>>> from sklearn.decomposition import PCA, TruncatedSVD
>>> union = FeatureUnion([("pca", PCA(n_components=1)),
...                       ("svd", TruncatedSVD(n_components=2))])
>>> X = [[0., 1., 3], [2., 2., 5]]
>>> union.fit_transform(X)
array([[-1.5       ,  3.0..., -0.8...],
       [ 1.5       ,  5.7...,  0.4...]])
>>> # An estimator's parameter can be set using '__' syntax
>>> union.set_params(svd__n_components=1).fit_transform(X)
array([[-1.5       ,  3.0...],
       [ 1.5       ,  5.7...]])
```

For a more detailed example of usage, see
[Concatenating multiple feature extraction methods](../../auto_examples/compose/plot_feature_union.md#sphx-glr-auto-examples-compose-plot-feature-union-py).

<!-- !! processed by numpydoc !! -->

#### *property* feature_names_in_

Names of features seen during [fit](../../glossary.md#term-fit).

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, \*\*fit_params)

Fit all transformers using X.

* **Parameters:**
  **X**
  : Input data, used to fit transformers.

  **y**
  : Targets for supervised learning.

  **\*\*fit_params**
  : - If `enable_metadata_routing=False` (default):
      Parameters directly passed to the `fit` methods of the
      sub-transformers.
    - If `enable_metadata_routing=True`:
      Parameters safely routed to the `fit` methods of the
      sub-transformers. See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more details.
    <br/>
    #### Versionchanged
    Changed in version 1.5: `**fit_params` can be routed via metadata routing API.
* **Returns:**
  **self**
  : FeatureUnion class instance.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*params)

Fit all transformers, transform the data and concatenate results.

* **Parameters:**
  **X**
  : Input data to be transformed.

  **y**
  : Targets for supervised learning.

  **\*\*params**
  : - If `enable_metadata_routing=False` (default):
      Parameters directly passed to the `fit` methods of the
      sub-transformers.
    - If `enable_metadata_routing=True`:
      Parameters safely routed to the `fit` methods of the
      sub-transformers. See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more details.
    <br/>
    #### Versionchanged
    Changed in version 1.5: `**params` can now be routed via metadata routing API.
* **Returns:**
  **X_t**
  : The `hstack` of results of transformers. `sum_n_components` is the
    sum of `n_components` (output dimension) over transformers.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.5.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

Returns the parameters given in the constructor as well as the
estimators contained within the `transformer_list` of the
`FeatureUnion`.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_features_in_

Number of features seen during [fit](../../glossary.md#term-fit).

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set the output container when `"transform"` and `"fit_transform"` are called.

`set_output` will set the output of all estimators in `transformer_list`.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*kwargs)

Set the parameters of this estimator.

Valid parameter keys can be listed with `get_params()`. Note that
you can directly set the parameters of the estimators contained in
`transformer_list`.

* **Parameters:**
  **\*\*kwargs**
  : Parameters of this estimator or parameters of estimators contained
    in `transform_list`. Parameters of the transformers may be set
    using its name and the parameter name separated by a ‘_\_’.
* **Returns:**
  **self**
  : FeatureUnion class instance.

<!-- !! processed by numpydoc !! -->

#### transform(X, \*\*params)

Transform X separately by each transformer, concatenate results.

* **Parameters:**
  **X**
  : Input data to be transformed.

  **\*\*params**
  : Parameters routed to the `transform` method of the sub-transformers via the
    metadata routing API. See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more details.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **X_t**
  : The `hstack` of results of transformers. `sum_n_components` is the
    sum of `n_components` (output dimension) over transformers.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="In many real-world examples, there are many ways to extract features from a dataset. Often it is beneficial to combine several methods to obtain good performance. This example shows how to use FeatureUnion to combine features obtained by PCA and univariate selection.">  <div class="sphx-glr-thumbnail-title">Concatenating multiple feature extraction methods</div>
</div>
* [Concatenating multiple feature extraction methods](../../auto_examples/compose/plot_feature_union.md#sphx-glr-auto-examples-compose-plot-feature-union-py)

<!-- thumbnail-parent-div-close --></div>
