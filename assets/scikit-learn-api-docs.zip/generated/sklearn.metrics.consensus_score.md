# consensus_score

### sklearn.metrics.consensus_score(a, b, \*, similarity='jaccard')

The similarity of two sets of biclusters.

Similarity between individual biclusters is computed. Then the best
matching between sets is found by solving a linear sum assignment problem,
using a modified Jonker-Volgenant algorithm.
The final score is the sum of similarities divided by the size of
the larger set.

Read more in the [User Guide](../biclustering.md#biclustering).

* **Parameters:**
  **a**
  : Tuple of row and column indicators for a set of biclusters.

  **b**
  : Another set of biclusters like `a`.

  **similarity**
  : May be the string “jaccard” to use the Jaccard coefficient, or
    any function that takes four arguments, each of which is a 1d
    indicator vector: (a_rows, a_columns, b_rows, b_columns).
* **Returns:**
  **consensus_score**
  : Consensus score, a non-negative value, sum of similarities
    divided by size of larger set.

#### SEE ALSO
[`scipy.optimize.linear_sum_assignment`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linear_sum_assignment.html#scipy.optimize.linear_sum_assignment)
: Solve the linear sum assignment problem.

### References

* Hochreiter, Bodenhofer, et. al., 2010. [FABIA: factor analysis
  for bicluster acquisition](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2881408/).

### Examples

```pycon
>>> from sklearn.metrics import consensus_score
>>> a = ([[True, False], [False, True]], [[False, True], [True, False]])
>>> b = ([[False, True], [True, False]], [[True, False], [False, True]])
>>> consensus_score(a, b, similarity='jaccard')
np.float64(1.0)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to generate a checkerboard dataset and bicluster it using the SpectralBiclustering algorithm. The spectral biclustering algorithm is specifically designed to cluster data by simultaneously considering both the rows (samples) and columns (features) of a matrix. It aims to identify patterns not only between samples but also within subsets of samples, allowing for the detection of localized structure within the data. This makes spectral biclustering particularly well-suited for datasets where the order or arrangement of features is fixed, such as in images, time series, or genomes.">  <div class="sphx-glr-thumbnail-title">A demo of the Spectral Biclustering algorithm</div>
</div>
* [A demo of the Spectral Biclustering algorithm](../../auto_examples/bicluster/plot_spectral_biclustering.md#sphx-glr-auto-examples-bicluster-plot-spectral-biclustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to generate a dataset and bicluster it using the Spectral Co-Clustering algorithm.">  <div class="sphx-glr-thumbnail-title">A demo of the Spectral Co-Clustering algorithm</div>
</div>
* [A demo of the Spectral Co-Clustering algorithm](../../auto_examples/bicluster/plot_spectral_coclustering.md#sphx-glr-auto-examples-bicluster-plot-spectral-coclustering-py)

<!-- thumbnail-parent-div-close --></div>
