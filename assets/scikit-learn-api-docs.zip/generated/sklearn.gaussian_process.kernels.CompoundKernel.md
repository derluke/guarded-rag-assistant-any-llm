# CompoundKernel

### *class* sklearn.gaussian_process.kernels.CompoundKernel(kernels)

Kernel which is composed of a set of other kernels.

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **kernels**
  : The other kernels

### Examples

```pycon
>>> from sklearn.gaussian_process.kernels import WhiteKernel
>>> from sklearn.gaussian_process.kernels import RBF
>>> from sklearn.gaussian_process.kernels import CompoundKernel
>>> kernel = CompoundKernel(
...     [WhiteKernel(noise_level=3.0), RBF(length_scale=2.0)])
>>> print(kernel.bounds)
[[-11.51292546  11.51292546]
 [-11.51292546  11.51292546]]
>>> print(kernel.n_dims)
2
>>> print(kernel.theta)
[1.09861229 0.69314718]
```

<!-- !! processed by numpydoc !! -->

#### \_\_call_\_(X, Y=None, eval_gradient=False)

Return the kernel k(X, Y) and optionally its gradient.

Note that this compound kernel returns the results of all simple kernel
stacked along an additional axis.

* **Parameters:**
  **X**
  : Left argument of the returned kernel k(X, Y)

  **Y**
  : Right argument of the returned kernel k(X, Y). If None, k(X, X)
    is evaluated instead.

  **eval_gradient**
  : Determines whether the gradient with respect to the log of the
    kernel hyperparameter is computed.
* **Returns:**
  **K**
  : Kernel k(X, Y)

  **K_gradient**
  : The gradient of the kernel k(X, X) with respect to the log of the
    hyperparameter of the kernel. Only returned when `eval_gradient`
    is True.

<!-- !! processed by numpydoc !! -->

#### *property* bounds

Returns the log-transformed bounds on the theta.

* **Returns:**
  **bounds**
  : The log-transformed bounds on the kernel’s hyperparameters theta

<!-- !! processed by numpydoc !! -->

#### clone_with_theta(theta)

Returns a clone of self with given hyperparameters theta.

* **Parameters:**
  **theta**
  : The hyperparameters

<!-- !! processed by numpydoc !! -->

#### diag(X)

Returns the diagonal of the kernel k(X, X).

The result of this method is identical to `np.diag(self(X))`; however,
it can be evaluated more efficiently since only the diagonal is
evaluated.

* **Parameters:**
  **X**
  : Argument to the kernel.
* **Returns:**
  **K_diag**
  : Diagonal of kernel k(X, X)

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters of this kernel.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* hyperparameters

Returns a list of all hyperparameter specifications.

<!-- !! processed by numpydoc !! -->

#### is_stationary()

Returns whether the kernel is stationary.

<!-- !! processed by numpydoc !! -->

#### *property* n_dims

Returns the number of non-fixed hyperparameters of the kernel.

<!-- !! processed by numpydoc !! -->

#### *property* requires_vector_input

Returns whether the kernel is defined on discrete structures.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this kernel.

The method works on simple kernels as well as on nested kernels.
The latter have parameters of the form `<component>__<parameter>`
so that it’s possible to update each component of a nested object.

* **Returns:**
  self

<!-- !! processed by numpydoc !! -->

#### *property* theta

Returns the (flattened, log-transformed) non-fixed hyperparameters.

Note that theta are typically the log-transformed values of the
kernel’s hyperparameters as this representation of the search space
is more amenable for hyperparameter search, as hyperparameters like
length-scales naturally live on a log-scale.

* **Returns:**
  **theta**
  : The non-fixed, log-transformed hyperparameters of the kernel

<!-- !! processed by numpydoc !! -->
