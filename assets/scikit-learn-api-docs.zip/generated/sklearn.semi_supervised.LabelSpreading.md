# LabelSpreading

### *class* sklearn.semi_supervised.LabelSpreading(kernel='rbf', \*, gamma=20, n_neighbors=7, alpha=0.2, max_iter=30, tol=0.001, n_jobs=None)

LabelSpreading model for semi-supervised learning.

This model is similar to the basic Label Propagation algorithm,
but uses affinity matrix based on the normalized graph Laplacian
and soft clamping across the labels.

Read more in the [User Guide](../semi_supervised.md#label-propagation).

* **Parameters:**
  **kernel**
  : String identifier for kernel function to use or the kernel function
    itself. Only ‘rbf’ and ‘knn’ strings are valid inputs. The function
    passed should take two inputs, each of shape (n_samples, n_features),
    and return a (n_samples, n_samples) shaped weight matrix.

  **gamma**
  : Parameter for rbf kernel.

  **n_neighbors**
  : Parameter for knn kernel which is a strictly positive integer.

  **alpha**
  : Clamping factor. A value in (0, 1) that specifies the relative amount
    that an instance should adopt the information from its neighbors as
    opposed to its initial label.
    alpha=0 means keeping the initial label information; alpha=1 means
    replacing all initial information.

  **max_iter**
  : Maximum number of iterations allowed.

  **tol**
  : Convergence tolerance: threshold to consider the system at steady
    state.

  **n_jobs**
  : The number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **X_**
  : Input array.

  **classes_**
  : The distinct labels used in classifying instances.

  **label_distributions_**
  : Categorical distribution for each item.

  **transduction_**
  : Label assigned to each item during [fit](../../glossary.md#term-fit).

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Number of iterations run.

#### SEE ALSO
[`LabelPropagation`](sklearn.semi_supervised.LabelPropagation.md#sklearn.semi_supervised.LabelPropagation)
: Unregularized graph based semi-supervised learning.

### References

[Dengyong Zhou, Olivier Bousquet, Thomas Navin Lal, Jason Weston,
Bernhard Schoelkopf. Learning with local and global consistency (2004)](https://citeseerx.ist.psu.edu/doc_view/pid/d74c37aabf2d5cae663007cbd8718175466aea8c)

### Examples

```pycon
>>> import numpy as np
>>> from sklearn import datasets
>>> from sklearn.semi_supervised import LabelSpreading
>>> label_prop_model = LabelSpreading()
>>> iris = datasets.load_iris()
>>> rng = np.random.RandomState(42)
>>> random_unlabeled_points = rng.rand(len(iris.target)) < 0.3
>>> labels = np.copy(iris.target)
>>> labels[random_unlabeled_points] = -1
>>> label_prop_model.fit(iris.data, labels)
LabelSpreading(...)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit a semi-supervised label propagation model to X.

The input samples (labeled and unlabeled) are provided by matrix X,
and target labels are provided by matrix y. We conventionally apply the
label -1 to unlabeled samples in matrix y in a semi-supervised
classification.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Target class values with unlabeled points marked as -1.
    All unlabeled samples will be transductively assigned labels
    internally, which are stored in `transduction_`.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Perform inductive inference across the model.

* **Parameters:**
  **X**
  : The data matrix.
* **Returns:**
  **y**
  : Predictions for input data.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict probability for each possible outcome.

Compute the probability estimates for each single sample in X
and each possible outcome seen during training (categorical
distribution).

* **Parameters:**
  **X**
  : The data matrix.
* **Returns:**
  **probabilities**
  : Normalized probability distributions across
    class labels.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LabelSpreading](#sklearn.semi_supervised.LabelSpreading)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A comparison for the decision boundaries generated on the iris dataset by Label Spreading, Self-training and SVM.">  <div class="sphx-glr-thumbnail-title">Decision boundary of semi-supervised classifiers versus SVM on the Iris dataset</div>
</div>
* [Decision boundary of semi-supervised classifiers versus SVM on the Iris dataset](../../auto_examples/semi_supervised/plot_semi_supervised_versus_svm_iris.md#sphx-glr-auto-examples-semi-supervised-plot-semi-supervised-versus-svm-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="Demonstrates an active learning technique to learn handwritten digits using label propagation.">  <div class="sphx-glr-thumbnail-title">Label Propagation digits active learning</div>
</div>
* [Label Propagation digits active learning](../../auto_examples/semi_supervised/plot_label_propagation_digits_active_learning.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-digits-active-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the power of semisupervised learning by training a Label Spreading model to classify handwritten digits with sets of very few labels.">  <div class="sphx-glr-thumbnail-title">Label Propagation digits: Demonstrating performance</div>
</div>
* [Label Propagation digits: Demonstrating performance](../../auto_examples/semi_supervised/plot_label_propagation_digits.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of LabelPropagation learning a complex internal structure to demonstrate &quot;manifold learning&quot;. The outer circle should be labeled &quot;red&quot; and the inner circle &quot;blue&quot;. Because both label groups lie inside their own distinct shape, we can see that the labels propagate correctly around the circle.">  <div class="sphx-glr-thumbnail-title">Label Propagation learning a complex structure</div>
</div>
* [Label Propagation learning a complex structure](../../auto_examples/semi_supervised/plot_label_propagation_structure.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-structure-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, semi-supervised classifiers are trained on the 20 newsgroups dataset (which will be automatically downloaded).">  <div class="sphx-glr-thumbnail-title">Semi-supervised Classification on a Text Dataset</div>
</div>
* [Semi-supervised Classification on a Text Dataset](../../auto_examples/semi_supervised/plot_semi_supervised_newsgroups.md#sphx-glr-auto-examples-semi-supervised-plot-semi-supervised-newsgroups-py)

<!-- thumbnail-parent-div-close --></div>
