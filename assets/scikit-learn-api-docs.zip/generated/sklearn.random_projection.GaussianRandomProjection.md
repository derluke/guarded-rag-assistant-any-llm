# GaussianRandomProjection

### *class* sklearn.random_projection.GaussianRandomProjection(n_components='auto', \*, eps=0.1, compute_inverse_components=False, random_state=None)

Reduce dimensionality through Gaussian random projection.

The components of the random matrix are drawn from N(0, 1 / n_components).

Read more in the [User Guide](../random_projection.md#gaussian-random-matrix).

#### Versionadded
Added in version 0.13.

* **Parameters:**
  **n_components**
  : Dimensionality of the target projection space.
    <br/>
    n_components can be automatically adjusted according to the
    number of samples in the dataset and the bound given by the
    Johnson-Lindenstrauss lemma. In that case the quality of the
    embedding is controlled by the `eps` parameter.
    <br/>
    It should be noted that Johnson-Lindenstrauss lemma can yield
    very conservative estimated of the required number of components
    as it makes no assumption on the structure of the dataset.

  **eps**
  : Parameter to control the quality of the embedding according to
    the Johnson-Lindenstrauss lemma when `n_components` is set to
    ‘auto’. The value should be strictly positive.
    <br/>
    Smaller values lead to better embedding and higher number of
    dimensions (n_components) in the target projection space.

  **compute_inverse_components**
  : Learn the inverse transform by computing the pseudo-inverse of the
    components during fit. Note that computing the pseudo-inverse does not
    scale well to large matrices.

  **random_state**
  : Controls the pseudo random number generator used to generate the
    projection matrix at fit time.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **n_components_**
  : Concrete number of components computed when n_components=”auto”.

  **components_**
  : Random matrix used for the projection.

  **inverse_components_**
  : Pseudo-inverse of the components, only computed if
    `compute_inverse_components` is True.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`SparseRandomProjection`](sklearn.random_projection.SparseRandomProjection.md#sklearn.random_projection.SparseRandomProjection)
: Reduce dimensionality through sparse random projection.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.random_projection import GaussianRandomProjection
>>> rng = np.random.RandomState(42)
>>> X = rng.rand(25, 3000)
>>> transformer = GaussianRandomProjection(random_state=rng)
>>> X_new = transformer.fit_transform(X)
>>> X_new.shape
(25, 2759)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Generate a sparse random projection matrix.

* **Parameters:**
  **X**
  : Training set: only the shape is used to find optimal random
    matrix dimensions based on the theory referenced in the
    afore mentioned papers.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : BaseRandomProjection class instance.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Project data back to its original space.

Returns an array X_original whose transform would be X. Note that even
if X is sparse, X_original is dense: this may use a lot of RAM.

If `compute_inverse_components` is False, the inverse of the components is
computed during each call to `inverse_transform` which can be costly.

* **Parameters:**
  **X**
  : Data to be transformed back.
* **Returns:**
  **X_original**
  : Reconstructed data.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Project the data by using matrix product with the random matrix.

* **Parameters:**
  **X**
  : The input data to project into a smaller dimensional space.
* **Returns:**
  **X_new**
  : Projected array.

<!-- !! processed by numpydoc !! -->
