# RepeatedKFold

### *class* sklearn.model_selection.RepeatedKFold(\*, n_splits=5, n_repeats=10, random_state=None)

Repeated K-Fold cross validator.

Repeats K-Fold n times with different randomization in each repetition.

Read more in the [User Guide](../cross_validation.md#repeated-k-fold).

* **Parameters:**
  **n_splits**
  : Number of folds. Must be at least 2.

  **n_repeats**
  : Number of times cross-validator needs to be repeated.

  **random_state**
  : Controls the randomness of each repeated cross-validation instance.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

#### SEE ALSO
[`RepeatedStratifiedKFold`](sklearn.model_selection.RepeatedStratifiedKFold.md#sklearn.model_selection.RepeatedStratifiedKFold)
: Repeats Stratified K-Fold n times.

### Notes

Randomized CV splitters may return different results for each call of
split. You can make the results identical by setting `random_state`
to an integer.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import RepeatedKFold
>>> X = np.array([[1, 2], [3, 4], [1, 2], [3, 4]])
>>> y = np.array([0, 0, 1, 1])
>>> rkf = RepeatedKFold(n_splits=2, n_repeats=2, random_state=2652124)
>>> rkf.get_n_splits(X, y)
4
>>> print(rkf)
RepeatedKFold(n_repeats=2, n_splits=2, random_state=2652124)
>>> for i, (train_index, test_index) in enumerate(rkf.split(X)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}")
...     print(f"  Test:  index={test_index}")
...
Fold 0:
  Train: index=[0 1]
  Test:  index=[2 3]
Fold 1:
  Train: index=[2 3]
  Test:  index=[0 1]
Fold 2:
  Train: index=[1 2]
  Test:  index=[0 3]
Fold 3:
  Train: index=[0 3]
  Test:  index=[1 2]
```

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X=None, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.
    `np.zeros(n_samples)` may be used as a placeholder.

  **y**
  : Always ignored, exists for compatibility.
    `np.zeros(n_samples)` may be used as a placeholder.

  **groups**
  : Group labels for the samples used while splitting the dataset into
    train/test set.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### split(X, y=None, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : The target variable for supervised learning problems.

  **groups**
  : Always ignored, exists for compatibility.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<!-- thumbnail-parent-div-close --></div>
