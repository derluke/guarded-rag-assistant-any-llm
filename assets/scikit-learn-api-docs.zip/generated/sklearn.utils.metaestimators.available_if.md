# available_if

### sklearn.utils.metaestimators.available_if(check)

An attribute that is available only if check returns a truthy value.

* **Parameters:**
  **check**
  : When passed the object with the decorated method, this should return
    a truthy value if the attribute is available, and either return False
    or raise an AttributeError if not available.
* **Returns:**
  callable
  : Callable makes the decorated method available if `check` returns
    a truthy value, otherwise the decorated method is unavailable.

### Examples

```pycon
>>> from sklearn.utils.metaestimators import available_if
>>> class HelloIfEven:
...    def __init__(self, x):
...        self.x = x
...
...    def _x_is_even(self):
...        return self.x % 2 == 0
...
...    @available_if(_x_is_even)
...    def say_hello(self):
...        print("Hello")
...
>>> obj = HelloIfEven(1)
>>> hasattr(obj, "say_hello")
False
>>> obj.x = 2
>>> hasattr(obj, "say_hello")
True
>>> obj.say_hello()
Hello
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Clustering can be expensive, especially when our dataset contains millions of datapoints. Many clustering algorithms are not inductive and so cannot be directly applied to new data samples without recomputing the clustering, which may be intractable. Instead, we can use clustering to then learn an inductive model with a classifier, which has several benefits:">  <div class="sphx-glr-thumbnail-title">Inductive Clustering</div>
</div>
* [Inductive Clustering](../../auto_examples/cluster/plot_inductive_clustering.md#sphx-glr-auto-examples-cluster-plot-inductive-clustering-py)

<!-- thumbnail-parent-div-close --></div>
