# classification_report

### sklearn.metrics.classification_report(y_true, y_pred, \*, labels=None, target_names=None, sample_weight=None, digits=2, output_dict=False, zero_division='warn')

Build a text report showing the main classification metrics.

Read more in the [User Guide](../model_evaluation.md#classification-report).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated targets as returned by a classifier.

  **labels**
  : Optional list of label indices to include in the report.

  **target_names**
  : Optional display names matching the labels (same order).

  **sample_weight**
  : Sample weights.

  **digits**
  : Number of digits for formatting output floating point values.
    When `output_dict` is `True`, this will be ignored and the
    returned values will not be rounded.

  **output_dict**
  : If True, return output as dict.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **zero_division**
  : Sets the value to return when there is a zero division. If set to
    “warn”, this acts as 0, but warnings are also raised.
    <br/>
    #### Versionadded
    Added in version 1.3: `np.nan` option was added.
* **Returns:**
  **report**
  : Text summary of the precision, recall, F1 score for each class.
    Dictionary returned if output_dict is True. Dictionary has the
    following structure:
    ```default
    {'label 1': {'precision':0.5,
                 'recall':1.0,
                 'f1-score':0.67,
                 'support':1},
     'label 2': { ... },
      ...
    }
    ```
    <br/>
    The reported averages include macro average (averaging the unweighted
    mean per label), weighted average (averaging the support-weighted mean
    per label), and sample average (only for multilabel classification).
    Micro average (averaging the total true positives, false negatives and
    false positives) is only shown for multi-label or multi-class
    with a subset of classes, because it corresponds to accuracy
    otherwise and would be the same for all metrics.
    See also [`precision_recall_fscore_support`](sklearn.metrics.precision_recall_fscore_support.md#sklearn.metrics.precision_recall_fscore_support) for more details
    on averages.
    <br/>
    Note that in binary classification, recall of the positive class
    is also known as “sensitivity”; recall of the negative class is
    “specificity”.

#### SEE ALSO
[`precision_recall_fscore_support`](sklearn.metrics.precision_recall_fscore_support.md#sklearn.metrics.precision_recall_fscore_support)
: Compute precision, recall, F-measure and support for each class.

[`confusion_matrix`](sklearn.metrics.confusion_matrix.md#sklearn.metrics.confusion_matrix)
: Compute confusion matrix to evaluate the accuracy of a classification.

[`multilabel_confusion_matrix`](sklearn.metrics.multilabel_confusion_matrix.md#sklearn.metrics.multilabel_confusion_matrix)
: Compute a confusion matrix for each class or sample.

### Examples

```pycon
>>> from sklearn.metrics import classification_report
>>> y_true = [0, 1, 2, 2, 2]
>>> y_pred = [0, 0, 2, 2, 1]
>>> target_names = ['class 0', 'class 1', 'class 2']
>>> print(classification_report(y_true, y_pred, target_names=target_names))
              precision    recall  f1-score   support

     class 0       0.50      1.00      0.67         1
     class 1       0.00      0.00      0.00         1
     class 2       1.00      0.67      0.80         3

    accuracy                           0.60         5
   macro avg       0.50      0.56      0.49         5
weighted avg       0.70      0.60      0.61         5

>>> y_pred = [1, 1, 0]
>>> y_true = [1, 1, 1]
>>> print(classification_report(y_true, y_pred, labels=[1, 2, 3]))
              precision    recall  f1-score   support

           1       1.00      0.67      0.80         3
           2       0.00      0.00      0.00         0
           3       0.00      0.00      0.00         0

   micro avg       1.00      0.67      0.80         3
   macro avg       0.33      0.22      0.27         3
weighted avg       1.00      0.67      0.80         3
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is a preprocessed excerpt of the &quot;Labeled Faces in the Wild&quot;, aka LFW_: http://vis-www.cs.umass.edu/lfw/lfw-funneled.tgz (233MB)">  <div class="sphx-glr-thumbnail-title">Faces recognition example using eigenfaces and SVMs</div>
</div>
* [Faces recognition example using eigenfaces and SVMs](../../auto_examples/applications/plot_face_recognition.md#sphx-glr-auto-examples-applications-plot-face-recognition-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how scikit-learn can be used to recognize images of hand-written digits, from 0-9.">  <div class="sphx-glr-thumbnail-title">Recognizing hand-written digits</div>
</div>
* [Recognizing hand-written digits](../../auto_examples/classification/plot_digits_classification.md#sphx-glr-auto-examples-classification-plot-digits-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Datasets can often contain components that require different feature extraction and processing pipelines. This scenario might occur when:">  <div class="sphx-glr-thumbnail-title">Column Transformer with Heterogeneous Data Sources</div>
</div>
* [Column Transformer with Heterogeneous Data Sources](../../auto_examples/compose/plot_column_transformer.md#sphx-glr-auto-examples-compose-plot-column-transformer-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how a feature selection can be easily integrated within a machine learning pipeline.">  <div class="sphx-glr-thumbnail-title">Pipeline ANOVA SVM</div>
</div>
* [Pipeline ANOVA SVM](../../auto_examples/feature_selection/plot_feature_selection_pipeline.md#sphx-glr-auto-examples-feature-selection-plot-feature-selection-pipeline-py)

<div class="sphx-glr-thumbcontainer" tooltip="This examples shows how a classifier is optimized by cross-validation, which is done using the GridSearchCV object on a development set that comprises only half of the available labeled data.">  <div class="sphx-glr-thumbnail-title">Custom refit strategy of a grid search with cross-validation</div>
</div>
* [Custom refit strategy of a grid search with cross-validation](../../auto_examples/model_selection/plot_grid_search_digits.md#sphx-glr-auto-examples-model-selection-plot-grid-search-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="For greyscale image data where pixel values can be interpreted as degrees of blackness on a white background, like handwritten digit recognition, the Bernoulli Restricted Boltzmann machine model (BernoulliRBM) can perform effective non-linear feature extraction.">  <div class="sphx-glr-thumbnail-title">Restricted Boltzmann Machine features for digit classification</div>
</div>
* [Restricted Boltzmann Machine features for digit classification](../../auto_examples/neural_networks/plot_rbm_logistic_classification.md#sphx-glr-auto-examples-neural-networks-plot-rbm-logistic-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Demonstrates an active learning technique to learn handwritten digits using label propagation.">  <div class="sphx-glr-thumbnail-title">Label Propagation digits active learning</div>
</div>
* [Label Propagation digits active learning](../../auto_examples/semi_supervised/plot_label_propagation_digits_active_learning.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-digits-active-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the power of semisupervised learning by training a Label Spreading model to classify handwritten digits with sets of very few labels.">  <div class="sphx-glr-thumbnail-title">Label Propagation digits: Demonstrating performance</div>
</div>
* [Label Propagation digits: Demonstrating performance](../../auto_examples/semi_supervised/plot_label_propagation_digits.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-digits-py)

<!-- thumbnail-parent-div-close --></div>
