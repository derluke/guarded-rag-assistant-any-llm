# estimate_bandwidth

### sklearn.cluster.estimate_bandwidth(X, \*, quantile=0.3, n_samples=None, random_state=0, n_jobs=None)

Estimate the bandwidth to use with the mean-shift algorithm.

This function takes time at least quadratic in `n_samples`. For large
datasets, it is wise to subsample by setting `n_samples`. Alternatively,
the parameter `bandwidth` can be set to a small value without estimating
it.

* **Parameters:**
  **X**
  : Input points.

  **quantile**
  : Should be between [0, 1]
    0.5 means that the median of all pairwise distances is used.

  **n_samples**
  : The number of samples to use. If not given, all samples are used.

  **random_state**
  : The generator used to randomly select the samples from input points
    for bandwidth estimation. Use an int to make the randomness
    deterministic.
    See [Glossary](../../glossary.md#term-random_state).

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Returns:**
  **bandwidth**
  : The bandwidth parameter.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.cluster import estimate_bandwidth
>>> X = np.array([[1, 1], [2, 1], [1, 0],
...               [4, 7], [3, 5], [3, 6]])
>>> estimate_bandwidth(X, quantile=0.5)
np.float64(1.61...)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Reference:">  <div class="sphx-glr-thumbnail-title">A demo of the mean-shift clustering algorithm</div>
</div>
* [A demo of the mean-shift clustering algorithm](../../auto_examples/cluster/plot_mean_shift.md#sphx-glr-auto-examples-cluster-plot-mean-shift-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<!-- thumbnail-parent-div-close --></div>
