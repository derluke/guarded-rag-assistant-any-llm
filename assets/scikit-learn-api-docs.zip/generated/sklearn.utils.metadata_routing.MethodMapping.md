# MethodMapping

### *class* sklearn.utils.metadata_routing.MethodMapping

Stores the mapping between caller and callee methods for a router.

This class is primarily used in a `get_metadata_routing()` of a router
object when defining the mapping between the router’s methods and a sub-object (a
sub-estimator or a scorer).

Iterating through an instance of this class yields
`MethodPair(caller, callee)` instances.

#### Versionadded
Added in version 1.3.

<!-- !! processed by numpydoc !! -->

#### add(\*, caller, callee)

Add a method mapping.

* **Parameters:**
  **caller**
  : Parent estimator’s method name in which the `callee` is called.

  **callee**
  : Child object’s method name. This method is called in `caller`.
* **Returns:**
  **self**
  : Returns self.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This document shows how you can use the metadata routing mechanism &lt;metadata_routing&gt; in scikit-learn to route metadata to the estimators, scorers, and CV splitters consuming them.">  <div class="sphx-glr-thumbnail-title">Metadata Routing</div>
</div>
* [Metadata Routing](../../auto_examples/miscellaneous/plot_metadata_routing.md#sphx-glr-auto-examples-miscellaneous-plot-metadata-routing-py)

<!-- thumbnail-parent-div-close --></div>
