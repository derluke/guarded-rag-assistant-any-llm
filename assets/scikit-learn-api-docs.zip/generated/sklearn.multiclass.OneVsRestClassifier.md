# OneVsRestClassifier

### *class* sklearn.multiclass.OneVsRestClassifier(estimator, \*, n_jobs=None, verbose=0)

One-vs-the-rest (OvR) multiclass strategy.

Also known as one-vs-all, this strategy consists in fitting one classifier
per class. For each classifier, the class is fitted against all the other
classes. In addition to its computational efficiency (only `n_classes`
classifiers are needed), one advantage of this approach is its
interpretability. Since each class is represented by one and one classifier
only, it is possible to gain knowledge about the class by inspecting its
corresponding classifier. This is the most commonly used strategy for
multiclass classification and is a fair default choice.

OneVsRestClassifier can also be used for multilabel classification. To use
this feature, provide an indicator matrix for the target `y` when calling
`.fit`. In other words, the target labels should be formatted as a 2D
binary (0/1) matrix, where [i, j] == 1 indicates the presence of label j
in sample i. This estimator uses the binary relevance method to perform
multilabel classification, which involves training one binary classifier
independently for each label.

Read more in the [User Guide](../multiclass.md#ovr-classification).

* **Parameters:**
  **estimator**
  : A regressor or a classifier that implements [fit](../../glossary.md#term-fit).
    When a classifier is passed, [decision_function](../../glossary.md#term-decision_function) will be used
    in priority and it will fallback to [predict_proba](../../glossary.md#term-predict_proba) if it is not
    available.
    When a regressor is passed, [predict](../../glossary.md#term-predict) is used.

  **n_jobs**
  : The number of jobs to use for the computation: the `n_classes`
    one-vs-rest problems are computed in parallel.
    <br/>
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionchanged
    Changed in version 0.20: `n_jobs` default changed from 1 to None

  **verbose**
  : The verbosity level, if non zero, progress messages are printed.
    Below 50, the output is sent to stderr. Otherwise, the output is sent
    to stdout. The frequency of the messages increases with the verbosity
    level, reporting all iterations at 10. See [`joblib.Parallel`](https://joblib.readthedocs.io/en/latest/generated/joblib.Parallel.html#joblib.Parallel) for
    more details.
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Attributes:**
  **estimators_**
  : Estimators used for predictions.

  **classes_**
  : Class labels.

  [`n_classes_`](#sklearn.multiclass.OneVsRestClassifier.n_classes_)
  : Number of classes.

  **label_binarizer_**
  : Object used to transform multiclass labels to binary labels and
    vice-versa.

  [`multilabel_`](#sklearn.multiclass.OneVsRestClassifier.multilabel_)
  : Whether this is a multilabel classifier.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`OneVsOneClassifier`](sklearn.multiclass.OneVsOneClassifier.md#sklearn.multiclass.OneVsOneClassifier)
: One-vs-one multiclass strategy.

[`OutputCodeClassifier`](sklearn.multiclass.OutputCodeClassifier.md#sklearn.multiclass.OutputCodeClassifier)
: (Error-Correcting) Output-Code multiclass strategy.

[`sklearn.multioutput.MultiOutputClassifier`](sklearn.multioutput.MultiOutputClassifier.md#sklearn.multioutput.MultiOutputClassifier)
: Alternate way of extending an estimator for multilabel classification.

[`sklearn.preprocessing.MultiLabelBinarizer`](sklearn.preprocessing.MultiLabelBinarizer.md#sklearn.preprocessing.MultiLabelBinarizer)
: Transform iterable of iterables to binary indicator matrix.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.multiclass import OneVsRestClassifier
>>> from sklearn.svm import SVC
>>> X = np.array([
...     [10, 10],
...     [8, 10],
...     [-5, 5.5],
...     [-5.4, 5.5],
...     [-20, -20],
...     [-15, -20]
... ])
>>> y = np.array([0, 0, 1, 1, 2, 2])
>>> clf = OneVsRestClassifier(SVC()).fit(X, y)
>>> clf.predict([[-19, -20], [9, 9], [-5, 5]])
array([2, 0, 1])
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Decision function for the OneVsRestClassifier.

Return the distance of each sample from the decision boundary for each
class. This can only be used with estimators which implement the
`decision_function` method.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  **T**
  : Result of calling `decision_function` on the final estimator.
    <br/>
    #### Versionchanged
    Changed in version 0.19: output shape changed to `(n_samples,)` to conform to
    scikit-learn conventions for binary classification.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*\*fit_params)

Fit underlying estimators.

* **Parameters:**
  **X**
  : Data.

  **y**
  : Multi-class targets. An indicator matrix turns on multilabel
    classification.

  **\*\*fit_params**
  : Parameters passed to the `estimator.fit` method of each
    sub-estimator.
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **self**
  : Instance of fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.4.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* multilabel_

Whether this is a multilabel classifier.

<!-- !! processed by numpydoc !! -->

#### *property* n_classes_

Number of classes.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y, classes=None, \*\*partial_fit_params)

Partially fit underlying estimators.

Should be used when memory is inefficient to train all data.
Chunks of data can be passed in several iterations.

* **Parameters:**
  **X**
  : Data.

  **y**
  : Multi-class targets. An indicator matrix turns on multilabel
    classification.

  **classes**
  : Classes across all calls to partial_fit.
    Can be obtained via `np.unique(y_all)`, where y_all is the
    target vector of the entire dataset.
    This argument is only required in the first call of partial_fit
    and can be omitted in the subsequent calls.

  **\*\*partial_fit_params**
  : Parameters passed to the `estimator.partial_fit` method of each
    sub-estimator.
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **self**
  : Instance of partially fitted estimator.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict multi-class targets using underlying estimators.

* **Parameters:**
  **X**
  : Data.
* **Returns:**
  **y**
  : Predicted multi-class targets.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Probability estimates.

The returned estimates for all classes are ordered by label of classes.

Note that in the multilabel case, each sample can have any number of
labels. This returns the marginal probability that the given sample has
the label in question. For example, it is entirely consistent that two
labels both have a 90% probability of applying to a given sample.

In the single label multiclass case, the rows of the returned matrix
sum to 1.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  **T**
  : Returns the probability of the sample for each class in the model,
    where classes are ordered as they are in `self.classes_`.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, classes: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [OneVsRestClassifier](#sklearn.multiclass.OneVsRestClassifier)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **classes**
  : Metadata routing for `classes` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [OneVsRestClassifier](#sklearn.multiclass.OneVsRestClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Plot the classification probability for different classifiers. We use a 3 class dataset, and we classify it with a Support Vector classifier, L1 and L2 penalized logistic regression (multinomial multiclass), a One-Vs-Rest version with logistic regression, and Gaussian process classification.">  <div class="sphx-glr-thumbnail-title">Plot classification probability</div>
</div>
* [Plot classification probability](../../auto_examples/classification/plot_classification_probability.md#sphx-glr-auto-examples-classification-plot-classification-probability-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares decision boundaries of multinomial and one-vs-rest logistic regression on a 2D dataset with three classes.">  <div class="sphx-glr-thumbnail-title">Decision Boundaries of Multinomial and One-vs-Rest Logistic Regression</div>
</div>
* [Decision Boundaries of Multinomial and One-vs-Rest Logistic Regression](../../auto_examples/linear_model/plot_logistic_multinomial.md#sphx-glr-auto-examples-linear-model-plot-logistic-multinomial-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparison of multinomial logistic L1 vs one-versus-rest L1 logistic regression to classify documents from the newgroups20 dataset. Multinomial logistic regression yields more accurate results and is faster to train on the larger scale dataset.">  <div class="sphx-glr-thumbnail-title">Multiclass sparse logistic regression on 20newgroups</div>
</div>
* [Multiclass sparse logistic regression on 20newgroups](../../auto_examples/linear_model/plot_sparse_logistic_regression_20newsgroups.md#sphx-glr-auto-examples-linear-model-plot-sparse-logistic-regression-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example simulates a multi-label document classification problem. The dataset is generated randomly based on the following process:">  <div class="sphx-glr-thumbnail-title">Multilabel classification</div>
</div>
* [Multilabel classification](../../auto_examples/miscellaneous/plot_multilabel.md#sphx-glr-auto-examples-miscellaneous-plot-multilabel-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example describes the use of the Receiver Operating Characteristic (ROC) metric to evaluate the quality of multiclass classifiers.">  <div class="sphx-glr-thumbnail-title">Multiclass Receiver Operating Characteristic (ROC)</div>
</div>
* [Multiclass Receiver Operating Characteristic (ROC)](../../auto_examples/model_selection/plot_roc.md#sphx-glr-auto-examples-model-selection-plot-roc-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we discuss the problem of classification when the target variable is composed of more than two classes. This is called multiclass classification.">  <div class="sphx-glr-thumbnail-title">Overview of multiclass training meta-estimators</div>
</div>
* [Overview of multiclass training meta-estimators](../../auto_examples/multiclass/plot_multiclass_overview.md#sphx-glr-auto-examples-multiclass-plot-multiclass-overview-py)

<div class="sphx-glr-thumbcontainer" tooltip="The most naive strategy to solve such a task is to independently train a binary classifier on each label (i.e. each column of the target variable). At prediction time, the ensemble of binary classifiers is used to assemble multitask prediction.">  <div class="sphx-glr-thumbnail-title">Multilabel classification using a classifier chain</div>
</div>
* [Multilabel classification using a classifier chain](../../auto_examples/multioutput/plot_classifier_chain_yeast.md#sphx-glr-auto-examples-multioutput-plot-classifier-chain-yeast-py)

<!-- thumbnail-parent-div-close --></div>
