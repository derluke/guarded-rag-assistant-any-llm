# SplineTransformer

### *class* sklearn.preprocessing.SplineTransformer(n_knots=5, degree=3, \*, knots='uniform', extrapolation='constant', include_bias=True, order='C', sparse_output=False)

Generate univariate B-spline bases for features.

Generate a new feature matrix consisting of
`n_splines=n_knots + degree - 1` (`n_knots - 1` for
`extrapolation="periodic"`) spline basis functions
(B-splines) of polynomial order=\`degree\` for each feature.

In order to learn more about the SplineTransformer class go to:
[Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

Read more in the [User Guide](../preprocessing.md#spline-transformer).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **n_knots**
  : Number of knots of the splines if `knots` equals one of
    {‘uniform’, ‘quantile’}. Must be larger or equal 2. Ignored if `knots`
    is array-like.

  **degree**
  : The polynomial degree of the spline basis. Must be a non-negative
    integer.

  **knots**
  : Set knot positions such that first knot <= features <= last knot.
    - If ‘uniform’, `n_knots` number of knots are distributed uniformly
      from min to max values of the features.
    - If ‘quantile’, they are distributed uniformly along the quantiles of
      the features.
    - If an array-like is given, it directly specifies the sorted knot
      positions including the boundary knots. Note that, internally,
      `degree` number of knots are added before the first knot, the same
      after the last knot.

  **extrapolation**
  : If ‘error’, values outside the min and max values of the training
    features raises a `ValueError`. If ‘constant’, the value of the
    splines at minimum and maximum value of the features is used as
    constant extrapolation. If ‘linear’, a linear extrapolation is used.
    If ‘continue’, the splines are extrapolated as is, i.e. option
    `extrapolate=True` in [`scipy.interpolate.BSpline`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.interpolate.BSpline.html#scipy.interpolate.BSpline). If
    ‘periodic’, periodic splines with a periodicity equal to the distance
    between the first and last knot are used. Periodic splines enforce
    equal function values and derivatives at the first and last knot.
    For example, this makes it possible to avoid introducing an arbitrary
    jump between Dec 31st and Jan 1st in spline features derived from a
    naturally periodic “day-of-year” input feature. In this case it is
    recommended to manually set the knot values to control the period.

  **include_bias**
  : If False, then the last spline element inside the data range
    of a feature is dropped. As B-splines sum to one over the spline basis
    functions for each data point, they implicitly include a bias term,
    i.e. a column of ones. It acts as an intercept term in a linear models.

  **order**
  : Order of output array in the dense case. `'F'` order is faster to compute, but
    may slow down subsequent estimators.

  **sparse_output**
  : Will return sparse CSR matrix if set True else will return an array. This
    option is only available with `scipy>=1.8`.
    <br/>
    #### Versionadded
    Added in version 1.2.
* **Attributes:**
  **bsplines_**
  : List of BSplines objects, one for each feature.

  **n_features_in_**
  : The total number of input features.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_features_out_**
  : The total number of output features, which is computed as
    `n_features * n_splines`, where `n_splines` is
    the number of bases elements of the B-splines,
    `n_knots + degree - 1` for non-periodic splines and
    `n_knots - 1` for periodic ones.
    If `include_bias=False`, then it is only
    `n_features * (n_splines - 1)`.

#### SEE ALSO
[`KBinsDiscretizer`](sklearn.preprocessing.KBinsDiscretizer.md#sklearn.preprocessing.KBinsDiscretizer)
: Transformer that bins continuous data into intervals.

[`PolynomialFeatures`](sklearn.preprocessing.PolynomialFeatures.md#sklearn.preprocessing.PolynomialFeatures)
: Transformer that generates polynomial and interaction features.

### Notes

High degrees and a high number of knots can cause overfitting.

See [examples/linear_model/plot_polynomial_interpolation.py](../../auto_examples/linear_model/plot_polynomial_interpolation.md#sphx-glr-auto-examples-linear-model-plot-polynomial-interpolation-py).

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.preprocessing import SplineTransformer
>>> X = np.arange(6).reshape(6, 1)
>>> spline = SplineTransformer(degree=2, n_knots=3)
>>> spline.fit_transform(X)
array([[0.5 , 0.5 , 0.  , 0.  ],
       [0.18, 0.74, 0.08, 0.  ],
       [0.02, 0.66, 0.32, 0.  ],
       [0.  , 0.32, 0.66, 0.02],
       [0.  , 0.08, 0.74, 0.18],
       [0.  , 0.  , 0.5 , 0.5 ]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Compute knot positions of splines.

* **Parameters:**
  **X**
  : The data.

  **y**
  : Ignored.

  **sample_weight**
  : Individual weights for each sample. Used to calculate quantiles if
    `knots="quantile"`. For `knots="uniform"`, zero weighted
    observations are ignored for finding the min and max of `X`.
* **Returns:**
  **self**
  : Fitted transformer.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SplineTransformer](#sklearn.preprocessing.SplineTransformer)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform each feature data to B-splines.

* **Parameters:**
  **X**
  : The data to transform.
* **Returns:**
  **XBS**
  : The matrix of features, where n_splines is the number of bases
    elements of the B-splines, n_knots + degree - 1.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to approximate a function with polynomials up to degree degree by using ridge regression. We show two different ways given n_samples of 1d points x_i:">  <div class="sphx-glr-thumbnail-title">Polynomial and Spline interpolation</div>
</div>
* [Polynomial and Spline interpolation](../../auto_examples/linear_model/plot_polynomial_interpolation.md#sphx-glr-auto-examples-linear-model-plot-polynomial-interpolation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are very pleased to announce the release of scikit-learn 1.0! The library has been stable for quite some time, releasing version 1.0 is recognizing that and signalling it to our users. This release does not include any breaking changes apart from the usual two-release deprecation cycle. For the future, we do our best to keep this pattern.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.0</div>
</div>
* [Release Highlights for scikit-learn 1.0](../../auto_examples/release_highlights/plot_release_highlights_1_0_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-0-0-py)

<!-- thumbnail-parent-div-close --></div>
