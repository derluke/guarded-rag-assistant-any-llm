# PowerTransformer

### *class* sklearn.preprocessing.PowerTransformer(method='yeo-johnson', \*, standardize=True, copy=True)

Apply a power transform featurewise to make data more Gaussian-like.

Power transforms are a family of parametric, monotonic transformations
that are applied to make data more Gaussian-like. This is useful for
modeling issues related to heteroscedasticity (non-constant variance),
or other situations where normality is desired.

Currently, PowerTransformer supports the Box-Cox transform and the
Yeo-Johnson transform. The optimal parameter for stabilizing variance and
minimizing skewness is estimated through maximum likelihood.

Box-Cox requires input data to be strictly positive, while Yeo-Johnson
supports both positive or negative data.

By default, zero-mean, unit-variance normalization is applied to the
transformed data.

For an example visualization, refer to [Compare PowerTransformer with
other scalers](../../auto_examples/preprocessing/plot_all_scaling.md#plot-all-scaling-power-transformer-section). To see the
effect of Box-Cox and Yeo-Johnson transformations on different
distributions, see:
[Map data to a normal distribution](../../auto_examples/preprocessing/plot_map_data_to_normal.md#sphx-glr-auto-examples-preprocessing-plot-map-data-to-normal-py).

Read more in the [User Guide](../preprocessing.md#preprocessing-transformer).

#### Versionadded
Added in version 0.20.

* **Parameters:**
  **method**
  : The power transform method. Available methods are:
    - ‘yeo-johnson’ [[1]](#rf3e1504535de-1), works with positive and negative values
    - ‘box-cox’ [[2]](#rf3e1504535de-2), only works with strictly positive values

  **standardize**
  : Set to True to apply zero-mean, unit-variance normalization to the
    transformed output.

  **copy**
  : Set to False to perform inplace computation during transformation.
* **Attributes:**
  **lambdas_**
  : The parameters of the power transformation for the selected features.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`power_transform`](sklearn.preprocessing.power_transform.md#sklearn.preprocessing.power_transform)
: Equivalent function without the estimator API.

[`QuantileTransformer`](sklearn.preprocessing.QuantileTransformer.md#sklearn.preprocessing.QuantileTransformer)
: Maps data to a standard normal distribution with the parameter `output_distribution='normal'`.

### Notes

NaNs are treated as missing values: disregarded in `fit`, and maintained
in `transform`.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.preprocessing import PowerTransformer
>>> pt = PowerTransformer()
>>> data = [[1, 2], [3, 2], [4, 5]]
>>> print(pt.fit(data))
PowerTransformer()
>>> print(pt.lambdas_)
[ 1.386... -3.100...]
>>> print(pt.transform(data))
[[-1.316... -0.707...]
 [ 0.209... -0.707...]
 [ 1.106...  1.414...]]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Estimate the optimal parameter lambda for each feature.

The optimal lambda parameter for minimizing skewness is estimated on
each feature independently using maximum likelihood.

* **Parameters:**
  **X**
  : The data used to estimate the optimal transformation parameters.

  **y**
  : Ignored.
* **Returns:**
  **self**
  : Fitted transformer.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Fit `PowerTransformer` to `X`, then transform `X`.

* **Parameters:**
  **X**
  : The data used to estimate the optimal transformation parameters
    and to be transformed using a power transformation.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **X_new**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Same as input features.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Apply the inverse power transformation using the fitted lambdas.

The inverse of the Box-Cox transformation is given by:

```default
if lambda_ == 0:
    X = exp(X_trans)
else:
    X = (X_trans * lambda_ + 1) ** (1 / lambda_)
```

The inverse of the Yeo-Johnson transformation is given by:

```default
if X >= 0 and lambda_ == 0:
    X = exp(X_trans) - 1
elif X >= 0 and lambda_ != 0:
    X = (X_trans * lambda_ + 1) ** (1 / lambda_) - 1
elif X < 0 and lambda_ != 2:
    X = 1 - (-(2 - lambda_) * X_trans + 1) ** (1 / (2 - lambda_))
elif X < 0 and lambda_ == 2:
    X = 1 - exp(-X_trans)
```

* **Parameters:**
  **X**
  : The transformed data.
* **Returns:**
  **X**
  : The original data.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Apply the power transform to each feature using the fitted lambdas.

* **Parameters:**
  **X**
  : The data to be transformed using a power transformation.
* **Returns:**
  **X_trans**
  : The transformed data.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Feature 0 (median income in a block) and feature 5 (average house occupancy) of the california_housing_dataset have very different scales and contain some very large outliers. These two characteristics lead to difficulties to visualize the data and, more importantly, they can degrade the predictive performance of many machine learning algorithms. Unscaled data can also slow down or even prevent the convergence of many gradient-based estimators.">  <div class="sphx-glr-thumbnail-title">Compare the effect of different scalers on data with outliers</div>
</div>
* [Compare the effect of different scalers on data with outliers](../../auto_examples/preprocessing/plot_all_scaling.md#sphx-glr-auto-examples-preprocessing-plot-all-scaling-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the use of the Box-Cox and Yeo-Johnson transforms through PowerTransformer to map data from various distributions to a normal distribution.">  <div class="sphx-glr-thumbnail-title">Map data to a normal distribution</div>
</div>
* [Map data to a normal distribution](../../auto_examples/preprocessing/plot_map_data_to_normal.md#sphx-glr-auto-examples-preprocessing-plot-map-data-to-normal-py)

<!-- thumbnail-parent-div-close --></div>
