# linear_kernel

### sklearn.metrics.pairwise.linear_kernel(X, Y=None, dense_output=True)

Compute the linear kernel between X and Y.

Read more in the [User Guide](../metrics.md#linear-kernel).

* **Parameters:**
  **X**
  : A feature array.

  **Y**
  : An optional second feature array. If `None`, uses `Y=X`.

  **dense_output**
  : Whether to return dense output even when the input is sparse. If
    `False`, the output is sparse if both input arrays are sparse.
    <br/>
    #### Versionadded
    Added in version 0.20.
* **Returns:**
  **kernel**
  : The Gram matrix of the linear kernel, i.e. `X @ Y.T`.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import linear_kernel
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> linear_kernel(X, Y)
array([[0., 0.],
       [1., 2.]])
```

<!-- !! processed by numpydoc !! -->
