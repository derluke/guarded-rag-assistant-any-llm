# LinearSVR

### *class* sklearn.svm.LinearSVR(\*, epsilon=0.0, tol=0.0001, C=1.0, loss='epsilon_insensitive', fit_intercept=True, intercept_scaling=1.0, dual='auto', verbose=0, random_state=None, max_iter=1000)

Linear Support Vector Regression.

Similar to SVR with parameter kernel=’linear’, but implemented in terms of
liblinear rather than libsvm, so it has more flexibility in the choice of
penalties and loss functions and should scale better to large numbers of
samples.

The main differences between [`LinearSVR`](#sklearn.svm.LinearSVR) and
[`SVR`](sklearn.svm.SVR.md#sklearn.svm.SVR) lie in the loss function used by default, and in
the handling of intercept regularization between those two implementations.

This class supports both dense and sparse input.

Read more in the [User Guide](../svm.md#svm-regression).

#### Versionadded
Added in version 0.16.

* **Parameters:**
  **epsilon**
  : Epsilon parameter in the epsilon-insensitive loss function. Note
    that the value of this parameter depends on the scale of the target
    variable y. If unsure, set `epsilon=0`.

  **tol**
  : Tolerance for stopping criteria.

  **C**
  : Regularization parameter. The strength of the regularization is
    inversely proportional to C. Must be strictly positive.

  **loss**
  : Specifies the loss function. The epsilon-insensitive loss
    (standard SVR) is the L1 loss, while the squared epsilon-insensitive
    loss (‘squared_epsilon_insensitive’) is the L2 loss.

  **fit_intercept**
  : Whether or not to fit an intercept. If set to True, the feature vector
    is extended to include an intercept term: `[x_1, ..., x_n, 1]`, where
    1 corresponds to the intercept. If set to False, no intercept will be
    used in calculations (i.e. data is expected to be already centered).

  **intercept_scaling**
  : When `fit_intercept` is True, the instance vector x becomes `[x_1, ...,
    x_n, intercept_scaling]`, i.e. a “synthetic” feature with a constant
    value equal to `intercept_scaling` is appended to the instance vector.
    The intercept becomes intercept_scaling \* synthetic feature weight.
    Note that liblinear internally penalizes the intercept, treating it
    like any other term in the feature vector. To reduce the impact of the
    regularization on the intercept, the `intercept_scaling` parameter can
    be set to a value greater than 1; the higher the value of
    `intercept_scaling`, the lower the impact of regularization on it.
    Then, the weights become `[w_x_1, ..., w_x_n,
    w_intercept*intercept_scaling]`, where `w_x_1, ..., w_x_n` represent
    the feature weights and the intercept weight is scaled by
    `intercept_scaling`. This scaling allows the intercept term to have a
    different regularization behavior compared to the other features.

  **dual**
  : Select the algorithm to either solve the dual or primal
    optimization problem. Prefer dual=False when n_samples > n_features.
    `dual="auto"` will choose the value of the parameter automatically,
    based on the values of `n_samples`, `n_features` and `loss`. If
    `n_samples` < `n_features` and optimizer supports chosen `loss`,
    then dual will be set to True, otherwise it will be set to False.
    <br/>
    #### Versionchanged
    Changed in version 1.3: The `"auto"` option is added in version 1.3 and will be the default
    in version 1.5.

  **verbose**
  : Enable verbose output. Note that this setting takes advantage of a
    per-process runtime setting in liblinear that, if enabled, may not work
    properly in a multithreaded context.

  **random_state**
  : Controls the pseudo random number generation for shuffling the data.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **max_iter**
  : The maximum number of iterations to be run.
* **Attributes:**
  **coef_**
  : Weights assigned to the features (coefficients in the primal
    problem).
    <br/>
    `coef_` is a readonly property derived from `raw_coef_` that
    follows the internal memory layout of liblinear.

  **intercept_**
  : Constants in decision function.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Maximum number of iterations run across all classes.

#### SEE ALSO
[`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC)
: Implementation of Support Vector Machine classifier using the same library as this class (liblinear).

[`SVR`](sklearn.svm.SVR.md#sklearn.svm.SVR)
: Implementation of Support Vector Machine regression using libsvm: the kernel can be non-linear but its SMO algorithm does not scale to large number of samples as [`LinearSVR`](#sklearn.svm.LinearSVR) does.

[`sklearn.linear_model.SGDRegressor`](sklearn.linear_model.SGDRegressor.md#sklearn.linear_model.SGDRegressor)
: SGDRegressor can optimize the same cost function as LinearSVR by adjusting the penalty and loss parameters. In addition it requires less memory, allows incremental (online) learning, and implements various loss functions and regularization regimes.

### Examples

```pycon
>>> from sklearn.svm import LinearSVR
>>> from sklearn.pipeline import make_pipeline
>>> from sklearn.preprocessing import StandardScaler
>>> from sklearn.datasets import make_regression
>>> X, y = make_regression(n_features=4, random_state=0)
>>> regr = make_pipeline(StandardScaler(),
...                      LinearSVR(random_state=0, tol=1e-5))
>>> regr.fit(X, y)
Pipeline(steps=[('standardscaler', StandardScaler()),
                ('linearsvr', LinearSVR(random_state=0, tol=1e-05))])
```

```pycon
>>> print(regr.named_steps['linearsvr'].coef_)
[18.582... 27.023... 44.357... 64.522...]
>>> print(regr.named_steps['linearsvr'].intercept_)
[-4...]
>>> print(regr.predict([[0, 0, 0, 0]]))
[-2.384...]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the model according to the given training data.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target vector relative to X.

  **sample_weight**
  : Array of weights that are assigned to individual
    samples. If not provided,
    then each sample is given unit weight.
    <br/>
    #### Versionadded
    Added in version 0.18.
* **Returns:**
  **self**
  : An instance of the estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LinearSVR](#sklearn.svm.LinearSVR)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LinearSVR](#sklearn.svm.LinearSVR)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->
