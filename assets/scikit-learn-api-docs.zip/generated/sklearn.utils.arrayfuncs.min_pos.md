# min_pos

### sklearn.utils.arrayfuncs.min_pos(X)

Find the minimum value of an array over positive values.

Returns the maximum representable value of the input dtype if none of the
values are positive.

* **Parameters:**
  **X**
  : Input array.
* **Returns:**
  **min_val**
  : The smallest positive value in the array, or the maximum representable value
    : of the input dtype if no positive values are found.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.utils.arrayfuncs import min_pos
>>> X = np.array([0, -1, 2, 3, -4, 5])
>>> min_pos(X)
2.0
```

<!-- !! processed by numpydoc !! -->
