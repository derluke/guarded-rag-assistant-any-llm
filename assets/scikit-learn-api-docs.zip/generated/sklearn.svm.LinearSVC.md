# LinearSVC

### *class* sklearn.svm.LinearSVC(penalty='l2', loss='squared_hinge', \*, dual='auto', tol=0.0001, C=1.0, multi_class='ovr', fit_intercept=True, intercept_scaling=1, class_weight=None, verbose=0, random_state=None, max_iter=1000)

Linear Support Vector Classification.

Similar to SVC with parameter kernel=’linear’, but implemented in terms of
liblinear rather than libsvm, so it has more flexibility in the choice of
penalties and loss functions and should scale better to large numbers of
samples.

The main differences between [`LinearSVC`](#sklearn.svm.LinearSVC) and
[`SVC`](sklearn.svm.SVC.md#sklearn.svm.SVC) lie in the loss function used by default, and in
the handling of intercept regularization between those two implementations.

This class supports both dense and sparse input and the multiclass support
is handled according to a one-vs-the-rest scheme.

Read more in the [User Guide](../svm.md#svm-classification).

* **Parameters:**
  **penalty**
  : Specifies the norm used in the penalization. The ‘l2’
    penalty is the standard used in SVC. The ‘l1’ leads to `coef_`
    vectors that are sparse.

  **loss**
  : Specifies the loss function. ‘hinge’ is the standard SVM loss
    (used e.g. by the SVC class) while ‘squared_hinge’ is the
    square of the hinge loss. The combination of `penalty='l1'`
    and `loss='hinge'` is not supported.

  **dual**
  : Select the algorithm to either solve the dual or primal
    optimization problem. Prefer dual=False when n_samples > n_features.
    `dual="auto"` will choose the value of the parameter automatically,
    based on the values of `n_samples`, `n_features`, `loss`, `multi_class`
    and `penalty`. If `n_samples` < `n_features` and optimizer supports
    chosen `loss`, `multi_class` and `penalty`, then dual will be set to True,
    otherwise it will be set to False.
    <br/>
    #### Versionchanged
    Changed in version 1.3: The `"auto"` option is added in version 1.3 and will be the default
    in version 1.5.

  **tol**
  : Tolerance for stopping criteria.

  **C**
  : Regularization parameter. The strength of the regularization is
    inversely proportional to C. Must be strictly positive.
    For an intuitive visualization of the effects of scaling
    the regularization parameter C, see
    [Scaling the regularization parameter for SVCs](../../auto_examples/svm/plot_svm_scale_c.md#sphx-glr-auto-examples-svm-plot-svm-scale-c-py).

  **multi_class**
  : Determines the multi-class strategy if `y` contains more than
    two classes.
    `"ovr"` trains n_classes one-vs-rest classifiers, while
    `"crammer_singer"` optimizes a joint objective over all classes.
    While `crammer_singer` is interesting from a theoretical perspective
    as it is consistent, it is seldom used in practice as it rarely leads
    to better accuracy and is more expensive to compute.
    If `"crammer_singer"` is chosen, the options loss, penalty and dual
    will be ignored.

  **fit_intercept**
  : Whether or not to fit an intercept. If set to True, the feature vector
    is extended to include an intercept term: `[x_1, ..., x_n, 1]`, where
    1 corresponds to the intercept. If set to False, no intercept will be
    used in calculations (i.e. data is expected to be already centered).

  **intercept_scaling**
  : When `fit_intercept` is True, the instance vector x becomes `[x_1,
    ..., x_n, intercept_scaling]`, i.e. a “synthetic” feature with a
    constant value equal to `intercept_scaling` is appended to the instance
    vector. The intercept becomes intercept_scaling \* synthetic feature
    weight. Note that liblinear internally penalizes the intercept,
    treating it like any other term in the feature vector. To reduce the
    impact of the regularization on the intercept, the `intercept_scaling`
    parameter can be set to a value greater than 1; the higher the value of
    `intercept_scaling`, the lower the impact of regularization on it.
    Then, the weights become `[w_x_1, ..., w_x_n,
    w_intercept*intercept_scaling]`, where `w_x_1, ..., w_x_n` represent
    the feature weights and the intercept weight is scaled by
    `intercept_scaling`. This scaling allows the intercept term to have a
    different regularization behavior compared to the other features.

  **class_weight**
  : Set the parameter C of class i to `class_weight[i]*C` for
    SVC. If not given, all classes are supposed to have
    weight one.
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`.

  **verbose**
  : Enable verbose output. Note that this setting takes advantage of a
    per-process runtime setting in liblinear that, if enabled, may not work
    properly in a multithreaded context.

  **random_state**
  : Controls the pseudo random number generation for shuffling the data for
    the dual coordinate descent (if `dual=True`). When `dual=False` the
    underlying implementation of [`LinearSVC`](#sklearn.svm.LinearSVC) is not random and
    `random_state` has no effect on the results.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **max_iter**
  : The maximum number of iterations to be run.
* **Attributes:**
  **coef_**
  : Weights assigned to the features (coefficients in the primal
    problem).
    <br/>
    `coef_` is a readonly property derived from `raw_coef_` that
    follows the internal memory layout of liblinear.

  **intercept_**
  : Constants in decision function.

  **classes_**
  : The unique classes labels.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Maximum number of iterations run across all classes.

#### SEE ALSO
[`SVC`](sklearn.svm.SVC.md#sklearn.svm.SVC)
: Implementation of Support Vector Machine classifier using libsvm: the kernel can be non-linear but its SMO algorithm does not scale to large number of samples as LinearSVC does. Furthermore SVC multi-class mode is implemented using one vs one scheme while LinearSVC uses one vs the rest. It is possible to implement one vs the rest with SVC by using the [`OneVsRestClassifier`](sklearn.multiclass.OneVsRestClassifier.md#sklearn.multiclass.OneVsRestClassifier) wrapper. Finally SVC can fit dense data without memory copy if the input is C-contiguous. Sparse data will still incur memory copy though.

[`sklearn.linear_model.SGDClassifier`](sklearn.linear_model.SGDClassifier.md#sklearn.linear_model.SGDClassifier)
: SGDClassifier can optimize the same cost function as LinearSVC by adjusting the penalty and loss parameters. In addition it requires less memory, allows incremental (online) learning, and implements various loss functions and regularization regimes.

### Notes

The underlying C implementation uses a random number generator to
select features when fitting the model. It is thus not uncommon
to have slightly different results for the same input data. If
that happens, try with a smaller `tol` parameter.

The underlying implementation, liblinear, uses a sparse internal
representation for the data that will incur a memory copy.

Predict output may not match that of standalone liblinear in certain
cases. See [differences from liblinear](../linear_model.md#liblinear-differences)
in the narrative documentation.

### References

[LIBLINEAR: A Library for Large Linear Classification](https://www.csie.ntu.edu.tw/~cjlin/liblinear/)

### Examples

```pycon
>>> from sklearn.svm import LinearSVC
>>> from sklearn.pipeline import make_pipeline
>>> from sklearn.preprocessing import StandardScaler
>>> from sklearn.datasets import make_classification
>>> X, y = make_classification(n_features=4, random_state=0)
>>> clf = make_pipeline(StandardScaler(),
...                     LinearSVC(random_state=0, tol=1e-5))
>>> clf.fit(X, y)
Pipeline(steps=[('standardscaler', StandardScaler()),
                ('linearsvc', LinearSVC(random_state=0, tol=1e-05))])
```

```pycon
>>> print(clf.named_steps['linearsvc'].coef_)
[[0.141...   0.526... 0.679... 0.493...]]
```

```pycon
>>> print(clf.named_steps['linearsvc'].intercept_)
[0.1693...]
>>> print(clf.predict([[0, 0, 0, 0]]))
[1]
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Predict confidence scores for samples.

The confidence score for a sample is proportional to the signed
distance of that sample to the hyperplane.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the confidence scores.
* **Returns:**
  **scores**
  : Confidence scores per `(n_samples, n_classes)` combination. In the
    binary case, confidence score for `self.classes_[1]` where >0 means
    this class would be predicted.

<!-- !! processed by numpydoc !! -->

#### densify()

Convert coefficient matrix to dense array format.

Converts the `coef_` member (back) to a numpy.ndarray. This is the
default format of `coef_` and is required for fitting, so calling
this method is only required on models that have previously been
sparsified; otherwise, it is a no-op.

* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the model according to the given training data.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target vector relative to X.

  **sample_weight**
  : Array of weights that are assigned to individual
    samples. If not provided,
    then each sample is given unit weight.
    <br/>
    #### Versionadded
    Added in version 0.18.
* **Returns:**
  **self**
  : An instance of the estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict class labels for samples in X.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the predictions.
* **Returns:**
  **y_pred**
  : Vector containing the class labels for each sample.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LinearSVC](#sklearn.svm.LinearSVC)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LinearSVC](#sklearn.svm.LinearSVC)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### sparsify()

Convert coefficient matrix to sparse format.

Converts the `coef_` member to a scipy.sparse matrix, which for
L1-regularized models can be much more memory- and storage-efficient
than the usual numpy.ndarray representation.

The `intercept_` member is not converted.

* **Returns:**
  self
  : Fitted estimator.

### Notes

For non-sparse models, i.e. when there are not many zeros in `coef_`,
this may actually *increase* memory usage, so use this method with
care. A rule of thumb is that the number of zero elements, which can
be computed with `(coef_ == 0).sum()`, must be more than 50% for this
to provide significant benefits.

After calling this method, further fitting with the partial_fit
method (if any) will not work until you call densify.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Well calibrated classifiers are probabilistic classifiers for which the output of predict_proba can be directly interpreted as a confidence level. For instance, a well calibrated (binary) classifier should classify the samples such that for the samples to which it gave a predict_proba value close to 0.8, approximately 80% actually belong to the positive class.">  <div class="sphx-glr-thumbnail-title">Comparison of Calibration of Classifiers</div>
</div>
* [Comparison of Calibration of Classifiers](../../auto_examples/calibration/plot_compare_calibration.md#sphx-glr-auto-examples-calibration-plot-compare-calibration-py)

<div class="sphx-glr-thumbcontainer" tooltip="When performing classification one often wants to predict not only the class label, but also the associated probability. This probability gives some kind of confidence on the prediction. This example demonstrates how to visualize how well calibrated the predicted probabilities are using calibration curves, also known as reliability diagrams. Calibration of an uncalibrated classifier will also be demonstrated.">  <div class="sphx-glr-thumbnail-title">Probability Calibration curves</div>
</div>
* [Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="Datasets can often contain components that require different feature extraction and processing pipelines. This scenario might occur when:">  <div class="sphx-glr-thumbnail-title">Column Transformer with Heterogeneous Data Sources</div>
</div>
* [Column Transformer with Heterogeneous Data Sources](../../auto_examples/compose/plot_column_transformer.md#sphx-glr-auto-examples-compose-plot-column-transformer-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example constructs a pipeline that does dimensionality reduction followed by prediction with a support vector classifier. It demonstrates the use of GridSearchCV and Pipeline to optimize over different classes of estimators in a single CV run -- unsupervised PCA and NMF dimensionality reductions are compared to univariate feature selection during the grid search.">  <div class="sphx-glr-thumbnail-title">Selecting dimensionality reduction with Pipeline and GridSearchCV</div>
</div>
* [Selecting dimensionality reduction with Pipeline and GridSearchCV](../../auto_examples/compose/plot_compare_reduction.md#sphx-glr-auto-examples-compose-plot-compare-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how a feature selection can be easily integrated within a machine learning pipeline.">  <div class="sphx-glr-thumbnail-title">Pipeline ANOVA SVM</div>
</div>
* [Pipeline ANOVA SVM](../../auto_examples/feature_selection/plot_feature_selection_pipeline.md#sphx-glr-auto-examples-feature-selection-plot-feature-selection-pipeline-py)

<div class="sphx-glr-thumbcontainer" tooltip="This notebook is an example of using univariate feature selection to improve classification accuracy on a noisy dataset.">  <div class="sphx-glr-thumbnail-title">Univariate Feature Selection</div>
</div>
* [Univariate Feature Selection](../../auto_examples/feature_selection/plot_feature_selection.md#sphx-glr-auto-examples-feature-selection-plot-feature-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of PolynomialCountSketch to efficiently generate polynomial kernel feature-space approximations. This is used to train linear classifiers that approximate the accuracy of kernelized ones.">  <div class="sphx-glr-thumbnail-title">Scalable learning with polynomial kernel approximation</div>
</div>
* [Scalable learning with polynomial kernel approximation](../../auto_examples/kernel_approximation/plot_scalable_poly_kernels.md#sphx-glr-auto-examples-kernel-approximation-plot-scalable-poly-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example illustrating the approximation of the feature map of an RBF kernel.">  <div class="sphx-glr-thumbnail-title">Explicit feature map approximation for RBF kernels</div>
</div>
* [Explicit feature map approximation for RBF kernels](../../auto_examples/miscellaneous/plot_kernel_approximation.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-approximation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example balances model complexity and cross-validated score by finding a decent accuracy within 1 standard deviation of the best accuracy score while minimising the number of PCA components [1].">  <div class="sphx-glr-thumbnail-title">Balance model complexity and cross-validated score</div>
</div>
* [Balance model complexity and cross-validated score](../../auto_examples/model_selection/plot_grid_search_refit_callable.md#sphx-glr-auto-examples-model-selection-plot-grid-search-refit-callable-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we compare two binary classification multi-threshold metrics: the Receiver Operating Characteristic (ROC) and the Detection Error Tradeoff (DET). For such purpose, we evaluate two different classifiers for the same classification task.">  <div class="sphx-glr-thumbnail-title">Detection error tradeoff (DET) curve</div>
</div>
* [Detection error tradeoff (DET) curve](../../auto_examples/model_selection/plot_det.md#sphx-glr-auto-examples-model-selection-plot-det-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<div class="sphx-glr-thumbcontainer" tooltip="A demonstration of feature discretization on synthetic classification datasets. Feature discretization decomposes each feature into a set of bins, here equally distributed in width. The discrete values are then one-hot encoded, and given to a linear classifier. This preprocessing enables a non-linear behavior even though the classifier is linear.">  <div class="sphx-glr-thumbnail-title">Feature discretization</div>
</div>
* [Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparison of different linear SVM classifiers on a 2D projection of the iris dataset. We only consider the first 2 features of this dataset:">  <div class="sphx-glr-thumbnail-title">Plot different SVM classifiers in the iris dataset</div>
</div>
* [Plot different SVM classifiers in the iris dataset](../../auto_examples/svm/plot_iris_svc.md#sphx-glr-auto-examples-svm-plot-iris-svc-py)

<div class="sphx-glr-thumbcontainer" tooltip="Unlike SVC (based on LIBSVM), LinearSVC (based on LIBLINEAR) does not provide the support vectors. This example demonstrates how to obtain the support vectors in LinearSVC.">  <div class="sphx-glr-thumbnail-title">Plot the support vectors in LinearSVC</div>
</div>
* [Plot the support vectors in LinearSVC](../../auto_examples/svm/plot_linearsvc_support_vectors.md#sphx-glr-auto-examples-svm-plot-linearsvc-support-vectors-py)

<div class="sphx-glr-thumbcontainer" tooltip="The following example illustrates the effect of scaling the regularization parameter when using svm for svm_classification. For SVC classification, we are interested in a risk minimization for the equation:">  <div class="sphx-glr-thumbnail-title">Scaling the regularization parameter for SVCs</div>
</div>
* [Scaling the regularization parameter for SVCs](../../auto_examples/svm/plot_svm_scale_c.md#sphx-glr-auto-examples-svm-plot-svm-scale-c-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
