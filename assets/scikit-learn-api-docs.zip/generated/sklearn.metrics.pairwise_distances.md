# pairwise_distances

### sklearn.metrics.pairwise_distances(X, Y=None, metric='euclidean', \*, n_jobs=None, force_all_finite='deprecated', ensure_all_finite=None, \*\*kwds)

Compute the distance matrix from a vector array X and optional Y.

This method takes either a vector array or a distance matrix, and returns
a distance matrix.
If the input is a vector array, the distances are computed.
If the input is a distances matrix, it is returned instead.
If the input is a collection of non-numeric data (e.g. a list of strings or a
boolean array), a custom metric must be passed.

This method provides a safe way to take a distance matrix as input, while
preserving compatibility with many other algorithms that take a vector
array.

If Y is given (default is None), then the returned matrix is the pairwise
distance between the arrays from both X and Y.

Valid values for metric are:

- From scikit-learn: [‘cityblock’, ‘cosine’, ‘euclidean’, ‘l1’, ‘l2’,
  ‘manhattan’]. These metrics support sparse matrix
  inputs.
  [‘nan_euclidean’] but it does not yet support sparse matrices.
- From scipy.spatial.distance: [‘braycurtis’, ‘canberra’, ‘chebyshev’,
  ‘correlation’, ‘dice’, ‘hamming’, ‘jaccard’, ‘kulsinski’, ‘mahalanobis’,
  ‘minkowski’, ‘rogerstanimoto’, ‘russellrao’, ‘seuclidean’,
  ‘sokalmichener’, ‘sokalsneath’, ‘sqeuclidean’, ‘yule’]
  See the documentation for scipy.spatial.distance for details on these
  metrics. These metrics do not support sparse matrix inputs.

#### NOTE
`'kulsinski'` is deprecated from SciPy 1.9 and will be removed in SciPy 1.11.

#### NOTE
`'matching'` has been removed in SciPy 1.9 (use `'hamming'` instead).

Note that in the case of ‘cityblock’, ‘cosine’ and ‘euclidean’ (which are
valid scipy.spatial.distance metrics), the scikit-learn implementation
will be used, which is faster and has support for sparse matrices (except
for ‘cityblock’). For a verbose description of the metrics from
scikit-learn, see [`sklearn.metrics.pairwise.distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics)
function.

Read more in the [User Guide](../metrics.md#metrics).

* **Parameters:**
  **X**
  : Array of pairwise distances between samples, or a feature array.
    The shape of the array should be (n_samples_X, n_samples_X) if
    metric == “precomputed” and (n_samples_X, n_features) otherwise.

  **Y**
  : An optional second feature array. Only allowed if
    metric != “precomputed”.

  **metric**
  : The metric to use when calculating distance between instances in a
    feature array. If metric is a string, it must be one of the options
    allowed by scipy.spatial.distance.pdist for its metric parameter, or
    a metric listed in `pairwise.PAIRWISE_DISTANCE_FUNCTIONS`.
    If metric is “precomputed”, X is assumed to be a distance matrix.
    Alternatively, if metric is a callable function, it is called on each
    pair of instances (rows) and the resulting value recorded. The callable
    should take two arrays from X as input and return a value indicating
    the distance between them.

  **n_jobs**
  : The number of jobs to use for the computation. This works by breaking
    down the pairwise matrix into n_jobs even slices and computing them
    using multithreading.
    <br/>
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    The “euclidean” and “cosine” metrics rely heavily on BLAS which is already
    multithreaded. So, increasing `n_jobs` would likely cause oversubscription
    and quickly degrade performance.

  **force_all_finite**
  : Whether to raise an error on np.inf, np.nan, pd.NA in array. Ignored
    for a metric listed in `pairwise.PAIRWISE_DISTANCE_FUNCTIONS`. The
    possibilities are:
    - True: Force all values of array to be finite.
    - False: accepts np.inf, np.nan, pd.NA in array.
    - ‘allow-nan’: accepts only np.nan and pd.NA values in array. Values
      cannot be infinite.
    <br/>
    #### Versionadded
    Added in version 0.22: `force_all_finite` accepts the string `'allow-nan'`.
    <br/>
    #### Versionchanged
    Changed in version 0.23: Accepts `pd.NA` and converts it into `np.nan`.
    <br/>
    #### Deprecated
    Deprecated since version 1.6: `force_all_finite` was renamed to `ensure_all_finite` and will be removed
    in 1.8.

  **ensure_all_finite**
  : Whether to raise an error on np.inf, np.nan, pd.NA in array. Ignored
    for a metric listed in `pairwise.PAIRWISE_DISTANCE_FUNCTIONS`. The
    possibilities are:
    - True: Force all values of array to be finite.
    - False: accepts np.inf, np.nan, pd.NA in array.
    - ‘allow-nan’: accepts only np.nan and pd.NA values in array. Values
      cannot be infinite.
    <br/>
    #### Versionadded
    Added in version 1.6: `force_all_finite` was renamed to `ensure_all_finite`.

  **\*\*kwds**
  : Any further parameters are passed directly to the distance function.
    If using a scipy.spatial.distance metric, the parameters are still
    metric dependent. See the scipy docs for usage examples.
* **Returns:**
  **D**
  : A distance matrix D such that D_{i, j} is the distance between the
    ith and jth vectors of the given matrix X, if Y is None.
    If Y is not None, then D_{i, j} is the distance between the ith array
    from X and the jth array from Y.

#### SEE ALSO
[`pairwise_distances_chunked`](sklearn.metrics.pairwise_distances_chunked.md#sklearn.metrics.pairwise_distances_chunked)
: Performs the same calculation as this function, but returns a generator of chunks of the distance matrix, in order to limit memory usage.

[`sklearn.metrics.pairwise.paired_distances`](sklearn.metrics.pairwise.paired_distances.md#sklearn.metrics.pairwise.paired_distances)
: Computes the distances between corresponding elements of two arrays.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import pairwise_distances
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> pairwise_distances(X, Y, metric='sqeuclidean')
array([[1., 2.],
       [2., 1.]])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Demonstrates the effect of different metrics on the hierarchical clustering.">  <div class="sphx-glr-thumbnail-title">Agglomerative clustering with different metrics</div>
</div>
* [Agglomerative clustering with different metrics](../../auto_examples/cluster/plot_agglomerative_clustering_metrics.md#sphx-glr-auto-examples-cluster-plot-agglomerative-clustering-metrics-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<!-- thumbnail-parent-div-close --></div>
