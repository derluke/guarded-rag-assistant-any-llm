# EstimatorCheckFailedWarning

### *exception* sklearn.exceptions.EstimatorCheckFailedWarning(\*, estimator, check_name: [str](https://docs.python.org/3/library/stdtypes.html#str), exception: [Exception](https://docs.python.org/3/library/exceptions.html#Exception), status: [str](https://docs.python.org/3/library/stdtypes.html#str), expected_to_fail: [bool](https://docs.python.org/3/library/functions.html#bool), expected_to_fail_reason: [str](https://docs.python.org/3/library/stdtypes.html#str))

Warning raised when an estimator check from the common tests fails.

* **Parameters:**
  **estimator**
  : Estimator instance for which the test failed.

  **check_name**
  : Name of the check that failed.

  **exception**
  : Exception raised by the failed check.

  **status**
  : Status of the check.

  **expected_to_fail**
  : Whether the check was expected to fail.

  **expected_to_fail_reason**
  : Reason for the expected failure.

<!-- !! processed by numpydoc !! -->
