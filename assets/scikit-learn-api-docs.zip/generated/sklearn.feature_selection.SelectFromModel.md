# SelectFromModel

### *class* sklearn.feature_selection.SelectFromModel(estimator, \*, threshold=None, prefit=False, norm_order=1, max_features=None, importance_getter='auto')

Meta-transformer for selecting features based on importance weights.

#### Versionadded
Added in version 0.17.

Read more in the [User Guide](../feature_selection.md#select-from-model).

* **Parameters:**
  **estimator**
  : The base estimator from which the transformer is built.
    This can be both a fitted (if `prefit` is set to True)
    or a non-fitted estimator. The estimator should have a
    `feature_importances_` or `coef_` attribute after fitting.
    Otherwise, the `importance_getter` parameter should be used.

  **threshold**
  : The threshold value to use for feature selection. Features whose
    absolute importance value is greater or equal are kept while the others
    are discarded. If “median” (resp. “mean”), then the `threshold` value
    is the median (resp. the mean) of the feature importances. A scaling
    factor (e.g., “1.25\*mean”) may also be used. If None and if the
    estimator has a parameter penalty set to l1, either explicitly
    or implicitly (e.g, Lasso), the threshold used is 1e-5.
    Otherwise, “mean” is used by default.

  **prefit**
  : Whether a prefit model is expected to be passed into the constructor
    directly or not.
    If `True`, `estimator` must be a fitted estimator.
    If `False`, `estimator` is fitted and updated by calling
    `fit` and `partial_fit`, respectively.

  **norm_order**
  : Order of the norm used to filter the vectors of coefficients below
    `threshold` in the case where the `coef_` attribute of the
    estimator is of dimension 2.

  **max_features**
  : The maximum number of features to select.
    - If an integer, then it specifies the maximum number of features to
      allow.
    - If a callable, then it specifies how to calculate the maximum number of
      features allowed by using the output of `max_features(X)`.
    - If `None`, then all features are kept.
    <br/>
    To only select based on `max_features`, set `threshold=-np.inf`.
    <br/>
    #### Versionadded
    Added in version 0.20.
    <br/>
    #### Versionchanged
    Changed in version 1.1: `max_features` accepts a callable.

  **importance_getter**
  : If ‘auto’, uses the feature importance either through a `coef_`
    attribute or `feature_importances_` attribute of estimator.
    <br/>
    Also accepts a string that specifies an attribute name/path
    for extracting feature importance (implemented with `attrgetter`).
    For example, give `regressor_.coef_` in case of
    [`TransformedTargetRegressor`](sklearn.compose.TransformedTargetRegressor.md#sklearn.compose.TransformedTargetRegressor)  or
    `named_steps.clf.feature_importances_` in case of
    [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline) with its last step named `clf`.
    <br/>
    If `callable`, overrides the default feature importance getter.
    The callable is passed with the fitted estimator and it should
    return importance for each feature.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  **estimator_**
  : The base estimator from which the transformer is built. This attribute
    exist only when `fit` has been called.
    - If `prefit=True`, it is a deep copy of `estimator`.
    - If `prefit=False`, it is a clone of `estimator` and fit on the data
      passed to `fit` or `partial_fit`.

  [`n_features_in_`](#sklearn.feature_selection.SelectFromModel.n_features_in_)
  : Number of features seen during `fit`.

  **max_features_**
  : Maximum number of features calculated during [fit](../../glossary.md#term-fit). Only defined
    if the `max_features` is not `None`.
    - If `max_features` is an `int`, then `max_features_ = max_features`.
    - If `max_features` is a callable, then `max_features_ = max_features(X)`.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  [`threshold_`](#sklearn.feature_selection.SelectFromModel.threshold_)
  : Threshold value used for feature selection.

#### SEE ALSO
[`RFE`](sklearn.feature_selection.RFE.md#sklearn.feature_selection.RFE)
: Recursive feature elimination based on importance weights.

[`RFECV`](sklearn.feature_selection.RFECV.md#sklearn.feature_selection.RFECV)
: Recursive feature elimination with built-in cross-validated selection of the best number of features.

[`SequentialFeatureSelector`](sklearn.feature_selection.SequentialFeatureSelector.md#sklearn.feature_selection.SequentialFeatureSelector)
: Sequential cross-validation based feature selection. Does not rely on importance weights.

### Notes

Allows NaN/Inf in the input if the underlying estimator does as well.

### Examples

```pycon
>>> from sklearn.feature_selection import SelectFromModel
>>> from sklearn.linear_model import LogisticRegression
>>> X = [[ 0.87, -1.34,  0.31 ],
...      [-2.79, -0.02, -0.85 ],
...      [-1.34, -0.48, -2.55 ],
...      [ 1.92,  1.48,  0.65 ]]
>>> y = [0, 1, 0, 1]
>>> selector = SelectFromModel(estimator=LogisticRegression()).fit(X, y)
>>> selector.estimator_.coef_
array([[-0.3252...,  0.8345...,  0.4976...]])
>>> selector.threshold_
np.float64(0.55249...)
>>> selector.get_support()
array([False,  True, False])
>>> selector.transform(X)
array([[-1.34],
       [-0.02],
       [-0.48],
       [ 1.48]])
```

Using a callable to create a selector that can use no more than half
of the input features.

```pycon
>>> def half_callable(X):
...     return round(len(X[0]) / 2)
>>> half_selector = SelectFromModel(estimator=LogisticRegression(),
...                                 max_features=half_callable)
>>> _ = half_selector.fit(X, y)
>>> half_selector.max_features_
2
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, \*\*fit_params)

Fit the SelectFromModel meta-transformer.

* **Parameters:**
  **X**
  : The training input samples.

  **y**
  : The target values (integers that correspond to classes in
    classification, real numbers in regression).

  **\*\*fit_params**
  : - If `enable_metadata_routing=False` (default): Parameters directly passed
      to the `fit` method of the sub-estimator. They are ignored if
      `prefit=True`.
    - If `enable_metadata_routing=True`: Parameters safely routed to the `fit`
      method of the sub-estimator. They are ignored if `prefit=True`.
    <br/>
    #### Versionchanged
    Changed in version 1.4: See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Mask feature names according to selected features.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.4.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_support(indices=False)

Get a mask, or integer index, of the features selected.

* **Parameters:**
  **indices**
  : If True, the return value will be an array of integers, rather
    than a boolean mask.
* **Returns:**
  **support**
  : An index that selects the retained features from a feature vector.
    If `indices` is False, this is a boolean array of shape
    [# input features], in which an element is True iff its
    corresponding feature is selected for retention. If `indices` is
    True, this is an integer array of shape [# output features] whose
    values are indices into the input feature vector.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Reverse the transformation operation.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : `X` with columns of zeros inserted where features would have
    been removed by [`transform`](#sklearn.feature_selection.SelectFromModel.transform).

<!-- !! processed by numpydoc !! -->

#### *property* n_features_in_

Number of features seen during `fit`.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y=None, \*\*partial_fit_params)

Fit the SelectFromModel meta-transformer only once.

* **Parameters:**
  **X**
  : The training input samples.

  **y**
  : The target values (integers that correspond to classes in
    classification, real numbers in regression).

  **\*\*partial_fit_params**
  : - If `enable_metadata_routing=False` (default): Parameters directly passed
      to the `partial_fit` method of the sub-estimator.
    - If `enable_metadata_routing=True`: Parameters passed to the `partial_fit`
      method of the sub-estimator. They are ignored if `prefit=True`.
    <br/>
    #### Versionchanged
    Changed in version 1.4: `**partial_fit_params` are routed to the sub-estimator, if
    `enable_metadata_routing=True` is set via
    [`set_config`](sklearn.set_config.md#sklearn.set_config), which allows for aliasing.
    <br/>
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### *property* threshold_

Threshold value used for feature selection.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Reduce X to the selected features.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : The input samples with only the selected features.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares two approaches for feature selection: SelectFromModel which is based on feature importance, and SequentialFeatureSelector which relies on a greedy approach.">  <div class="sphx-glr-thumbnail-title">Model-based and sequential feature selection</div>
</div>
* [Model-based and sequential feature selection](../../auto_examples/feature_selection/plot_select_from_model_diabetes.md#sphx-glr-auto-examples-feature-selection-plot-select-from-model-diabetes-py)

<!-- thumbnail-parent-div-close --></div>
