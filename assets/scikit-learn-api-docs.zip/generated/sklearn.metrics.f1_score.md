# f1_score

### sklearn.metrics.f1_score(y_true, y_pred, \*, labels=None, pos_label=1, average='binary', sample_weight=None, zero_division='warn')

Compute the F1 score, also known as balanced F-score or F-measure.

The F1 score can be interpreted as a harmonic mean of the precision and
recall, where an F1 score reaches its best value at 1 and worst score at 0.
The relative contribution of precision and recall to the F1 score are
equal. The formula for the F1 score is:

$$
\text{F1} = \frac{2 * \text{TP}}{2 * \text{TP} + \text{FP} + \text{FN}}

$$

Where $\text{TP}$ is the number of true positives, $\text{FN}$ is the
number of false negatives, and $\text{FP}$ is the number of false positives.
F1 is by default
calculated as 0.0 when there are no true positives, false negatives, or
false positives.

Support beyond [binary](../../glossary.md#term-binary) targets is achieved by treating [multiclass](../../glossary.md#term-multiclass)
and [multilabel](../../glossary.md#term-multilabel) data as a collection of binary problems, one for each
label. For the [binary](../../glossary.md#term-binary) case, setting `average='binary'` will return
F1 score for `pos_label`. If `average` is not `'binary'`, `pos_label` is ignored
and F1 score for both classes are computed, then averaged or both returned (when
`average=None`). Similarly, for [multiclass](../../glossary.md#term-multiclass) and [multilabel](../../glossary.md#term-multilabel) targets,
F1 score for all `labels` are either returned or averaged depending on the
`average` parameter. Use `labels` specify the set of labels to calculate F1 score
for.

Read more in the [User Guide](../model_evaluation.md#precision-recall-f-measure-metrics).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated targets as returned by a classifier.

  **labels**
  : The set of labels to include when `average != 'binary'`, and their
    order if `average is None`. Labels present in the data can be
    excluded, for example in multiclass classification to exclude a “negative
    class”. Labels not present in the data can be included and will be
    “assigned” 0 samples. For multilabel targets, labels are column indices.
    By default, all labels in `y_true` and `y_pred` are used in sorted order.
    <br/>
    #### Versionchanged
    Changed in version 0.17: Parameter `labels` improved for multiclass problem.

  **pos_label**
  : The class to report if `average='binary'` and the data is binary,
    otherwise this parameter is ignored.
    For multiclass or multilabel targets, set `labels=[pos_label]` and
    `average != 'binary'` to report metrics for one label only.

  **average**
  : This parameter is required for multiclass/multilabel targets.
    If `None`, the metrics for each class are returned. Otherwise, this
    determines the type of averaging performed on the data:
    <br/>
    `'binary'`:
    : Only report results for the class specified by `pos_label`.
      This is applicable only if targets (`y_{true,pred}`) are binary.
    <br/>
    `'micro'`:
    : Calculate metrics globally by counting the total true positives,
      false negatives and false positives.
    <br/>
    `'macro'`:
    : Calculate metrics for each label, and find their unweighted
      mean.  This does not take label imbalance into account.
    <br/>
    `'weighted'`:
    : Calculate metrics for each label, and find their average weighted
      by support (the number of true instances for each label). This
      alters ‘macro’ to account for label imbalance; it can result in an
      F-score that is not between precision and recall.
    <br/>
    `'samples'`:
    : Calculate metrics for each instance, and find their average (only
      meaningful for multilabel classification where this differs from
      [`accuracy_score`](sklearn.metrics.accuracy_score.md#sklearn.metrics.accuracy_score)).

  **sample_weight**
  : Sample weights.

  **zero_division**
  : Sets the value to return when there is a zero division, i.e. when all
    predictions and labels are negative.
    <br/>
    Notes:
    - If set to “warn”, this acts like 0, but a warning is also raised.
    - If set to `np.nan`, such values will be excluded from the average.
    <br/>
    #### Versionadded
    Added in version 1.3: `np.nan` option was added.
* **Returns:**
  **f1_score**
  : F1 score of the positive class in binary classification or weighted
    average of the F1 scores of each class for the multiclass task.

#### SEE ALSO
[`fbeta_score`](sklearn.metrics.fbeta_score.md#sklearn.metrics.fbeta_score)
: Compute the F-beta score.

[`precision_recall_fscore_support`](sklearn.metrics.precision_recall_fscore_support.md#sklearn.metrics.precision_recall_fscore_support)
: Compute the precision, recall, F-score, and support.

[`jaccard_score`](sklearn.metrics.jaccard_score.md#sklearn.metrics.jaccard_score)
: Compute the Jaccard similarity coefficient score.

[`multilabel_confusion_matrix`](sklearn.metrics.multilabel_confusion_matrix.md#sklearn.metrics.multilabel_confusion_matrix)
: Compute a confusion matrix for each class or sample.

### Notes

When `true positive + false positive + false negative == 0` (i.e. a class
is completely absent from both `y_true` or `y_pred`), f-score is
undefined. In such cases, by default f-score will be set to 0.0, and
`UndefinedMetricWarning` will be raised. This behavior can be modified by
setting the `zero_division` parameter.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.metrics import f1_score
>>> y_true = [0, 1, 2, 0, 1, 2]
>>> y_pred = [0, 2, 1, 0, 0, 1]
>>> f1_score(y_true, y_pred, average='macro')
0.26...
>>> f1_score(y_true, y_pred, average='micro')
0.33...
>>> f1_score(y_true, y_pred, average='weighted')
0.26...
>>> f1_score(y_true, y_pred, average=None)
array([0.8, 0. , 0. ])
```

```pycon
>>> # binary classification
>>> y_true_empty = [0, 0, 0, 0, 0, 0]
>>> y_pred_empty = [0, 0, 0, 0, 0, 0]
>>> f1_score(y_true_empty, y_pred_empty)
0.0...
>>> f1_score(y_true_empty, y_pred_empty, zero_division=1.0)
1.0...
>>> f1_score(y_true_empty, y_pred_empty, zero_division=np.nan)
nan...
```

```pycon
>>> # multilabel classification
>>> y_true = [[0, 0, 0], [1, 1, 1], [0, 1, 1]]
>>> y_pred = [[0, 0, 0], [1, 1, 1], [1, 1, 0]]
>>> f1_score(y_true, y_pred, average=None)
array([0.66666667, 1.        , 0.66666667])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="When performing classification one often wants to predict not only the class label, but also the associated probability. This probability gives some kind of confidence on the prediction. This example demonstrates how to visualize how well calibrated the predicted probabilities are using calibration curves, also known as reliability diagrams. Calibration of an uncalibrated classifier will also be demonstrated.">  <div class="sphx-glr-thumbnail-title">Probability Calibration curves</div>
</div>
* [Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, semi-supervised classifiers are trained on the 20 newsgroups dataset (which will be automatically downloaded).">  <div class="sphx-glr-thumbnail-title">Semi-supervised Classification on a Text Dataset</div>
</div>
* [Semi-supervised Classification on a Text Dataset](../../auto_examples/semi_supervised/plot_semi_supervised_newsgroups.md#sphx-glr-auto-examples-semi-supervised-plot-semi-supervised-newsgroups-py)

<!-- thumbnail-parent-div-close --></div>
