# UndefinedMetricWarning

### *exception* sklearn.exceptions.UndefinedMetricWarning

Warning used when the metric is invalid

#### Versionchanged
Changed in version 0.18: Moved from sklearn.base.

<!-- !! processed by numpydoc !! -->
