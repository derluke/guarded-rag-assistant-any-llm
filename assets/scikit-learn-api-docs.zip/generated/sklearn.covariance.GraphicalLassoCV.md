# GraphicalLassoCV

### *class* sklearn.covariance.GraphicalLassoCV(\*, alphas=4, n_refinements=4, cv=None, tol=0.0001, enet_tol=0.0001, max_iter=100, mode='cd', n_jobs=None, verbose=False, eps=2.220446049250313e-16, assume_centered=False)

Sparse inverse covariance w/ cross-validated choice of the l1 penalty.

See glossary entry for [cross-validation estimator](../../glossary.md#term-cross-validation-estimator).

Read more in the [User Guide](../covariance.md#sparse-inverse-covariance).

#### Versionchanged
Changed in version v0.20: GraphLassoCV has been renamed to GraphicalLassoCV

* **Parameters:**
  **alphas**
  : If an integer is given, it fixes the number of points on the
    grids of alpha to be used. If a list is given, it gives the
    grid to be used. See the notes in the class docstring for
    more details. Range is [1, inf) for an integer.
    Range is (0, inf] for an array-like of floats.

  **n_refinements**
  : The number of times the grid is refined. Not used if explicit
    values of alphas are passed. Range is [1, inf).

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross-validation,
    - integer, to specify the number of folds.
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.20: `cv` default value if None changed from 3-fold to 5-fold.

  **tol**
  : The tolerance to declare convergence: if the dual gap goes below
    this value, iterations are stopped. Range is (0, inf].

  **enet_tol**
  : The tolerance for the elastic net solver used to calculate the descent
    direction. This parameter controls the accuracy of the search direction
    for a given column update, not of the overall parameter estimate. Only
    used for mode=’cd’. Range is (0, inf].

  **max_iter**
  : Maximum number of iterations.

  **mode**
  : The Lasso solver to use: coordinate descent or LARS. Use LARS for
    very sparse underlying graphs, where number of features is greater
    than number of samples. Elsewhere prefer cd which is more numerically
    stable.

  **n_jobs**
  : Number of jobs to run in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionchanged
    Changed in version v0.20: `n_jobs` default changed from 1 to None

  **verbose**
  : If verbose is True, the objective function and duality gap are
    printed at each iteration.

  **eps**
  : The machine-precision regularization in the computation of the
    Cholesky diagonal factors. Increase this for very ill-conditioned
    systems. Default is `np.finfo(np.float64).eps`.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **assume_centered**
  : If True, data are not centered before computation.
    Useful when working with data whose mean is almost, but not exactly
    zero.
    If False, data are centered before computation.
* **Attributes:**
  **location_**
  : Estimated location, i.e. the estimated mean.

  **covariance_**
  : Estimated covariance matrix.

  **precision_**
  : Estimated precision matrix (inverse covariance).

  **costs_**
  : The list of values of the objective function and the dual gap at
    each iteration. Returned only if return_costs is True.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **alpha_**
  : Penalization parameter selected.

  **cv_results_**
  : A dict with keys:
    <br/>
    alphas
    : All penalization parameters explored.
    <br/>
    split(k)_test_score
    : Log-likelihood score on left-out data across (k)th fold.
      <br/>
      #### Versionadded
      Added in version 1.0.
    <br/>
    mean_test_score
    : Mean of scores over the folds.
      <br/>
      #### Versionadded
      Added in version 1.0.
    <br/>
    std_test_score
    : Standard deviation of scores over the folds.
      <br/>
      #### Versionadded
      Added in version 1.0.

  **n_iter_**
  : Number of iterations run for the optimal alpha.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`graphical_lasso`](sklearn.covariance.graphical_lasso.md#sklearn.covariance.graphical_lasso)
: L1-penalized covariance estimator.

[`GraphicalLasso`](sklearn.covariance.GraphicalLasso.md#sklearn.covariance.GraphicalLasso)
: Sparse inverse covariance estimation with an l1-penalized estimator.

### Notes

The search for the optimal penalization parameter (`alpha`) is done on an
iteratively refined grid: first the cross-validated scores on a grid are
computed, then a new refined grid is centered around the maximum, and so
on.

One of the challenges which is faced here is that the solvers can
fail to converge to a well-conditioned estimate. The corresponding
values of `alpha` then come out as missing values, but the optimum may
be close to these missing values.

In `fit`, once the best parameter `alpha` is found through
cross-validation, the model is fit again using the entire training set.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.covariance import GraphicalLassoCV
>>> true_cov = np.array([[0.8, 0.0, 0.2, 0.0],
...                      [0.0, 0.4, 0.0, 0.0],
...                      [0.2, 0.0, 0.3, 0.1],
...                      [0.0, 0.0, 0.1, 0.7]])
>>> np.random.seed(0)
>>> X = np.random.multivariate_normal(mean=[0, 0, 0, 0],
...                                   cov=true_cov,
...                                   size=200)
>>> cov = GraphicalLassoCV().fit(X)
>>> np.around(cov.covariance_, decimals=3)
array([[0.816, 0.051, 0.22 , 0.017],
       [0.051, 0.364, 0.018, 0.036],
       [0.22 , 0.018, 0.322, 0.094],
       [0.017, 0.036, 0.094, 0.69 ]])
>>> np.around(cov.location_, decimals=3)
array([0.073, 0.04 , 0.038, 0.143])
```

<!-- !! processed by numpydoc !! -->

#### error_norm(comp_cov, norm='frobenius', scaling=True, squared=True)

Compute the Mean Squared Error between two covariance estimators.

* **Parameters:**
  **comp_cov**
  : The covariance to compare with.

  **norm**
  : The type of norm used to compute the error. Available error types:
    - ‘frobenius’ (default): sqrt(tr(A^t.A))
    - ‘spectral’: sqrt(max(eigenvalues(A^t.A))
    where A is the error `(comp_cov - self.covariance_)`.

  **scaling**
  : If True (default), the squared error norm is divided by n_features.
    If False, the squared error norm is not rescaled.

  **squared**
  : Whether to compute the squared error norm or the error norm.
    If True (default), the squared error norm is returned.
    If False, the error norm is returned.
* **Returns:**
  **result**
  : The Mean Squared Error (in the sense of the Frobenius norm) between
    `self` and `comp_cov` covariance estimators.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, \*\*params)

Fit the GraphicalLasso covariance model to X.

* **Parameters:**
  **X**
  : Data from which to compute the covariance estimate.

  **y**
  : Not used, present for API consistency by convention.

  **\*\*params**
  : Parameters to be passed to the CV splitter and the
    cross_val_score function.
    <br/>
    #### Versionadded
    Added in version 1.5: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.5.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_precision()

Getter for the precision matrix.

* **Returns:**
  **precision_**
  : The precision matrix associated to the current covariance object.

<!-- !! processed by numpydoc !! -->

#### mahalanobis(X)

Compute the squared Mahalanobis distances of given observations.

* **Parameters:**
  **X**
  : The observations, the Mahalanobis distances of the which we
    compute. Observations are assumed to be drawn from the same
    distribution than the data used in fit.
* **Returns:**
  **dist**
  : Squared Mahalanobis distances of the observations.

<!-- !! processed by numpydoc !! -->

#### score(X_test, y=None)

Compute the log-likelihood of `X_test` under the estimated Gaussian model.

The Gaussian model is defined by its mean and covariance matrix which are
represented respectively by `self.location_` and `self.covariance_`.

* **Parameters:**
  **X_test**
  : Test data of which we compute the likelihood, where `n_samples` is
    the number of samples and `n_features` is the number of features.
    `X_test` is assumed to be drawn from the same distribution than
    the data used in fit (including centering).

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **res**
  : The log-likelihood of `X_test` with `self.location_` and `self.covariance_`
    as estimators of the Gaussian model mean and covariance matrix respectively.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example employs several unsupervised learning techniques to extract the stock market structure from variations in historical quotes.">  <div class="sphx-glr-thumbnail-title">Visualizing the stock market structure</div>
</div>
* [Visualizing the stock market structure](../../auto_examples/applications/plot_stock_market.md#sphx-glr-auto-examples-applications-plot-stock-market-py)

<div class="sphx-glr-thumbcontainer" tooltip="Using the GraphicalLasso estimator to learn a covariance and sparse precision from a small number of samples.">  <div class="sphx-glr-thumbnail-title">Sparse inverse covariance estimation</div>
</div>
* [Sparse inverse covariance estimation](../../auto_examples/covariance/plot_sparse_cov.md#sphx-glr-auto-examples-covariance-plot-sparse-cov-py)

<!-- thumbnail-parent-div-close --></div>
