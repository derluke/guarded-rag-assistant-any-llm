# precision_recall_curve

### sklearn.metrics.precision_recall_curve(y_true, y_score=None, \*, pos_label=None, sample_weight=None, drop_intermediate=False, probas_pred='deprecated')

Compute precision-recall pairs for different probability thresholds.

Note: this implementation is restricted to the binary classification task.

The precision is the ratio `tp / (tp + fp)` where `tp` is the number of
true positives and `fp` the number of false positives. The precision is
intuitively the ability of the classifier not to label as positive a sample
that is negative.

The recall is the ratio `tp / (tp + fn)` where `tp` is the number of
true positives and `fn` the number of false negatives. The recall is
intuitively the ability of the classifier to find all the positive samples.

The last precision and recall values are 1. and 0. respectively and do not
have a corresponding threshold. This ensures that the graph starts on the
y axis.

The first precision and recall values are precision=class balance and recall=1.0
which corresponds to a classifier that always predicts the positive class.

Read more in the [User Guide](../model_evaluation.md#precision-recall-f-measure-metrics).

* **Parameters:**
  **y_true**
  : True binary labels. If labels are not either {-1, 1} or {0, 1}, then
    pos_label should be explicitly given.

  **y_score**
  : Target scores, can either be probability estimates of the positive
    class, or non-thresholded measure of decisions (as returned by
    `decision_function` on some classifiers).
    For [decision_function](../../glossary.md#term-decision_function) scores, values greater than or equal to
    zero should indicate the positive class.

  **pos_label**
  : The label of the positive class.
    When `pos_label=None`, if y_true is in {-1, 1} or {0, 1},
    `pos_label` is set to 1, otherwise an error will be raised.

  **sample_weight**
  : Sample weights.

  **drop_intermediate**
  : Whether to drop some suboptimal thresholds which would not appear
    on a plotted precision-recall curve. This is useful in order to create
    lighter precision-recall curves.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **probas_pred**
  : Target scores, can either be probability estimates of the positive
    class, or non-thresholded measure of decisions (as returned by
    `decision_function` on some classifiers).
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `probas_pred` is deprecated and will be removed in 1.7. Use
    `y_score` instead.
* **Returns:**
  **precision**
  : Precision values such that element i is the precision of
    predictions with score >= thresholds[i] and the last element is 1.

  **recall**
  : Decreasing recall values such that element i is the recall of
    predictions with score >= thresholds[i] and the last element is 0.

  **thresholds**
  : Increasing thresholds on the decision function used to compute
    precision and recall where `n_thresholds = len(np.unique(probas_pred))`.

#### SEE ALSO
[`PrecisionRecallDisplay.from_estimator`](sklearn.metrics.PrecisionRecallDisplay.md#sklearn.metrics.PrecisionRecallDisplay.from_estimator)
: Plot Precision Recall Curve given a binary classifier.

[`PrecisionRecallDisplay.from_predictions`](sklearn.metrics.PrecisionRecallDisplay.md#sklearn.metrics.PrecisionRecallDisplay.from_predictions)
: Plot Precision Recall Curve using predictions from a binary classifier.

[`average_precision_score`](sklearn.metrics.average_precision_score.md#sklearn.metrics.average_precision_score)
: Compute average precision from prediction scores.

[`det_curve`](sklearn.metrics.det_curve.md#sklearn.metrics.det_curve)
: Compute error rates for different probability thresholds.

[`roc_curve`](sklearn.metrics.roc_curve.md#sklearn.metrics.roc_curve)
: Compute Receiver operating characteristic (ROC) curve.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.metrics import precision_recall_curve
>>> y_true = np.array([0, 0, 1, 1])
>>> y_scores = np.array([0.1, 0.4, 0.35, 0.8])
>>> precision, recall, thresholds = precision_recall_curve(
...     y_true, y_scores)
>>> precision
array([0.5       , 0.66666667, 0.5       , 1.        , 1.        ])
>>> recall
array([1. , 1. , 0.5, 0.5, 0. ])
>>> thresholds
array([0.1 , 0.35, 0.4 , 0.8 ])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<!-- thumbnail-parent-div-close --></div>
