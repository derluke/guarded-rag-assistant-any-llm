# MinCovDet

### *class* sklearn.covariance.MinCovDet(\*, store_precision=True, assume_centered=False, support_fraction=None, random_state=None)

Minimum Covariance Determinant (MCD): robust estimator of covariance.

The Minimum Covariance Determinant covariance estimator is to be applied
on Gaussian-distributed data, but could still be relevant on data
drawn from a unimodal, symmetric distribution. It is not meant to be used
with multi-modal data (the algorithm used to fit a MinCovDet object is
likely to fail in such a case).
One should consider projection pursuit methods to deal with multi-modal
datasets.

Read more in the [User Guide](../covariance.md#robust-covariance).

* **Parameters:**
  **store_precision**
  : Specify if the estimated precision is stored.

  **assume_centered**
  : If True, the support of the robust location and the covariance
    estimates is computed, and a covariance estimate is recomputed from
    it, without centering the data.
    Useful to work with data whose mean is significantly equal to
    zero but is not exactly zero.
    If False, the robust location and covariance are directly computed
    with the FastMCD algorithm without additional treatment.

  **support_fraction**
  : The proportion of points to be included in the support of the raw
    MCD estimate. Default is None, which implies that the minimum
    value of support_fraction will be used within the algorithm:
    `(n_samples + n_features + 1) / 2 * n_samples`. The parameter must be
    in the range (0, 1].

  **random_state**
  : Determines the pseudo random number generator for shuffling the data.
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **raw_location_**
  : The raw robust estimated location before correction and re-weighting.

  **raw_covariance_**
  : The raw robust estimated covariance before correction and re-weighting.

  **raw_support_**
  : A mask of the observations that have been used to compute
    the raw robust estimates of location and shape, before correction
    and re-weighting.

  **location_**
  : Estimated robust location.

  **covariance_**
  : Estimated robust covariance matrix.

  **precision_**
  : Estimated pseudo inverse matrix.
    (stored only if store_precision is True)

  **support_**
  : A mask of the observations that have been used to compute
    the robust estimates of location and shape.

  **dist_**
  : Mahalanobis distances of the training set (on which [`fit`](#sklearn.covariance.MinCovDet.fit) is
    called) observations.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`EllipticEnvelope`](sklearn.covariance.EllipticEnvelope.md#sklearn.covariance.EllipticEnvelope)
: An object for detecting outliers in a Gaussian distributed dataset.

[`EmpiricalCovariance`](sklearn.covariance.EmpiricalCovariance.md#sklearn.covariance.EmpiricalCovariance)
: Maximum likelihood covariance estimator.

[`GraphicalLasso`](sklearn.covariance.GraphicalLasso.md#sklearn.covariance.GraphicalLasso)
: Sparse inverse covariance estimation with an l1-penalized estimator.

[`GraphicalLassoCV`](sklearn.covariance.GraphicalLassoCV.md#sklearn.covariance.GraphicalLassoCV)
: Sparse inverse covariance with cross-validated choice of the l1 penalty.

[`LedoitWolf`](sklearn.covariance.LedoitWolf.md#sklearn.covariance.LedoitWolf)
: LedoitWolf Estimator.

[`OAS`](sklearn.covariance.OAS.md#sklearn.covariance.OAS)
: Oracle Approximating Shrinkage Estimator.

[`ShrunkCovariance`](sklearn.covariance.ShrunkCovariance.md#sklearn.covariance.ShrunkCovariance)
: Covariance estimator with shrinkage.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.covariance import MinCovDet
>>> from sklearn.datasets import make_gaussian_quantiles
>>> real_cov = np.array([[.8, .3],
...                      [.3, .4]])
>>> rng = np.random.RandomState(0)
>>> X = rng.multivariate_normal(mean=[0, 0],
...                                   cov=real_cov,
...                                   size=500)
>>> cov = MinCovDet(random_state=0).fit(X)
>>> cov.covariance_
array([[0.7411..., 0.2535...],
       [0.2535..., 0.3053...]])
>>> cov.location_
array([0.0813... , 0.0427...])
```

<!-- !! processed by numpydoc !! -->

#### correct_covariance(data)

Apply a correction to raw Minimum Covariance Determinant estimates.

Correction using the empirical correction factor suggested
by Rousseeuw and Van Driessen in [[RVD]](#r491365aeaa84-rvd).

* **Parameters:**
  **data**
  : The data matrix, with p features and n samples.
    The data set must be the one which was used to compute
    the raw estimates.
* **Returns:**
  **covariance_corrected**
  : Corrected robust covariance estimate.

### References

<!-- !! processed by numpydoc !! -->

#### error_norm(comp_cov, norm='frobenius', scaling=True, squared=True)

Compute the Mean Squared Error between two covariance estimators.

* **Parameters:**
  **comp_cov**
  : The covariance to compare with.

  **norm**
  : The type of norm used to compute the error. Available error types:
    - ‘frobenius’ (default): sqrt(tr(A^t.A))
    - ‘spectral’: sqrt(max(eigenvalues(A^t.A))
    where A is the error `(comp_cov - self.covariance_)`.

  **scaling**
  : If True (default), the squared error norm is divided by n_features.
    If False, the squared error norm is not rescaled.

  **squared**
  : Whether to compute the squared error norm or the error norm.
    If True (default), the squared error norm is returned.
    If False, the error norm is returned.
* **Returns:**
  **result**
  : The Mean Squared Error (in the sense of the Frobenius norm) between
    `self` and `comp_cov` covariance estimators.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit a Minimum Covariance Determinant with the FastMCD algorithm.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_precision()

Getter for the precision matrix.

* **Returns:**
  **precision_**
  : The precision matrix associated to the current covariance object.

<!-- !! processed by numpydoc !! -->

#### mahalanobis(X)

Compute the squared Mahalanobis distances of given observations.

* **Parameters:**
  **X**
  : The observations, the Mahalanobis distances of the which we
    compute. Observations are assumed to be drawn from the same
    distribution than the data used in fit.
* **Returns:**
  **dist**
  : Squared Mahalanobis distances of the observations.

<!-- !! processed by numpydoc !! -->

#### reweight_covariance(data)

Re-weight raw Minimum Covariance Determinant estimates.

Re-weight observations using Rousseeuw’s method (equivalent to
deleting outlying observations from the data set before
computing location and covariance estimates) described
in [[RVDriessen]](#r9465bad4668c-rvdriessen).

* **Parameters:**
  **data**
  : The data matrix, with p features and n samples.
    The data set must be the one which was used to compute
    the raw estimates.
* **Returns:**
  **location_reweighted**
  : Re-weighted robust location estimate.

  **covariance_reweighted**
  : Re-weighted robust covariance estimate.

  **support_reweighted**
  : A mask of the observations that have been used to compute
    the re-weighted robust location and covariance estimates.

### References

<!-- !! processed by numpydoc !! -->

#### score(X_test, y=None)

Compute the log-likelihood of `X_test` under the estimated Gaussian model.

The Gaussian model is defined by its mean and covariance matrix which are
represented respectively by `self.location_` and `self.covariance_`.

* **Parameters:**
  **X_test**
  : Test data of which we compute the likelihood, where `n_samples` is
    the number of samples and `n_features` is the number of features.
    `X_test` is assumed to be drawn from the same distribution than
    the data used in fit (including centering).

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **res**
  : The log-likelihood of `X_test` with `self.location_` and `self.covariance_`
    as estimators of the Gaussian model mean and covariance matrix respectively.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows covariance estimation with Mahalanobis distances on Gaussian distributed data.">  <div class="sphx-glr-thumbnail-title">Robust covariance estimation and Mahalanobis distances relevance</div>
</div>
* [Robust covariance estimation and Mahalanobis distances relevance](../../auto_examples/covariance/plot_mahalanobis_distances.md#sphx-glr-auto-examples-covariance-plot-mahalanobis-distances-py)

<div class="sphx-glr-thumbcontainer" tooltip="The usual covariance maximum likelihood estimate is very sensitive to the presence of outliers in the data set. In such a case, it would be better to use a robust estimator of covariance to guarantee that the estimation is resistant to &quot;erroneous&quot; observations in the data set. [1]_, [2]_">  <div class="sphx-glr-thumbnail-title">Robust vs Empirical covariance estimate</div>
</div>
* [Robust vs Empirical covariance estimate](../../auto_examples/covariance/plot_robust_vs_empirical_covariance.md#sphx-glr-auto-examples-covariance-plot-robust-vs-empirical-covariance-py)

<!-- thumbnail-parent-div-close --></div>
