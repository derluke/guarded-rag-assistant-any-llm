# FrozenEstimator

### *class* sklearn.frozen.FrozenEstimator(estimator)

Estimator that wraps a fitted estimator to prevent re-fitting.

This meta-estimator takes an estimator and freezes it, in the sense that calling
`fit` on it has no effect. `fit_predict` and `fit_transform` are also disabled.
All other methods are delegated to the original estimator and original estimator’s
attributes are accessible as well.

This is particularly useful when you have a fitted or a pre-trained model as a
transformer in a pipeline, and you’d like `pipeline.fit` to have no effect on this
step.

* **Parameters:**
  **estimator**
  : The estimator which is to be kept frozen.

#### SEE ALSO
[`None`](https://docs.python.org/3/library/constants.html#None)
: No similar entry in the scikit-learn documentation.

### Examples

```pycon
>>> from sklearn.datasets import make_classification
>>> from sklearn.frozen import FrozenEstimator
>>> from sklearn.linear_model import LogisticRegression
>>> X, y = make_classification(random_state=0)
>>> clf = LogisticRegression(random_state=0).fit(X, y)
>>> frozen_clf = FrozenEstimator(clf)
>>> frozen_clf.fit(X, y)  # No-op
FrozenEstimator(estimator=LogisticRegression(random_state=0))
>>> frozen_clf.predict(X)  # Predictions from `clf.predict`
array(...)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*args, \*\*kwargs)

No-op.

As a frozen estimator, calling `fit` has no effect.

* **Parameters:**
  **X**
  : Ignored.

  **y**
  : Ignored.

  **\*args**
  : Additional positional arguments. Ignored, but present for API compatibility
    with `self.estimator`.

  **\*\*kwargs**
  : Additional keyword arguments. Ignored, but present for API compatibility
    with `self.estimator`.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

Returns a `{"estimator": estimator}` dict. The parameters of the inner
estimator are not included.

* **Parameters:**
  **deep**
  : Ignored.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*kwargs)

Set the parameters of this estimator.

The only valid key here is `estimator`. You cannot set the parameters of the
inner estimator.

* **Parameters:**
  **\*\*kwargs**
  : Estimator parameters.
* **Returns:**
  **self**
  : This estimator.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how sigmoid calibration changes predicted probabilities for a 3-class classification problem. Illustrated is the standard 2-simplex, where the three corners correspond to the three classes. Arrows point from the probability vectors predicted by an uncalibrated classifier to the probability vectors predicted by the same classifier after sigmoid calibration on a hold-out validation set. Colors indicate the true class of an instance (red: class 1, green: class 2, blue: class 3).">  <div class="sphx-glr-thumbnail-title">Probability Calibration for 3-class classification</div>
</div>
* [Probability Calibration for 3-class classification](../../auto_examples/calibration/plot_calibration_multiclass.md#sphx-glr-auto-examples-calibration-plot-calibration-multiclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="This examples showcases some use cases of FrozenEstimator.">  <div class="sphx-glr-thumbnail-title">Examples of Using FrozenEstimator</div>
</div>
* [Examples of Using FrozenEstimator](../../auto_examples/frozen/plot_frozen_examples.md#sphx-glr-auto-examples-frozen-plot-frozen-examples-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.6! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_6&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.6</div>
</div>
* [Release Highlights for scikit-learn 1.6](../../auto_examples/release_highlights/plot_release_highlights_1_6_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-6-0-py)

<!-- thumbnail-parent-div-close --></div>
