# DataDimensionalityWarning

### *exception* sklearn.exceptions.DataDimensionalityWarning

Custom warning to notify potential issues with data dimensionality.

For example, in random projection, this warning is raised when the
number of components, which quantifies the dimensionality of the target
projection space, is higher than the number of features, which quantifies
the dimensionality of the original source space, to imply that the
dimensionality of the problem will not be reduced.

#### Versionchanged
Changed in version 0.18: Moved from sklearn.utils.

<!-- !! processed by numpydoc !! -->
