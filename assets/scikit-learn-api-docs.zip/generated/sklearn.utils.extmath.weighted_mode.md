# weighted_mode

### sklearn.utils.extmath.weighted_mode(a, w, \*, axis=0)

Return an array of the weighted modal (most common) value in the passed array.

If there is more than one such value, only the first is returned.
The bin-count for the modal bins is also returned.

This is an extension of the algorithm in scipy.stats.mode.

* **Parameters:**
  **a**
  : Array of which values to find mode(s).

  **w**
  : Array of weights for each value.

  **axis**
  : Axis along which to operate. Default is 0, i.e. the first axis.
* **Returns:**
  **vals**
  : Array of modal values.

  **score**
  : Array of weighted counts for each mode.

#### SEE ALSO
[`scipy.stats.mode`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.mode.html#scipy.stats.mode)
: Calculates the Modal (most common) value of array elements along specified axis.

### Examples

```pycon
>>> from sklearn.utils.extmath import weighted_mode
>>> x = [4, 1, 4, 2, 4, 2]
>>> weights = [1, 1, 1, 1, 1, 1]
>>> weighted_mode(x, weights)
(array([4.]), array([3.]))
```

The value 4 appears three times: with uniform weights, the result is
simply the mode of the distribution.

```pycon
>>> weights = [1, 3, 0.5, 1.5, 1, 2]  # deweight the 4's
>>> weighted_mode(x, weights)
(array([2.]), array([3.5]))
```

The value 2 has the highest score: it appears twice with weights of
1.5 and 2: the sum of these is 3.5.

<!-- !! processed by numpydoc !! -->
