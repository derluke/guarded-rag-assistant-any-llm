# LinearRegression

### *class* sklearn.linear_model.LinearRegression(\*, fit_intercept=True, copy_X=True, n_jobs=None, positive=False)

Ordinary least squares Linear Regression.

LinearRegression fits a linear model with coefficients w = (w1, …, wp)
to minimize the residual sum of squares between the observed targets in
the dataset, and the targets predicted by the linear approximation.

* **Parameters:**
  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to False, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **copy_X**
  : If True, X will be copied; else, it may be overwritten.

  **n_jobs**
  : The number of jobs to use for the computation. This will only provide
    speedup in case of sufficiently large problems, that is if firstly
    `n_targets > 1` and secondly `X` is sparse or if `positive` is set
    to `True`. `None` means 1 unless in a
    [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context. `-1` means using all
    processors. See [Glossary](../../glossary.md#term-n_jobs) for more details.

  **positive**
  : When set to `True`, forces the coefficients to be positive. This
    option is only supported for dense arrays.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  **coef_**
  : Estimated coefficients for the linear regression problem.
    If multiple targets are passed during the fit (y 2D), this
    is a 2D array of shape (n_targets, n_features), while if only
    one target is passed, this is a 1D array of length n_features.

  **rank_**
  : Rank of matrix `X`. Only available when `X` is dense.

  **singular_**
  : Singular values of `X`. Only available when `X` is dense.

  **intercept_**
  : Independent term in the linear model. Set to 0.0 if
    `fit_intercept = False`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`Ridge`](sklearn.linear_model.Ridge.md#sklearn.linear_model.Ridge)
: Ridge regression addresses some of the problems of Ordinary Least Squares by imposing a penalty on the size of the coefficients with l2 regularization.

[`Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso)
: The Lasso is a linear model that estimates sparse coefficients with l1 regularization.

[`ElasticNet`](sklearn.linear_model.ElasticNet.md#sklearn.linear_model.ElasticNet)
: Elastic-Net is a linear regression model trained with both l1 and l2 -norm regularization of the coefficients.

### Notes

From the implementation point of view, this is just plain Ordinary
Least Squares (scipy.linalg.lstsq) or Non Negative Least Squares
(scipy.optimize.nnls) wrapped as a predictor object.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.linear_model import LinearRegression
>>> X = np.array([[1, 1], [1, 2], [2, 2], [2, 3]])
>>> # y = 1 * x_0 + 2 * x_1 + 3
>>> y = np.dot(X, np.array([1, 2])) + 3
>>> reg = LinearRegression().fit(X, y)
>>> reg.score(X, y)
1.0
>>> reg.coef_
array([1., 2.])
>>> reg.intercept_
np.float64(3.0...)
>>> reg.predict(np.array([[3, 5]]))
array([16.])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit linear model.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values. Will be cast to X’s dtype if necessary.

  **sample_weight**
  : Individual weights for each sample.
    <br/>
    #### Versionadded
    Added in version 0.17: parameter *sample_weight* support to LinearRegression.
* **Returns:**
  **self**
  : Fitted Estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LinearRegression](#sklearn.linear_model.LinearRegression)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LinearRegression](#sklearn.linear_model.LinearRegression)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares Principal Component Regression (PCR) and Partial Least Squares Regression (PLS) on a toy dataset. Our goal is to illustrate how PLS can outperform PCR when the target is strongly correlated with some directions in the data that have a low variance.">  <div class="sphx-glr-thumbnail-title">Principal Component Regression vs Partial Least Squares Regression</div>
</div>
* [Principal Component Regression vs Partial Least Squares Regression](../../auto_examples/cross_decomposition/plot_pcr_vs_pls.md#sphx-glr-auto-examples-cross-decomposition-plot-pcr-vs-pls-py)

<div class="sphx-glr-thumbcontainer" tooltip="A voting regressor is an ensemble meta-estimator that fits several base regressors, each on the whole dataset. Then it averages the individual predictions to form a final prediction. We will use three different regressors to predict the data: GradientBoostingRegressor, RandomForestRegressor, and LinearRegression). Then the above 3 regressors will be used for the VotingRegressor.">  <div class="sphx-glr-thumbnail-title">Plot individual and voting regression predictions</div>
</div>
* [Plot individual and voting regression predictions](../../auto_examples/ensemble/plot_voting_regressor.md#sphx-glr-auto-examples-ensemble-plot-voting-regressor-py)

<div class="sphx-glr-thumbcontainer" tooltip="Machine Learning models are great for measuring statistical associations. Unfortunately, unless we&#x27;re willing to make strong assumptions about the data, those models are unable to infer causal effects.">  <div class="sphx-glr-thumbnail-title">Failure of Machine Learning to infer causal effects</div>
</div>
* [Failure of Machine Learning to infer causal effects](../../auto_examples/inspection/plot_causal_interpretation.md#sphx-glr-auto-examples-inspection-plot-causal-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two different bayesian regressors:">  <div class="sphx-glr-thumbnail-title">Comparing Linear Bayesian Regressors</div>
</div>
* [Comparing Linear Bayesian Regressors](../../auto_examples/linear_model/plot_ard.md#sphx-glr-auto-examples-linear-model-plot-ard-py)

<div class="sphx-glr-thumbcontainer" tooltip="Shown in the plot is how the logistic regression would, in this synthetic dataset, classify values as either 0 or 1, i.e. class one or two, using the logistic curve.">  <div class="sphx-glr-thumbnail-title">Logistic function</div>
</div>
* [Logistic function](../../auto_examples/linear_model/plot_logistic.md#sphx-glr-auto-examples-linear-model-plot-logistic-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we fit a linear model with positive constraints on the regression coefficients and compare the estimated coefficients to a classic linear regression.">  <div class="sphx-glr-thumbnail-title">Non-negative least squares</div>
</div>
* [Non-negative least squares](../../auto_examples/linear_model/plot_nnls.md#sphx-glr-auto-examples-linear-model-plot-nnls-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use the ordinary least squares (OLS) model called LinearRegression in scikit-learn.">  <div class="sphx-glr-thumbnail-title">Ordinary Least Squares Example</div>
</div>
* [Ordinary Least Squares Example](../../auto_examples/linear_model/plot_ols.md#sphx-glr-auto-examples-linear-model-plot-ols-py)

<div class="sphx-glr-thumbcontainer" tooltip="Ridge regression is basically minimizing a penalised version of the least-squared function. The penalising shrinks the value of the regression coefficients. Despite the few data points in each dimension, the slope of the prediction is much more stable and the variance in the line itself is greatly reduced, in comparison to that of the standard linear regression">  <div class="sphx-glr-thumbnail-title">Ordinary Least Squares and Ridge Regression Variance</div>
</div>
* [Ordinary Least Squares and Ridge Regression Variance](../../auto_examples/linear_model/plot_ols_ridge_variance.md#sphx-glr-auto-examples-linear-model-plot-ols-ridge-variance-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how quantile regression can predict non-trivial conditional quantiles.">  <div class="sphx-glr-thumbnail-title">Quantile regression</div>
</div>
* [Quantile regression](../../auto_examples/linear_model/plot_quantile_regression.md#sphx-glr-auto-examples-linear-model-plot-quantile-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="Here a sine function is fit with a polynomial of order 3, for values close to zero.">  <div class="sphx-glr-thumbnail-title">Robust linear estimator fitting</div>
</div>
* [Robust linear estimator fitting](../../auto_examples/linear_model/plot_robust_fit.md#sphx-glr-auto-examples-linear-model-plot-robust-fit-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we see how to robustly fit a linear model to faulty data using the ransac_regression algorithm.">  <div class="sphx-glr-thumbnail-title">Robust linear model estimation using RANSAC</div>
</div>
* [Robust linear model estimation using RANSAC](../../auto_examples/linear_model/plot_ransac.md#sphx-glr-auto-examples-linear-model-plot-ransac-py)

<div class="sphx-glr-thumbcontainer" tooltip="Computes a Theil-Sen Regression on a synthetic dataset.">  <div class="sphx-glr-thumbnail-title">Theil-Sen Regression</div>
</div>
* [Theil-Sen Regression](../../auto_examples/linear_model/plot_theilsen.md#sphx-glr-auto-examples-linear-model-plot-theilsen-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows the use of multi-output estimator to complete images. The goal is to predict the lower half of a face given its upper half.">  <div class="sphx-glr-thumbnail-title">Face completion with a multi-output estimators</div>
</div>
* [Face completion with a multi-output estimators](../../auto_examples/miscellaneous/plot_multioutput_face_completion.md#sphx-glr-auto-examples-miscellaneous-plot-multioutput-face-completion-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of the isotonic regression on generated data (non-linear monotonic trend with homoscedastic uniform noise).">  <div class="sphx-glr-thumbnail-title">Isotonic Regression</div>
</div>
* [Isotonic Regression](../../auto_examples/miscellaneous/plot_isotonic_regression.md#sphx-glr-auto-examples-miscellaneous-plot-isotonic-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="This document shows how you can use the metadata routing mechanism &lt;metadata_routing&gt; in scikit-learn to route metadata to the estimators, scorers, and CV splitters consuming them.">  <div class="sphx-glr-thumbnail-title">Metadata Routing</div>
</div>
* [Metadata Routing](../../auto_examples/miscellaneous/plot_metadata_routing.md#sphx-glr-auto-examples-miscellaneous-plot-metadata-routing-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use cross_val_predict together with PredictionErrorDisplay to visualize prediction errors.">  <div class="sphx-glr-thumbnail-title">Plotting Cross-Validated Predictions</div>
</div>
* [Plotting Cross-Validated Predictions](../../auto_examples/model_selection/plot_cv_predict.md#sphx-glr-auto-examples-model-selection-plot-cv-predict-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the problems of underfitting and overfitting and how we can use linear regression with polynomial features to approximate nonlinear functions. The plot shows the function that we want to approximate, which is a part of the cosine function. In addition, the samples from the real function and the approximations of different models are displayed. The models have polynomial features of different degrees. We can see that a linear function (polynomial with degree 1) is not sufficient to fit the training samples. This is called underfitting. A polynomial of degree 4 approximates the true function almost perfectly. However, for higher degrees the model will overfit the training data, i.e. it learns the noise of the training data. We evaluate quantitatively overfitting / underfitting by using cross-validation. We calculate the mean squared error (MSE) on the validation set, the higher, the less likely the model generalizes correctly from the training data.">  <div class="sphx-glr-thumbnail-title">Underfitting vs. Overfitting</div>
</div>
* [Underfitting vs. Overfitting](../../auto_examples/model_selection/plot_underfitting_overfitting.md#sphx-glr-auto-examples-model-selection-plot-underfitting-overfitting-py)

<div class="sphx-glr-thumbcontainer" tooltip="The example compares prediction result of linear regression (linear model) and decision tree (tree based model) with and without discretization of real-valued features.">  <div class="sphx-glr-thumbnail-title">Using KBinsDiscretizer to discretize continuous features</div>
</div>
* [Using KBinsDiscretizer to discretize continuous features](../../auto_examples/preprocessing/plot_discretization.md#sphx-glr-auto-examples-preprocessing-plot-discretization-py)

<!-- thumbnail-parent-div-close --></div>
