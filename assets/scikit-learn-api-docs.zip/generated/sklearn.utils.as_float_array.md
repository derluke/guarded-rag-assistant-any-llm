# as_float_array

### sklearn.utils.as_float_array(X, \*, copy=True, force_all_finite='deprecated', ensure_all_finite=None)

Convert an array-like to an array of floats.

The new dtype will be np.float32 or np.float64, depending on the original
type. The function can create a copy or modify the argument depending
on the argument copy.

* **Parameters:**
  **X**
  : The input data.

  **copy**
  : If True, a copy of X will be created. If False, a copy may still be
    returned if X’s dtype is not a floating point type.

  **force_all_finite**
  : Whether to raise an error on np.inf, np.nan, pd.NA in X. The
    possibilities are:
    - True: Force all values of X to be finite.
    - False: accepts np.inf, np.nan, pd.NA in X.
    - ‘allow-nan’: accepts only np.nan and pd.NA values in X. Values cannot
      be infinite.
    <br/>
    #### Versionadded
    Added in version 0.20: `force_all_finite` accepts the string `'allow-nan'`.
    <br/>
    #### Versionchanged
    Changed in version 0.23: Accepts `pd.NA` and converts it into `np.nan`
    <br/>
    #### Deprecated
    Deprecated since version 1.6: `force_all_finite` was renamed to `ensure_all_finite` and will be removed
    in 1.8.

  **ensure_all_finite**
  : Whether to raise an error on np.inf, np.nan, pd.NA in X. The
    possibilities are:
    - True: Force all values of X to be finite.
    - False: accepts np.inf, np.nan, pd.NA in X.
    - ‘allow-nan’: accepts only np.nan and pd.NA values in X. Values cannot
      be infinite.
    <br/>
    #### Versionadded
    Added in version 1.6: `force_all_finite` was renamed to `ensure_all_finite`.
* **Returns:**
  **XT**
  : An array of type float.

### Examples

```pycon
>>> from sklearn.utils import as_float_array
>>> import numpy as np
>>> array = np.array([0, 0, 1, 2, 2], dtype=np.int64)
>>> as_float_array(array)
array([0., 0., 1., 2., 2.])
```

<!-- !! processed by numpydoc !! -->
