# ExtraTreeRegressor

### *class* sklearn.tree.ExtraTreeRegressor(\*, criterion='squared_error', splitter='random', max_depth=None, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features=1.0, random_state=None, min_impurity_decrease=0.0, max_leaf_nodes=None, ccp_alpha=0.0, monotonic_cst=None)

An extremely randomized tree regressor.

Extra-trees differ from classic decision trees in the way they are built.
When looking for the best split to separate the samples of a node into two
groups, random splits are drawn for each of the `max_features` randomly
selected features and the best split among those is chosen. When
`max_features` is set 1, this amounts to building a totally random
decision tree.

Warning: Extra-trees should only be used within ensemble methods.

Read more in the [User Guide](../tree.md#tree).

* **Parameters:**
  **criterion**
  : The function to measure the quality of a split. Supported criteria
    are “squared_error” for the mean squared error, which is equal to
    variance reduction as feature selection criterion and minimizes the L2
    loss using the mean of each terminal node, “friedman_mse”, which uses
    mean squared error with Friedman’s improvement score for potential
    splits, “absolute_error” for the mean absolute error, which minimizes
    the L1 loss using the median of each terminal node, and “poisson” which
    uses reduction in Poisson deviance to find splits.
    <br/>
    #### Versionadded
    Added in version 0.18: Mean Absolute Error (MAE) criterion.
    <br/>
    #### Versionadded
    Added in version 0.24: Poisson deviance criterion.

  **splitter**
  : The strategy used to choose the split at each node. Supported
    strategies are “best” to choose the best split and “random” to choose
    the best random split.

  **max_depth**
  : The maximum depth of the tree. If None, then nodes are expanded until
    all leaves are pure or until all leaves contain less than
    min_samples_split samples.

  **min_samples_split**
  : The minimum number of samples required to split an internal node:
    - If int, then consider `min_samples_split` as the minimum number.
    - If float, then `min_samples_split` is a fraction and
      `ceil(min_samples_split * n_samples)` are the minimum
      number of samples for each split.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_samples_leaf**
  : The minimum number of samples required to be at a leaf node.
    A split point at any depth will only be considered if it leaves at
    least `min_samples_leaf` training samples in each of the left and
    right branches.  This may have the effect of smoothing the model,
    especially in regression.
    - If int, then consider `min_samples_leaf` as the minimum number.
    - If float, then `min_samples_leaf` is a fraction and
      `ceil(min_samples_leaf * n_samples)` are the minimum
      number of samples for each node.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_weight_fraction_leaf**
  : The minimum weighted fraction of the sum total of weights (of all
    the input samples) required to be at a leaf node. Samples have
    equal weight when sample_weight is not provided.

  **max_features**
  : The number of features to consider when looking for the best split:
    - If int, then consider `max_features` features at each split.
    - If float, then `max_features` is a fraction and
      `max(1, int(max_features * n_features_in_))` features are considered at each
      split.
    - If “sqrt”, then `max_features=sqrt(n_features)`.
    - If “log2”, then `max_features=log2(n_features)`.
    - If None, then `max_features=n_features`.
    <br/>
    #### Versionchanged
    Changed in version 1.1: The default of `max_features` changed from `"auto"` to `1.0`.
    <br/>
    Note: the search for a split does not stop until at least one
    valid partition of the node samples is found, even if it requires to
    effectively inspect more than `max_features` features.

  **random_state**
  : Used to pick randomly the `max_features` used at each split.
    See [Glossary](../../glossary.md#term-random_state) for details.

  **min_impurity_decrease**
  : A node will be split if this split induces a decrease of the impurity
    greater than or equal to this value.
    <br/>
    The weighted impurity decrease equation is the following:
    ```default
    N_t / N * (impurity - N_t_R / N_t * right_impurity
                        - N_t_L / N_t * left_impurity)
    ```
    <br/>
    where `N` is the total number of samples, `N_t` is the number of
    samples at the current node, `N_t_L` is the number of samples in the
    left child, and `N_t_R` is the number of samples in the right child.
    <br/>
    `N`, `N_t`, `N_t_R` and `N_t_L` all refer to the weighted sum,
    if `sample_weight` is passed.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **max_leaf_nodes**
  : Grow a tree with `max_leaf_nodes` in best-first fashion.
    Best nodes are defined as relative reduction in impurity.
    If None then unlimited number of leaf nodes.

  **ccp_alpha**
  : Complexity parameter used for Minimal Cost-Complexity Pruning. The
    subtree with the largest cost complexity that is smaller than
    `ccp_alpha` will be chosen. By default, no pruning is performed. See
    [Minimal Cost-Complexity Pruning](../tree.md#minimal-cost-complexity-pruning) for details. See
    [Post pruning decision trees with cost complexity pruning](../../auto_examples/tree/plot_cost_complexity_pruning.md#sphx-glr-auto-examples-tree-plot-cost-complexity-pruning-py)
    for an example of such pruning.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **monotonic_cst**
  : Indicates the monotonicity constraint to enforce on each feature.
    : - 1: monotonic increase
      - 0: no constraint
      - -1: monotonic decrease
    <br/>
    If monotonic_cst is None, no constraints are applied.
    <br/>
    Monotonicity constraints are not supported for:
    : - multioutput regressions (i.e. when `n_outputs_ > 1`),
      - regressions trained on data with missing values.
    <br/>
    Read more in the [User Guide](../ensemble.md#monotonic-cst-gbdt).
    <br/>
    #### Versionadded
    Added in version 1.4.
* **Attributes:**
  **max_features_**
  : The inferred value of max_features.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  [`feature_importances_`](#sklearn.tree.ExtraTreeRegressor.feature_importances_)
  : Return the feature importances.

  **n_outputs_**
  : The number of outputs when `fit` is performed.

  **tree_**
  : The underlying Tree object. Please refer to
    `help(sklearn.tree._tree.Tree)` for attributes of Tree object and
    [Understanding the decision tree structure](../../auto_examples/tree/plot_unveil_tree_structure.md#sphx-glr-auto-examples-tree-plot-unveil-tree-structure-py)
    for basic usage of these attributes.

#### SEE ALSO
[`ExtraTreeClassifier`](sklearn.tree.ExtraTreeClassifier.md#sklearn.tree.ExtraTreeClassifier)
: An extremely randomized tree classifier.

[`sklearn.ensemble.ExtraTreesClassifier`](sklearn.ensemble.ExtraTreesClassifier.md#sklearn.ensemble.ExtraTreesClassifier)
: An extra-trees classifier.

[`sklearn.ensemble.ExtraTreesRegressor`](sklearn.ensemble.ExtraTreesRegressor.md#sklearn.ensemble.ExtraTreesRegressor)
: An extra-trees regressor.

### Notes

The default values for the parameters controlling the size of the trees
(e.g. `max_depth`, `min_samples_leaf`, etc.) lead to fully grown and
unpruned trees which can potentially be very large on some data sets. To
reduce memory consumption, the complexity and size of the trees should be
controlled by setting those parameter values.

### References

### Examples

```pycon
>>> from sklearn.datasets import load_diabetes
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.ensemble import BaggingRegressor
>>> from sklearn.tree import ExtraTreeRegressor
>>> X, y = load_diabetes(return_X_y=True)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, random_state=0)
>>> extra_tree = ExtraTreeRegressor(random_state=0)
>>> reg = BaggingRegressor(extra_tree, random_state=0).fit(
...     X_train, y_train)
>>> reg.score(X_test, y_test)
0.33...
```

<!-- !! processed by numpydoc !! -->

#### apply(X, check_input=True)

Return the index of the leaf that each sample is predicted as.

#### Versionadded
Added in version 0.17.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you’re doing.
* **Returns:**
  **X_leaves**
  : For each datapoint x in X, return the index of the leaf x
    ends up in. Leaves are numbered within
    `[0; self.tree_.node_count)`, possibly with gaps in the
    numbering.

<!-- !! processed by numpydoc !! -->

#### cost_complexity_pruning_path(X, y, sample_weight=None)

Compute the pruning path during Minimal Cost-Complexity Pruning.

See [Minimal Cost-Complexity Pruning](../tree.md#minimal-cost-complexity-pruning) for details on the pruning
process.

* **Parameters:**
  **X**
  : The training input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csc_matrix`.

  **y**
  : The target values (class labels) as integers or strings.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted. Splits
    that would create child nodes with net zero or negative weight are
    ignored while searching for a split in each node. Splits are also
    ignored if they would result in any single class carrying a
    negative weight in either child node.
* **Returns:**
  **ccp_path**
  : Dictionary-like object, with the following attributes.
    <br/>
    ccp_alphas
    : Effective alphas of subtree during pruning.
    <br/>
    impurities
    : Sum of the impurities of the subtree leaves for the
      corresponding alpha value in `ccp_alphas`.

<!-- !! processed by numpydoc !! -->

#### decision_path(X, check_input=True)

Return the decision path in the tree.

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you’re doing.
* **Returns:**
  **indicator**
  : Return a node indicator CSR matrix where non zero elements
    indicates that the samples goes through the nodes.

<!-- !! processed by numpydoc !! -->

#### *property* feature_importances_

Return the feature importances.

The importance of a feature is computed as the (normalized) total
reduction of the criterion brought by that feature.
It is also known as the Gini importance.

Warning: impurity-based feature importances can be misleading for
high cardinality features (many unique values). See
[`sklearn.inspection.permutation_importance`](sklearn.inspection.permutation_importance.md#sklearn.inspection.permutation_importance) as an alternative.

* **Returns:**
  **feature_importances_**
  : Normalized total reduction of criteria by feature
    (Gini importance).

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, check_input=True)

Build a decision tree regressor from the training set (X, y).

* **Parameters:**
  **X**
  : The training input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csc_matrix`.

  **y**
  : The target values (real numbers). Use `dtype=np.float64` and
    `order='C'` for maximum efficiency.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted. Splits
    that would create child nodes with net zero or negative weight are
    ignored while searching for a split in each node.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you’re doing.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_depth()

Return the depth of the decision tree.

The depth of a tree is the maximum distance between the root
and any leaf.

* **Returns:**
  **self.tree_.max_depth**
  : The maximum depth of the tree.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_leaves()

Return the number of leaves of the decision tree.

* **Returns:**
  **self.tree_.n_leaves**
  : Number of leaves.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X, check_input=True)

Predict class or regression value for X.

For a classification model, the predicted class for each sample in X is
returned. For a regression model, the predicted value based on X is
returned.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you’re doing.
* **Returns:**
  **y**
  : The predicted classes, or the predict values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [ExtraTreeRegressor](#sklearn.tree.ExtraTreeRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [ExtraTreeRegressor](#sklearn.tree.ExtraTreeRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->
