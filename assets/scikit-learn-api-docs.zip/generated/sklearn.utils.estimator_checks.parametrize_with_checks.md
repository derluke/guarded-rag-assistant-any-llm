# parametrize_with_checks

### sklearn.utils.estimator_checks.parametrize_with_checks(estimators, \*, legacy: [bool](https://docs.python.org/3/library/functions.html#bool) = True, expected_failed_checks: Callable | [None](https://docs.python.org/3/library/constants.html#None) = None)

Pytest specific decorator for parametrizing estimator checks.

Checks are categorised into the following groups:

- API checks: a set of checks to ensure API compatibility with scikit-learn.
  Refer to [https://scikit-learn.org/dev/developers/develop.html](https://scikit-learn.org/dev/developers/develop.html) a requirement of
  scikit-learn estimators.
- legacy: a set of checks which gradually will be grouped into other categories.

The `id` of each check is set to be a pprint version of the estimator
and the name of the check with its keyword arguments.
This allows to use `pytest -k` to specify which tests to run:

```default
pytest test_check_estimators.py -k check_estimators_fit_returns_self
```

* **Parameters:**
  **estimators**
  : Estimators to generated checks for.
    <br/>
    #### Versionchanged
    Changed in version 0.24: Passing a class was deprecated in version 0.23, and support for
    classes was removed in 0.24. Pass an instance instead.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **legacy**
  : Whether to include legacy checks. Over time we remove checks from this category
    and move them into their specific category.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **expected_failed_checks**
  : A callable that takes an estimator as input and returns a dictionary of the
    form:
    ```default
    {
        "check_name": "my reason",
    }
    ```
    <br/>
    Where `"check_name"` is the name of the check, and `"my reason"` is why
    the check fails. These tests will be marked as xfail if the check fails.
    <br/>
    #### Versionadded
    Added in version 1.6.
* **Returns:**
  **decorator**

#### SEE ALSO
[`check_estimator`](sklearn.utils.estimator_checks.check_estimator.md#sklearn.utils.estimator_checks.check_estimator)
: Check if estimator adheres to scikit-learn conventions.

### Examples

```pycon
>>> from sklearn.utils.estimator_checks import parametrize_with_checks
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.tree import DecisionTreeRegressor
```

```pycon
>>> @parametrize_with_checks([LogisticRegression(),
...                           DecisionTreeRegressor()])
... def test_sklearn_compatible_estimator(estimator, check):
...     check(estimator)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.6! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_6&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.6</div>
</div>
* [Release Highlights for scikit-learn 1.6](../../auto_examples/release_highlights/plot_release_highlights_1_6_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-6-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
