# adjusted_rand_score

### sklearn.metrics.adjusted_rand_score(labels_true, labels_pred)

Rand index adjusted for chance.

The Rand Index computes a similarity measure between two clusterings
by considering all pairs of samples and counting pairs that are
assigned in the same or different clusters in the predicted and
true clusterings.

The raw RI score is then “adjusted for chance” into the ARI score
using the following scheme:

```default
ARI = (RI - Expected_RI) / (max(RI) - Expected_RI)
```

The adjusted Rand index is thus ensured to have a value close to
0.0 for random labeling independently of the number of clusters and
samples and exactly 1.0 when the clusterings are identical (up to
a permutation). The adjusted Rand index is bounded below by -0.5 for
especially discordant clusterings.

ARI is a symmetric measure:

```default
adjusted_rand_score(a, b) == adjusted_rand_score(b, a)
```

Read more in the [User Guide](../clustering.md#adjusted-rand-score).

* **Parameters:**
  **labels_true**
  : Ground truth class labels to be used as a reference.

  **labels_pred**
  : Cluster labels to evaluate.
* **Returns:**
  **ARI**
  : Similarity score between -0.5 and 1.0. Random labelings have an ARI
    close to 0.0. 1.0 stands for perfect match.

#### SEE ALSO
[`adjusted_mutual_info_score`](sklearn.metrics.adjusted_mutual_info_score.md#sklearn.metrics.adjusted_mutual_info_score)
: Adjusted Mutual Information.

### References

### Examples

Perfectly matching labelings have a score of 1 even

```pycon
>>> from sklearn.metrics.cluster import adjusted_rand_score
>>> adjusted_rand_score([0, 0, 1, 1], [0, 0, 1, 1])
1.0
>>> adjusted_rand_score([0, 0, 1, 1], [1, 1, 0, 0])
1.0
```

Labelings that assign all classes members to the same clusters
are complete but may not always be pure, hence penalized:

```default
>>> adjusted_rand_score([0, 0, 1, 2], [0, 0, 1, 1])
0.57...
```

ARI is symmetric, so labelings that have pure clusters with members
coming from the same classes but unnecessary splits are penalized:

```default
>>> adjusted_rand_score([0, 0, 1, 1], [0, 0, 1, 2])
0.57...
```

If classes members are completely split across different clusters, the
assignment is totally incomplete, hence the ARI is very low:

```default
>>> adjusted_rand_score([0, 0, 0, 0], [0, 1, 2, 3])
0.0
```

ARI may take a negative value for especially discordant labelings that
are a worse choice than the expected value of random labels:

```default
>>> adjusted_rand_score([0, 0, 1, 1], [0, 1, 0, 1])
-0.5
```

See [Adjustment for chance in clustering performance evaluation](../../auto_examples/cluster/plot_adjusted_for_chance_measures.md#sphx-glr-auto-examples-cluster-plot-adjusted-for-chance-measures-py)
for a more detailed example.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the various initialization strategies for K-means in terms of runtime and quality of the results.">  <div class="sphx-glr-thumbnail-title">A demo of K-Means clustering on the handwritten digits data</div>
</div>
* [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="- a first experiment with fixed &quot;ground truth labels&quot; (and therefore fixed   number of classes) and randomly &quot;predicted labels&quot;; - a second experiment with varying &quot;ground truth labels&quot;, randomly &quot;predicted   labels&quot;. The &quot;predicted labels&quot; have the same number of classes and clusters   as the &quot;ground truth labels&quot;.">  <div class="sphx-glr-thumbnail-title">Adjustment for chance in clustering performance evaluation</div>
</div>
* [Adjustment for chance in clustering performance evaluation](../../auto_examples/cluster/plot_adjusted_for_chance_measures.md#sphx-glr-auto-examples-cluster-plot-adjusted-for-chance-measures-py)

<div class="sphx-glr-thumbcontainer" tooltip="DBSCAN (Density-Based Spatial Clustering of Applications with Noise) finds core samples in regions of high density and expands clusters from them. This algorithm is good for data which contains clusters of similar density.">  <div class="sphx-glr-thumbnail-title">Demo of DBSCAN clustering algorithm</div>
</div>
* [Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="Reference: Brendan J. Frey and Delbert Dueck, &quot;Clustering by Passing Messages Between Data Points&quot;, Science Feb. 2007">  <div class="sphx-glr-thumbnail-title">Demo of affinity propagation clustering algorithm</div>
</div>
* [Demo of affinity propagation clustering algorithm](../../auto_examples/cluster/plot_affinity_propagation.md#sphx-glr-auto-examples-cluster-plot-affinity-propagation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how the scikit-learn API can be used to cluster documents by topics using a Bag of Words approach.">  <div class="sphx-glr-thumbnail-title">Clustering text documents using k-means</div>
</div>
* [Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py)

<!-- thumbnail-parent-div-close --></div>
