# LogisticRegression

### *class* sklearn.linear_model.LogisticRegression(penalty='l2', \*, dual=False, tol=0.0001, C=1.0, fit_intercept=True, intercept_scaling=1, class_weight=None, random_state=None, solver='lbfgs', max_iter=100, multi_class='deprecated', verbose=0, warm_start=False, n_jobs=None, l1_ratio=None)

Logistic Regression (aka logit, MaxEnt) classifier.

This class implements regularized logistic regression using the
‘liblinear’ library, ‘newton-cg’, ‘sag’, ‘saga’ and ‘lbfgs’ solvers. **Note
that regularization is applied by default**. It can handle both dense
and sparse input. Use C-ordered arrays or CSR matrices containing 64-bit
floats for optimal performance; any other input format will be converted
(and copied).

The ‘newton-cg’, ‘sag’, and ‘lbfgs’ solvers support only L2 regularization
with primal formulation, or no regularization. The ‘liblinear’ solver
supports both L1 and L2 regularization, with a dual formulation only for
the L2 penalty. The Elastic-Net regularization is only supported by the
‘saga’ solver.

For [multiclass](../../glossary.md#term-multiclass) problems, only ‘newton-cg’, ‘sag’, ‘saga’ and ‘lbfgs’
handle multinomial loss. ‘liblinear’ and ‘newton-cholesky’ only handle binary
classification but can be extended to handle multiclass by using
[`OneVsRestClassifier`](sklearn.multiclass.OneVsRestClassifier.md#sklearn.multiclass.OneVsRestClassifier).

Read more in the [User Guide](../linear_model.md#logistic-regression).

* **Parameters:**
  **penalty**
  : Specify the norm of the penalty:
    - `None`: no penalty is added;
    - `'l2'`: add a L2 penalty term and it is the default choice;
    - `'l1'`: add a L1 penalty term;
    - `'elasticnet'`: both L1 and L2 penalty terms are added.
    <br/>
    #### WARNING
    Some penalties may not work with some solvers. See the parameter
    `solver` below, to know the compatibility between the penalty and
    solver.
    <br/>
    #### Versionadded
    Added in version 0.19: l1 penalty with SAGA solver (allowing ‘multinomial’ + L1)

  **dual**
  : Dual (constrained) or primal (regularized, see also
    [this equation](../linear_model.md#regularized-logistic-loss)) formulation. Dual formulation
    is only implemented for l2 penalty with liblinear solver. Prefer dual=False when
    n_samples > n_features.

  **tol**
  : Tolerance for stopping criteria.

  **C**
  : Inverse of regularization strength; must be a positive float.
    Like in support vector machines, smaller values specify stronger
    regularization.

  **fit_intercept**
  : Specifies if a constant (a.k.a. bias or intercept) should be
    added to the decision function.

  **intercept_scaling**
  : Useful only when the solver ‘liblinear’ is used
    and self.fit_intercept is set to True. In this case, x becomes
    [x, self.intercept_scaling],
    i.e. a “synthetic” feature with constant value equal to
    intercept_scaling is appended to the instance vector.
    The intercept becomes `intercept_scaling * synthetic_feature_weight`.
    <br/>
    Note! the synthetic feature weight is subject to l1/l2 regularization
    as all other features.
    To lessen the effect of regularization on synthetic feature weight
    (and therefore on the intercept) intercept_scaling has to be increased.

  **class_weight**
  : Weights associated with classes in the form `{class_label: weight}`.
    If not given, all classes are supposed to have weight one.
    <br/>
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`.
    <br/>
    Note that these weights will be multiplied with sample_weight (passed
    through the fit method) if sample_weight is specified.
    <br/>
    #### Versionadded
    Added in version 0.17: *class_weight=’balanced’*

  **random_state**
  : Used when `solver` == ‘sag’, ‘saga’ or ‘liblinear’ to shuffle the
    data. See [Glossary](../../glossary.md#term-random_state) for details.

  **solver**
  : Algorithm to use in the optimization problem. Default is ‘lbfgs’.
    To choose a solver, you might want to consider the following aspects:
    - For small datasets, ‘liblinear’ is a good choice, whereas ‘sag’
      and ‘saga’ are faster for large ones;
    - For [multiclass](../../glossary.md#term-multiclass) problems, all solvers except ‘liblinear’ minimize the
      full multinomial loss;
    - ‘liblinear’ can only handle binary classification by default. To apply a
      one-versus-rest scheme for the multiclass setting one can wrap it with the
      [`OneVsRestClassifier`](sklearn.multiclass.OneVsRestClassifier.md#sklearn.multiclass.OneVsRestClassifier).
    - ‘newton-cholesky’ is a good choice for
      `n_samples` >> `n_features * n_classes`, especially with one-hot encoded
      categorical features with rare categories. Be aware that the memory usage
      of this solver has a quadratic dependency on `n_features * n_classes`
      because it explicitly computes the full Hessian matrix.
    <br/>
    #### WARNING
    The choice of the algorithm depends on the penalty chosen and on
    (multinomial) multiclass support:
    <br/>
    | solver            | penalty                        | multinomial multiclass   |
    |-------------------|--------------------------------|--------------------------|
    | ‘lbfgs’           | ‘l2’, None                     | yes                      |
    | ‘liblinear’       | ‘l1’, ‘l2’                     | no                       |
    | ‘newton-cg’       | ‘l2’, None                     | yes                      |
    | ‘newton-cholesky’ | ‘l2’, None                     | no                       |
    | ‘sag’             | ‘l2’, None                     | yes                      |
    | ‘saga’            | ‘elasticnet’, ‘l1’, ‘l2’, None | yes                      |
    <br/>
    #### NOTE
    ‘sag’ and ‘saga’ fast convergence is only guaranteed on features
    with approximately the same scale. You can preprocess the data with
    a scaler from [`sklearn.preprocessing`](../../api/sklearn.preprocessing.md#module-sklearn.preprocessing).
    <br/>
    #### SEE ALSO
    Refer to the [User Guide](../linear_model.md#logistic-regression) for more
    information regarding [`LogisticRegression`](#sklearn.linear_model.LogisticRegression) and more specifically the
    [Table](../linear_model.md#logistic-regression-solvers)
    summarizing solver/penalty supports.
    <br/>
    #### Versionadded
    Added in version 0.17: Stochastic Average Gradient descent solver.
    <br/>
    #### Versionadded
    Added in version 0.19: SAGA solver.
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default solver changed from ‘liblinear’ to ‘lbfgs’ in 0.22.
    <br/>
    #### Versionadded
    Added in version 1.2: newton-cholesky solver.

  **max_iter**
  : Maximum number of iterations taken for the solvers to converge.

  **multi_class**
  : If the option chosen is ‘ovr’, then a binary problem is fit for each
    label. For ‘multinomial’ the loss minimised is the multinomial loss fit
    across the entire probability distribution, *even when the data is
    binary*. ‘multinomial’ is unavailable when solver=’liblinear’.
    ‘auto’ selects ‘ovr’ if the data is binary, or if solver=’liblinear’,
    and otherwise selects ‘multinomial’.
    <br/>
    #### Versionadded
    Added in version 0.18: Stochastic Average Gradient descent solver for ‘multinomial’ case.
    <br/>
    #### Versionchanged
    Changed in version 0.22: Default changed from ‘ovr’ to ‘auto’ in 0.22.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `multi_class` was deprecated in version 1.5 and will be removed in 1.7.
    From then on, the recommended ‘multinomial’ will always be used for
    `n_classes >= 3`.
    Solvers that do not support ‘multinomial’ will raise an error.
    Use `sklearn.multiclass.OneVsRestClassifier(LogisticRegression())` if you
    still want to use OvR.

  **verbose**
  : For the liblinear and lbfgs solvers set verbose to any positive
    number for verbosity.

  **warm_start**
  : When set to True, reuse the solution of the previous call to fit as
    initialization, otherwise, just erase the previous solution.
    Useless for liblinear solver. See [the Glossary](../../glossary.md#term-warm_start).
    <br/>
    #### Versionadded
    Added in version 0.17: *warm_start* to support *lbfgs*, *newton-cg*, *sag*, *saga* solvers.

  **n_jobs**
  : Number of CPU cores used when parallelizing over classes if
    multi_class=’ovr’”. This parameter is ignored when the `solver` is
    set to ‘liblinear’ regardless of whether ‘multi_class’ is specified or
    not. `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend)
    context. `-1` means using all processors.
    See [Glossary](../../glossary.md#term-n_jobs) for more details.

  **l1_ratio**
  : The Elastic-Net mixing parameter, with `0 <= l1_ratio <= 1`. Only
    used if `penalty='elasticnet'`. Setting `l1_ratio=0` is equivalent
    to using `penalty='l2'`, while setting `l1_ratio=1` is equivalent
    to using `penalty='l1'`. For `0 < l1_ratio <1`, the penalty is a
    combination of L1 and L2.
* **Attributes:**
  **classes_**
  : A list of class labels known to the classifier.

  **coef_**
  : Coefficient of the features in the decision function.
    <br/>
    `coef_` is of shape (1, n_features) when the given problem is binary.
    In particular, when `multi_class='multinomial'`, `coef_` corresponds
    to outcome 1 (True) and `-coef_` corresponds to outcome 0 (False).

  **intercept_**
  : Intercept (a.k.a. bias) added to the decision function.
    <br/>
    If `fit_intercept` is set to False, the intercept is set to zero.
    `intercept_` is of shape (1,) when the given problem is binary.
    In particular, when `multi_class='multinomial'`, `intercept_`
    corresponds to outcome 1 (True) and `-intercept_` corresponds to
    outcome 0 (False).

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Actual number of iterations for all classes. If binary or multinomial,
    it returns only 1 element. For liblinear solver, only the maximum
    number of iteration across all classes is given.
    <br/>
    #### Versionchanged
    Changed in version 0.20: In SciPy <= 1.0.0 the number of lbfgs iterations may exceed
    `max_iter`. `n_iter_` will now report at most `max_iter`.

#### SEE ALSO
[`SGDClassifier`](sklearn.linear_model.SGDClassifier.md#sklearn.linear_model.SGDClassifier)
: Incrementally trained logistic regression (when given the parameter `loss="log_loss"`).

[`LogisticRegressionCV`](sklearn.linear_model.LogisticRegressionCV.md#sklearn.linear_model.LogisticRegressionCV)
: Logistic regression with built-in cross validation.

### Notes

The underlying C implementation uses a random number generator to
select features when fitting the model. It is thus not uncommon,
to have slightly different results for the same input data. If
that happens, try with a smaller tol parameter.

Predict output may not match that of standalone liblinear in certain
cases. See [differences from liblinear](../linear_model.md#liblinear-differences)
in the narrative documentation.

### References

L-BFGS-B – Software for Large-scale Bound-constrained Optimization
: Ciyou Zhu, Richard Byrd, Jorge Nocedal and Jose Luis Morales.
  [http://users.iems.northwestern.edu/~nocedal/lbfgsb.html](http://users.iems.northwestern.edu/~nocedal/lbfgsb.html)

LIBLINEAR – A Library for Large Linear Classification
: [https://www.csie.ntu.edu.tw/~cjlin/liblinear/](https://www.csie.ntu.edu.tw/~cjlin/liblinear/)

SAG – Mark Schmidt, Nicolas Le Roux, and Francis Bach
: Minimizing Finite Sums with the Stochastic Average Gradient
  [https://hal.inria.fr/hal-00860051/document](https://hal.inria.fr/hal-00860051/document)

SAGA – Defazio, A., Bach F. & Lacoste-Julien S. (2014).
: [“SAGA: A Fast Incremental Gradient Method With Support
  for Non-Strongly Convex Composite Objectives”](https://arxiv.org/abs/1407.0202)

Hsiang-Fu Yu, Fang-Lan Huang, Chih-Jen Lin (2011). Dual coordinate descent
: methods for logistic regression and maximum entropy models.
  Machine Learning 85(1-2):41-75.
  [https://www.csie.ntu.edu.tw/~cjlin/papers/maxent_dual.pdf](https://www.csie.ntu.edu.tw/~cjlin/papers/maxent_dual.pdf)

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn.linear_model import LogisticRegression
>>> X, y = load_iris(return_X_y=True)
>>> clf = LogisticRegression(random_state=0).fit(X, y)
>>> clf.predict(X[:2, :])
array([0, 0])
>>> clf.predict_proba(X[:2, :])
array([[9.8...e-01, 1.8...e-02, 1.4...e-08],
       [9.7...e-01, 2.8...e-02, ...e-08]])
>>> clf.score(X, y)
0.97...
```

For a comaprison of the LogisticRegression with other classifiers see:
[Plot classification probability](../../auto_examples/classification/plot_classification_probability.md#sphx-glr-auto-examples-classification-plot-classification-probability-py).

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Predict confidence scores for samples.

The confidence score for a sample is proportional to the signed
distance of that sample to the hyperplane.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the confidence scores.
* **Returns:**
  **scores**
  : Confidence scores per `(n_samples, n_classes)` combination. In the
    binary case, confidence score for `self.classes_[1]` where >0 means
    this class would be predicted.

<!-- !! processed by numpydoc !! -->

#### densify()

Convert coefficient matrix to dense array format.

Converts the `coef_` member (back) to a numpy.ndarray. This is the
default format of `coef_` and is required for fitting, so calling
this method is only required on models that have previously been
sparsified; otherwise, it is a no-op.

* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the model according to the given training data.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target vector relative to X.

  **sample_weight**
  : Array of weights that are assigned to individual samples.
    If not provided, then each sample is given unit weight.
    <br/>
    #### Versionadded
    Added in version 0.17: *sample_weight* support to LogisticRegression.
* **Returns:**
  self
  : Fitted estimator.

### Notes

The SAGA solver supports both float64 and float32 bit arrays.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict class labels for samples in X.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the predictions.
* **Returns:**
  **y_pred**
  : Vector containing the class labels for each sample.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Predict logarithm of probability estimates.

The returned estimates for all classes are ordered by the
label of classes.

* **Parameters:**
  **X**
  : Vector to be scored, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **T**
  : Returns the log-probability of the sample for each class in the
    model, where classes are ordered as they are in `self.classes_`.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Probability estimates.

The returned estimates for all classes are ordered by the
label of classes.

For a multi_class problem, if multi_class is set to be “multinomial”
the softmax function is used to find the predicted probability of
each class.
Else use a one-vs-rest approach, i.e. calculate the probability
of each class assuming it to be positive using the logistic function
and normalize these values across all the classes.

* **Parameters:**
  **X**
  : Vector to be scored, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **T**
  : Returns the probability of the sample for each class in the model,
    where classes are ordered as they are in `self.classes_`.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LogisticRegression](#sklearn.linear_model.LogisticRegression)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LogisticRegression](#sklearn.linear_model.LogisticRegression)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### sparsify()

Convert coefficient matrix to sparse format.

Converts the `coef_` member to a scipy.sparse matrix, which for
L1-regularized models can be much more memory- and storage-efficient
than the usual numpy.ndarray representation.

The `intercept_` member is not converted.

* **Returns:**
  self
  : Fitted estimator.

### Notes

For non-sparse models, i.e. when there are not many zeros in `coef_`,
this may actually *increase* memory usage, so use this method with
care. A rule of thumb is that the number of zero elements, which can
be computed with `(coef_ == 0).sum()`, must be more than 50% for this
to provide significant benefits.

After calling this method, further fitting with the partial_fit
method (if any) will not work until you call densify.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="When performing classification one often wants to predict not only the class label, but also the associated probability. This probability gives some kind of confidence on the prediction. This example demonstrates how to visualize how well calibrated the predicted probabilities are using calibration curves, also known as reliability diagrams. Calibration of an uncalibrated classifier will also be demonstrated.">  <div class="sphx-glr-thumbnail-title">Probability Calibration curves</div>
</div>
* [Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the classification probability for different classifiers. We use a 3 class dataset, and we classify it with a Support Vector classifier, L1 and L2 penalized logistic regression (multinomial multiclass), a One-Vs-Rest version with logistic regression, and Gaussian process classification.">  <div class="sphx-glr-thumbnail-title">Plot classification probability</div>
</div>
* [Plot classification probability](../../auto_examples/classification/plot_classification_probability.md#sphx-glr-auto-examples-classification-plot-classification-probability-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to apply different preprocessing and feature extraction pipelines to different subsets of features, using ColumnTransformer. This is particularly handy for the case of datasets that contain heterogeneous data types, since we may want to scale the numeric features and one-hot encode the categorical ones.">  <div class="sphx-glr-thumbnail-title">Column Transformer with Mixed Types</div>
</div>
* [Column Transformer with Mixed Types](../../auto_examples/compose/plot_column_transformer_mixed_types.md#sphx-glr-auto-examples-compose-plot-column-transformer-mixed-types-py)

<div class="sphx-glr-thumbcontainer" tooltip="The PCA does an unsupervised dimensionality reduction, while the logistic regression does the prediction.">  <div class="sphx-glr-thumbnail-title">Pipelining: chaining a PCA and a logistic regression</div>
</div>
* [Pipelining: chaining a PCA and a logistic regression](../../auto_examples/compose/plot_digits_pipe.md#sphx-glr-auto-examples-compose-plot-digits-pipe-py)

<div class="sphx-glr-thumbcontainer" tooltip="Transform your features into a higher dimensional, sparse space. Then train a linear model on these features.">  <div class="sphx-glr-thumbnail-title">Feature transformations with ensembles of trees</div>
</div>
* [Feature transformations with ensembles of trees](../../auto_examples/ensemble/plot_feature_transformation.md#sphx-glr-auto-examples-ensemble-plot-feature-transformation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the class probabilities of the first sample in a toy dataset predicted by three different classifiers and averaged by the VotingClassifier.">  <div class="sphx-glr-thumbnail-title">Plot class probabilities calculated by the VotingClassifier</div>
</div>
* [Plot class probabilities calculated by the VotingClassifier](../../auto_examples/ensemble/plot_voting_probas.md#sphx-glr-auto-examples-ensemble-plot-voting-probas-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares two approaches for feature selection: SelectFromModel which is based on feature importance, and SequentialFeatureSelector which relies on a greedy approach.">  <div class="sphx-glr-thumbnail-title">Model-based and sequential feature selection</div>
</div>
* [Model-based and sequential feature selection](../../auto_examples/feature_selection/plot_select_from_model_diabetes.md#sphx-glr-auto-examples-feature-selection-plot-select-from-model-diabetes-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Recursive Feature Elimination (~sklearn.feature_selection.RFE) can be used to determine the importance of individual pixels for classifying handwritten digits. RFE recursively removes the least significant features, assigning ranks based on their importance, where higher ranking_ values denote lower importance. The ranking is visualized using both shades of blue and pixel annotations for clarity. As expected, pixels positioned at the center of the image tend to be more predictive than those near the edges.">  <div class="sphx-glr-thumbnail-title">Recursive feature elimination</div>
</div>
* [Recursive feature elimination](../../auto_examples/feature_selection/plot_rfe_digits.md#sphx-glr-auto-examples-feature-selection-plot-rfe-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="A Recursive Feature Elimination (RFE) example with automatic tuning of the number of features selected with cross-validation.">  <div class="sphx-glr-thumbnail-title">Recursive feature elimination with cross-validation</div>
</div>
* [Recursive feature elimination with cross-validation](../../auto_examples/feature_selection/plot_rfe_with_cross_validation.md#sphx-glr-auto-examples-feature-selection-plot-rfe-with-cross-validation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This examples showcases some use cases of FrozenEstimator.">  <div class="sphx-glr-thumbnail-title">Examples of Using FrozenEstimator</div>
</div>
* [Examples of Using FrozenEstimator](../../auto_examples/frozen/plot_frozen_examples.md#sphx-glr-auto-examples-frozen-plot-frozen-examples-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparing various online solvers">  <div class="sphx-glr-thumbnail-title">Comparing various online solvers</div>
</div>
* [Comparing various online solvers](../../auto_examples/linear_model/plot_sgd_comparison.md#sphx-glr-auto-examples-linear-model-plot-sgd-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares decision boundaries of multinomial and one-vs-rest logistic regression on a 2D dataset with three classes.">  <div class="sphx-glr-thumbnail-title">Decision Boundaries of Multinomial and One-vs-Rest Logistic Regression</div>
</div>
* [Decision Boundaries of Multinomial and One-vs-Rest Logistic Regression](../../auto_examples/linear_model/plot_logistic_multinomial.md#sphx-glr-auto-examples-linear-model-plot-logistic-multinomial-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparison of the sparsity (percentage of zero coefficients) of solutions when L1, L2 and Elastic-Net penalty are used for different values of C. We can see that large values of C give more freedom to the model.  Conversely, smaller values of C constrain the model more. In the L1 penalty case, this leads to sparser solutions. As expected, the Elastic-Net penalty sparsity is between that of L1 and L2.">  <div class="sphx-glr-thumbnail-title">L1 Penalty and Sparsity in Logistic Regression</div>
</div>
* [L1 Penalty and Sparsity in Logistic Regression](../../auto_examples/linear_model/plot_logistic_l1_l2_sparsity.md#sphx-glr-auto-examples-linear-model-plot-logistic-l1-l2-sparsity-py)

<div class="sphx-glr-thumbcontainer" tooltip="Shown in the plot is how the logistic regression would, in this synthetic dataset, classify values as either 0 or 1, i.e. class one or two, using the logistic curve.">  <div class="sphx-glr-thumbnail-title">Logistic function</div>
</div>
* [Logistic function](../../auto_examples/linear_model/plot_logistic.md#sphx-glr-auto-examples-linear-model-plot-logistic-py)

<div class="sphx-glr-thumbcontainer" tooltip="Here we fit a multinomial logistic regression with L1 penalty on a subset of the MNIST digits classification task. We use the SAGA algorithm for this purpose: this a solver that is fast when the number of samples is significantly larger than the number of features and is able to finely optimize non-smooth objective functions which is the case with the l1-penalty. Test accuracy reaches &gt; 0.8, while weight vectors remains sparse and therefore more easily interpretable.">  <div class="sphx-glr-thumbnail-title">MNIST classification using multinomial logistic + L1</div>
</div>
* [MNIST classification using multinomial logistic + L1](../../auto_examples/linear_model/plot_sparse_logistic_regression_mnist.md#sphx-glr-auto-examples-linear-model-plot-sparse-logistic-regression-mnist-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparison of multinomial logistic L1 vs one-versus-rest L1 logistic regression to classify documents from the newgroups20 dataset. Multinomial logistic regression yields more accurate results and is faster to train on the larger scale dataset.">  <div class="sphx-glr-thumbnail-title">Multiclass sparse logistic regression on 20newgroups</div>
</div>
* [Multiclass sparse logistic regression on 20newgroups](../../auto_examples/linear_model/plot_sparse_logistic_regression_20newsgroups.md#sphx-glr-auto-examples-linear-model-plot-sparse-logistic-regression-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip=" Train l1-penalized logistic regression models on a binary classification problem derived from the Iris dataset.">  <div class="sphx-glr-thumbnail-title">Regularization path of L1- Logistic Regression</div>
</div>
* [Regularization path of L1- Logistic Regression](../../auto_examples/linear_model/plot_logistic_path.md#sphx-glr-auto-examples-linear-model-plot-logistic-path-py)

<div class="sphx-glr-thumbcontainer" tooltip="The default configuration for displaying a pipeline in a Jupyter Notebook is &#x27;diagram&#x27; where set_config(display=&#x27;diagram&#x27;). To deactivate HTML representation, use set_config(display=&#x27;text&#x27;).">  <div class="sphx-glr-thumbnail-title">Displaying Pipelines</div>
</div>
* [Displaying Pipelines](../../auto_examples/miscellaneous/plot_pipeline_display.md#sphx-glr-auto-examples-miscellaneous-plot-pipeline-display-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates different ways estimators and pipelines can be displayed.">  <div class="sphx-glr-thumbnail-title">Displaying estimators and complex pipelines</div>
</div>
* [Displaying estimators and complex pipelines](../../auto_examples/miscellaneous/plot_estimator_representation.md#sphx-glr-auto-examples-miscellaneous-plot-estimator-representation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example will demonstrate the set_output API to configure transformers to output pandas DataFrames. set_output can be configured per estimator by calling the set_output method or globally by setting set_config(transform_output=&quot;pandas&quot;). For details, see SLEP018.">  <div class="sphx-glr-thumbnail-title">Introducing the set_output API</div>
</div>
* [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the class_likelihood_ratios function, which computes the positive and negative likelihood ratios (\`LR+\`, LR-) to assess the predictive power of a binary classifier. As we will see, these metrics are independent of the proportion between classes in the test set, which makes them very useful when the available data for a study has a different class proportion than the target application.">  <div class="sphx-glr-thumbnail-title">Class Likelihood Ratios to measure classification performance</div>
</div>
* [Class Likelihood Ratios to measure classification performance](../../auto_examples/model_selection/plot_likelihood_ratios.md#sphx-glr-auto-examples-model-selection-plot-likelihood-ratios-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example describes the use of the Receiver Operating Characteristic (ROC) metric to evaluate the quality of multiclass classifiers.">  <div class="sphx-glr-thumbnail-title">Multiclass Receiver Operating Characteristic (ROC)</div>
</div>
* [Multiclass Receiver Operating Characteristic (ROC)](../../auto_examples/model_selection/plot_roc.md#sphx-glr-auto-examples-model-selection-plot-roc-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a binary classifier is trained, the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. The default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0. However, this default strategy may not be optimal for the task at hand.">  <div class="sphx-glr-thumbnail-title">Post-hoc tuning the cut-off point of decision function</div>
</div>
* [Post-hoc tuning the cut-off point of decision function](../../auto_examples/model_selection/plot_tuned_decision_threshold.md#sphx-glr-auto-examples-model-selection-plot-tuned-decision-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="The most naive strategy to solve such a task is to independently train a binary classifier on each label (i.e. each column of the target variable). At prediction time, the ensemble of binary classifiers is used to assemble multitask prediction.">  <div class="sphx-glr-thumbnail-title">Multilabel classification using a classifier chain</div>
</div>
* [Multilabel classification using a classifier chain](../../auto_examples/multioutput/plot_classifier_chain_yeast.md#sphx-glr-auto-examples-multioutput-plot-classifier-chain-yeast-py)

<div class="sphx-glr-thumbcontainer" tooltip="For greyscale image data where pixel values can be interpreted as degrees of blackness on a white background, like handwritten digit recognition, the Bernoulli Restricted Boltzmann machine model (BernoulliRBM) can perform effective non-linear feature extraction.">  <div class="sphx-glr-thumbnail-title">Restricted Boltzmann Machine features for digit classification</div>
</div>
* [Restricted Boltzmann Machine features for digit classification](../../auto_examples/neural_networks/plot_rbm_logistic_classification.md#sphx-glr-auto-examples-neural-networks-plot-rbm-logistic-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="A demonstration of feature discretization on synthetic classification datasets. Feature discretization decomposes each feature into a set of bins, here equally distributed in width. The discrete values are then one-hot encoded, and given to a linear classifier. This preprocessing enables a non-linear behavior even though the classifier is linear.">  <div class="sphx-glr-thumbnail-title">Feature discretization</div>
</div>
* [Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.3! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_3&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.3</div>
</div>
* [Release Highlights for scikit-learn 1.3](../../auto_examples/release_highlights/plot_release_highlights_1_3_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-3-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are very pleased to announce the release of scikit-learn 1.0! The library has been stable for quite some time, releasing version 1.0 is recognizing that and signalling it to our users. This release does not include any breaking changes apart from the usual two-release deprecation cycle. For the future, we do our best to keep this pattern.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.0</div>
</div>
* [Release Highlights for scikit-learn 1.0](../../auto_examples/release_highlights/plot_release_highlights_1_0_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-0-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
