# BayesianRidge

### *class* sklearn.linear_model.BayesianRidge(\*, max_iter=300, tol=0.001, alpha_1=1e-06, alpha_2=1e-06, lambda_1=1e-06, lambda_2=1e-06, alpha_init=None, lambda_init=None, compute_score=False, fit_intercept=True, copy_X=True, verbose=False)

Bayesian ridge regression.

Fit a Bayesian ridge model. See the Notes section for details on this
implementation and the optimization of the regularization parameters
lambda (precision of the weights) and alpha (precision of the noise).

Read more in the [User Guide](../linear_model.md#bayesian-regression).
For an intuitive visualization of how the sinusoid is approximated by
a polynomial using different pairs of initial values, see
[Curve Fitting with Bayesian Ridge Regression](../../auto_examples/linear_model/plot_bayesian_ridge_curvefit.md#sphx-glr-auto-examples-linear-model-plot-bayesian-ridge-curvefit-py).

* **Parameters:**
  **max_iter**
  : Maximum number of iterations over the complete dataset before
    stopping independently of any early stopping criterion.
    <br/>
    #### Versionchanged
    Changed in version 1.3.

  **tol**
  : Stop the algorithm if w has converged.

  **alpha_1**
  : Hyper-parameter : shape parameter for the Gamma distribution prior
    over the alpha parameter.

  **alpha_2**
  : Hyper-parameter : inverse scale parameter (rate parameter) for the
    Gamma distribution prior over the alpha parameter.

  **lambda_1**
  : Hyper-parameter : shape parameter for the Gamma distribution prior
    over the lambda parameter.

  **lambda_2**
  : Hyper-parameter : inverse scale parameter (rate parameter) for the
    Gamma distribution prior over the lambda parameter.

  **alpha_init**
  : Initial value for alpha (precision of the noise).
    If not set, alpha_init is 1/Var(y).
    <br/>
    #### Versionadded
    Added in version 0.22.

  **lambda_init**
  : Initial value for lambda (precision of the weights).
    If not set, lambda_init is 1.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **compute_score**
  : If True, compute the log marginal likelihood at each iteration of the
    optimization.

  **fit_intercept**
  : Whether to calculate the intercept for this model.
    The intercept is not treated as a probabilistic parameter
    and thus has no associated variance. If set
    to False, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **copy_X**
  : If True, X will be copied; else, it may be overwritten.

  **verbose**
  : Verbose mode when fitting the model.
* **Attributes:**
  **coef_**
  : Coefficients of the regression model (mean of distribution)

  **intercept_**
  : Independent term in decision function. Set to 0.0 if
    `fit_intercept = False`.

  **alpha_**
  : Estimated precision of the noise.

  **lambda_**
  : Estimated precision of the weights.

  **sigma_**
  : Estimated variance-covariance matrix of the weights

  **scores_**
  : If computed_score is True, value of the log marginal likelihood (to be
    maximized) at each iteration of the optimization. The array starts
    with the value of the log marginal likelihood obtained for the initial
    values of alpha and lambda and ends with the value obtained for the
    estimated alpha and lambda.

  **n_iter_**
  : The actual number of iterations to reach the stopping criterion.

  **X_offset_**
  : If `fit_intercept=True`, offset subtracted for centering data to a
    zero mean. Set to np.zeros(n_features) otherwise.

  **X_scale_**
  : Set to np.ones(n_features).

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`ARDRegression`](sklearn.linear_model.ARDRegression.md#sklearn.linear_model.ARDRegression)
: Bayesian ARD regression.

### Notes

There exist several strategies to perform Bayesian ridge regression. This
implementation is based on the algorithm described in Appendix A of
(Tipping, 2001) where updates of the regularization parameters are done as
suggested in (MacKay, 1992). Note that according to A New
View of Automatic Relevance Determination (Wipf and Nagarajan, 2008) these
update rules do not guarantee that the marginal likelihood is increasing
between two consecutive iterations of the optimization.

### References

D. J. C. MacKay, Bayesian Interpolation, Computation and Neural Systems,
Vol. 4, No. 3, 1992.

M. E. Tipping, Sparse Bayesian Learning and the Relevance Vector Machine,
Journal of Machine Learning Research, Vol. 1, 2001.

### Examples

```pycon
>>> from sklearn import linear_model
>>> clf = linear_model.BayesianRidge()
>>> clf.fit([[0,0], [1, 1], [2, 2]], [0, 1, 2])
BayesianRidge()
>>> clf.predict([[1, 1]])
array([1.])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the model.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values. Will be cast to X’s dtype if necessary.

  **sample_weight**
  : Individual weights for each sample.
    <br/>
    #### Versionadded
    Added in version 0.20: parameter *sample_weight* support to BayesianRidge.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X, return_std=False)

Predict using the linear model.

In addition to the mean of the predictive distribution, also its
standard deviation can be returned.

* **Parameters:**
  **X**
  : Samples.

  **return_std**
  : Whether to return the standard deviation of posterior prediction.
* **Returns:**
  **y_mean**
  : Mean of predictive distribution of query points.

  **y_std**
  : Standard deviation of predictive distribution of query points.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BayesianRidge](#sklearn.linear_model.BayesianRidge)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_predict_request(\*, return_std: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BayesianRidge](#sklearn.linear_model.BayesianRidge)

Request metadata passed to the `predict` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `predict` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `predict`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **return_std**
  : Metadata routing for `return_std` parameter in `predict`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BayesianRidge](#sklearn.linear_model.BayesianRidge)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares 2 dimensionality reduction strategies:">  <div class="sphx-glr-thumbnail-title">Feature agglomeration vs. univariate selection</div>
</div>
* [Feature agglomeration vs. univariate selection](../../auto_examples/cluster/plot_feature_agglomeration_vs_univariate_selection.md#sphx-glr-auto-examples-cluster-plot-feature-agglomeration-vs-univariate-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="The IterativeImputer class is very flexible - it can be used with a variety of estimators to do round-robin regression, treating every variable as an output in turn.">  <div class="sphx-glr-thumbnail-title">Imputing missing values with variants of IterativeImputer</div>
</div>
* [Imputing missing values with variants of IterativeImputer](../../auto_examples/impute/plot_iterative_imputer_variants_comparison.md#sphx-glr-auto-examples-impute-plot-iterative-imputer-variants-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two different bayesian regressors:">  <div class="sphx-glr-thumbnail-title">Comparing Linear Bayesian Regressors</div>
</div>
* [Comparing Linear Bayesian Regressors](../../auto_examples/linear_model/plot_ard.md#sphx-glr-auto-examples-linear-model-plot-ard-py)

<div class="sphx-glr-thumbcontainer" tooltip="Computes a Bayesian Ridge Regression of Sinusoids.">  <div class="sphx-glr-thumbnail-title">Curve Fitting with Bayesian Ridge Regression</div>
</div>
* [Curve Fitting with Bayesian Ridge Regression](../../auto_examples/linear_model/plot_bayesian_ridge_curvefit.md#sphx-glr-auto-examples-linear-model-plot-bayesian-ridge-curvefit-py)

<div class="sphx-glr-thumbcontainer" tooltip="The present example compares three l1-based regression models on a synthetic signal obtained from sparse and correlated features that are further corrupted with additive gaussian noise:">  <div class="sphx-glr-thumbnail-title">L1-based models for Sparse Signals</div>
</div>
* [L1-based models for Sparse Signals](../../auto_examples/linear_model/plot_lasso_and_elasticnet.md#sphx-glr-auto-examples-linear-model-plot-lasso-and-elasticnet-py)

<!-- thumbnail-parent-div-close --></div>
