# SparseRandomProjection

### *class* sklearn.random_projection.SparseRandomProjection(n_components='auto', \*, density='auto', eps=0.1, dense_output=False, compute_inverse_components=False, random_state=None)

Reduce dimensionality through sparse random projection.

Sparse random matrix is an alternative to dense random
projection matrix that guarantees similar embedding quality while being
much more memory efficient and allowing faster computation of the
projected data.

If we note `s = 1 / density` the components of the random matrix are
drawn from:

```text
-sqrt(s) / sqrt(n_components)   with probability 1 / 2s
 0                              with probability 1 - 1 / s
+sqrt(s) / sqrt(n_components)   with probability 1 / 2s
```

Read more in the [User Guide](../random_projection.md#sparse-random-matrix).

#### Versionadded
Added in version 0.13.

* **Parameters:**
  **n_components**
  : Dimensionality of the target projection space.
    <br/>
    n_components can be automatically adjusted according to the
    number of samples in the dataset and the bound given by the
    Johnson-Lindenstrauss lemma. In that case the quality of the
    embedding is controlled by the `eps` parameter.
    <br/>
    It should be noted that Johnson-Lindenstrauss lemma can yield
    very conservative estimated of the required number of components
    as it makes no assumption on the structure of the dataset.

  **density**
  : Ratio in the range (0, 1] of non-zero component in the random
    projection matrix.
    <br/>
    If density = ‘auto’, the value is set to the minimum density
    as recommended by Ping Li et al.: 1 / sqrt(n_features).
    <br/>
    Use density = 1 / 3.0 if you want to reproduce the results from
    Achlioptas, 2001.

  **eps**
  : Parameter to control the quality of the embedding according to
    the Johnson-Lindenstrauss lemma when n_components is set to
    ‘auto’. This value should be strictly positive.
    <br/>
    Smaller values lead to better embedding and higher number of
    dimensions (n_components) in the target projection space.

  **dense_output**
  : If True, ensure that the output of the random projection is a
    dense numpy array even if the input and random projection matrix
    are both sparse. In practice, if the number of components is
    small the number of zero components in the projected data will
    be very small and it will be more CPU and memory efficient to
    use a dense representation.
    <br/>
    If False, the projected data uses a sparse representation if
    the input is sparse.

  **compute_inverse_components**
  : Learn the inverse transform by computing the pseudo-inverse of the
    components during fit. Note that the pseudo-inverse is always a dense
    array, even if the training data was sparse. This means that it might be
    necessary to call `inverse_transform` on a small batch of samples at a
    time to avoid exhausting the available memory on the host. Moreover,
    computing the pseudo-inverse does not scale well to large matrices.

  **random_state**
  : Controls the pseudo random number generator used to generate the
    projection matrix at fit time.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **n_components_**
  : Concrete number of components computed when n_components=”auto”.

  **components_**
  : Random matrix used for the projection. Sparse matrix will be of CSR
    format.

  **inverse_components_**
  : Pseudo-inverse of the components, only computed if
    `compute_inverse_components` is True.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **density_**
  : Concrete density computed from when density = “auto”.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`GaussianRandomProjection`](sklearn.random_projection.GaussianRandomProjection.md#sklearn.random_projection.GaussianRandomProjection)
: Reduce dimensionality through Gaussian random projection.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.random_projection import SparseRandomProjection
>>> rng = np.random.RandomState(42)
>>> X = rng.rand(25, 3000)
>>> transformer = SparseRandomProjection(random_state=rng)
>>> X_new = transformer.fit_transform(X)
>>> X_new.shape
(25, 2759)
>>> # very few components are non-zero
>>> np.mean(transformer.components_ != 0)
np.float64(0.0182...)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Generate a sparse random projection matrix.

* **Parameters:**
  **X**
  : Training set: only the shape is used to find optimal random
    matrix dimensions based on the theory referenced in the
    afore mentioned papers.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : BaseRandomProjection class instance.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Project data back to its original space.

Returns an array X_original whose transform would be X. Note that even
if X is sparse, X_original is dense: this may use a lot of RAM.

If `compute_inverse_components` is False, the inverse of the components is
computed during each call to `inverse_transform` which can be costly.

* **Parameters:**
  **X**
  : Data to be transformed back.
* **Returns:**
  **X_original**
  : Reconstructed data.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Project the data by using matrix product with the random matrix.

* **Parameters:**
  **X**
  : The input data to project into a smaller dimensional space.
* **Returns:**
  **X_new**
  : Projected array. It is a sparse matrix only when the input is sparse and
    `dense_output = False`.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip=" The \`Johnson-Lindenstrauss lemma\`_ states that any high dimensional dataset can be randomly projected into a lower dimensional Euclidean space while controlling the distortion in the pairwise distances.">  <div class="sphx-glr-thumbnail-title">The Johnson-Lindenstrauss bound for embedding with random projections</div>
</div>
* [The Johnson-Lindenstrauss bound for embedding with random projections](../../auto_examples/miscellaneous/plot_johnson_lindenstrauss_bound.md#sphx-glr-auto-examples-miscellaneous-plot-johnson-lindenstrauss-bound-py)

<!-- thumbnail-parent-div-close --></div>
