# fetch_openml

### sklearn.datasets.fetch_openml(name: [str](https://docs.python.org/3/library/stdtypes.html#str) | [None](https://docs.python.org/3/library/constants.html#None) = None, \*, version: [str](https://docs.python.org/3/library/stdtypes.html#str) | [int](https://docs.python.org/3/library/functions.html#int) = 'active', data_id: [int](https://docs.python.org/3/library/functions.html#int) | [None](https://docs.python.org/3/library/constants.html#None) = None, data_home: [str](https://docs.python.org/3/library/stdtypes.html#str) | [PathLike](https://docs.python.org/3/library/os.html#os.PathLike) | [None](https://docs.python.org/3/library/constants.html#None) = None, target_column: [str](https://docs.python.org/3/library/stdtypes.html#str) | [List](https://docs.python.org/3/library/typing.html#typing.List) | [None](https://docs.python.org/3/library/constants.html#None) = 'default-target', cache: [bool](https://docs.python.org/3/library/functions.html#bool) = True, return_X_y: [bool](https://docs.python.org/3/library/functions.html#bool) = False, as_frame: [str](https://docs.python.org/3/library/stdtypes.html#str) | [bool](https://docs.python.org/3/library/functions.html#bool) = 'auto', n_retries: [int](https://docs.python.org/3/library/functions.html#int) = 3, delay: [float](https://docs.python.org/3/library/functions.html#float) = 1.0, parser: [str](https://docs.python.org/3/library/stdtypes.html#str) = 'auto', read_csv_kwargs: [Dict](https://docs.python.org/3/library/typing.html#typing.Dict) | [None](https://docs.python.org/3/library/constants.html#None) = None)

Fetch dataset from openml by name or dataset id.

Datasets are uniquely identified by either an integer ID or by a
combination of name and version (i.e. there might be multiple
versions of the ‘iris’ dataset). Please give either name or data_id
(not both). In case a name is given, a version can also be
provided.

Read more in the [User Guide](../../datasets/loading_other_datasets.md#openml).

#### Versionadded
Added in version 0.20.

#### NOTE
EXPERIMENTAL

The API is experimental (particularly the return value structure),
and might have small backward-incompatible changes without notice
or warning in future releases.

* **Parameters:**
  **name**
  : String identifier of the dataset. Note that OpenML can have multiple
    datasets with the same name.

  **version**
  : Version of the dataset. Can only be provided if also `name` is given.
    If ‘active’ the oldest version that’s still active is used. Since
    there may be more than one active version of a dataset, and those
    versions may fundamentally be different from one another, setting an
    exact version is highly recommended.

  **data_id**
  : OpenML ID of the dataset. The most specific way of retrieving a
    dataset. If data_id is not given, name (and potential version) are
    used to obtain a dataset.

  **data_home**
  : Specify another download and cache folder for the data sets. By default
    all scikit-learn data is stored in ‘~/scikit_learn_data’ subfolders.

  **target_column**
  : Specify the column name in the data to use as target. If
    ‘default-target’, the standard target column a stored on the server
    is used. If `None`, all columns are returned as data and the
    target is `None`. If list (of strings), all columns with these names
    are returned as multi-target (Note: not all scikit-learn classifiers
    can handle all types of multi-output combinations).

  **cache**
  : Whether to cache the downloaded datasets into `data_home`.

  **return_X_y**
  : If True, returns `(data, target)` instead of a Bunch object. See
    below for more information about the `data` and `target` objects.

  **as_frame**
  : If True, the data is a pandas DataFrame including columns with
    appropriate dtypes (numeric, string or categorical). The target is
    a pandas DataFrame or Series depending on the number of target_columns.
    The Bunch will contain a `frame` attribute with the target and the
    data. If `return_X_y` is True, then `(data, target)` will be pandas
    DataFrames or Series as describe above.
    <br/>
    If `as_frame` is ‘auto’, the data and target will be converted to
    DataFrame or Series as if `as_frame` is set to True, unless the dataset
    is stored in sparse format.
    <br/>
    If `as_frame` is False, the data and target will be NumPy arrays and
    the `data` will only contain numerical values when `parser="liac-arff"`
    where the categories are provided in the attribute `categories` of the
    `Bunch` instance. When `parser="pandas"`, no ordinal encoding is made.
    <br/>
    #### Versionchanged
    Changed in version 0.24: The default value of `as_frame` changed from `False` to `'auto'`
    in 0.24.

  **n_retries**
  : Number of retries when HTTP errors or network timeouts are encountered.
    Error with status code 412 won’t be retried as they represent OpenML
    generic errors.

  **delay**
  : Number of seconds between retries.

  **parser**
  : Parser used to load the ARFF file. Two parsers are implemented:
    - `"pandas"`: this is the most efficient parser. However, it requires
      pandas to be installed and can only open dense datasets.
    - `"liac-arff"`: this is a pure Python ARFF parser that is much less
      memory- and CPU-efficient. It deals with sparse ARFF datasets.
    <br/>
    If `"auto"`, the parser is chosen automatically such that `"liac-arff"`
    is selected for sparse ARFF datasets, otherwise `"pandas"` is selected.
    <br/>
    #### Versionadded
    Added in version 1.2.
    <br/>
    #### Versionchanged
    Changed in version 1.4: The default value of `parser` changes from `"liac-arff"` to
    `"auto"`.

  **read_csv_kwargs**
  : Keyword arguments passed to [`pandas.read_csv`](https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.read_csv.html#pandas.read_csv) when loading the data
    from a ARFF file and using the pandas parser. It can allow to
    overwrite some default parameters.
    <br/>
    #### Versionadded
    Added in version 1.3.
* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : The feature matrix. Categorical features are encoded as ordinals.
    <br/>
    target
    : The regression target or classification labels, if applicable.
      Dtype is float if numeric, and object if categorical. If
      `as_frame` is True, `target` is a pandas object.
    <br/>
    DESCR
    : The full description of the dataset.
    <br/>
    feature_names
    : The names of the dataset columns.
    <br/>
    target_names: list
    : The names of the target columns.
    <br/>
    #### Versionadded
    Added in version 0.22.
    <br/>
    categories
    : Maps each categorical feature name to a list of values, such
      that the value encoded as i is ith in the list. If `as_frame`
      is True, this is None.
    <br/>
    details
    : More metadata from OpenML.
    <br/>
    frame
    : Only present when `as_frame=True`. DataFrame with `data` and
      `target`.

  **(data, target)**
  : #### NOTE
    EXPERIMENTAL
    <br/>
    This interface is **experimental** and subsequent releases may
    change attributes without notice (although there should only be
    minor changes to `data` and `target`).
    <br/>
    Missing values in the ‘data’ are represented as NaN’s. Missing values
    in ‘target’ are represented as NaN’s (numerical target) or None
    (categorical target).

### Notes

The `"pandas"` and `"liac-arff"` parsers can lead to different data types
in the output. The notable differences are the following:

- The `"liac-arff"` parser always encodes categorical features as `str` objects.
  To the contrary, the `"pandas"` parser instead infers the type while
  reading and numerical categories will be casted into integers whenever
  possible.
- The `"liac-arff"` parser uses float64 to encode numerical features
  tagged as ‘REAL’ and ‘NUMERICAL’ in the metadata. The `"pandas"`
  parser instead infers if these numerical features corresponds
  to integers and uses panda’s Integer extension dtype.
- In particular, classification datasets with integer categories are
  typically loaded as such `(0, 1, ...)` with the `"pandas"` parser while
  `"liac-arff"` will force the use of string encoded class labels such as
  `"0"`, `"1"` and so on.
- The `"pandas"` parser will not strip single quotes - i.e. `'` - from
  string columns. For instance, a string `'my string'` will be kept as is
  while the `"liac-arff"` parser will strip the single quotes. For
  categorical columns, the single quotes are stripped from the values.

In addition, when `as_frame=False` is used, the `"liac-arff"` parser
returns ordinally encoded data where the categories are provided in the
attribute `categories` of the `Bunch` instance. Instead, `"pandas"` returns
a NumPy array were the categories are not encoded.

### Examples

```pycon
>>> from sklearn.datasets import fetch_openml
>>> adult = fetch_openml("adult", version=2)  
>>> adult.frame.info()  
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 48842 entries, 0 to 48841
Data columns (total 15 columns):
 #   Column          Non-Null Count  Dtype
---  ------          --------------  -----
 0   age             48842 non-null  int64
 1   workclass       46043 non-null  category
 2   fnlwgt          48842 non-null  int64
 3   education       48842 non-null  category
 4   education-num   48842 non-null  int64
 5   marital-status  48842 non-null  category
 6   occupation      46033 non-null  category
 7   relationship    48842 non-null  category
 8   race            48842 non-null  category
 9   sex             48842 non-null  category
 10  capital-gain    48842 non-null  int64
 11  capital-loss    48842 non-null  int64
 12  hours-per-week  48842 non-null  int64
 13  native-country  47985 non-null  category
 14  class           48842 non-null  category
dtypes: category(9), int64(6)
memory usage: 2.7 MB
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use KernelPCA to denoise images. In short, we take advantage of the approximation function learned during fit to reconstruct the original image.">  <div class="sphx-glr-thumbnail-title">Image denoising using kernel PCA</div>
</div>
* [Image denoising using kernel PCA](../../auto_examples/applications/plot_digits_denoising.md#sphx-glr-auto-examples-applications-plot-digits-denoising-py)

<div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to apply different preprocessing and feature extraction pipelines to different subsets of features, using ColumnTransformer. This is particularly handy for the case of datasets that contain heterogeneous data types, since we may want to scale the numeric features and one-hot encode the categorical ones.">  <div class="sphx-glr-thumbnail-title">Column Transformer with Mixed Types</div>
</div>
* [Column Transformer with Mixed Types](../../auto_examples/compose/plot_column_transformer_mixed_types.md#sphx-glr-auto-examples-compose-plot-column-transformer-mixed-types-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we give an overview of TransformedTargetRegressor. We use two examples to illustrate the benefit of transforming the targets before learning a linear regression model. The first example uses synthetic data while the second example is based on the Ames housing data set.">  <div class="sphx-glr-thumbnail-title">Effect of transforming the targets in regression model</div>
</div>
* [Effect of transforming the targets in regression model](../../auto_examples/compose/plot_transformed_target.md#sphx-glr-auto-examples-compose-plot-transformed-target-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the training times and prediction performances of HistGradientBoostingRegressor with different encoding strategies for categorical features. In particular, we will evaluate:">  <div class="sphx-glr-thumbnail-title">Categorical Feature Support in Gradient Boosting</div>
</div>
* [Categorical Feature Support in Gradient Boosting](../../auto_examples/ensemble/plot_gradient_boosting_categorical.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-categorical-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="histogram_based_gradient_boosting (HGBT) models may be one of the most useful supervised learning models in scikit-learn. They are based on a modern gradient boosting implementation comparable to LightGBM and XGBoost. As such, HGBT models are more feature rich than and often outperform alternative models like random forests, especially when the number of samples is larger than some ten thousands (see sphx_glr_auto_examples_ensemble_plot_forest_hist_grad_boosting_comparison.py).">  <div class="sphx-glr-thumbnail-title">Features in Histogram Gradient Boosting Trees</div>
</div>
* [Features in Histogram Gradient Boosting Trees](../../auto_examples/ensemble/plot_hgbt_regression.md#sphx-glr-auto-examples-ensemble-plot-hgbt-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example is based on Section 5.4.3 of &quot;Gaussian Processes for Machine Learning&quot; [1]_. It illustrates an example of complex kernel engineering and hyperparameter optimization using gradient ascent on the log-marginal-likelihood. The data consists of the monthly average atmospheric CO2 concentrations (in parts per million by volume (ppm)) collected at the Mauna Loa Observatory in Hawaii, between 1958 and 2001. The objective is to model the CO2 concentration as a function of the time t and extrapolate for years after 2001.">  <div class="sphx-glr-thumbnail-title">Forecasting of CO2 level on Mona Loa dataset using Gaussian process regression (GPR)</div>
</div>
* [Forecasting of CO2 level on Mona Loa dataset using Gaussian process regression (GPR)](../../auto_examples/gaussian_process/plot_gpr_co2.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-co2-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Partial dependence plots show the dependence between the target function [2]_ and a set of features of interest, marginalizing over the values of all other features (the complement features). Due to the limits of human perception, the size of the set of features of interest must be small (usually, one or two) thus they are usually chosen among the most important features.">  <div class="sphx-glr-thumbnail-title">Partial Dependence and Individual Conditional Expectation Plots</div>
</div>
* [Partial Dependence and Individual Conditional Expectation Plots](../../auto_examples/inspection/plot_partial_dependence.md#sphx-glr-auto-examples-inspection-plot-partial-dependence-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the impurity-based feature importance of RandomForestClassifier with the permutation importance on the titanic dataset using permutation_importance. We will show that the impurity-based feature importance can inflate the importance of numerical features.">  <div class="sphx-glr-thumbnail-title">Permutation Importance vs Random Forest Feature Importance (MDI)</div>
</div>
* [Permutation Importance vs Random Forest Feature Importance (MDI)](../../auto_examples/inspection/plot_permutation_importance.md#sphx-glr-auto-examples-inspection-plot-permutation-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stochastic Gradient Descent is an optimization technique which minimizes a loss function in a stochastic fashion, performing a gradient descent step sample by sample. In particular, it is a very efficient method to fit linear models.">  <div class="sphx-glr-thumbnail-title">Early stopping of Stochastic Gradient Descent</div>
</div>
* [Early stopping of Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgd_early_stopping.md#sphx-glr-auto-examples-linear-model-plot-sgd-early-stopping-py)

<div class="sphx-glr-thumbcontainer" tooltip="Here we fit a multinomial logistic regression with L1 penalty on a subset of the MNIST digits classification task. We use the SAGA algorithm for this purpose: this a solver that is fast when the number of samples is significantly larger than the number of features and is able to finely optimize non-smooth objective functions which is the case with the l1-penalty. Test accuracy reaches &gt; 0.8, while weight vectors remains sparse and therefore more easily interpretable.">  <div class="sphx-glr-thumbnail-title">MNIST classification using multinomial logistic + L1</div>
</div>
* [MNIST classification using multinomial logistic + L1](../../auto_examples/linear_model/plot_sparse_logistic_regression_mnist.md#sphx-glr-auto-examples-linear-model-plot-sparse-logistic-regression-mnist-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Poisson, Gamma and Tweedie regression on the French Motor Third-Party Liability Claims dataset, and is inspired by an R tutorial [1]_.">  <div class="sphx-glr-thumbnail-title">Tweedie regression on insurance claims</div>
</div>
* [Tweedie regression on insurance claims](../../auto_examples/linear_model/plot_tweedie_regression_insurance_claims.md#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example will demonstrate the set_output API to configure transformers to output pandas DataFrames. set_output can be configured per estimator by calling the set_output method or globally by setting set_config(transform_output=&quot;pandas&quot;). For details, see SLEP018.">  <div class="sphx-glr-thumbnail-title">Introducing the set_output API</div>
</div>
* [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a binary classifier is trained, the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. The default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0. However, this default strategy may not be optimal for the task at hand.">  <div class="sphx-glr-thumbnail-title">Post-hoc tuning the cut-off point of decision function</div>
</div>
* [Post-hoc tuning the cut-off point of decision function](../../auto_examples/model_selection/plot_tuned_decision_threshold.md#sphx-glr-auto-examples-model-selection-plot-tuned-decision-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we discuss the problem of classification when the target variable is composed of more than two classes. This is called multiclass classification.">  <div class="sphx-glr-thumbnail-title">Overview of multiclass training meta-estimators</div>
</div>
* [Overview of multiclass training meta-estimators](../../auto_examples/multiclass/plot_multiclass_overview.md#sphx-glr-auto-examples-multiclass-plot-multiclass-overview-py)

<div class="sphx-glr-thumbcontainer" tooltip="The most naive strategy to solve such a task is to independently train a binary classifier on each label (i.e. each column of the target variable). At prediction time, the ensemble of binary classifiers is used to assemble multitask prediction.">  <div class="sphx-glr-thumbnail-title">Multilabel classification using a classifier chain</div>
</div>
* [Multilabel classification using a classifier chain](../../auto_examples/multioutput/plot_classifier_chain_yeast.md#sphx-glr-auto-examples-multioutput-plot-classifier-chain-yeast-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents how to chain KNeighborsTransformer and TSNE in a pipeline. It also shows how to wrap the packages nmslib and pynndescent to replace KNeighborsTransformer and perform approximate nearest neighbors. These packages can be installed with pip install nmslib pynndescent.">  <div class="sphx-glr-thumbnail-title">Approximate nearest neighbors in TSNE</div>
</div>
* [Approximate nearest neighbors in TSNE](../../auto_examples/neighbors/approximate_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-approximate-nearest-neighbors-py)

<div class="sphx-glr-thumbcontainer" tooltip="Sometimes looking at the learned coefficients of a neural network can provide insight into the learning behavior. For example if weights look unstructured, maybe some were not used at all, or if very large coefficients exist, maybe regularization was too low or the learning rate too high.">  <div class="sphx-glr-thumbnail-title">Visualization of MLP weights on MNIST</div>
</div>
* [Visualization of MLP weights on MNIST](../../auto_examples/neural_networks/plot_mnist_filters.md#sphx-glr-auto-examples-neural-networks-plot-mnist-filters-py)

<div class="sphx-glr-thumbcontainer" tooltip="The TargetEncoder uses the value of the target to encode each categorical feature. In this example, we will compare three different approaches for handling categorical features: TargetEncoder, OrdinalEncoder, OneHotEncoder and dropping the category.">  <div class="sphx-glr-thumbnail-title">Comparing Target Encoder with Other Encoders</div>
</div>
* [Comparing Target Encoder with Other Encoders](../../auto_examples/preprocessing/plot_target_encoder.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.2! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_2&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.2</div>
</div>
* [Release Highlights for scikit-learn 1.2](../../auto_examples/release_highlights/plot_release_highlights_1_2_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-2-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
