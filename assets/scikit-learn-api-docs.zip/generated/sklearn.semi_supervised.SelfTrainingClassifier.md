# SelfTrainingClassifier

### *class* sklearn.semi_supervised.SelfTrainingClassifier(estimator=None, base_estimator='deprecated', threshold=0.75, criterion='threshold', k_best=10, max_iter=10, verbose=False)

Self-training classifier.

This [metaestimator](../../glossary.md#term-metaestimator) allows a given supervised classifier to function as a
semi-supervised classifier, allowing it to learn from unlabeled data. It
does this by iteratively predicting pseudo-labels for the unlabeled data
and adding them to the training set.

The classifier will continue iterating until either max_iter is reached, or
no pseudo-labels were added to the training set in the previous iteration.

Read more in the [User Guide](../semi_supervised.md#self-training).

* **Parameters:**
  **estimator**
  : An estimator object implementing `fit` and `predict_proba`.
    Invoking the `fit` method will fit a clone of the passed estimator,
    which will be stored in the `estimator_` attribute.
    <br/>
    #### Versionadded
    Added in version 1.6: `estimator` was added to replace `base_estimator`.

  **base_estimator**
  : An estimator object implementing `fit` and `predict_proba`.
    Invoking the `fit` method will fit a clone of the passed estimator,
    which will be stored in the `estimator_` attribute.
    <br/>
    #### Deprecated
    Deprecated since version 1.6: `base_estimator` was deprecated in 1.6 and will be removed in 1.8.
    Use `estimator` instead.

  **threshold**
  : The decision threshold for use with `criterion='threshold'`.
    Should be in [0, 1). When using the `'threshold'` criterion, a
    [well calibrated classifier](../calibration.md#calibration) should be used.

  **criterion**
  : The selection criterion used to select which labels to add to the
    training set. If `'threshold'`, pseudo-labels with prediction
    probabilities above `threshold` are added to the dataset. If `'k_best'`,
    the `k_best` pseudo-labels with highest prediction probabilities are
    added to the dataset. When using the ‘threshold’ criterion, a
    [well calibrated classifier](../calibration.md#calibration) should be used.

  **k_best**
  : The amount of samples to add in each iteration. Only used when
    `criterion='k_best'`.

  **max_iter**
  : Maximum number of iterations allowed. Should be greater than or equal
    to 0. If it is `None`, the classifier will continue to predict labels
    until no new pseudo-labels are added, or all unlabeled samples have
    been labeled.

  **verbose**
  : Enable verbose output.
* **Attributes:**
  **estimator_**
  : The fitted estimator.

  **classes_**
  : Class labels for each output. (Taken from the trained
    `estimator_`).

  **transduction_**
  : The labels used for the final fit of the classifier, including
    pseudo-labels added during fit.

  **labeled_iter_**
  : The iteration in which each sample was labeled. When a sample has
    iteration 0, the sample was already labeled in the original dataset.
    When a sample has iteration -1, the sample was not labeled in any
    iteration.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : The number of rounds of self-training, that is the number of times the
    base estimator is fitted on relabeled variants of the training set.

  **termination_condition_**
  : The reason that fitting was stopped.
    - `'max_iter'`: `n_iter_` reached `max_iter`.
    - `'no_change'`: no new labels were predicted.
    - `'all_labeled'`: all unlabeled samples were labeled before `max_iter`
      was reached.

#### SEE ALSO
[`LabelPropagation`](sklearn.semi_supervised.LabelPropagation.md#sklearn.semi_supervised.LabelPropagation)
: Label propagation classifier.

[`LabelSpreading`](sklearn.semi_supervised.LabelSpreading.md#sklearn.semi_supervised.LabelSpreading)
: Label spreading model for semi-supervised learning.

### References

[David Yarowsky. 1995. Unsupervised word sense disambiguation rivaling
supervised methods. In Proceedings of the 33rd annual meeting on
Association for Computational Linguistics (ACL ‘95). Association for
Computational Linguistics, Stroudsburg, PA, USA, 189-196.](https://doi.org/10.3115/981658.981684)

### Examples

```pycon
>>> import numpy as np
>>> from sklearn import datasets
>>> from sklearn.semi_supervised import SelfTrainingClassifier
>>> from sklearn.svm import SVC
>>> rng = np.random.RandomState(42)
>>> iris = datasets.load_iris()
>>> random_unlabeled_points = rng.rand(iris.target.shape[0]) < 0.3
>>> iris.target[random_unlabeled_points] = -1
>>> svc = SVC(probability=True, gamma="auto")
>>> self_training_model = SelfTrainingClassifier(svc)
>>> self_training_model.fit(iris.data, iris.target)
SelfTrainingClassifier(...)
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X, \*\*params)

Call decision function of the `estimator`.

* **Parameters:**
  **X**
  : Array representing the data.

  **\*\*params**
  : Parameters to pass to the underlying estimator’s
    `decision_function` method.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **y**
  : Result of the decision function of the `estimator`.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*\*params)

Fit self-training classifier using `X`, `y` as training data.

* **Parameters:**
  **X**
  : Array representing the data.

  **y**
  : Array representing the labels. Unlabeled samples should have the
    label -1.

  **\*\*params**
  : Parameters to pass to the underlying estimators.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.6.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X, \*\*params)

Predict the classes of `X`.

* **Parameters:**
  **X**
  : Array representing the data.

  **\*\*params**
  : Parameters to pass to the underlying estimator’s `predict` method.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **y**
  : Array with predicted labels.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X, \*\*params)

Predict log probability for each possible outcome.

* **Parameters:**
  **X**
  : Array representing the data.

  **\*\*params**
  : Parameters to pass to the underlying estimator’s
    `predict_log_proba` method.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **y**
  : Array with log prediction probabilities.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X, \*\*params)

Predict probability for each possible outcome.

* **Parameters:**
  **X**
  : Array representing the data.

  **\*\*params**
  : Parameters to pass to the underlying estimator’s
    `predict_proba` method.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **y**
  : Array with prediction probabilities.

<!-- !! processed by numpydoc !! -->

#### score(X, y, \*\*params)

Call score on the `estimator`.

* **Parameters:**
  **X**
  : Array representing the data.

  **y**
  : Array representing the labels.

  **\*\*params**
  : Parameters to pass to the underlying estimator’s `score` method.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **score**
  : Result of calling score on the `estimator`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A comparison for the decision boundaries generated on the iris dataset by Label Spreading, Self-training and SVM.">  <div class="sphx-glr-thumbnail-title">Decision boundary of semi-supervised classifiers versus SVM on the Iris dataset</div>
</div>
* [Decision boundary of semi-supervised classifiers versus SVM on the Iris dataset](../../auto_examples/semi_supervised/plot_semi_supervised_versus_svm_iris.md#sphx-glr-auto-examples-semi-supervised-plot-semi-supervised-versus-svm-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of a varying threshold on self-training. The breast_cancer dataset is loaded, and labels are deleted such that only 50 out of 569 samples have labels. A SelfTrainingClassifier is fitted on this dataset, with varying thresholds.">  <div class="sphx-glr-thumbnail-title">Effect of varying threshold for self-training</div>
</div>
* [Effect of varying threshold for self-training](../../auto_examples/semi_supervised/plot_self_training_varying_threshold.md#sphx-glr-auto-examples-semi-supervised-plot-self-training-varying-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, semi-supervised classifiers are trained on the 20 newsgroups dataset (which will be automatically downloaded).">  <div class="sphx-glr-thumbnail-title">Semi-supervised Classification on a Text Dataset</div>
</div>
* [Semi-supervised Classification on a Text Dataset](../../auto_examples/semi_supervised/plot_semi_supervised_newsgroups.md#sphx-glr-auto-examples-semi-supervised-plot-semi-supervised-newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
