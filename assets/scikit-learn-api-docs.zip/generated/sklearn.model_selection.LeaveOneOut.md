# LeaveOneOut

### *class* sklearn.model_selection.LeaveOneOut

Leave-One-Out cross-validator.

Provides train/test indices to split data in train/test sets. Each
sample is used once as a test set (singleton) while the remaining
samples form the training set.

Note: `LeaveOneOut()` is equivalent to `KFold(n_splits=n)` and
`LeavePOut(p=1)` where `n` is the number of samples.

Due to the high number of test sets (which is the same as the
number of samples) this cross-validation method can be very costly.
For large datasets one should favor [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold), [`ShuffleSplit`](sklearn.model_selection.ShuffleSplit.md#sklearn.model_selection.ShuffleSplit)
or [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold).

Read more in the [User Guide](../cross_validation.md#leave-one-out).

#### SEE ALSO
[`LeaveOneGroupOut`](sklearn.model_selection.LeaveOneGroupOut.md#sklearn.model_selection.LeaveOneGroupOut)
: For splitting the data according to explicit, domain-specific stratification of the dataset.

[`GroupKFold`](sklearn.model_selection.GroupKFold.md#sklearn.model_selection.GroupKFold)
: K-fold iterator variant with non-overlapping groups.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import LeaveOneOut
>>> X = np.array([[1, 2], [3, 4]])
>>> y = np.array([1, 2])
>>> loo = LeaveOneOut()
>>> loo.get_n_splits(X)
2
>>> print(loo)
LeaveOneOut()
>>> for i, (train_index, test_index) in enumerate(loo.split(X)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}")
...     print(f"  Test:  index={test_index}")
Fold 0:
  Train: index=[1]
  Test:  index=[0]
Fold 1:
  Train: index=[0]
  Test:  index=[1]
```

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Always ignored, exists for compatibility.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### split(X, y=None, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : The target variable for supervised learning problems.

  **groups**
  : Always ignored, exists for compatibility.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

<!-- !! processed by numpydoc !! -->
