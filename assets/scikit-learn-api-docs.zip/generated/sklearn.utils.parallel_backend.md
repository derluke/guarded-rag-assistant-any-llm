# parallel_backend

### *class* sklearn.utils.parallel_backend(backend, n_jobs=-1, inner_max_num_threads=None, \*\*backend_params)

<!-- !! processed by numpydoc !! -->
