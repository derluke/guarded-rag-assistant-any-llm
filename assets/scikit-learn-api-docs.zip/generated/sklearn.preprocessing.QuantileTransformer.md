# QuantileTransformer

### *class* sklearn.preprocessing.QuantileTransformer(\*, n_quantiles=1000, output_distribution='uniform', ignore_implicit_zeros=False, subsample=10000, random_state=None, copy=True)

Transform features using quantiles information.

This method transforms the features to follow a uniform or a normal
distribution. Therefore, for a given feature, this transformation tends
to spread out the most frequent values. It also reduces the impact of
(marginal) outliers: this is therefore a robust preprocessing scheme.

The transformation is applied on each feature independently. First an
estimate of the cumulative distribution function of a feature is
used to map the original values to a uniform distribution. The obtained
values are then mapped to the desired output distribution using the
associated quantile function. Features values of new/unseen data that fall
below or above the fitted range will be mapped to the bounds of the output
distribution. Note that this transform is non-linear. It may distort linear
correlations between variables measured at the same scale but renders
variables measured at different scales more directly comparable.

For example visualizations, refer to [Compare QuantileTransformer with
other scalers](../../auto_examples/preprocessing/plot_all_scaling.md#plot-all-scaling-quantile-transformer-section).

Read more in the [User Guide](../preprocessing.md#preprocessing-transformer).

#### Versionadded
Added in version 0.19.

* **Parameters:**
  **n_quantiles**
  : Number of quantiles to be computed. It corresponds to the number
    of landmarks used to discretize the cumulative distribution function.
    If n_quantiles is larger than the number of samples, n_quantiles is set
    to the number of samples as a larger number of quantiles does not give
    a better approximation of the cumulative distribution function
    estimator.

  **output_distribution**
  : Marginal distribution for the transformed data. The choices are
    ‘uniform’ (default) or ‘normal’.

  **ignore_implicit_zeros**
  : Only applies to sparse matrices. If True, the sparse entries of the
    matrix are discarded to compute the quantile statistics. If False,
    these entries are treated as zeros.

  **subsample**
  : Maximum number of samples used to estimate the quantiles for
    computational efficiency. Note that the subsampling procedure may
    differ for value-identical sparse and dense matrices.
    Disable subsampling by setting `subsample=None`.
    <br/>
    #### Versionadded
    Added in version 1.5: The option `None` to disable subsampling was added.

  **random_state**
  : Determines random number generation for subsampling and smoothing
    noise.
    Please see `subsample` for more details.
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **copy**
  : Set to False to perform inplace transformation and avoid a copy (if the
    input is already a numpy array).
* **Attributes:**
  **n_quantiles_**
  : The actual number of quantiles used to discretize the cumulative
    distribution function.

  **quantiles_**
  : The values corresponding the quantiles of reference.

  **references_**
  : Quantiles of references.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`quantile_transform`](sklearn.preprocessing.quantile_transform.md#sklearn.preprocessing.quantile_transform)
: Equivalent function without the estimator API.

[`PowerTransformer`](sklearn.preprocessing.PowerTransformer.md#sklearn.preprocessing.PowerTransformer)
: Perform mapping to a normal distribution using a power transform.

[`StandardScaler`](sklearn.preprocessing.StandardScaler.md#sklearn.preprocessing.StandardScaler)
: Perform standardization that is faster, but less robust to outliers.

[`RobustScaler`](sklearn.preprocessing.RobustScaler.md#sklearn.preprocessing.RobustScaler)
: Perform robust standardization that removes the influence of outliers but does not put outliers and inliers on the same scale.

### Notes

NaNs are treated as missing values: disregarded in fit, and maintained in
transform.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.preprocessing import QuantileTransformer
>>> rng = np.random.RandomState(0)
>>> X = np.sort(rng.normal(loc=0.5, scale=0.25, size=(25, 1)), axis=0)
>>> qt = QuantileTransformer(n_quantiles=10, random_state=0)
>>> qt.fit_transform(X)
array([...])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Compute the quantiles used for transforming.

* **Parameters:**
  **X**
  : The data used to scale along the features axis. If a sparse
    matrix is provided, it will be converted into a sparse
    `csc_matrix`. Additionally, the sparse matrix needs to be
    nonnegative if `ignore_implicit_zeros` is False.

  **y**
  : Ignored.
* **Returns:**
  **self**
  : Fitted transformer.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Same as input features.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Back-projection to the original space.

* **Parameters:**
  **X**
  : The data used to scale along the features axis. If a sparse
    matrix is provided, it will be converted into a sparse
    `csc_matrix`. Additionally, the sparse matrix needs to be
    nonnegative if `ignore_implicit_zeros` is False.
* **Returns:**
  **Xt**
  : The projected data.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Feature-wise transformation of the data.

* **Parameters:**
  **X**
  : The data used to scale along the features axis. If a sparse
    matrix is provided, it will be converted into a sparse
    `csc_matrix`. Additionally, the sparse matrix needs to be
    nonnegative if `ignore_implicit_zeros` is False.
* **Returns:**
  **Xt**
  : The projected data.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we give an overview of TransformedTargetRegressor. We use two examples to illustrate the benefit of transforming the targets before learning a linear regression model. The first example uses synthetic data while the second example is based on the Ames housing data set.">  <div class="sphx-glr-thumbnail-title">Effect of transforming the targets in regression model</div>
</div>
* [Effect of transforming the targets in regression model](../../auto_examples/compose/plot_transformed_target.md#sphx-glr-auto-examples-compose-plot-transformed-target-py)

<div class="sphx-glr-thumbcontainer" tooltip="Partial dependence plots show the dependence between the target function [2]_ and a set of features of interest, marginalizing over the values of all other features (the complement features). Due to the limits of human perception, the size of the set of features of interest must be small (usually, one or two) thus they are usually chosen among the most important features.">  <div class="sphx-glr-thumbnail-title">Partial Dependence and Individual Conditional Expectation Plots</div>
</div>
* [Partial Dependence and Individual Conditional Expectation Plots](../../auto_examples/inspection/plot_partial_dependence.md#sphx-glr-auto-examples-inspection-plot-partial-dependence-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature 0 (median income in a block) and feature 5 (average house occupancy) of the california_housing_dataset have very different scales and contain some very large outliers. These two characteristics lead to difficulties to visualize the data and, more importantly, they can degrade the predictive performance of many machine learning algorithms. Unscaled data can also slow down or even prevent the convergence of many gradient-based estimators.">  <div class="sphx-glr-thumbnail-title">Compare the effect of different scalers on data with outliers</div>
</div>
* [Compare the effect of different scalers on data with outliers](../../auto_examples/preprocessing/plot_all_scaling.md#sphx-glr-auto-examples-preprocessing-plot-all-scaling-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the use of the Box-Cox and Yeo-Johnson transforms through PowerTransformer to map data from various distributions to a normal distribution.">  <div class="sphx-glr-thumbnail-title">Map data to a normal distribution</div>
</div>
* [Map data to a normal distribution](../../auto_examples/preprocessing/plot_map_data_to_normal.md#sphx-glr-auto-examples-preprocessing-plot-map-data-to-normal-py)

<!-- thumbnail-parent-div-close --></div>
