# KMeans

### *class* sklearn.cluster.KMeans(n_clusters=8, \*, init='k-means++', n_init='auto', max_iter=300, tol=0.0001, verbose=0, random_state=None, copy_x=True, algorithm='lloyd')

K-Means clustering.

Read more in the [User Guide](../clustering.md#k-means).

* **Parameters:**
  **n_clusters**
  : The number of clusters to form as well as the number of
    centroids to generate.
    <br/>
    For an example of how to choose an optimal value for `n_clusters` refer to
    [Selecting the number of clusters with silhouette analysis on KMeans clustering](../../auto_examples/cluster/plot_kmeans_silhouette_analysis.md#sphx-glr-auto-examples-cluster-plot-kmeans-silhouette-analysis-py).

  **init**
  : Method for initialization:
    * ‘k-means++’ : selects initial cluster centroids using sampling             based on an empirical probability distribution of the points’             contribution to the overall inertia. This technique speeds up             convergence. The algorithm implemented is “greedy k-means++”. It             differs from the vanilla k-means++ by making several trials at             each sampling step and choosing the best centroid among them.
    * ‘random’: choose `n_clusters` observations (rows) at random from         data for the initial centroids.
    * If an array is passed, it should be of shape (n_clusters, n_features)        and gives the initial centers.
    * If a callable is passed, it should take arguments X, n_clusters and a        random state and return an initialization.
    <br/>
    For an example of how to use the different `init` strategies, see
    [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py).
    <br/>
    For an evaluation of the impact of initialization, see the example
    [Empirical evaluation of the impact of k-means initialization](../../auto_examples/cluster/plot_kmeans_stability_low_dim_dense.md#sphx-glr-auto-examples-cluster-plot-kmeans-stability-low-dim-dense-py).

  **n_init**
  : Number of times the k-means algorithm is run with different centroid
    seeds. The final results is the best output of `n_init` consecutive runs
    in terms of inertia. Several runs are recommended for sparse
    high-dimensional problems (see [Clustering sparse data with k-means](../../auto_examples/text/plot_document_clustering.md#kmeans-sparse-high-dim)).
    <br/>
    When `n_init='auto'`, the number of runs depends on the value of init:
    10 if using `init='random'` or `init` is a callable;
    1 if using `init='k-means++'` or `init` is an array-like.
    <br/>
    #### Versionadded
    Added in version 1.2: Added ‘auto’ option for `n_init`.
    <br/>
    #### Versionchanged
    Changed in version 1.4: Default value for `n_init` changed to `'auto'`.

  **max_iter**
  : Maximum number of iterations of the k-means algorithm for a
    single run.

  **tol**
  : Relative tolerance with regards to Frobenius norm of the difference
    in the cluster centers of two consecutive iterations to declare
    convergence.

  **verbose**
  : Verbosity mode.

  **random_state**
  : Determines random number generation for centroid initialization. Use
    an int to make the randomness deterministic.
    See [Glossary](../../glossary.md#term-random_state).

  **copy_x**
  : When pre-computing distances it is more numerically accurate to center
    the data first. If copy_x is True (default), then the original data is
    not modified. If False, the original data is modified, and put back
    before the function returns, but small numerical differences may be
    introduced by subtracting and then adding the data mean. Note that if
    the original data is not C-contiguous, a copy will be made even if
    copy_x is False. If the original data is sparse, but not in CSR format,
    a copy will be made even if copy_x is False.

  **algorithm**
  : K-means algorithm to use. The classical EM-style algorithm is `"lloyd"`.
    The `"elkan"` variation can be more efficient on some datasets with
    well-defined clusters, by using the triangle inequality. However it’s
    more memory intensive due to the allocation of an extra array of shape
    `(n_samples, n_clusters)`.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added Elkan algorithm
    <br/>
    #### Versionchanged
    Changed in version 1.1: Renamed “full” to “lloyd”, and deprecated “auto” and “full”.
    Changed “auto” to use “lloyd” instead of “elkan”.
* **Attributes:**
  **cluster_centers_**
  : Coordinates of cluster centers. If the algorithm stops before fully
    converging (see `tol` and `max_iter`), these will not be
    consistent with `labels_`.

  **labels_**
  : Labels of each point

  **inertia_**
  : Sum of squared distances of samples to their closest cluster center,
    weighted by the sample weights if provided.

  **n_iter_**
  : Number of iterations run.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`MiniBatchKMeans`](sklearn.cluster.MiniBatchKMeans.md#sklearn.cluster.MiniBatchKMeans)
: Alternative online implementation that does incremental updates of the centers positions using mini-batches. For large scale learning (say n_samples > 10k) MiniBatchKMeans is probably much faster than the default batch implementation.

### Notes

The k-means problem is solved using either Lloyd’s or Elkan’s algorithm.

The average complexity is given by O(k n T), where n is the number of
samples and T is the number of iteration.

The worst case complexity is given by O(n^(k+2/p)) with
n = n_samples, p = n_features.
Refer to [“How slow is the k-means method?” D. Arthur and S. Vassilvitskii -
SoCG2006.](https://doi.org/10.1145/1137856.1137880) for more details.

In practice, the k-means algorithm is very fast (one of the fastest
clustering algorithms available), but it falls in local minima. That’s why
it can be useful to restart it several times.

If the algorithm stops before fully converging (because of `tol` or
`max_iter`), `labels_` and `cluster_centers_` will not be consistent,
i.e. the `cluster_centers_` will not be the means of the points in each
cluster. Also, the estimator will reassign `labels_` after the last
iteration to make `labels_` consistent with `predict` on the training
set.

### Examples

```pycon
>>> from sklearn.cluster import KMeans
>>> import numpy as np
>>> X = np.array([[1, 2], [1, 4], [1, 0],
...               [10, 2], [10, 4], [10, 0]])
>>> kmeans = KMeans(n_clusters=2, random_state=0, n_init="auto").fit(X)
>>> kmeans.labels_
array([1, 1, 1, 0, 0, 0], dtype=int32)
>>> kmeans.predict([[0, 0], [12, 3]])
array([1, 0], dtype=int32)
>>> kmeans.cluster_centers_
array([[10.,  2.],
       [ 1.,  2.]])
```

For examples of common problems with K-Means and how to address them see
[Demonstration of k-means assumptions](../../auto_examples/cluster/plot_kmeans_assumptions.md#sphx-glr-auto-examples-cluster-plot-kmeans-assumptions-py).

For a demonstration of how K-Means can be used to cluster text documents see
[Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py).

For a comparison between K-Means and MiniBatchKMeans refer to example
[Comparison of the K-Means and MiniBatchKMeans clustering algorithms](../../auto_examples/cluster/plot_mini_batch_kmeans.md#sphx-glr-auto-examples-cluster-plot-mini-batch-kmeans-py).

For a comparison between K-Means and BisectingKMeans refer to example
[Bisecting K-Means and Regular K-Means Performance Comparison](../../auto_examples/cluster/plot_bisect_kmeans.md#sphx-glr-auto-examples-cluster-plot-bisect-kmeans-py).

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Compute k-means clustering.

* **Parameters:**
  **X**
  : Training instances to cluster. It must be noted that the data
    will be converted to C ordering, which will cause a memory
    copy if the given data is not C-contiguous.
    If a sparse matrix is passed, a copy will be made if it’s not in
    CSR format.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : The weights for each observation in X. If None, all observations
    are assigned equal weight. `sample_weight` is not used during
    initialization if `init` is a callable or a user provided array.
    <br/>
    #### Versionadded
    Added in version 0.20.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None, sample_weight=None)

Compute cluster centers and predict cluster index for each sample.

Convenience method; equivalent to calling fit(X) followed by
predict(X).

* **Parameters:**
  **X**
  : New data to transform.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : The weights for each observation in X. If None, all observations
    are assigned equal weight.
* **Returns:**
  **labels**
  : Index of the cluster each sample belongs to.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, sample_weight=None)

Compute clustering and transform X to cluster-distance space.

Equivalent to fit(X).transform(X), but more efficiently implemented.

* **Parameters:**
  **X**
  : New data to transform.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : The weights for each observation in X. If None, all observations
    are assigned equal weight.
* **Returns:**
  **X_new**
  : X transformed in the new space.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict the closest cluster each sample in X belongs to.

In the vector quantization literature, `cluster_centers_` is called
the code book and each value returned by `predict` is the index of
the closest code in the code book.

* **Parameters:**
  **X**
  : New data to predict.
* **Returns:**
  **labels**
  : Index of the cluster each sample belongs to.

<!-- !! processed by numpydoc !! -->

#### score(X, y=None, sample_weight=None)

Opposite of the value of X on the K-means objective.

* **Parameters:**
  **X**
  : New data.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : The weights for each observation in X. If None, all observations
    are assigned equal weight.
* **Returns:**
  **score**
  : Opposite of the value of X on the K-means objective.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [KMeans](#sklearn.cluster.KMeans)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [KMeans](#sklearn.cluster.KMeans)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform X to a cluster-distance space.

In the new space, each dimension is the distance to the cluster
centers. Note that even if X is sparse, the array returned by
`transform` will typically be dense.

* **Parameters:**
  **X**
  : New data to transform.
* **Returns:**
  **X_new**
  : X transformed in the new space.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the various initialization strategies for K-means in terms of runtime and quality of the results.">  <div class="sphx-glr-thumbnail-title">A demo of K-Means clustering on the handwritten digits data</div>
</div>
* [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows differences between Regular K-Means algorithm and Bisecting K-Means.">  <div class="sphx-glr-thumbnail-title">Bisecting K-Means and Regular K-Means Performance Comparison</div>
</div>
* [Bisecting K-Means and Regular K-Means Performance Comparison](../../auto_examples/cluster/plot_bisect_kmeans.md#sphx-glr-auto-examples-cluster-plot-bisect-kmeans-py)

<div class="sphx-glr-thumbcontainer" tooltip="We want to compare the performance of the MiniBatchKMeans and KMeans: the MiniBatchKMeans is faster, but gives slightly different results (see mini_batch_kmeans).">  <div class="sphx-glr-thumbnail-title">Comparison of the K-Means and MiniBatchKMeans clustering algorithms</div>
</div>
* [Comparison of the K-Means and MiniBatchKMeans clustering algorithms](../../auto_examples/cluster/plot_mini_batch_kmeans.md#sphx-glr-auto-examples-cluster-plot-mini-batch-kmeans-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example is meant to illustrate situations where k-means produces unintuitive and possibly undesirable clusters.">  <div class="sphx-glr-thumbnail-title">Demonstration of k-means assumptions</div>
</div>
* [Demonstration of k-means assumptions](../../auto_examples/cluster/plot_kmeans_assumptions.md#sphx-glr-auto-examples-cluster-plot-kmeans-assumptions-py)

<div class="sphx-glr-thumbcontainer" tooltip="Evaluate the ability of k-means initializations strategies to make the algorithm convergence robust, as measured by the relative standard deviation of the inertia of the clustering (i.e. the sum of squared distances to the nearest cluster center).">  <div class="sphx-glr-thumbnail-title">Empirical evaluation of the impact of k-means initialization</div>
</div>
* [Empirical evaluation of the impact of k-means initialization](../../auto_examples/cluster/plot_kmeans_stability_low_dim_dense.md#sphx-glr-auto-examples-cluster-plot-kmeans-stability-low-dim-dense-py)

<div class="sphx-glr-thumbcontainer" tooltip="Silhouette analysis can be used to study the separation distance between the resulting clusters. The silhouette plot displays a measure of how close each point in one cluster is to points in the neighboring clusters and thus provides a way to assess parameters like number of clusters visually. This measure has a range of [-1, 1].">  <div class="sphx-glr-thumbnail-title">Selecting the number of clusters with silhouette analysis on KMeans clustering</div>
</div>
* [Selecting the number of clusters with silhouette analysis on KMeans clustering](../../auto_examples/cluster/plot_kmeans_silhouette_analysis.md#sphx-glr-auto-examples-cluster-plot-kmeans-silhouette-analysis-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how the scikit-learn API can be used to cluster documents by topics using a Bag of Words approach.">  <div class="sphx-glr-thumbnail-title">Clustering text documents using k-means</div>
</div>
* [Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<!-- thumbnail-parent-div-close --></div>
