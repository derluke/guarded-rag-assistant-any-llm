# BisectingKMeans

### *class* sklearn.cluster.BisectingKMeans(n_clusters=8, \*, init='random', n_init=1, random_state=None, max_iter=300, verbose=0, tol=0.0001, copy_x=True, algorithm='lloyd', bisecting_strategy='biggest_inertia')

Bisecting K-Means clustering.

Read more in the [User Guide](../clustering.md#bisect-k-means).

#### Versionadded
Added in version 1.1.

* **Parameters:**
  **n_clusters**
  : The number of clusters to form as well as the number of
    centroids to generate.

  **init**
  : Method for initialization:
    <br/>
    ‘k-means++’ : selects initial cluster centers for k-mean
    clustering in a smart way to speed up convergence. See section
    Notes in k_init for more details.
    <br/>
    ‘random’: choose `n_clusters` observations (rows) at random from data
    for the initial centroids.
    <br/>
    If a callable is passed, it should take arguments X, n_clusters and a
    random state and return an initialization.

  **n_init**
  : Number of time the inner k-means algorithm will be run with different
    centroid seeds in each bisection.
    That will result producing for each bisection best output of n_init
    consecutive runs in terms of inertia.

  **random_state**
  : Determines random number generation for centroid initialization
    in inner K-Means. Use an int to make the randomness deterministic.
    See [Glossary](../../glossary.md#term-random_state).

  **max_iter**
  : Maximum number of iterations of the inner k-means algorithm at each
    bisection.

  **verbose**
  : Verbosity mode.

  **tol**
  : Relative tolerance with regards to Frobenius norm of the difference
    in the cluster centers of two consecutive iterations  to declare
    convergence. Used in inner k-means algorithm at each bisection to pick
    best possible clusters.

  **copy_x**
  : When pre-computing distances it is more numerically accurate to center
    the data first. If copy_x is True (default), then the original data is
    not modified. If False, the original data is modified, and put back
    before the function returns, but small numerical differences may be
    introduced by subtracting and then adding the data mean. Note that if
    the original data is not C-contiguous, a copy will be made even if
    copy_x is False. If the original data is sparse, but not in CSR format,
    a copy will be made even if copy_x is False.

  **algorithm**
  : Inner K-means algorithm used in bisection.
    The classical EM-style algorithm is `"lloyd"`.
    The `"elkan"` variation can be more efficient on some datasets with
    well-defined clusters, by using the triangle inequality. However it’s
    more memory intensive due to the allocation of an extra array of shape
    `(n_samples, n_clusters)`.

  **bisecting_strategy**
  : Defines how bisection should be performed:
    - “biggest_inertia” means that BisectingKMeans will always check
      all calculated cluster for cluster with biggest SSE
      (Sum of squared errors) and bisect it. This approach concentrates on
      precision, but may be costly in terms of execution time (especially for
      larger amount of data points).
    - “largest_cluster” - BisectingKMeans will always split cluster with
      largest amount of points assigned to it from all clusters
      previously calculated. That should work faster than picking by SSE
      (‘biggest_inertia’) and may produce similar results in most cases.
* **Attributes:**
  **cluster_centers_**
  : Coordinates of cluster centers. If the algorithm stops before fully
    converging (see `tol` and `max_iter`), these will not be
    consistent with `labels_`.

  **labels_**
  : Labels of each point.

  **inertia_**
  : Sum of squared distances of samples to their closest cluster center,
    weighted by the sample weights if provided.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.

#### SEE ALSO
[`KMeans`](sklearn.cluster.KMeans.md#sklearn.cluster.KMeans)
: Original implementation of K-Means algorithm.

### Notes

It might be inefficient when n_cluster is less than 3, due to unnecessary
calculations for that case.

### Examples

```pycon
>>> from sklearn.cluster import BisectingKMeans
>>> import numpy as np
>>> X = np.array([[1, 1], [10, 1], [3, 1],
...               [10, 0], [2, 1], [10, 2],
...               [10, 8], [10, 9], [10, 10]])
>>> bisect_means = BisectingKMeans(n_clusters=3, random_state=0).fit(X)
>>> bisect_means.labels_
array([0, 2, 0, 2, 0, 2, 1, 1, 1], dtype=int32)
>>> bisect_means.predict([[0, 0], [12, 3]])
array([0, 2], dtype=int32)
>>> bisect_means.cluster_centers_
array([[ 2., 1.],
       [10., 9.],
       [10., 1.]])
```

For a comparison between BisectingKMeans and K-Means refer to example
[Bisecting K-Means and Regular K-Means Performance Comparison](../../auto_examples/cluster/plot_bisect_kmeans.md#sphx-glr-auto-examples-cluster-plot-bisect-kmeans-py).

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Compute bisecting k-means clustering.

* **Parameters:**
  **X**
  : Training instances to cluster.
    <br/>
    #### NOTE
    The data will be converted to C ordering,
    which will cause a memory copy
    if the given data is not C-contiguous.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : The weights for each observation in X. If None, all observations
    are assigned equal weight. `sample_weight` is not used during
    initialization if `init` is a callable.
* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None, sample_weight=None)

Compute cluster centers and predict cluster index for each sample.

Convenience method; equivalent to calling fit(X) followed by
predict(X).

* **Parameters:**
  **X**
  : New data to transform.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : The weights for each observation in X. If None, all observations
    are assigned equal weight.
* **Returns:**
  **labels**
  : Index of the cluster each sample belongs to.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, sample_weight=None)

Compute clustering and transform X to cluster-distance space.

Equivalent to fit(X).transform(X), but more efficiently implemented.

* **Parameters:**
  **X**
  : New data to transform.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : The weights for each observation in X. If None, all observations
    are assigned equal weight.
* **Returns:**
  **X_new**
  : X transformed in the new space.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict which cluster each sample in X belongs to.

Prediction is made by going down the hierarchical tree
in searching of closest leaf cluster.

In the vector quantization literature, `cluster_centers_` is called
the code book and each value returned by `predict` is the index of
the closest code in the code book.

* **Parameters:**
  **X**
  : New data to predict.
* **Returns:**
  **labels**
  : Index of the cluster each sample belongs to.

<!-- !! processed by numpydoc !! -->

#### score(X, y=None, sample_weight=None)

Opposite of the value of X on the K-means objective.

* **Parameters:**
  **X**
  : New data.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : The weights for each observation in X. If None, all observations
    are assigned equal weight.
* **Returns:**
  **score**
  : Opposite of the value of X on the K-means objective.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BisectingKMeans](#sklearn.cluster.BisectingKMeans)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BisectingKMeans](#sklearn.cluster.BisectingKMeans)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform X to a cluster-distance space.

In the new space, each dimension is the distance to the cluster
centers. Note that even if X is sparse, the array returned by
`transform` will typically be dense.

* **Parameters:**
  **X**
  : New data to transform.
* **Returns:**
  **X_new**
  : X transformed in the new space.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows differences between Regular K-Means algorithm and Bisecting K-Means.">  <div class="sphx-glr-thumbnail-title">Bisecting K-Means and Regular K-Means Performance Comparison</div>
</div>
* [Bisecting K-Means and Regular K-Means Performance Comparison](../../auto_examples/cluster/plot_bisect_kmeans.md#sphx-glr-auto-examples-cluster-plot-bisect-kmeans-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<!-- thumbnail-parent-div-close --></div>
