# load_sample_image

### sklearn.datasets.load_sample_image(image_name)

Load the numpy array of a single sample image.

Read more in the [User Guide](../../datasets/loading_other_datasets.md#sample-images).

* **Parameters:**
  **image_name**
  : The name of the sample image loaded.
* **Returns:**
  **img**
  : The image as a numpy array: height x width x color.

### Examples

```pycon
>>> from sklearn.datasets import load_sample_image
>>> china = load_sample_image('china.jpg')   
>>> china.dtype                              
dtype('uint8')
>>> china.shape                              
(427, 640, 3)
>>> flower = load_sample_image('flower.jpg') 
>>> flower.dtype                             
dtype('uint8')
>>> flower.shape                             
(427, 640, 3)
```

<!-- !! processed by numpydoc !! -->
