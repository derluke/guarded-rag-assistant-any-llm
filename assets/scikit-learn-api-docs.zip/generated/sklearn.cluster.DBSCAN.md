# DBSCAN

### *class* sklearn.cluster.DBSCAN(eps=0.5, \*, min_samples=5, metric='euclidean', metric_params=None, algorithm='auto', leaf_size=30, p=None, n_jobs=None)

Perform DBSCAN clustering from vector array or distance matrix.

DBSCAN - Density-Based Spatial Clustering of Applications with Noise.
Finds core samples of high density and expands clusters from them.
Good for data which contains clusters of similar density.

This implementation has a worst case memory complexity of $O({n}^2)$,
which can occur when the `eps` param is large and `min_samples` is low,
while the original DBSCAN only uses linear memory.
For further details, see the Notes below.

Read more in the [User Guide](../clustering.md#dbscan).

* **Parameters:**
  **eps**
  : The maximum distance between two samples for one to be considered
    as in the neighborhood of the other. This is not a maximum bound
    on the distances of points within a cluster. This is the most
    important DBSCAN parameter to choose appropriately for your data set
    and distance function.

  **min_samples**
  : The number of samples (or total weight) in a neighborhood for a point to
    be considered as a core point. This includes the point itself. If
    `min_samples` is set to a higher value, DBSCAN will find denser clusters,
    whereas if it is set to a lower value, the found clusters will be more
    sparse.

  **metric**
  : The metric to use when calculating distance between instances in a
    feature array. If metric is a string or callable, it must be one of
    the options allowed by [`sklearn.metrics.pairwise_distances`](sklearn.metrics.pairwise_distances.md#sklearn.metrics.pairwise_distances) for
    its metric parameter.
    If metric is “precomputed”, X is assumed to be a distance matrix and
    must be square. X may be a [sparse graph](../../glossary.md#term-sparse-graph), in which
    case only “nonzero” elements may be considered neighbors for DBSCAN.
    <br/>
    #### Versionadded
    Added in version 0.17: metric *precomputed* to accept precomputed sparse matrix.

  **metric_params**
  : Additional keyword arguments for the metric function.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **algorithm**
  : The algorithm to be used by the NearestNeighbors module
    to compute pointwise distances and find nearest neighbors.
    See NearestNeighbors module documentation for details.

  **leaf_size**
  : Leaf size passed to BallTree or cKDTree. This can affect the speed
    of the construction and query, as well as the memory required
    to store the tree. The optimal value depends
    on the nature of the problem.

  **p**
  : The power of the Minkowski metric to be used to calculate distance
    between points. If None, then `p=2` (equivalent to the Euclidean
    distance).

  **n_jobs**
  : The number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **core_sample_indices_**
  : Indices of core samples.

  **components_**
  : Copy of each core sample found by training.

  **labels_**
  : Cluster labels for each point in the dataset given to fit().
    Noisy samples are given the label -1.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`OPTICS`](sklearn.cluster.OPTICS.md#sklearn.cluster.OPTICS)
: A similar clustering at multiple values of eps. Our implementation is optimized for memory usage.

### Notes

For an example, see
[Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py).

This implementation bulk-computes all neighborhood queries, which increases
the memory complexity to O(n.d) where d is the average number of neighbors,
while original DBSCAN had memory complexity O(n). It may attract a higher
memory complexity when querying these nearest neighborhoods, depending
on the `algorithm`.

One way to avoid the query complexity is to pre-compute sparse
neighborhoods in chunks using
[`NearestNeighbors.radius_neighbors_graph`](sklearn.neighbors.NearestNeighbors.md#sklearn.neighbors.NearestNeighbors.radius_neighbors_graph) with
`mode='distance'`, then using `metric='precomputed'` here.

Another way to reduce memory and computation time is to remove
(near-)duplicate points and use `sample_weight` instead.

[`OPTICS`](sklearn.cluster.OPTICS.md#sklearn.cluster.OPTICS) provides a similar clustering with lower memory
usage.

### References

Ester, M., H. P. Kriegel, J. Sander, and X. Xu, [“A Density-Based
Algorithm for Discovering Clusters in Large Spatial Databases with Noise”](https://www.dbs.ifi.lmu.de/Publikationen/Papers/KDD-96.final.frame.pdf).
In: Proceedings of the 2nd International Conference on Knowledge Discovery
and Data Mining, Portland, OR, AAAI Press, pp. 226-231. 1996

Schubert, E., Sander, J., Ester, M., Kriegel, H. P., & Xu, X. (2017).
[“DBSCAN revisited, revisited: why and how you should (still) use DBSCAN.”](https://doi.org/10.1145/3068335)
ACM Transactions on Database Systems (TODS), 42(3), 19.

### Examples

```pycon
>>> from sklearn.cluster import DBSCAN
>>> import numpy as np
>>> X = np.array([[1, 2], [2, 2], [2, 3],
...               [8, 7], [8, 8], [25, 80]])
>>> clustering = DBSCAN(eps=3, min_samples=2).fit(X)
>>> clustering.labels_
array([ 0,  0,  0,  1,  1, -1])
>>> clustering
DBSCAN(eps=3, min_samples=2)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Perform DBSCAN clustering from features, or distance matrix.

* **Parameters:**
  **X**
  : Training instances to cluster, or distances between instances if
    `metric='precomputed'`. If a sparse matrix is provided, it will
    be converted into a sparse `csr_matrix`.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : Weight of each sample, such that a sample with a weight of at least
    `min_samples` is by itself a core sample; a sample with a
    negative weight may inhibit its eps-neighbor from being core.
    Note that weights are absolute, and default to 1.
* **Returns:**
  **self**
  : Returns a fitted instance of self.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None, sample_weight=None)

Compute clusters from a data or distance matrix and predict labels.

* **Parameters:**
  **X**
  : Training instances to cluster, or distances between instances if
    `metric='precomputed'`. If a sparse matrix is provided, it will
    be converted into a sparse `csr_matrix`.

  **y**
  : Not used, present here for API consistency by convention.

  **sample_weight**
  : Weight of each sample, such that a sample with a weight of at least
    `min_samples` is by itself a core sample; a sample with a
    negative weight may inhibit its eps-neighbor from being core.
    Note that weights are absolute, and default to 1.
* **Returns:**
  **labels**
  : Cluster labels. Noisy samples are given the label -1.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [DBSCAN](#sklearn.cluster.DBSCAN)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="DBSCAN (Density-Based Spatial Clustering of Applications with Noise) finds core samples in regions of high density and expands clusters from them. This algorithm is good for data which contains clusters of similar density.">  <div class="sphx-glr-thumbnail-title">Demo of DBSCAN clustering algorithm</div>
</div>
* [Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this demo we will take a look at cluster.HDBSCAN from the perspective of generalizing the cluster.DBSCAN algorithm. We&#x27;ll compare both algorithms on specific datasets. Finally we&#x27;ll evaluate HDBSCAN&#x27;s sensitivity to certain hyperparameters.">  <div class="sphx-glr-thumbnail-title">Demo of HDBSCAN clustering algorithm</div>
</div>
* [Demo of HDBSCAN clustering algorithm](../../auto_examples/cluster/plot_hdbscan.md#sphx-glr-auto-examples-cluster-plot-hdbscan-py)

<!-- thumbnail-parent-div-close --></div>
