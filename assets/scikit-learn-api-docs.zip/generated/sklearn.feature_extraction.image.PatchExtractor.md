# PatchExtractor

### *class* sklearn.feature_extraction.image.PatchExtractor(\*, patch_size=None, max_patches=None, random_state=None)

Extracts patches from a collection of images.

Read more in the [User Guide](../feature_extraction.md#image-feature-extraction).

#### Versionadded
Added in version 0.9.

* **Parameters:**
  **patch_size**
  : The dimensions of one patch. If set to None, the patch size will be
    automatically set to `(img_height // 10, img_width // 10)`, where
    `img_height` and `img_width` are the dimensions of the input images.

  **max_patches**
  : The maximum number of patches per image to extract. If `max_patches` is
    a float in (0, 1), it is taken to mean a proportion of the total number
    of patches. If set to None, extract all possible patches.

  **random_state**
  : Determines the random number generator used for random sampling when
    `max_patches is not None`. Use an int to make the randomness
    deterministic.
    See [Glossary](../../glossary.md#term-random_state).

#### SEE ALSO
[`reconstruct_from_patches_2d`](sklearn.feature_extraction.image.reconstruct_from_patches_2d.md#sklearn.feature_extraction.image.reconstruct_from_patches_2d)
: Reconstruct image from all of its patches.

### Notes

This estimator is stateless and does not need to be fitted. However, we
recommend to call [`fit_transform`](#sklearn.feature_extraction.image.PatchExtractor.fit_transform) instead of [`transform`](#sklearn.feature_extraction.image.PatchExtractor.transform), as
parameter validation is only performed in [`fit`](#sklearn.feature_extraction.image.PatchExtractor.fit).

### Examples

```pycon
>>> from sklearn.datasets import load_sample_images
>>> from sklearn.feature_extraction import image
>>> # Use the array data from the second image in this dataset:
>>> X = load_sample_images().images[1]
>>> X = X[None, ...]
>>> print(f"Image shape: {X.shape}")
Image shape: (1, 427, 640, 3)
>>> pe = image.PatchExtractor(patch_size=(10, 10))
>>> pe_trans = pe.transform(X)
>>> print(f"Patches shape: {pe_trans.shape}")
Patches shape: (263758, 10, 10, 3)
>>> X_reconstructed = image.reconstruct_from_patches_2d(pe_trans, X.shape[1:])
>>> print(f"Reconstructed shape: {X_reconstructed.shape}")
Reconstructed shape: (427, 640, 3)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Only validate the parameters of the estimator.

This method allows to: (i) validate the parameters of the estimator  and
(ii) be consistent with the scikit-learn transformer API.

* **Parameters:**
  **X**
  : Array of images from which to extract patches. For color images,
    the last dimension specifies the channel: a RGB image would have
    `n_channels=3`.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform the image samples in `X` into a matrix of patch data.

* **Parameters:**
  **X**
  : Array of images from which to extract patches. For color images,
    the last dimension specifies the channel: a RGB image would have
    `n_channels=3`.
* **Returns:**
  **patches**
  : The collection of patches extracted from the images, where
    `n_patches` is either `n_samples * max_patches` or the total
    number of patches that can be extracted.

<!-- !! processed by numpydoc !! -->
