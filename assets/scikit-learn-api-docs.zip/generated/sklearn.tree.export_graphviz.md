# export_graphviz

### sklearn.tree.export_graphviz(decision_tree, out_file=None, \*, max_depth=None, feature_names=None, class_names=None, label='all', filled=False, leaves_parallel=False, impurity=True, node_ids=False, proportion=False, rotate=False, rounded=False, special_characters=False, precision=3, fontname='helvetica')

Export a decision tree in DOT format.

This function generates a GraphViz representation of the decision tree,
which is then written into `out_file`. Once exported, graphical renderings
can be generated using, for example:

```default
$ dot -Tps tree.dot -o tree.ps      (PostScript format)
$ dot -Tpng tree.dot -o tree.png    (PNG format)
```

The sample counts that are shown are weighted with any sample_weights that
might be present.

Read more in the [User Guide](../tree.md#tree).

* **Parameters:**
  **decision_tree**
  : The decision tree estimator to be exported to GraphViz.

  **out_file**
  : Handle or name of the output file. If `None`, the result is
    returned as a string.
    <br/>
    #### Versionchanged
    Changed in version 0.20: Default of out_file changed from “tree.dot” to None.

  **max_depth**
  : The maximum depth of the representation. If None, the tree is fully
    generated.

  **feature_names**
  : An array containing the feature names.
    If None, generic names will be used (“x[0]”, “x[1]”, …).

  **class_names**
  : Names of each of the target classes in ascending numerical order.
    Only relevant for classification and not supported for multi-output.
    If `True`, shows a symbolic representation of the class name.

  **label**
  : Whether to show informative labels for impurity, etc.
    Options include ‘all’ to show at every node, ‘root’ to show only at
    the top root node, or ‘none’ to not show at any node.

  **filled**
  : When set to `True`, paint nodes to indicate majority class for
    classification, extremity of values for regression, or purity of node
    for multi-output.

  **leaves_parallel**
  : When set to `True`, draw all leaf nodes at the bottom of the tree.

  **impurity**
  : When set to `True`, show the impurity at each node.

  **node_ids**
  : When set to `True`, show the ID number on each node.

  **proportion**
  : When set to `True`, change the display of ‘values’ and/or ‘samples’
    to be proportions and percentages respectively.

  **rotate**
  : When set to `True`, orient tree left to right rather than top-down.

  **rounded**
  : When set to `True`, draw node boxes with rounded corners.

  **special_characters**
  : When set to `False`, ignore special characters for PostScript
    compatibility.

  **precision**
  : Number of digits of precision for floating point in the values of
    impurity, threshold and value attributes of each node.

  **fontname**
  : Name of font used to render text.
* **Returns:**
  **dot_data**
  : String representation of the input tree in GraphViz dot format.
    Only returned if `out_file` is None.
    <br/>
    #### Versionadded
    Added in version 0.18.

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn import tree
```

```pycon
>>> clf = tree.DecisionTreeClassifier()
>>> iris = load_iris()
```

```pycon
>>> clf = clf.fit(iris.data, iris.target)
>>> tree.export_graphviz(clf)
'digraph Tree {...
```

<!-- !! processed by numpydoc !! -->
