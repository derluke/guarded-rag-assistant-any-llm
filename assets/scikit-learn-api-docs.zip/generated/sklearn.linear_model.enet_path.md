# enet_path

### sklearn.linear_model.enet_path(X, y, \*, l1_ratio=0.5, eps=0.001, n_alphas=100, alphas=None, precompute='auto', Xy=None, copy_X=True, coef_init=None, verbose=False, return_n_iter=False, positive=False, check_input=True, \*\*params)

Compute elastic net path with coordinate descent.

The elastic net optimization function varies for mono and multi-outputs.

For mono-output tasks it is:

```default
1 / (2 * n_samples) * ||y - Xw||^2_2
+ alpha * l1_ratio * ||w||_1
+ 0.5 * alpha * (1 - l1_ratio) * ||w||^2_2
```

For multi-output tasks it is:

```default
(1 / (2 * n_samples)) * ||Y - XW||_Fro^2
+ alpha * l1_ratio * ||W||_21
+ 0.5 * alpha * (1 - l1_ratio) * ||W||_Fro^2
```

Where:

```default
||W||_21 = \sum_i \sqrt{\sum_j w_{ij}^2}
```

i.e. the sum of norm of each row.

Read more in the [User Guide](../linear_model.md#elastic-net).

* **Parameters:**
  **X**
  : Training data. Pass directly as Fortran-contiguous data to avoid
    unnecessary memory duplication. If `y` is mono-output then `X`
    can be sparse.

  **y**
  : Target values.

  **l1_ratio**
  : Number between 0 and 1 passed to elastic net (scaling between
    l1 and l2 penalties). `l1_ratio=1` corresponds to the Lasso.

  **eps**
  : Length of the path. `eps=1e-3` means that
    `alpha_min / alpha_max = 1e-3`.

  **n_alphas**
  : Number of alphas along the regularization path.

  **alphas**
  : List of alphas where to compute the models.
    If None alphas are set automatically.

  **precompute**
  : Whether to use a precomputed Gram matrix to speed up
    calculations. If set to `'auto'` let us decide. The Gram
    matrix can also be passed as argument.

  **Xy**
  : Xy = np.dot(X.T, y) that can be precomputed. It is useful
    only when the Gram matrix is precomputed.

  **copy_X**
  : If `True`, X will be copied; else, it may be overwritten.

  **coef_init**
  : The initial values of the coefficients.

  **verbose**
  : Amount of verbosity.

  **return_n_iter**
  : Whether to return the number of iterations or not.

  **positive**
  : If set to True, forces coefficients to be positive.
    (Only allowed when `y.ndim == 1`).

  **check_input**
  : If set to False, the input validation checks are skipped (including the
    Gram matrix when provided). It is assumed that they are handled
    by the caller.

  **\*\*params**
  : Keyword arguments passed to the coordinate descent solver.
* **Returns:**
  **alphas**
  : The alphas along the path where models are computed.

  **coefs**
  : Coefficients along the path.

  **dual_gaps**
  : The dual gaps at the end of the optimization for each alpha.

  **n_iters**
  : The number of iterations taken by the coordinate descent optimizer to
    reach the specified tolerance for each alpha.
    (Is returned when `return_n_iter` is set to True).

#### SEE ALSO
[`MultiTaskElasticNet`](sklearn.linear_model.MultiTaskElasticNet.md#sklearn.linear_model.MultiTaskElasticNet)
: Multi-task ElasticNet model trained with L1/L2 mixed-norm     as regularizer.

[`MultiTaskElasticNetCV`](sklearn.linear_model.MultiTaskElasticNetCV.md#sklearn.linear_model.MultiTaskElasticNetCV)
: Multi-task L1/L2 ElasticNet with built-in cross-validation.

[`ElasticNet`](sklearn.linear_model.ElasticNet.md#sklearn.linear_model.ElasticNet)
: Linear regression with combined L1 and L2 priors as regularizer.

[`ElasticNetCV`](sklearn.linear_model.ElasticNetCV.md#sklearn.linear_model.ElasticNetCV)
: Elastic Net model with iterative fitting along a regularization path.

### Notes

For an example, see
[examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.py](../../auto_examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.md#sphx-glr-auto-examples-linear-model-plot-lasso-lasso-lars-elasticnet-path-py).

### Examples

```pycon
>>> from sklearn.linear_model import enet_path
>>> from sklearn.datasets import make_regression
>>> X, y, true_coef = make_regression(
...    n_samples=100, n_features=5, n_informative=2, coef=True, random_state=0
... )
>>> true_coef
array([ 0.        ,  0.        ,  0.        , 97.9..., 45.7...])
>>> alphas, estimated_coef, _ = enet_path(X, y, n_alphas=3)
>>> alphas.shape
(3,)
>>> estimated_coef
 array([[ 0.        ,  0.78...,  0.56...],
        [ 0.        ,  1.12...,  0.61...],
        [-0.        , -2.12..., -1.12...],
        [ 0.        , 23.04..., 88.93...],
        [ 0.        , 10.63..., 41.56...]])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows how to compute the &quot;paths&quot; of coefficients along the Lasso, Lasso-LARS, and Elastic Net regularization paths. In other words, it shows the relationship between the regularization parameter (alpha) and the coefficients.">  <div class="sphx-glr-thumbnail-title">Lasso, Lasso-LARS, and Elastic Net paths</div>
</div>
* [Lasso, Lasso-LARS, and Elastic Net paths](../../auto_examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.md#sphx-glr-auto-examples-linear-model-plot-lasso-lasso-lars-elasticnet-path-py)

<!-- thumbnail-parent-div-close --></div>
