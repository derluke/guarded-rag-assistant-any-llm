# permutation_test_score

### sklearn.model_selection.permutation_test_score(estimator, X, y, \*, groups=None, cv=None, n_permutations=100, n_jobs=None, random_state=0, verbose=0, scoring=None, fit_params=None, params=None)

Evaluate the significance of a cross-validated score with permutations.

Permutes targets to generate ‘randomized data’ and compute the empirical
p-value against the null hypothesis that features and targets are
independent.

The p-value represents the fraction of randomized data sets where the
estimator performed as well or better than in the original data. A small
p-value suggests that there is a real dependency between features and
targets which has been used by the estimator to give good predictions.
A large p-value may be due to lack of real dependency between features
and targets or the estimator was not able to use the dependency to
give good predictions.

Read more in the [User Guide](../cross_validation.md#permutation-test-score).

* **Parameters:**
  **estimator**
  : The object to use to fit the data.

  **X**
  : The data to fit.

  **y**
  : The target variable to try to predict in the case of
    supervised learning.

  **groups**
  : Labels to constrain permutation within groups, i.e. `y` values
    are permuted among samples with the same group identifier.
    When not specified, `y` values are permuted among all samples.
    <br/>
    When a grouped cross-validator is used, the group labels are
    also passed on to the `split` method of the cross-validator. The
    cross-validator uses them for grouping the samples  while splitting
    the dataset into train/test set.
    <br/>
    #### Versionchanged
    Changed in version 1.6: `groups` can only be passed if metadata routing is not enabled
    via `sklearn.set_config(enable_metadata_routing=True)`. When routing
    is enabled, pass `groups` alongside other metadata via the `params`
    argument instead. E.g.:
    `permutation_test_score(..., params={'groups': groups})`.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - `None`, to use the default 5-fold cross validation,
    - int, to specify the number of folds in a `(Stratified)KFold`,
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For `int`/`None` inputs, if the estimator is a classifier and `y` is
    either binary or multiclass, [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. In all
    other cases, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used. These splitters are instantiated
    with `shuffle=False` so the splits will be the same across calls.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value if `None` changed from 3-fold to 5-fold.

  **n_permutations**
  : Number of times to permute `y`.

  **n_jobs**
  : Number of jobs to run in parallel. Training the estimator and computing
    the cross-validated score are parallelized over the permutations.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **random_state**
  : Pass an int for reproducible output for permutation of
    `y` values among samples. See [Glossary](../../glossary.md#term-random_state).

  **verbose**
  : The verbosity level.

  **scoring**
  : A single str (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter)) or a callable
    (see [Callable scorers](../model_evaluation.md#scoring-callable)) to evaluate the predictions on the test set.
    <br/>
    If `None` the estimator’s score method is used.

  **fit_params**
  : Parameters to pass to the fit method of the estimator.
    <br/>
    #### Deprecated
    Deprecated since version 1.6: This parameter is deprecated and will be removed in version 1.6. Use
    `params` instead.

  **params**
  : Parameters to pass to the `fit` method of the estimator, the scorer
    and the cv splitter.
    - If `enable_metadata_routing=False` (default): Parameters directly passed to
      the `fit` method of the estimator.
    - If `enable_metadata_routing=True`: Parameters safely routed to the `fit`
      method of the estimator, `cv` object and `scorer`. See [Metadata Routing
      User Guide](../../metadata_routing.md#metadata-routing) for more details.
    <br/>
    #### Versionadded
    Added in version 1.6.
* **Returns:**
  **score**
  : The true score without permuting targets.

  **permutation_scores**
  : The scores obtained for each permutations.

  **pvalue**
  : The p-value, which approximates the probability that the score would
    be obtained by chance. This is calculated as:
    <br/>
    `(C + 1) / (n_permutations + 1)`
    <br/>
    Where C is the number of permutations whose score >= the true score.
    <br/>
    The best possible p-value is 1/(n_permutations + 1), the worst is 1.0.

### Notes

This function implements Test 1 in:

Ojala and Garriga. [Permutation Tests for Studying Classifier Performance](http://www.jmlr.org/papers/volume11/ojala10a/ojala10a.pdf). The
Journal of Machine Learning Research (2010) vol. 11

### Examples

```pycon
>>> from sklearn.datasets import make_classification
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.model_selection import permutation_test_score
>>> X, y = make_classification(random_state=0)
>>> estimator = LogisticRegression()
>>> score, permutation_scores, pvalue = permutation_test_score(
...     estimator, X, y, random_state=0
... )
>>> print(f"Original Score: {score:.3f}")
Original Score: 0.810
>>> print(
...     f"Permutation Scores: {permutation_scores.mean():.3f} +/- "
...     f"{permutation_scores.std():.3f}"
... )
Permutation Scores: 0.505 +/- 0.057
>>> print(f"P-value: {pvalue:.3f}")
P-value: 0.010
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the use of permutation_test_score to evaluate the significance of a cross-validated score using permutations.">  <div class="sphx-glr-thumbnail-title">Test with permutations the significance of a classification score</div>
</div>
* [Test with permutations the significance of a classification score](../../auto_examples/model_selection/plot_permutation_tests_for_classification.md#sphx-glr-auto-examples-model-selection-plot-permutation-tests-for-classification-py)

<!-- thumbnail-parent-div-close --></div>
