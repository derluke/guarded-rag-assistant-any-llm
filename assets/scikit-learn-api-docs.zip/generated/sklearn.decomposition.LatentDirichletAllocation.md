# LatentDirichletAllocation

### *class* sklearn.decomposition.LatentDirichletAllocation(n_components=10, \*, doc_topic_prior=None, topic_word_prior=None, learning_method='batch', learning_decay=0.7, learning_offset=10.0, max_iter=10, batch_size=128, evaluate_every=-1, total_samples=1000000.0, perp_tol=0.1, mean_change_tol=0.001, max_doc_update_iter=100, n_jobs=None, verbose=0, random_state=None)

Latent Dirichlet Allocation with online variational Bayes algorithm.

The implementation is based on [[1]](#re25e5648fc37-1) and [[2]](#re25e5648fc37-2).

#### Versionadded
Added in version 0.17.

Read more in the [User Guide](../decomposition.md#latentdirichletallocation).

* **Parameters:**
  **n_components**
  : Number of topics.
    <br/>
    #### Versionchanged
    Changed in version 0.19: `n_topics` was renamed to `n_components`

  **doc_topic_prior**
  : Prior of document topic distribution `theta`. If the value is None,
    defaults to `1 / n_components`.
    In [[1]](#re25e5648fc37-1), this is called `alpha`.

  **topic_word_prior**
  : Prior of topic word distribution `beta`. If the value is None, defaults
    to `1 / n_components`.
    In [[1]](#re25e5648fc37-1), this is called `eta`.

  **learning_method**
  : Method used to update `_component`. Only used in [`fit`](#sklearn.decomposition.LatentDirichletAllocation.fit) method.
    In general, if the data size is large, the online update will be much
    faster than the batch update.
    <br/>
    Valid options:
    - ‘batch’: Batch variational Bayes method. Use all training data in each EM
      update. Old `components_` will be overwritten in each iteration.
    - ‘online’: Online variational Bayes method. In each EM update, use mini-batch
      of training data to update the `components_` variable incrementally. The
      learning rate is controlled by the `learning_decay` and the
      `learning_offset` parameters.
    <br/>
    #### Versionchanged
    Changed in version 0.20: The default learning method is now `"batch"`.

  **learning_decay**
  : It is a parameter that control learning rate in the online learning
    method. The value should be set between (0.5, 1.0] to guarantee
    asymptotic convergence. When the value is 0.0 and batch_size is
    `n_samples`, the update method is same as batch learning. In the
    literature, this is called kappa.

  **learning_offset**
  : A (positive) parameter that downweights early iterations in online
    learning.  It should be greater than 1.0. In the literature, this is
    called tau_0.

  **max_iter**
  : The maximum number of passes over the training data (aka epochs).
    It only impacts the behavior in the [`fit`](#sklearn.decomposition.LatentDirichletAllocation.fit) method, and not the
    [`partial_fit`](#sklearn.decomposition.LatentDirichletAllocation.partial_fit) method.

  **batch_size**
  : Number of documents to use in each EM iteration. Only used in online
    learning.

  **evaluate_every**
  : How often to evaluate perplexity. Only used in `fit` method.
    set it to 0 or negative number to not evaluate perplexity in
    training at all. Evaluating perplexity can help you check convergence
    in training process, but it will also increase total training time.
    Evaluating perplexity in every iteration might increase training time
    up to two-fold.

  **total_samples**
  : Total number of documents. Only used in the [`partial_fit`](#sklearn.decomposition.LatentDirichletAllocation.partial_fit) method.

  **perp_tol**
  : Perplexity tolerance. Only used when `evaluate_every` is greater than 0.

  **mean_change_tol**
  : Stopping tolerance for updating document topic distribution in E-step.

  **max_doc_update_iter**
  : Max number of iterations for updating document topic distribution in
    the E-step.

  **n_jobs**
  : The number of jobs to use in the E-step.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **verbose**
  : Verbosity level.

  **random_state**
  : Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **components_**
  : Variational parameters for topic word distribution. Since the complete
    conditional for topic word distribution is a Dirichlet,
    `components_[i, j]` can be viewed as pseudocount that represents the
    number of times word `j` was assigned to topic `i`.
    It can also be viewed as distribution over the words for each topic
    after normalization:
    `model.components_ / model.components_.sum(axis=1)[:, np.newaxis]`.

  **exp_dirichlet_component_**
  : Exponential value of expectation of log topic word distribution.
    In the literature, this is `exp(E[log(beta)])`.

  **n_batch_iter_**
  : Number of iterations of the EM step.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Number of passes over the dataset.

  **bound_**
  : Final perplexity score on training set.

  **doc_topic_prior_**
  : Prior of document topic distribution `theta`. If the value is None,
    it is `1 / n_components`.

  **random_state_**
  : RandomState instance that is generated either from a seed, the random
    number generator or by `np.random`.

  **topic_word_prior_**
  : Prior of topic word distribution `beta`. If the value is None, it is
    `1 / n_components`.

#### SEE ALSO
[`sklearn.discriminant_analysis.LinearDiscriminantAnalysis`](sklearn.discriminant_analysis.LinearDiscriminantAnalysis.md#sklearn.discriminant_analysis.LinearDiscriminantAnalysis)
: A classifier with a linear decision boundary, generated by fitting class conditional densities to the data and using Bayes’ rule.

### References

### Examples

```pycon
>>> from sklearn.decomposition import LatentDirichletAllocation
>>> from sklearn.datasets import make_multilabel_classification
>>> # This produces a feature matrix of token counts, similar to what
>>> # CountVectorizer would produce on text.
>>> X, _ = make_multilabel_classification(random_state=0)
>>> lda = LatentDirichletAllocation(n_components=5,
...     random_state=0)
>>> lda.fit(X)
LatentDirichletAllocation(...)
>>> # get topics for some given samples:
>>> lda.transform(X[-2:])
array([[0.00360392, 0.25499205, 0.0036211 , 0.64236448, 0.09541846],
       [0.15297572, 0.00362644, 0.44412786, 0.39568399, 0.003586  ]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Learn model for the data X with variational Bayes method.

When `learning_method` is ‘online’, use mini-batch update.
Otherwise, use batch update.

* **Parameters:**
  **X**
  : Document word matrix.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*, normalize=True)

Fit to data, then transform it.

Fits transformer to `X` and `y` and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **normalize**
  : Whether to normalize the document topic distribution in `transform`.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y=None)

Online VB with Mini-Batch update.

* **Parameters:**
  **X**
  : Document word matrix.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  self
  : Partially fitted estimator.

<!-- !! processed by numpydoc !! -->

#### perplexity(X, sub_sampling=False)

Calculate approximate perplexity for data X.

Perplexity is defined as exp(-1. \* log-likelihood per word)

#### Versionchanged
Changed in version 0.19: *doc_topic_distr* argument has been deprecated and is ignored
because user no longer has access to unnormalized distribution

* **Parameters:**
  **X**
  : Document word matrix.

  **sub_sampling**
  : Do sub-sampling or not.
* **Returns:**
  **score**
  : Perplexity score.

<!-- !! processed by numpydoc !! -->

#### score(X, y=None)

Calculate approximate log-likelihood as score.

* **Parameters:**
  **X**
  : Document word matrix.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **score**
  : Use approximate bound as score.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_transform_request(\*, normalize: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LatentDirichletAllocation](#sklearn.decomposition.LatentDirichletAllocation)

Request metadata passed to the `transform` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `transform` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `transform`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **normalize**
  : Metadata routing for `normalize` parameter in `transform`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### transform(X, \*, normalize=True)

Transform data X according to the fitted model.

#### Versionchanged
Changed in version 0.18: `doc_topic_distr` is now normalized.

* **Parameters:**
  **X**
  : Document word matrix.

  **normalize**
  : Whether to normalize the document topic distribution.
* **Returns:**
  **doc_topic_distr**
  : Document topic distribution for X.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This is an example of applying NMF and LatentDirichletAllocation on a corpus of documents and extract additive models of the topic structure of the corpus.  The output is a plot of topics, each represented as bar plot using top few words based on weights.">  <div class="sphx-glr-thumbnail-title">Topic extraction with Non-negative Matrix Factorization and Latent Dirichlet Allocation</div>
</div>
* [Topic extraction with Non-negative Matrix Factorization and Latent Dirichlet Allocation](../../auto_examples/applications/plot_topics_extraction_with_nmf_lda.md#sphx-glr-auto-examples-applications-plot-topics-extraction-with-nmf-lda-py)

<!-- thumbnail-parent-div-close --></div>
