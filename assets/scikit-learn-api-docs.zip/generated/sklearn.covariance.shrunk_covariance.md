# shrunk_covariance

### sklearn.covariance.shrunk_covariance(emp_cov, shrinkage=0.1)

Calculate covariance matrices shrunk on the diagonal.

Read more in the [User Guide](../covariance.md#shrunk-covariance).

* **Parameters:**
  **emp_cov**
  : Covariance matrices to be shrunk, at least 2D ndarray.

  **shrinkage**
  : Coefficient in the convex combination used for the computation
    of the shrunk estimate. Range is [0, 1].
* **Returns:**
  **shrunk_cov**
  : Shrunk covariance matrices.

### Notes

The regularized (shrunk) covariance is given by:

```default
(1 - shrinkage) * cov + shrinkage * mu * np.identity(n_features)
```

where `mu = trace(cov) / n_features`.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.datasets import make_gaussian_quantiles
>>> from sklearn.covariance import empirical_covariance, shrunk_covariance
>>> real_cov = np.array([[.8, .3], [.3, .4]])
>>> rng = np.random.RandomState(0)
>>> X = rng.multivariate_normal(mean=[0, 0], cov=real_cov, size=500)
>>> shrunk_covariance(empirical_covariance(X))
array([[0.73..., 0.25...],
       [0.25..., 0.41...]])
```

<!-- !! processed by numpydoc !! -->
