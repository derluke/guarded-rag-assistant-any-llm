# fetch_kddcup99

### sklearn.datasets.fetch_kddcup99(\*, subset=None, data_home=None, shuffle=False, random_state=None, percent10=True, download_if_missing=True, return_X_y=False, as_frame=False, n_retries=3, delay=1.0)

Load the kddcup99 dataset (classification).

Download it if necessary.

| Classes        | 23                                   |
|----------------|--------------------------------------|
| Samples total  | 4898431                              |
| Dimensionality | 41                                   |
| Features       | discrete (int) or continuous (float) |

Read more in the [User Guide](../../datasets/real_world.md#kddcup99-dataset).

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **subset**
  : To return the corresponding classical subsets of kddcup 99.
    If None, return the entire kddcup 99 dataset.

  **data_home**
  : Specify another download and cache folder for the datasets. By default
    all scikit-learn data is stored in ‘~/scikit_learn_data’ subfolders.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **shuffle**
  : Whether to shuffle dataset.

  **random_state**
  : Determines random number generation for dataset shuffling and for
    selection of abnormal samples if `subset='SA'`. Pass an int for
    reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **percent10**
  : Whether to load only 10 percent of the data.

  **download_if_missing**
  : If False, raise an OSError if the data is not locally available
    instead of trying to download the data from the source site.

  **return_X_y**
  : If True, returns `(data, target)` instead of a Bunch object. See
    below for more information about the `data` and `target` object.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **as_frame**
  : If `True`, returns a pandas Dataframe for the `data` and `target`
    objects in the `Bunch` returned object; `Bunch` return object will also
    have a `frame` member.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **n_retries**
  : Number of retries when HTTP errors are encountered.
    <br/>
    #### Versionadded
    Added in version 1.5.

  **delay**
  : Number of seconds between retries.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : The data matrix to learn. If `as_frame=True`, `data` will be a
      pandas DataFrame.
    <br/>
    target
    : The regression target for each sample. If `as_frame=True`, `target`
      will be a pandas Series.
    <br/>
    frame
    : Only present when `as_frame=True`. Contains `data` and `target`.
    <br/>
    DESCR
    : The full description of the dataset.
    <br/>
    feature_names
    : The names of the dataset columns
    <br/>
    target_names: list
    : The names of the target columns

  **(data, target)**
  : A tuple of two ndarray. The first containing a 2D array of
    shape (n_samples, n_features) with each row representing one
    sample and each column representing the features. The second
    ndarray of shape (n_samples,) containing the target samples.
    <br/>
    #### Versionadded
    Added in version 0.20.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<!-- thumbnail-parent-div-close --></div>
