# ConstantKernel

### *class* sklearn.gaussian_process.kernels.ConstantKernel(constant_value=1.0, constant_value_bounds=(1e-05, 100000.0))

Constant kernel.

Can be used as part of a product-kernel where it scales the magnitude of
the other factor (kernel) or as part of a sum-kernel, where it modifies
the mean of the Gaussian process.

$$
k(x_1, x_2) = constant\_value \;\forall\; x_1, x_2

$$

Adding a constant kernel is equivalent to adding a constant:

```default
kernel = RBF() + ConstantKernel(constant_value=2)
```

is the same as:

```default
kernel = RBF() + 2
```

Read more in the [User Guide](../gaussian_process.md#gp-kernels).

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **constant_value**
  : The constant value which defines the covariance:
    k(x_1, x_2) = constant_value

  **constant_value_bounds**
  : The lower and upper bound on `constant_value`.
    If set to “fixed”, `constant_value` cannot be changed during
    hyperparameter tuning.

### Examples

```pycon
>>> from sklearn.datasets import make_friedman2
>>> from sklearn.gaussian_process import GaussianProcessRegressor
>>> from sklearn.gaussian_process.kernels import RBF, ConstantKernel
>>> X, y = make_friedman2(n_samples=500, noise=0, random_state=0)
>>> kernel = RBF() + ConstantKernel(constant_value=2)
>>> gpr = GaussianProcessRegressor(kernel=kernel, alpha=5,
...         random_state=0).fit(X, y)
>>> gpr.score(X, y)
0.3696...
>>> gpr.predict(X[:1,:], return_std=True)
(array([606.1...]), array([0.24...]))
```

<!-- !! processed by numpydoc !! -->

#### \_\_call_\_(X, Y=None, eval_gradient=False)

Return the kernel k(X, Y) and optionally its gradient.

* **Parameters:**
  **X**
  : Left argument of the returned kernel k(X, Y)

  **Y**
  : Right argument of the returned kernel k(X, Y). If None, k(X, X)
    is evaluated instead.

  **eval_gradient**
  : Determines whether the gradient with respect to the log of
    the kernel hyperparameter is computed.
    Only supported when Y is None.
* **Returns:**
  **K**
  : Kernel k(X, Y)

  **K_gradient**
  : The gradient of the kernel k(X, X) with respect to the log of the
    hyperparameter of the kernel. Only returned when eval_gradient
    is True.

<!-- !! processed by numpydoc !! -->

#### *property* bounds

Returns the log-transformed bounds on the theta.

* **Returns:**
  **bounds**
  : The log-transformed bounds on the kernel’s hyperparameters theta

<!-- !! processed by numpydoc !! -->

#### clone_with_theta(theta)

Returns a clone of self with given hyperparameters theta.

* **Parameters:**
  **theta**
  : The hyperparameters

<!-- !! processed by numpydoc !! -->

#### diag(X)

Returns the diagonal of the kernel k(X, X).

The result of this method is identical to np.diag(self(X)); however,
it can be evaluated more efficiently since only the diagonal is
evaluated.

* **Parameters:**
  **X**
  : Argument to the kernel.
* **Returns:**
  **K_diag**
  : Diagonal of kernel k(X, X)

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters of this kernel.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* hyperparameters

Returns a list of all hyperparameter specifications.

<!-- !! processed by numpydoc !! -->

#### is_stationary()

Returns whether the kernel is stationary.

<!-- !! processed by numpydoc !! -->

#### *property* n_dims

Returns the number of non-fixed hyperparameters of the kernel.

<!-- !! processed by numpydoc !! -->

#### *property* requires_vector_input

Whether the kernel works only on fixed-length feature vectors.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this kernel.

The method works on simple kernels as well as on nested kernels.
The latter have parameters of the form `<component>__<parameter>`
so that it’s possible to update each component of a nested object.

* **Returns:**
  self

<!-- !! processed by numpydoc !! -->

#### *property* theta

Returns the (flattened, log-transformed) non-fixed hyperparameters.

Note that theta are typically the log-transformed values of the
kernel’s hyperparameters as this representation of the search space
is more amenable for hyperparameter search, as hyperparameters like
length-scales naturally live on a log-scale.

* **Returns:**
  **theta**
  : The non-fixed, log-transformed hyperparameters of the kernel

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the prior and posterior of a GaussianProcessRegressor with different kernels. Mean, standard deviation, and 5 samples are shown for both prior and posterior distributions.">  <div class="sphx-glr-thumbnail-title">Illustration of prior and posterior Gaussian process for different kernels</div>
</div>
* [Illustration of prior and posterior Gaussian process for different kernels](../../auto_examples/gaussian_process/plot_gpr_prior_posterior.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-prior-posterior-py)

<div class="sphx-glr-thumbcontainer" tooltip="A two-dimensional classification example showing iso-probability lines for the predicted probabilities.">  <div class="sphx-glr-thumbnail-title">Iso-probability lines for Gaussian Processes classification (GPC)</div>
</div>
* [Iso-probability lines for Gaussian Processes classification (GPC)](../../auto_examples/gaussian_process/plot_gpc_isoprobability.md#sphx-glr-auto-examples-gaussian-process-plot-gpc-isoprobability-py)

<!-- thumbnail-parent-div-close --></div>
