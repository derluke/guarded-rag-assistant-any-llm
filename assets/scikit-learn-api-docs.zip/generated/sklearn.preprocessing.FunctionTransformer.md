# FunctionTransformer

### *class* sklearn.preprocessing.FunctionTransformer(func=None, inverse_func=None, \*, validate=False, accept_sparse=False, check_inverse=True, feature_names_out=None, kw_args=None, inv_kw_args=None)

Constructs a transformer from an arbitrary callable.

A FunctionTransformer forwards its X (and optionally y) arguments to a
user-defined function or function object and returns the result of this
function. This is useful for stateless transformations such as taking the
log of frequencies, doing custom scaling, etc.

Note: If a lambda is used as the function, then the resulting
transformer will not be pickleable.

#### Versionadded
Added in version 0.17.

Read more in the [User Guide](../preprocessing.md#function-transformer).

* **Parameters:**
  **func**
  : The callable to use for the transformation. This will be passed
    the same arguments as transform, with args and kwargs forwarded.
    If func is None, then func will be the identity function.

  **inverse_func**
  : The callable to use for the inverse transformation. This will be
    passed the same arguments as inverse transform, with args and
    kwargs forwarded. If inverse_func is None, then inverse_func
    will be the identity function.

  **validate**
  : Indicate that the input X array should be checked before calling
    `func`. The possibilities are:
    - If False, there is no input validation.
    - If True, then X will be converted to a 2-dimensional NumPy array or
      sparse matrix. If the conversion is not possible an exception is
      raised.
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default of `validate` changed from True to False.

  **accept_sparse**
  : Indicate that func accepts a sparse matrix as input. If validate is
    False, this has no effect. Otherwise, if accept_sparse is false,
    sparse matrix inputs will cause an exception to be raised.

  **check_inverse**
  : Whether to check that or `func` followed by `inverse_func` leads to
    the original inputs. It can be used for a sanity check, raising a
    warning when the condition is not fulfilled.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **feature_names_out**
  : Determines the list of feature names that will be returned by the
    `get_feature_names_out` method. If it is ‘one-to-one’, then the output
    feature names will be equal to the input feature names. If it is a
    callable, then it must take two positional arguments: this
    `FunctionTransformer` (`self`) and an array-like of input feature names
    (`input_features`). It must return an array-like of output feature
    names. The `get_feature_names_out` method is only defined if
    `feature_names_out` is not None.
    <br/>
    See `get_feature_names_out` for more details.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **kw_args**
  : Dictionary of additional keyword arguments to pass to func.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **inv_kw_args**
  : Dictionary of additional keyword arguments to pass to inverse_func.
    <br/>
    #### Versionadded
    Added in version 0.18.
* **Attributes:**
  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X` has feature
    names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`MaxAbsScaler`](sklearn.preprocessing.MaxAbsScaler.md#sklearn.preprocessing.MaxAbsScaler)
: Scale each feature by its maximum absolute value.

[`StandardScaler`](sklearn.preprocessing.StandardScaler.md#sklearn.preprocessing.StandardScaler)
: Standardize features by removing the mean and scaling to unit variance.

[`LabelBinarizer`](sklearn.preprocessing.LabelBinarizer.md#sklearn.preprocessing.LabelBinarizer)
: Binarize labels in a one-vs-all fashion.

[`MultiLabelBinarizer`](sklearn.preprocessing.MultiLabelBinarizer.md#sklearn.preprocessing.MultiLabelBinarizer)
: Transform between iterable of iterables and a multilabel format.

### Notes

If `func` returns an output with a `columns` attribute, then the columns is enforced
to be consistent with the output of `get_feature_names_out`.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.preprocessing import FunctionTransformer
>>> transformer = FunctionTransformer(np.log1p)
>>> X = np.array([[0, 1], [2, 3]])
>>> transformer.transform(X)
array([[0.       , 0.6931...],
       [1.0986..., 1.3862...]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit transformer by checking X.

If `validate` is `True`, `X` will be checked.

* **Parameters:**
  **X**
  : Input array.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : FunctionTransformer class instance.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

This method is only defined if `feature_names_out` is not None.

* **Parameters:**
  **input_features**
  : Input feature names.
    - If `input_features` is None, then `feature_names_in_` is
      used as the input feature names. If `feature_names_in_` is not
      defined, then names are generated:
      `[x0, x1, ..., x(n_features_in_ - 1)]`.
    - If `input_features` is array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.
    - If `feature_names_out` is ‘one-to-one’, the input feature names
      are returned (see `input_features` above). This requires
      `feature_names_in_` and/or `n_features_in_` to be defined, which
      is done automatically if `validate=True`. Alternatively, you can
      set them in `func`.
    - If `feature_names_out` is a callable, then it is called with two
      arguments, `self` and `input_features`, and its return value is
      returned by this method.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Transform X using the inverse function.

* **Parameters:**
  **X**
  : Input array.
* **Returns:**
  **X_out**
  : Transformed input.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform X using the forward function.

* **Parameters:**
  **X**
  : Input array.
* **Returns:**
  **X_out**
  : Transformed input.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="Datasets can often contain components that require different feature extraction and processing pipelines. This scenario might occur when:">  <div class="sphx-glr-thumbnail-title">Column Transformer with Heterogeneous Data Sources</div>
</div>
* [Column Transformer with Heterogeneous Data Sources](../../auto_examples/compose/plot_column_transformer.md#sphx-glr-auto-examples-compose-plot-column-transformer-py)

<div class="sphx-glr-thumbcontainer" tooltip="Transform your features into a higher dimensional, sparse space. Then train a linear model on these features.">  <div class="sphx-glr-thumbnail-title">Feature transformations with ensembles of trees</div>
</div>
* [Feature transformations with ensembles of trees](../../auto_examples/ensemble/plot_feature_transformation.md#sphx-glr-auto-examples-ensemble-plot-feature-transformation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Poisson, Gamma and Tweedie regression on the French Motor Third-Party Liability Claims dataset, and is inspired by an R tutorial [1]_.">  <div class="sphx-glr-thumbnail-title">Tweedie regression on insurance claims</div>
</div>
* [Tweedie regression on insurance claims](../../auto_examples/linear_model/plot_tweedie_regression_insurance_claims.md#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, semi-supervised classifiers are trained on the 20 newsgroups dataset (which will be automatically downloaded).">  <div class="sphx-glr-thumbnail-title">Semi-supervised Classification on a Text Dataset</div>
</div>
* [Semi-supervised Classification on a Text Dataset](../../auto_examples/semi_supervised/plot_semi_supervised_newsgroups.md#sphx-glr-auto-examples-semi-supervised-plot-semi-supervised-newsgroups-py)

<!-- thumbnail-parent-div-close --></div>
