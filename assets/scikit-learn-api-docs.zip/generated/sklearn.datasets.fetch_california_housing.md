# fetch_california_housing

### sklearn.datasets.fetch_california_housing(\*, data_home=None, download_if_missing=True, return_X_y=False, as_frame=False, n_retries=3, delay=1.0)

Load the California housing dataset (regression).

| Samples total   | 20640          |
|-----------------|----------------|
| Dimensionality  | 8              |
| Features        | real           |
| Target          | real 0.15 - 5. |

Read more in the [User Guide](../../datasets/real_world.md#california-housing-dataset).

* **Parameters:**
  **data_home**
  : Specify another download and cache folder for the datasets. By default
    all scikit-learn data is stored in ‘~/scikit_learn_data’ subfolders.

  **download_if_missing**
  : If False, raise an OSError if the data is not locally available
    instead of trying to download the data from the source site.

  **return_X_y**
  : If True, returns `(data.data, data.target)` instead of a Bunch
    object.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **as_frame**
  : If True, the data is a pandas DataFrame including columns with
    appropriate dtypes (numeric, string or categorical). The target is
    a pandas DataFrame or Series depending on the number of target_columns.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **n_retries**
  : Number of retries when HTTP errors are encountered.
    <br/>
    #### Versionadded
    Added in version 1.5.

  **delay**
  : Number of seconds between retries.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **dataset**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : Each row corresponding to the 8 feature values in order.
      If `as_frame` is True, `data` is a pandas object.
    <br/>
    target
    : Each value corresponds to the average
      house value in units of 100,000.
      If `as_frame` is True, `target` is a pandas object.
    <br/>
    feature_names
    : Array of ordered feature names used in the dataset.
    <br/>
    DESCR
    : Description of the California housing dataset.
    <br/>
    frame
    : Only present when `as_frame=True`. DataFrame with `data` and
      `target`.
      <br/>
      #### Versionadded
      Added in version 0.23.

  **(data, target)**
  : A tuple of two ndarray. The first containing a 2D array of
    shape (n_samples, n_features) with each row representing one
    sample and each column representing the features. The second
    ndarray of shape (n_samples,) containing the target samples.
    <br/>
    #### Versionadded
    Added in version 0.20.

### Notes

This dataset consists of 20,640 samples and 9 features.

### Examples

```pycon
>>> from sklearn.datasets import fetch_california_housing
>>> housing = fetch_california_housing()
>>> print(housing.data.shape, housing.target.shape)
(20640, 8) (20640,)
>>> print(housing.feature_names[0:6])
['MedInc', 'HouseAge', 'AveRooms', 'AveBedrms', 'Population', 'AveOccup']
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the performance of Random Forest (RF) and Histogram Gradient Boosting (HGBT) models in terms of score and computation time for a regression dataset, though all the concepts here presented apply to classification as well.">  <div class="sphx-glr-thumbnail-title">Comparing Random Forests and Histogram Gradient Boosting models</div>
</div>
* [Comparing Random Forests and Histogram Gradient Boosting models](../../auto_examples/ensemble/plot_forest_hist_grad_boosting_comparison.md#sphx-glr-auto-examples-ensemble-plot-forest-hist-grad-boosting-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Gradient Boosting is an ensemble technique that combines multiple weak learners, typically decision trees, to create a robust and powerful predictive model. It does so in an iterative fashion, where each new stage (tree) corrects the errors of the previous ones.">  <div class="sphx-glr-thumbnail-title">Early stopping in Gradient Boosting</div>
</div>
* [Early stopping in Gradient Boosting](../../auto_examples/ensemble/plot_gradient_boosting_early_stopping.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-early-stopping-py)

<div class="sphx-glr-thumbcontainer" tooltip="Missing values can be replaced by the mean, the median or the most frequent value using the basic SimpleImputer.">  <div class="sphx-glr-thumbnail-title">Imputing missing values before building an estimator</div>
</div>
* [Imputing missing values before building an estimator](../../auto_examples/impute/plot_missing_values.md#sphx-glr-auto-examples-impute-plot-missing-values-py)

<div class="sphx-glr-thumbcontainer" tooltip="The IterativeImputer class is very flexible - it can be used with a variety of estimators to do round-robin regression, treating every variable as an output in turn.">  <div class="sphx-glr-thumbnail-title">Imputing missing values with variants of IterativeImputer</div>
</div>
* [Imputing missing values with variants of IterativeImputer](../../auto_examples/impute/plot_iterative_imputer_variants_comparison.md#sphx-glr-auto-examples-impute-plot-iterative-imputer-variants-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature 0 (median income in a block) and feature 5 (average house occupancy) of the california_housing_dataset have very different scales and contain some very large outliers. These two characteristics lead to difficulties to visualize the data and, more importantly, they can degrade the predictive performance of many machine learning algorithms. Unscaled data can also slow down or even prevent the convergence of many gradient-based estimators.">  <div class="sphx-glr-thumbnail-title">Compare the effect of different scalers on data with outliers</div>
</div>
* [Compare the effect of different scalers on data with outliers](../../auto_examples/preprocessing/plot_all_scaling.md#sphx-glr-auto-examples-preprocessing-plot-all-scaling-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
