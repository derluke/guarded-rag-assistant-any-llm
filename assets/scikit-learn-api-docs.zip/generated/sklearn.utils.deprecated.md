# deprecated

### *class* sklearn.utils.deprecated(extra='')

Decorator to mark a function or class as deprecated.

Issue a warning when the function is called/the class is instantiated and
adds a warning to the docstring.

The optional extra argument will be appended to the deprecation message
and the docstring. Note: to use this with the default value for extra, put
in an empty of parentheses:

* **Parameters:**
  **extra**
  : To be added to the deprecation messages.

### Examples

```pycon
>>> from sklearn.utils import deprecated
>>> deprecated()
<sklearn.utils.deprecation.deprecated object at ...>
>>> @deprecated()
... def some_function(): pass
```

<!-- !! processed by numpydoc !! -->

#### \_\_call_\_(obj)

Call method

* **Parameters:**
  **obj**

<!-- !! processed by numpydoc !! -->
