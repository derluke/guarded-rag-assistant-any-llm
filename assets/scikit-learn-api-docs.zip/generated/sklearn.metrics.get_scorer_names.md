# get_scorer_names

### sklearn.metrics.get_scorer_names()

Get the names of all available scorers.

These names can be passed to [`get_scorer`](sklearn.metrics.get_scorer.md#sklearn.metrics.get_scorer) to
retrieve the scorer object.

* **Returns:**
  list of str
  : Names of all available scorers.

### Examples

```pycon
>>> from sklearn.metrics import get_scorer_names
>>> all_scorers = get_scorer_names()
>>> type(all_scorers)
<class 'list'>
>>> all_scorers[:3]
['accuracy', 'adjusted_mutual_info_score', 'adjusted_rand_score']
>>> "roc_auc" in all_scorers
True
```

<!-- !! processed by numpydoc !! -->
