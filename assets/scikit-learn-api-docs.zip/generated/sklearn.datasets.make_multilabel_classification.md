# make_multilabel_classification

### sklearn.datasets.make_multilabel_classification(n_samples=100, n_features=20, \*, n_classes=5, n_labels=2, length=50, allow_unlabeled=True, sparse=False, return_indicator='dense', return_distributions=False, random_state=None)

Generate a random multilabel classification problem.

For each sample, the generative process is:
: - pick the number of labels: n ~ Poisson(n_labels)
  - n times, choose a class c: c ~ Multinomial(theta)
  - pick the document length: k ~ Poisson(length)
  - k times, choose a word: w ~ Multinomial(theta_c)

In the above process, rejection sampling is used to make sure that
n is never zero or more than `n_classes`, and that the document length
is never zero. Likewise, we reject classes which have already been chosen.

For an example of usage, see
[Plot randomly generated multilabel dataset](../../auto_examples/datasets/plot_random_multilabel_dataset.md#sphx-glr-auto-examples-datasets-plot-random-multilabel-dataset-py).

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **n_samples**
  : The number of samples.

  **n_features**
  : The total number of features.

  **n_classes**
  : The number of classes of the classification problem.

  **n_labels**
  : The average number of labels per instance. More precisely, the number
    of labels per sample is drawn from a Poisson distribution with
    `n_labels` as its expected value, but samples are bounded (using
    rejection sampling) by `n_classes`, and must be nonzero if
    `allow_unlabeled` is False.

  **length**
  : The sum of the features (number of words if documents) is drawn from
    a Poisson distribution with this expected value.

  **allow_unlabeled**
  : If `True`, some instances might not belong to any class.

  **sparse**
  : If `True`, return a sparse feature matrix.
    <br/>
    #### Versionadded
    Added in version 0.17: parameter to allow *sparse* output.

  **return_indicator**
  : If `'dense'` return `Y` in the dense binary indicator format. If
    `'sparse'` return `Y` in the sparse binary indicator format.
    `False` returns a list of lists of labels.

  **return_distributions**
  : If `True`, return the prior class probability and conditional
    probabilities of features given classes, from which the data was
    drawn.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : The generated samples.

  **Y**
  : The label sets. Sparse matrix should be of CSR format.

  **p_c**
  : The probability of each class being drawn. Only returned if
    `return_distributions=True`.

  **p_w_c**
  : The probability of each feature being drawn given each class.
    Only returned if `return_distributions=True`.

### Examples

```pycon
>>> from sklearn.datasets import make_multilabel_classification
>>> X, y = make_multilabel_classification(n_labels=3, random_state=42)
>>> X.shape
(100, 20)
>>> y.shape
(100, 5)
>>> list(y[:3])
[array([1, 1, 0, 1, 0]), array([0, 1, 1, 1, 0]), array([0, 1, 0, 0, 0])]
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This illustrates the make_multilabel_classification dataset generator. Each sample consists of counts of two features (up to 50 in total), which are differently distributed in each of two classes.">  <div class="sphx-glr-thumbnail-title">Plot randomly generated multilabel dataset</div>
</div>
* [Plot randomly generated multilabel dataset](../../auto_examples/datasets/plot_random_multilabel_dataset.md#sphx-glr-auto-examples-datasets-plot-random-multilabel-dataset-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example simulates a multi-label document classification problem. The dataset is generated randomly based on the following process:">  <div class="sphx-glr-thumbnail-title">Multilabel classification</div>
</div>
* [Multilabel classification](../../auto_examples/miscellaneous/plot_multilabel.md#sphx-glr-auto-examples-miscellaneous-plot-multilabel-py)

<!-- thumbnail-parent-div-close --></div>
