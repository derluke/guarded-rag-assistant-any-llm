# sort_graph_by_row_values

### sklearn.neighbors.sort_graph_by_row_values(graph, copy=False, warn_when_not_sorted=True)

Sort a sparse graph such that each row is stored with increasing values.

#### Versionadded
Added in version 1.2.

* **Parameters:**
  **graph**
  : Distance matrix to other samples, where only non-zero elements are
    considered neighbors. Matrix is converted to CSR format if not already.

  **copy**
  : If True, the graph is copied before sorting. If False, the sorting is
    performed inplace. If the graph is not of CSR format, `copy` must be
    True to allow the conversion to CSR format, otherwise an error is
    raised.

  **warn_when_not_sorted**
  : If True, a [`EfficiencyWarning`](sklearn.exceptions.EfficiencyWarning.md#sklearn.exceptions.EfficiencyWarning) is raised
    when the input graph is not sorted by row values.
* **Returns:**
  **graph**
  : Distance matrix to other samples, where only non-zero elements are
    considered neighbors. Matrix is in CSR format.

### Examples

```pycon
>>> from scipy.sparse import csr_matrix
>>> from sklearn.neighbors import sort_graph_by_row_values
>>> X = csr_matrix(
...     [[0., 3., 1.],
...      [3., 0., 2.],
...      [1., 2., 0.]])
>>> X.data
array([3., 1., 3., 2., 1., 2.])
>>> X_ = sort_graph_by_row_values(X)
>>> X_.data
array([1., 3., 2., 3., 1., 2.])
```

<!-- !! processed by numpydoc !! -->
