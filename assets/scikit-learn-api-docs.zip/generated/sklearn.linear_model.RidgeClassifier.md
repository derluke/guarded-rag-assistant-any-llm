# RidgeClassifier

### *class* sklearn.linear_model.RidgeClassifier(alpha=1.0, \*, fit_intercept=True, copy_X=True, max_iter=None, tol=0.0001, class_weight=None, solver='auto', positive=False, random_state=None)

Classifier using Ridge regression.

This classifier first converts the target values into `{-1, 1}` and
then treats the problem as a regression task (multi-output regression in
the multiclass case).

Read more in the [User Guide](../linear_model.md#ridge-regression).

* **Parameters:**
  **alpha**
  : Regularization strength; must be a positive float. Regularization
    improves the conditioning of the problem and reduces the variance of
    the estimates. Larger values specify stronger regularization.
    Alpha corresponds to `1 / (2C)` in other linear models such as
    [`LogisticRegression`](sklearn.linear_model.LogisticRegression.md#sklearn.linear_model.LogisticRegression) or
    [`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC).

  **fit_intercept**
  : Whether to calculate the intercept for this model. If set to false, no
    intercept will be used in calculations (e.g. data is expected to be
    already centered).

  **copy_X**
  : If True, X will be copied; else, it may be overwritten.

  **max_iter**
  : Maximum number of iterations for conjugate gradient solver.
    The default value is determined by scipy.sparse.linalg.

  **tol**
  : The precision of the solution (`coef_`) is determined by `tol` which
    specifies a different convergence criterion for each solver:
    - ‘svd’: `tol` has no impact.
    - ‘cholesky’: `tol` has no impact.
    - ‘sparse_cg’: norm of residuals smaller than `tol`.
    - ‘lsqr’: `tol` is set as atol and btol of scipy.sparse.linalg.lsqr,
      which control the norm of the residual vector in terms of the norms of
      matrix and coefficients.
    - ‘sag’ and ‘saga’: relative change of coef smaller than `tol`.
    - ‘lbfgs’: maximum of the absolute (projected) gradient=max|residuals|
      smaller than `tol`.
    <br/>
    #### Versionchanged
    Changed in version 1.2: Default value changed from 1e-3 to 1e-4 for consistency with other linear
    models.

  **class_weight**
  : Weights associated with classes in the form `{class_label: weight}`.
    If not given, all classes are supposed to have weight one.
    <br/>
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`.

  **solver**
  : Solver to use in the computational routines:
    - ‘auto’ chooses the solver automatically based on the type of data.
    - ‘svd’ uses a Singular Value Decomposition of X to compute the Ridge
      coefficients. It is the most stable solver, in particular more stable
      for singular matrices than ‘cholesky’ at the cost of being slower.
    - ‘cholesky’ uses the standard scipy.linalg.solve function to
      obtain a closed-form solution.
    - ‘sparse_cg’ uses the conjugate gradient solver as found in
      scipy.sparse.linalg.cg. As an iterative algorithm, this solver is
      more appropriate than ‘cholesky’ for large-scale data
      (possibility to set `tol` and `max_iter`).
    - ‘lsqr’ uses the dedicated regularized least-squares routine
      scipy.sparse.linalg.lsqr. It is the fastest and uses an iterative
      procedure.
    - ‘sag’ uses a Stochastic Average Gradient descent, and ‘saga’ uses
      its unbiased and more flexible version named SAGA. Both methods
      use an iterative procedure, and are often faster than other solvers
      when both n_samples and n_features are large. Note that ‘sag’ and
      ‘saga’ fast convergence is only guaranteed on features with
      approximately the same scale. You can preprocess the data with a
      scaler from sklearn.preprocessing.
    <br/>
      #### Versionadded
      Added in version 0.17: Stochastic Average Gradient descent solver.
    <br/>
      #### Versionadded
      Added in version 0.19: SAGA solver.
    - ‘lbfgs’ uses L-BFGS-B algorithm implemented in
      `scipy.optimize.minimize`. It can be used only when `positive`
      is True.

  **positive**
  : When set to `True`, forces the coefficients to be positive.
    Only ‘lbfgs’ solver is supported in this case.

  **random_state**
  : Used when `solver` == ‘sag’ or ‘saga’ to shuffle the data.
    See [Glossary](../../glossary.md#term-random_state) for details.
* **Attributes:**
  **coef_**
  : Coefficient of the features in the decision function.
    <br/>
    `coef_` is of shape (1, n_features) when the given problem is binary.

  **intercept_**
  : Independent term in decision function. Set to 0.0 if
    `fit_intercept = False`.

  **n_iter_**
  : Actual number of iterations for each target. Available only for
    sag and lsqr solvers. Other solvers will return None.

  [`classes_`](#sklearn.linear_model.RidgeClassifier.classes_)
  : Classes labels.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **solver_**
  : The solver that was used at fit time by the computational
    routines.
    <br/>
    #### Versionadded
    Added in version 1.5.

#### SEE ALSO
[`Ridge`](sklearn.linear_model.Ridge.md#sklearn.linear_model.Ridge)
: Ridge regression.

[`RidgeClassifierCV`](sklearn.linear_model.RidgeClassifierCV.md#sklearn.linear_model.RidgeClassifierCV)
: Ridge classifier with built-in cross validation.

### Notes

For multi-class classification, n_class classifiers are trained in
a one-versus-all approach. Concretely, this is implemented by taking
advantage of the multi-variate response support in Ridge.

### Examples

```pycon
>>> from sklearn.datasets import load_breast_cancer
>>> from sklearn.linear_model import RidgeClassifier
>>> X, y = load_breast_cancer(return_X_y=True)
>>> clf = RidgeClassifier().fit(X, y)
>>> clf.score(X, y)
0.9595...
```

<!-- !! processed by numpydoc !! -->

#### *property* classes_

Classes labels.

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Predict confidence scores for samples.

The confidence score for a sample is proportional to the signed
distance of that sample to the hyperplane.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the confidence scores.
* **Returns:**
  **scores**
  : Confidence scores per `(n_samples, n_classes)` combination. In the
    binary case, confidence score for `self.classes_[1]` where >0 means
    this class would be predicted.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit Ridge classifier model.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **sample_weight**
  : Individual weights for each sample. If given a float, every sample
    will have the same weight.
    <br/>
    #### Versionadded
    Added in version 0.17: *sample_weight* support to RidgeClassifier.
* **Returns:**
  **self**
  : Instance of the estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict class labels for samples in `X`.

* **Parameters:**
  **X**
  : The data matrix for which we want to predict the targets.
* **Returns:**
  **y_pred**
  : Vector or matrix containing the predictions. In binary and
    multiclass problems, this is a vector containing `n_samples`. In
    a multilabel problem, it returns a matrix of shape
    `(n_samples, n_outputs)`.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RidgeClassifier](#sklearn.linear_model.RidgeClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RidgeClassifier](#sklearn.linear_model.RidgeClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<!-- thumbnail-parent-div-close --></div>
