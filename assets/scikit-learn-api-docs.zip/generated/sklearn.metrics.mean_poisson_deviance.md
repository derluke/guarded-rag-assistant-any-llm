# mean_poisson_deviance

### sklearn.metrics.mean_poisson_deviance(y_true, y_pred, \*, sample_weight=None)

Mean Poisson deviance regression loss.

Poisson deviance is equivalent to the Tweedie deviance with
the power parameter `power=1`.

Read more in the [User Guide](../model_evaluation.md#mean-tweedie-deviance).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values. Requires y_true >= 0.

  **y_pred**
  : Estimated target values. Requires y_pred > 0.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **loss**
  : A non-negative floating point value (the best value is 0.0).

### Examples

```pycon
>>> from sklearn.metrics import mean_poisson_deviance
>>> y_true = [2, 0, 1, 4]
>>> y_pred = [0.5, 0.5, 2., 2.]
>>> mean_poisson_deviance(y_true, y_pred)
1.4260...
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<!-- thumbnail-parent-div-close --></div>
