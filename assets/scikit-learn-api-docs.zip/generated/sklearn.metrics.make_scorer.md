# make_scorer

### sklearn.metrics.make_scorer(score_func, \*, response_method='default', greater_is_better=True, \*\*kwargs)

Make a scorer from a performance metric or loss function.

A scorer is a wrapper around an arbitrary metric or loss function that is called
with the signature `scorer(estimator, X, y_true, **kwargs)`.

It is accepted in all scikit-learn estimators or functions allowing a `scoring`
parameter.

The parameter `response_method` allows to specify which method of the estimator
should be used to feed the scoring/loss function.

Read more in the [User Guide](../model_evaluation.md#scoring-callable).

* **Parameters:**
  **score_func**
  : Score function (or loss function) with signature
    `score_func(y, y_pred, **kwargs)`.

  **response_method**
  : Specifies the response method to use get prediction from an estimator
    (i.e. [predict_proba](../../glossary.md#term-predict_proba), [decision_function](../../glossary.md#term-decision_function) or
    [predict](../../glossary.md#term-predict)). Possible choices are:
    - if `str`, it corresponds to the name to the method to return;
    - if a list or tuple of `str`, it provides the method names in order of
      preference. The method returned corresponds to the first method in
      the list and which is implemented by `estimator`.
    - if `None`, it is equivalent to `"predict"`.
    <br/>
    #### Versionadded
    Added in version 1.4.
    <br/>
    #### Deprecated
    Deprecated since version 1.6: None is equivalent to ‘predict’ and is deprecated. It will be removed in
    version 1.8.

  **greater_is_better**
  : Whether `score_func` is a score function (default), meaning high is
    good, or a loss function, meaning low is good. In the latter case, the
    scorer object will sign-flip the outcome of the `score_func`.

  **\*\*kwargs**
  : Additional parameters to be passed to `score_func`.
* **Returns:**
  **scorer**
  : Callable object that returns a scalar score; greater is better.

### Examples

```pycon
>>> from sklearn.metrics import fbeta_score, make_scorer
>>> ftwo_scorer = make_scorer(fbeta_score, beta=2)
>>> ftwo_scorer
make_scorer(fbeta_score, response_method='predict', beta=2)
>>> from sklearn.model_selection import GridSearchCV
>>> from sklearn.svm import LinearSVC
>>> grid = GridSearchCV(LinearSVC(), param_grid={'C': [1, 10]},
...                     scoring=ftwo_scorer)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Polars-engineered lagged features can be used for time series forecasting with HistGradientBoostingRegressor on the Bike Sharing Demand dataset.">  <div class="sphx-glr-thumbnail-title">Lagged features for time series forecasting</div>
</div>
* [Lagged features for time series forecasting](../../auto_examples/applications/plot_time_series_lagged_features.md#sphx-glr-auto-examples-applications-plot-time-series-lagged-features-py)

<div class="sphx-glr-thumbcontainer" tooltip="histogram_based_gradient_boosting (HGBT) models may be one of the most useful supervised learning models in scikit-learn. They are based on a modern gradient boosting implementation comparable to LightGBM and XGBoost. As such, HGBT models are more feature rich than and often outperform alternative models like random forests, especially when the number of samples is larger than some ten thousands (see sphx_glr_auto_examples_ensemble_plot_forest_hist_grad_boosting_comparison.py).">  <div class="sphx-glr-thumbnail-title">Features in Histogram Gradient Boosting Trees</div>
</div>
* [Features in Histogram Gradient Boosting Trees](../../auto_examples/ensemble/plot_hgbt_regression.md#sphx-glr-auto-examples-ensemble-plot-hgbt-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how quantile regression can be used to create prediction intervals. See sphx_glr_auto_examples_ensemble_plot_hgbt_regression.py for an example showcasing some other features of HistGradientBoostingRegressor.">  <div class="sphx-glr-thumbnail-title">Prediction Intervals for Gradient Boosting Regression</div>
</div>
* [Prediction Intervals for Gradient Boosting Regression](../../auto_examples/ensemble/plot_gradient_boosting_quantile.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-quantile-py)

<div class="sphx-glr-thumbcontainer" tooltip="Multiple metric parameter search can be done by setting the scoring parameter to a list of metric scorer names or a dict mapping the scorer names to the scorer callables.">  <div class="sphx-glr-thumbnail-title">Demonstration of multi-metric evaluation on cross_val_score and GridSearchCV</div>
</div>
* [Demonstration of multi-metric evaluation on cross_val_score and GridSearchCV](../../auto_examples/model_selection/plot_multi_metric_evaluation.md#sphx-glr-auto-examples-model-selection-plot-multi-metric-evaluation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<!-- thumbnail-parent-div-close --></div>
