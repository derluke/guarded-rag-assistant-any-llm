# QuadraticDiscriminantAnalysis

### *class* sklearn.discriminant_analysis.QuadraticDiscriminantAnalysis(\*, priors=None, reg_param=0.0, store_covariance=False, tol=0.0001)

Quadratic Discriminant Analysis.

A classifier with a quadratic decision boundary, generated
by fitting class conditional densities to the data
and using Bayes’ rule.

The model fits a Gaussian density to each class.

#### Versionadded
Added in version 0.17.

For a comparison between
[`QuadraticDiscriminantAnalysis`](#sklearn.discriminant_analysis.QuadraticDiscriminantAnalysis)
and [`LinearDiscriminantAnalysis`](sklearn.discriminant_analysis.LinearDiscriminantAnalysis.md#sklearn.discriminant_analysis.LinearDiscriminantAnalysis), see
[Linear and Quadratic Discriminant Analysis with covariance ellipsoid](../../auto_examples/classification/plot_lda_qda.md#sphx-glr-auto-examples-classification-plot-lda-qda-py).

Read more in the [User Guide](../lda_qda.md#lda-qda).

* **Parameters:**
  **priors**
  : Class priors. By default, the class proportions are inferred from the
    training data.

  **reg_param**
  : Regularizes the per-class covariance estimates by transforming S2 as
    `S2 = (1 - reg_param) * S2 + reg_param * np.eye(n_features)`,
    where S2 corresponds to the `scaling_` attribute of a given class.

  **store_covariance**
  : If True, the class covariance matrices are explicitly computed and
    stored in the `self.covariance_` attribute.
    <br/>
    #### Versionadded
    Added in version 0.17.

  **tol**
  : Absolute threshold for the covariance matrix to be considered rank
    deficient after applying some regularization (see `reg_param`) to each
    `Sk` where `Sk` represents covariance matrix for k-th class. This
    parameter does not affect the predictions. It controls when a warning
    is raised if the covariance matrix is not full rank.
    <br/>
    #### Versionadded
    Added in version 0.17.
* **Attributes:**
  **covariance_**
  : For each class, gives the covariance matrix estimated using the
    samples of that class. The estimations are unbiased. Only present if
    `store_covariance` is True.

  **means_**
  : Class-wise means.

  **priors_**
  : Class priors (sum to 1).

  **rotations_**
  : For each class k an array of shape (n_features, n_k), where
    `n_k = min(n_features, number of elements in class k)`
    It is the rotation of the Gaussian distribution, i.e. its
    principal axis. It corresponds to `V`, the matrix of eigenvectors
    coming from the SVD of `Xk = U S Vt` where `Xk` is the centered
    matrix of samples from class k.

  **scalings_**
  : For each class, contains the scaling of
    the Gaussian distributions along its principal axes, i.e. the
    variance in the rotated coordinate system. It corresponds to `S^2 /
    (n_samples - 1)`, where `S` is the diagonal matrix of singular values
    from the SVD of `Xk`, where `Xk` is the centered matrix of samples
    from class k.

  **classes_**
  : Unique class labels.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`LinearDiscriminantAnalysis`](sklearn.discriminant_analysis.LinearDiscriminantAnalysis.md#sklearn.discriminant_analysis.LinearDiscriminantAnalysis)
: Linear Discriminant Analysis.

### Examples

```pycon
>>> from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
>>> import numpy as np
>>> X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
>>> y = np.array([1, 1, 1, 2, 2, 2])
>>> clf = QuadraticDiscriminantAnalysis()
>>> clf.fit(X, y)
QuadraticDiscriminantAnalysis()
>>> print(clf.predict([[-0.8, -1]]))
[1]
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Apply decision function to an array of samples.

The decision function is equal (up to a constant factor) to the
log-posterior of the model, i.e. `log p(y = k | x)`. In a binary
classification setting this instead corresponds to the difference
`log p(y = 1 | x) - log p(y = 0 | x)`. See [Mathematical formulation of the LDA and QDA classifiers](../lda_qda.md#lda-qda-math).

* **Parameters:**
  **X**
  : Array of samples (test vectors).
* **Returns:**
  **C**
  : Decision function values related to each class, per sample.
    In the two-class case, the shape is `(n_samples,)`, giving the
    log likelihood ratio of the positive class.

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit the model according to the given training data and parameters.

#### Versionchanged
Changed in version 0.19: `store_covariances` has been moved to main constructor as
`store_covariance`.

#### Versionchanged
Changed in version 0.19: `tol` has been moved to main constructor.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target values (integers).
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Perform classification on an array of test vectors X.

The predicted class C for each sample in X is returned.

* **Parameters:**
  **X**
  : Vector to be scored, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **C**
  : Estimated probabilities.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Return log of posterior probabilities of classification.

* **Parameters:**
  **X**
  : Array of samples/test vectors.
* **Returns:**
  **C**
  : Posterior log-probabilities of classification per class.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Return posterior probabilities of classification.

* **Parameters:**
  **X**
  : Array of samples/test vectors.
* **Returns:**
  **C**
  : Posterior probabilities of classification per class.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [QuadraticDiscriminantAnalysis](#sklearn.discriminant_analysis.QuadraticDiscriminantAnalysis)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example plots the covariance ellipsoids of each class and the decision boundary learned by LinearDiscriminantAnalysis (LDA) and QuadraticDiscriminantAnalysis (QDA). The ellipsoids display the double standard deviation for each class. With LDA, the standard deviation is the same for all the classes, while each class has its own standard deviation with QDA.">  <div class="sphx-glr-thumbnail-title">Linear and Quadratic Discriminant Analysis with covariance ellipsoid</div>
</div>
* [Linear and Quadratic Discriminant Analysis with covariance ellipsoid](../../auto_examples/classification/plot_lda_qda.md#sphx-glr-auto-examples-classification-plot-lda-qda-py)

<!-- thumbnail-parent-div-close --></div>
