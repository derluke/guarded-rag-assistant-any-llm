# RidgeCV

### *class* sklearn.linear_model.RidgeCV(alphas=(0.1, 1.0, 10.0), \*, fit_intercept=True, scoring=None, cv=None, gcv_mode=None, store_cv_results=None, alpha_per_target=False, store_cv_values='deprecated')

Ridge regression with built-in cross-validation.

See glossary entry for [cross-validation estimator](../../glossary.md#term-cross-validation-estimator).

By default, it performs efficient Leave-One-Out Cross-Validation.

Read more in the [User Guide](../linear_model.md#ridge-regression).

* **Parameters:**
  **alphas**
  : Array of alpha values to try.
    Regularization strength; must be a positive float. Regularization
    improves the conditioning of the problem and reduces the variance of
    the estimates. Larger values specify stronger regularization.
    Alpha corresponds to `1 / (2C)` in other linear models such as
    [`LogisticRegression`](sklearn.linear_model.LogisticRegression.md#sklearn.linear_model.LogisticRegression) or
    [`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC).
    If using Leave-One-Out cross-validation, alphas must be strictly positive.

  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to false, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **scoring**
  : A string (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter)) or a scorer callable object /
    function with signature `scorer(estimator, X, y)`. If None, the
    negative mean squared error if cv is ‘auto’ or None (i.e. when using
    leave-one-out cross-validation), and r2 score otherwise.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the efficient Leave-One-Out cross-validation
    - integer, to specify the number of folds.
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs, if `y` is binary or multiclass,
    [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used, else,
    [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.

  **gcv_mode**
  : Flag indicating which strategy to use when performing
    Leave-One-Out Cross-Validation. Options are:
    ```default
    'auto' : use 'svd' if n_samples > n_features, otherwise use 'eigen'
    'svd' : force use of singular value decomposition of X when X is
        dense, eigenvalue decomposition of X^T.X when X is sparse.
    'eigen' : force computation via eigendecomposition of X.X^T
    ```
    <br/>
    The ‘auto’ mode is the default and is intended to pick the cheaper
    option of the two depending on the shape of the training data.

  **store_cv_results**
  : Flag indicating if the cross-validation values corresponding to
    each alpha should be stored in the `cv_results_` attribute (see
    below). This flag is only compatible with `cv=None` (i.e. using
    Leave-One-Out Cross-Validation).
    <br/>
    #### Versionchanged
    Changed in version 1.5: Parameter name changed from `store_cv_values` to `store_cv_results`.

  **alpha_per_target**
  : Flag indicating whether to optimize the alpha value (picked from the
    `alphas` parameter list) for each target separately (for multi-output
    settings: multiple prediction targets). When set to `True`, after
    fitting, the `alpha_` attribute will contain a value for each target.
    When set to `False`, a single alpha is used for all targets.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **store_cv_values**
  : Flag indicating if the cross-validation values corresponding to
    each alpha should be stored in the `cv_values_` attribute (see
    below). This flag is only compatible with `cv=None` (i.e. using
    Leave-One-Out Cross-Validation).
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `store_cv_values` is deprecated in version 1.5 in favor of
    `store_cv_results` and will be removed in version 1.7.
* **Attributes:**
  **cv_results_**
  : Cross-validation values for each alpha (only available if
    `store_cv_results=True` and `cv=None`). After `fit()` has been
    called, this attribute will contain the mean squared errors if
    `scoring is None` otherwise it will contain standardized per point
    prediction values.
    <br/>
    #### Versionchanged
    Changed in version 1.5: `cv_values_` changed to `cv_results_`.

  **coef_**
  : Weight vector(s).

  **intercept_**
  : Independent term in decision function. Set to 0.0 if
    `fit_intercept = False`.

  **alpha_**
  : Estimated regularization parameter, or, if `alpha_per_target=True`,
    the estimated regularization parameter for each target.

  **best_score_**
  : Score of base estimator with best alpha, or, if
    `alpha_per_target=True`, a score for each target.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`Ridge`](sklearn.linear_model.Ridge.md#sklearn.linear_model.Ridge)
: Ridge regression.

[`RidgeClassifier`](sklearn.linear_model.RidgeClassifier.md#sklearn.linear_model.RidgeClassifier)
: Classifier based on ridge regression on {-1, 1} labels.

[`RidgeClassifierCV`](sklearn.linear_model.RidgeClassifierCV.md#sklearn.linear_model.RidgeClassifierCV)
: Ridge classifier with built-in cross validation.

### Examples

```pycon
>>> from sklearn.datasets import load_diabetes
>>> from sklearn.linear_model import RidgeCV
>>> X, y = load_diabetes(return_X_y=True)
>>> clf = RidgeCV(alphas=[1e-3, 1e-2, 1e-1, 1]).fit(X, y)
>>> clf.score(X, y)
0.5166...
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, \*\*params)

Fit Ridge regression model with cv.

* **Parameters:**
  **X**
  : Training data. If using GCV, will be cast to float64
    if necessary.

  **y**
  : Target values. Will be cast to X’s dtype if necessary.

  **sample_weight**
  : Individual weights for each sample. If given a float, every sample
    will have the same weight.

  **\*\*params**
  : Parameters to be passed to the underlying scorer.
    <br/>
    #### Versionadded
    Added in version 1.5: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Fitted estimator.

### Notes

When sample_weight is provided, the selected hyperparameter may depend
on whether we use leave-one-out cross-validation (cv=None or cv=’auto’)
or another form of cross-validation, because only leave-one-out
cross-validation takes the sample weights into account when computing
the validation score.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.5.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RidgeCV](#sklearn.linear_model.RidgeCV)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RidgeCV](#sklearn.linear_model.RidgeCV)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we give an overview of TransformedTargetRegressor. We use two examples to illustrate the benefit of transforming the targets before learning a linear regression model. The first example uses synthetic data while the second example is based on the Ames housing data set.">  <div class="sphx-glr-thumbnail-title">Effect of transforming the targets in regression model</div>
</div>
* [Effect of transforming the targets in regression model](../../auto_examples/compose/plot_transformed_target.md#sphx-glr-auto-examples-compose-plot-transformed-target-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares two approaches for feature selection: SelectFromModel which is based on feature importance, and SequentialFeatureSelector which relies on a greedy approach.">  <div class="sphx-glr-thumbnail-title">Model-based and sequential feature selection</div>
</div>
* [Model-based and sequential feature selection](../../auto_examples/feature_selection/plot_select_from_model_diabetes.md#sphx-glr-auto-examples-feature-selection-plot-select-from-model-diabetes-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows the use of multi-output estimator to complete images. The goal is to predict the lower half of a face given its upper half.">  <div class="sphx-glr-thumbnail-title">Face completion with a multi-output estimators</div>
</div>
* [Face completion with a multi-output estimators](../../auto_examples/miscellaneous/plot_multioutput_face_completion.md#sphx-glr-auto-examples-miscellaneous-plot-multioutput-face-completion-py)

<!-- thumbnail-parent-div-close --></div>
