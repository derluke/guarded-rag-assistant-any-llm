# compute_optics_graph

### sklearn.cluster.compute_optics_graph(X, \*, min_samples, max_eps, metric, p, metric_params, algorithm, leaf_size, n_jobs)

Compute the OPTICS reachability graph.

Read more in the [User Guide](../clustering.md#optics).

* **Parameters:**
  **X**
  : A feature array, or array of distances between samples if
    metric=’precomputed’.

  **min_samples**
  : The number of samples in a neighborhood for a point to be considered
    as a core point. Expressed as an absolute number or a fraction of the
    number of samples (rounded to be at least 2).

  **max_eps**
  : The maximum distance between two samples for one to be considered as
    in the neighborhood of the other. Default value of `np.inf` will
    identify clusters across all scales; reducing `max_eps` will result
    in shorter run times.

  **metric**
  : Metric to use for distance computation. Any metric from scikit-learn
    or scipy.spatial.distance can be used.
    <br/>
    If metric is a callable function, it is called on each
    pair of instances (rows) and the resulting value recorded. The callable
    should take two arrays as input and return one value indicating the
    distance between them. This works for Scipy’s metrics, but is less
    efficient than passing the metric name as a string. If metric is
    “precomputed”, X is assumed to be a distance matrix and must be square.
    <br/>
    Valid values for metric are:
    - from scikit-learn: [‘cityblock’, ‘cosine’, ‘euclidean’, ‘l1’, ‘l2’,
      ‘manhattan’]
    - from scipy.spatial.distance: [‘braycurtis’, ‘canberra’, ‘chebyshev’,
      ‘correlation’, ‘dice’, ‘hamming’, ‘jaccard’, ‘kulsinski’,
      ‘mahalanobis’, ‘minkowski’, ‘rogerstanimoto’, ‘russellrao’,
      ‘seuclidean’, ‘sokalmichener’, ‘sokalsneath’, ‘sqeuclidean’,
      ‘yule’]
    <br/>
    See the documentation for scipy.spatial.distance for details on these
    metrics.
    <br/>
    #### NOTE
    `'kulsinski'` is deprecated from SciPy 1.9 and will be removed in SciPy 1.11.

  **p**
  : Parameter for the Minkowski metric from
    [`pairwise_distances`](sklearn.metrics.pairwise_distances.md#sklearn.metrics.pairwise_distances). When p = 1, this is
    equivalent to using manhattan_distance (l1), and euclidean_distance
    (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.

  **metric_params**
  : Additional keyword arguments for the metric function.

  **algorithm**
  : Algorithm used to compute the nearest neighbors:
    - ‘ball_tree’ will use [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree).
    - ‘kd_tree’ will use [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree).
    - ‘brute’ will use a brute-force search.
    - ‘auto’ will attempt to decide the most appropriate algorithm
      based on the values passed to `fit` method. (default)
    <br/>
    Note: fitting on sparse input will override the setting of
    this parameter, using brute force.

  **leaf_size**
  : Leaf size passed to [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree) or
    [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree). This can affect the speed of the
    construction and query, as well as the memory required to store the
    tree. The optimal value depends on the nature of the problem.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Returns:**
  **ordering_**
  : The cluster ordered list of sample indices.

  **core_distances_**
  : Distance at which each sample becomes a core point, indexed by object
    order. Points which will never be core have a distance of inf. Use
    `clust.core_distances_[clust.ordering_]` to access in cluster order.

  **reachability_**
  : Reachability distances per sample, indexed by object order. Use
    `clust.reachability_[clust.ordering_]` to access in cluster order.

  **predecessor_**
  : Point that a sample was reached from, indexed by object order.
    Seed points have a predecessor of -1.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.cluster import compute_optics_graph
>>> X = np.array([[1, 2], [2, 5], [3, 6],
...               [8, 7], [8, 8], [7, 3]])
>>> ordering, core_distances, reachability, predecessor = compute_optics_graph(
...     X,
...     min_samples=2,
...     max_eps=np.inf,
...     metric="minkowski",
...     p=2,
...     metric_params=None,
...     algorithm="auto",
...     leaf_size=30,
...     n_jobs=None,
... )
>>> ordering
array([0, 1, 2, 5, 3, 4])
>>> core_distances
array([3.16..., 1.41..., 1.41..., 1.        , 1.        ,
       4.12...])
>>> reachability
array([       inf, 3.16..., 1.41..., 4.12..., 1.        ,
       5.        ])
>>> predecessor
array([-1,  0,  1,  5,  3,  2])
```

<!-- !! processed by numpydoc !! -->
