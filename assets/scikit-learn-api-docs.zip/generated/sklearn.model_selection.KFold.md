# KFold

### *class* sklearn.model_selection.KFold(n_splits=5, \*, shuffle=False, random_state=None)

K-Fold cross-validator.

Provides train/test indices to split data in train/test sets. Split
dataset into k consecutive folds (without shuffling by default).

Each fold is then used once as a validation while the k - 1 remaining
folds form the training set.

Read more in the [User Guide](../cross_validation.md#k-fold).

For visualisation of cross-validation behaviour and
comparison between common scikit-learn split methods
refer to [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

* **Parameters:**
  **n_splits**
  : Number of folds. Must be at least 2.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `n_splits` default value changed from 3 to 5.

  **shuffle**
  : Whether to shuffle the data before splitting into batches.
    Note that the samples within each split will not be shuffled.

  **random_state**
  : When `shuffle` is True, `random_state` affects the ordering of the
    indices, which controls the randomness of each fold. Otherwise, this
    parameter has no effect.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

#### SEE ALSO
[`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold)
: Takes class information into account to avoid building folds with imbalanced class distributions (for binary or multiclass classification tasks).

[`GroupKFold`](sklearn.model_selection.GroupKFold.md#sklearn.model_selection.GroupKFold)
: K-fold iterator variant with non-overlapping groups.

[`RepeatedKFold`](sklearn.model_selection.RepeatedKFold.md#sklearn.model_selection.RepeatedKFold)
: Repeats K-Fold n times.

### Notes

The first `n_samples % n_splits` folds have size
`n_samples // n_splits + 1`, other folds have size
`n_samples // n_splits`, where `n_samples` is the number of samples.

Randomized CV splitters may return different results for each call of
split. You can make the results identical by setting `random_state`
to an integer.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import KFold
>>> X = np.array([[1, 2], [3, 4], [1, 2], [3, 4]])
>>> y = np.array([1, 2, 3, 4])
>>> kf = KFold(n_splits=2)
>>> kf.get_n_splits(X)
2
>>> print(kf)
KFold(n_splits=2, random_state=None, shuffle=False)
>>> for i, (train_index, test_index) in enumerate(kf.split(X)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}")
...     print(f"  Test:  index={test_index}")
Fold 0:
  Train: index=[2 3]
  Test:  index=[0 1]
Fold 1:
  Train: index=[0 1]
  Test:  index=[2 3]
```

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X=None, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Always ignored, exists for compatibility.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### split(X, y=None, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : The target variable for supervised learning problems.

  **groups**
  : Always ignored, exists for compatibility.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares 2 dimensionality reduction strategies:">  <div class="sphx-glr-thumbnail-title">Feature agglomeration vs. univariate selection</div>
</div>
* [Feature agglomeration vs. univariate selection](../../auto_examples/cluster/plot_feature_agglomeration_vs_univariate_selection.md#sphx-glr-auto-examples-cluster-plot-feature-agglomeration-vs-univariate-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the performance of Random Forest (RF) and Histogram Gradient Boosting (HGBT) models in terms of score and computation time for a regression dataset, though all the concepts here presented apply to classification as well.">  <div class="sphx-glr-thumbnail-title">Comparing Random Forests and Histogram Gradient Boosting models</div>
</div>
* [Comparing Random Forests and Histogram Gradient Boosting models](../../auto_examples/ensemble/plot_forest_hist_grad_boosting_comparison.md#sphx-glr-auto-examples-ensemble-plot-forest-hist-grad-boosting-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Gradient Boosting Out-of-Bag estimates">  <div class="sphx-glr-thumbnail-title">Gradient Boosting Out-of-Bag estimates</div>
</div>
* [Gradient Boosting Out-of-Bag estimates](../../auto_examples/ensemble/plot_gradient_boosting_oob.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-oob-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares non-nested and nested cross-validation strategies on a classifier of the iris data set. Nested cross-validation (CV) is often used to train a model in which hyperparameters also need to be optimized. Nested CV estimates the generalization error of the underlying model and its (hyper)parameter search. Choosing the parameters that maximize non-nested CV biases the model to the dataset, yielding an overly-optimistic score.">  <div class="sphx-glr-thumbnail-title">Nested versus non-nested cross-validation</div>
</div>
* [Nested versus non-nested cross-validation](../../auto_examples/model_selection/plot_nested_cross_validation_iris.md#sphx-glr-auto-examples-model-selection-plot-nested-cross-validation-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="Choosing the right cross-validation object is a crucial part of fitting a model properly. There are many ways to split data into training and test sets in order to avoid model overfitting, to standardize the number of groups in test sets, etc.">  <div class="sphx-glr-thumbnail-title">Visualizing cross-validation behavior in scikit-learn</div>
</div>
* [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

<!-- thumbnail-parent-div-close --></div>
