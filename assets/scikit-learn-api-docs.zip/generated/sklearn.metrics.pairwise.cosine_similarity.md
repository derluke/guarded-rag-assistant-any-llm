# cosine_similarity

### sklearn.metrics.pairwise.cosine_similarity(X, Y=None, dense_output=True)

Compute cosine similarity between samples in X and Y.

Cosine similarity, or the cosine kernel, computes similarity as the
normalized dot product of X and Y:

```text
K(X, Y) = <X, Y> / (||X||*||Y||)
```

On L2-normalized data, this function is equivalent to linear_kernel.

Read more in the [User Guide](../metrics.md#cosine-similarity).

* **Parameters:**
  **X**
  : Input data.

  **Y**
  : Input data. If `None`, the output will be the pairwise
    similarities between all samples in `X`.

  **dense_output**
  : Whether to return dense output even when the input is sparse. If
    `False`, the output is sparse if both input arrays are sparse.
    <br/>
    #### Versionadded
    Added in version 0.17: parameter `dense_output` for dense output.
* **Returns:**
  **similarities**
  : Returns the cosine similarity between samples in X and Y.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import cosine_similarity
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> cosine_similarity(X, Y)
array([[0.     , 0.     ],
       [0.57..., 0.81...]])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="SVCs aim to find a hyperplane that effectively separates the classes in their training data by maximizing the margin between the outermost data points of each class. This is achieved by finding the best weight vector w that defines the decision boundary hyperplane and minimizes the sum of hinge losses for misclassified samples, as measured by the hinge_loss function. By default, regularization is applied with the parameter C=1, which allows for a certain degree of misclassification tolerance.">  <div class="sphx-glr-thumbnail-title">Plot classification boundaries with different SVM Kernels</div>
</div>
* [Plot classification boundaries with different SVM Kernels](../../auto_examples/svm/plot_svm_kernels.md#sphx-glr-auto-examples-svm-plot-svm-kernels-py)

<!-- thumbnail-parent-div-close --></div>
