# inplace_csr_row_normalize_l1

### sklearn.utils.sparsefuncs_fast.inplace_csr_row_normalize_l1(X)

Normalize inplace the rows of a CSR matrix or array by their L1 norm.

* **Parameters:**
  **X**
  : The input matrix or array to be modified inplace.

### Examples

```pycon
>>> from scipy.sparse import csr_matrix
>>> from sklearn.utils.sparsefuncs_fast import inplace_csr_row_normalize_l1
>>> import numpy as np
>>> indptr = np.array([0, 2, 3, 4])
>>> indices = np.array([0, 1, 2, 3])
>>> data = np.array([1.0, 2.0, 3.0, 4.0])
>>> X = csr_matrix((data, indices, indptr), shape=(3, 4))
>>> X.toarray()
array([[1., 2., 0., 0.],
       [0., 0., 3., 0.],
       [0., 0., 0., 4.]])
>>> inplace_csr_row_normalize_l1(X)
>>> X.toarray()
array([[0.33...   , 0.66...   , 0.        , 0.        ],
       [0.        , 0.        , 1.        , 0.        ],
       [0.        , 0.        , 0.        , 1.        ]])
```

<!-- !! processed by numpydoc !! -->
