# fetch_rcv1

### sklearn.datasets.fetch_rcv1(\*, data_home=None, subset='all', download_if_missing=True, random_state=None, shuffle=False, return_X_y=False, n_retries=3, delay=1.0)

Load the RCV1 multilabel dataset (classification).

Download it if necessary.

Version: RCV1-v2, vectors, full sets, topics multilabels.

| Classes        | 103                   |
|----------------|-----------------------|
| Samples total  | 804414                |
| Dimensionality | 47236                 |
| Features       | real, between 0 and 1 |

Read more in the [User Guide](../../datasets/real_world.md#rcv1-dataset).

#### Versionadded
Added in version 0.17.

* **Parameters:**
  **data_home**
  : Specify another download and cache folder for the datasets. By default
    all scikit-learn data is stored in ‘~/scikit_learn_data’ subfolders.

  **subset**
  : Select the dataset to load: ‘train’ for the training set
    (23149 samples), ‘test’ for the test set (781265 samples),
    ‘all’ for both, with the training samples first if shuffle is False.
    This follows the official LYRL2004 chronological split.

  **download_if_missing**
  : If False, raise an OSError if the data is not locally available
    instead of trying to download the data from the source site.

  **random_state**
  : Determines random number generation for dataset shuffling. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **shuffle**
  : Whether to shuffle dataset.

  **return_X_y**
  : If True, returns `(dataset.data, dataset.target)` instead of a Bunch
    object. See below for more information about the `dataset.data` and
    `dataset.target` object.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **n_retries**
  : Number of retries when HTTP errors are encountered.
    <br/>
    #### Versionadded
    Added in version 1.5.

  **delay**
  : Number of seconds between retries.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **dataset**
  : Dictionary-like object. Returned only if `return_X_y` is False.
    `dataset` has the following attributes:
    - data
      : The array has 0.16% of non zero values. Will be of CSR format.
    - target
      : Each sample has a value of 1 in its categories, and 0 in others.
        The array has 3.15% of non zero values. Will be of CSR format.
    - sample_id
      : Identification number of each sample, as ordered in dataset.data.
    - target_names
      : Names of each target (RCV1 topics), as ordered in dataset.target.
    - DESCR
      : Description of the RCV1 dataset.

  **(data, target)**
  : A tuple consisting of `dataset.data` and `dataset.target`, as
    described above. Returned only if `return_X_y` is True.
    <br/>
    #### Versionadded
    Added in version 0.20.

### Examples

```pycon
>>> from sklearn.datasets import fetch_rcv1
>>> rcv1 = fetch_rcv1()
>>> rcv1.data.shape
(804414, 47236)
>>> rcv1.target.shape
(804414, 103)
```

<!-- !! processed by numpydoc !! -->
