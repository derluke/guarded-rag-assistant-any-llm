# make_sparse_uncorrelated

### sklearn.datasets.make_sparse_uncorrelated(n_samples=100, n_features=10, \*, random_state=None)

Generate a random regression problem with sparse uncorrelated design.

This dataset is described in Celeux et al [1]. as:

```default
X ~ N(0, 1)
y(X) = X[:, 0] + 2 * X[:, 1] - 2 * X[:, 2] - 1.5 * X[:, 3]
```

Only the first 4 features are informative. The remaining features are
useless.

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **n_samples**
  : The number of samples.

  **n_features**
  : The number of features.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : The input samples.

  **y**
  : The output values.

### References

### Examples

```pycon
>>> from sklearn.datasets import make_sparse_uncorrelated
>>> X, y = make_sparse_uncorrelated(random_state=0)
>>> X.shape
(100, 10)
>>> y.shape
(100,)
```

<!-- !! processed by numpydoc !! -->
