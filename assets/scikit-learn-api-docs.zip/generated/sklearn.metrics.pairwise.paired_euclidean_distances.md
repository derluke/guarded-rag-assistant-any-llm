# paired_euclidean_distances

### sklearn.metrics.pairwise.paired_euclidean_distances(X, Y)

Compute the paired euclidean distances between X and Y.

Read more in the [User Guide](../metrics.md#metrics).

* **Parameters:**
  **X**
  : Input array/matrix X.

  **Y**
  : Input array/matrix Y.
* **Returns:**
  **distances**
  : Output array/matrix containing the calculated paired euclidean
    distances.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import paired_euclidean_distances
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> paired_euclidean_distances(X, Y)
array([1., 1.])
```

<!-- !! processed by numpydoc !! -->
