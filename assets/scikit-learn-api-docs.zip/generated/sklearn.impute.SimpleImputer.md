# SimpleImputer

### *class* sklearn.impute.SimpleImputer(\*, missing_values=nan, strategy='mean', fill_value=None, copy=True, add_indicator=False, keep_empty_features=False)

Univariate imputer for completing missing values with simple strategies.

Replace missing values using a descriptive statistic (e.g. mean, median, or
most frequent) along each column, or using a constant value.

Read more in the [User Guide](../impute.md#impute).

#### Versionadded
Added in version 0.20: `SimpleImputer` replaces the previous `sklearn.preprocessing.Imputer`
estimator which is now removed.

* **Parameters:**
  **missing_values**
  : The placeholder for the missing values. All occurrences of
    `missing_values` will be imputed. For pandas’ dataframes with
    nullable integer dtypes with missing values, `missing_values`
    can be set to either `np.nan` or `pd.NA`.

  **strategy**
  : The imputation strategy.
    - If “mean”, then replace missing values using the mean along
      each column. Can only be used with numeric data.
    - If “median”, then replace missing values using the median along
      each column. Can only be used with numeric data.
    - If “most_frequent”, then replace missing using the most frequent
      value along each column. Can be used with strings or numeric data.
      If there is more than one such value, only the smallest is returned.
    - If “constant”, then replace missing values with fill_value. Can be
      used with strings or numeric data.
    - If an instance of Callable, then replace missing values using the
      scalar statistic returned by running the callable over a dense 1d
      array containing non-missing values of each column.
    <br/>
    #### Versionadded
    Added in version 0.20: strategy=”constant” for fixed value imputation.
    <br/>
    #### Versionadded
    Added in version 1.5: strategy=callable for custom value imputation.

  **fill_value**
  : When strategy == “constant”, `fill_value` is used to replace all
    occurrences of missing_values. For string or object data types,
    `fill_value` must be a string.
    If `None`, `fill_value` will be 0 when imputing numerical
    data and “missing_value” for strings or object data types.

  **copy**
  : If True, a copy of X will be created. If False, imputation will
    be done in-place whenever possible. Note that, in the following cases,
    a new copy will always be made, even if `copy=False`:
    - If `X` is not an array of floating values;
    - If `X` is encoded as a CSR matrix;
    - If `add_indicator=True`.

  **add_indicator**
  : If True, a [`MissingIndicator`](sklearn.impute.MissingIndicator.md#sklearn.impute.MissingIndicator) transform will stack onto output
    of the imputer’s transform. This allows a predictive estimator
    to account for missingness despite imputation. If a feature has no
    missing values at fit/train time, the feature won’t appear on
    the missing indicator even if there are missing values at
    transform/test time.

  **keep_empty_features**
  : If True, features that consist exclusively of missing values when
    `fit` is called are returned in results when `transform` is called.
    The imputed value is always `0` except when `strategy="constant"`
    in which case `fill_value` will be used instead.
    <br/>
    #### Versionadded
    Added in version 1.2.
    <br/>
    #### Versionchanged
    Changed in version 1.6: Currently, when `keep_empty_feature=False` and `strategy="constant"`,
    empty features are not dropped. This behaviour will change in version
    1.8. Set `keep_empty_feature=True` to preserve this behaviour.
* **Attributes:**
  **statistics_**
  : The imputation fill value for each feature.
    Computing statistics can result in `np.nan` values.
    During [`transform`](#sklearn.impute.SimpleImputer.transform), features corresponding to `np.nan`
    statistics will be discarded.

  **indicator_**
  : Indicator used to add binary indicators for missing values.
    `None` if `add_indicator=False`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`IterativeImputer`](sklearn.impute.IterativeImputer.md#sklearn.impute.IterativeImputer)
: Multivariate imputer that estimates values to impute for each feature with missing values from all the others.

[`KNNImputer`](sklearn.impute.KNNImputer.md#sklearn.impute.KNNImputer)
: Multivariate imputer that estimates missing features using nearest samples.

### Notes

Columns which only contained missing values at [`fit`](#sklearn.impute.SimpleImputer.fit) are discarded
upon [`transform`](#sklearn.impute.SimpleImputer.transform) if strategy is not `"constant"`.

In a prediction context, simple imputation usually performs poorly when
associated with a weak learner. However, with a powerful learner, it can
lead to as good or better performance than complex imputation such as
[`IterativeImputer`](sklearn.impute.IterativeImputer.md#sklearn.impute.IterativeImputer) or [`KNNImputer`](sklearn.impute.KNNImputer.md#sklearn.impute.KNNImputer).

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.impute import SimpleImputer
>>> imp_mean = SimpleImputer(missing_values=np.nan, strategy='mean')
>>> imp_mean.fit([[7, 2, 3], [4, np.nan, 6], [10, 5, 9]])
SimpleImputer()
>>> X = [[np.nan, 2, 3], [4, np.nan, 6], [10, np.nan, 9]]
>>> print(imp_mean.transform(X))
[[ 7.   2.   3. ]
 [ 4.   3.5  6. ]
 [10.   3.5  9. ]]
```

For a more detailed example see
[Imputing missing values before building an estimator](../../auto_examples/impute/plot_missing_values.md#sphx-glr-auto-examples-impute-plot-missing-values-py).

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the imputer on `X`.

* **Parameters:**
  **X**
  : Input data, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Convert the data back to the original representation.

Inverts the `transform` operation performed on an array.
This operation can only be performed after [`SimpleImputer`](#sklearn.impute.SimpleImputer) is
instantiated with `add_indicator=True`.

Note that `inverse_transform` can only invert the transform in
features that have binary indicators for missing values. If a feature
has no missing values at `fit` time, the feature won’t have a binary
indicator, and the imputation done at `transform` time won’t be
inverted.

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **X**
  : The imputed data to be reverted to original data. It has to be
    an augmented array of imputed data and the missing indicator mask.
* **Returns:**
  **X_original**
  : The original `X` with missing values as it was prior
    to imputation.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Impute all missing values in `X`.

* **Parameters:**
  **X**
  : The input data to complete.
* **Returns:**
  **X_imputed**
  : `X` with imputed values.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to apply different preprocessing and feature extraction pipelines to different subsets of features, using ColumnTransformer. This is particularly handy for the case of datasets that contain heterogeneous data types, since we may want to scale the numeric features and one-hot encode the categorical ones.">  <div class="sphx-glr-thumbnail-title">Column Transformer with Mixed Types</div>
</div>
* [Column Transformer with Mixed Types](../../auto_examples/compose/plot_column_transformer_mixed_types.md#sphx-glr-auto-examples-compose-plot-column-transformer-mixed-types-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="Missing values can be replaced by the mean, the median or the most frequent value using the basic SimpleImputer.">  <div class="sphx-glr-thumbnail-title">Imputing missing values before building an estimator</div>
</div>
* [Imputing missing values before building an estimator](../../auto_examples/impute/plot_missing_values.md#sphx-glr-auto-examples-impute-plot-missing-values-py)

<div class="sphx-glr-thumbcontainer" tooltip="The IterativeImputer class is very flexible - it can be used with a variety of estimators to do round-robin regression, treating every variable as an output in turn.">  <div class="sphx-glr-thumbnail-title">Imputing missing values with variants of IterativeImputer</div>
</div>
* [Imputing missing values with variants of IterativeImputer](../../auto_examples/impute/plot_iterative_imputer_variants_comparison.md#sphx-glr-auto-examples-impute-plot-iterative-imputer-variants-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the impurity-based feature importance of RandomForestClassifier with the permutation importance on the titanic dataset using permutation_importance. We will show that the impurity-based feature importance can inflate the importance of numerical features.">  <div class="sphx-glr-thumbnail-title">Permutation Importance vs Random Forest Feature Importance (MDI)</div>
</div>
* [Permutation Importance vs Random Forest Feature Importance (MDI)](../../auto_examples/inspection/plot_permutation_importance.md#sphx-glr-auto-examples-inspection-plot-permutation-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="The default configuration for displaying a pipeline in a Jupyter Notebook is &#x27;diagram&#x27; where set_config(display=&#x27;diagram&#x27;). To deactivate HTML representation, use set_config(display=&#x27;text&#x27;).">  <div class="sphx-glr-thumbnail-title">Displaying Pipelines</div>
</div>
* [Displaying Pipelines](../../auto_examples/miscellaneous/plot_pipeline_display.md#sphx-glr-auto-examples-miscellaneous-plot-pipeline-display-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates different ways estimators and pipelines can be displayed.">  <div class="sphx-glr-thumbnail-title">Displaying estimators and complex pipelines</div>
</div>
* [Displaying estimators and complex pipelines](../../auto_examples/miscellaneous/plot_estimator_representation.md#sphx-glr-auto-examples-miscellaneous-plot-estimator-representation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example will demonstrate the set_output API to configure transformers to output pandas DataFrames. set_output can be configured per estimator by calling the set_output method or globally by setting set_config(transform_output=&quot;pandas&quot;). For details, see SLEP018.">  <div class="sphx-glr-thumbnail-title">Introducing the set_output API</div>
</div>
* [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<!-- thumbnail-parent-div-close --></div>
