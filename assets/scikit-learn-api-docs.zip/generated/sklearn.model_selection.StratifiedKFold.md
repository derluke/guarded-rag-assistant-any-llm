# StratifiedKFold

### *class* sklearn.model_selection.StratifiedKFold(n_splits=5, \*, shuffle=False, random_state=None)

Stratified K-Fold cross-validator.

Provides train/test indices to split data in train/test sets.

This cross-validation object is a variation of KFold that returns
stratified folds. The folds are made by preserving the percentage of
samples for each class.

Read more in the [User Guide](../cross_validation.md#stratified-k-fold).

For visualisation of cross-validation behaviour and
comparison between common scikit-learn split methods
refer to [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

* **Parameters:**
  **n_splits**
  : Number of folds. Must be at least 2.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `n_splits` default value changed from 3 to 5.

  **shuffle**
  : Whether to shuffle each class’s samples before splitting into batches.
    Note that the samples within each split will not be shuffled.

  **random_state**
  : When `shuffle` is True, `random_state` affects the ordering of the
    indices, which controls the randomness of each fold for each class.
    Otherwise, leave `random_state` as `None`.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

#### SEE ALSO
[`RepeatedStratifiedKFold`](sklearn.model_selection.RepeatedStratifiedKFold.md#sklearn.model_selection.RepeatedStratifiedKFold)
: Repeats Stratified K-Fold n times.

### Notes

The implementation is designed to:

* Generate test sets such that all contain the same distribution of
  classes, or as close as possible.
* Be invariant to class label: relabelling `y = ["Happy", "Sad"]` to
  `y = [1, 0]` should not change the indices generated.
* Preserve order dependencies in the dataset ordering, when
  `shuffle=False`: all samples from class k in some test set were
  contiguous in y, or separated in y by samples from classes other than k.
* Generate test sets where the smallest and largest differ by at most one
  sample.

#### Versionchanged
Changed in version 0.22: The previous implementation did not follow the last constraint.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import StratifiedKFold
>>> X = np.array([[1, 2], [3, 4], [1, 2], [3, 4]])
>>> y = np.array([0, 0, 1, 1])
>>> skf = StratifiedKFold(n_splits=2)
>>> skf.get_n_splits(X, y)
2
>>> print(skf)
StratifiedKFold(n_splits=2, random_state=None, shuffle=False)
>>> for i, (train_index, test_index) in enumerate(skf.split(X, y)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}")
...     print(f"  Test:  index={test_index}")
Fold 0:
  Train: index=[1 3]
  Test:  index=[0 2]
Fold 1:
  Train: index=[0 2]
  Test:  index=[1 3]
```

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X=None, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Always ignored, exists for compatibility.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### split(X, y, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.
    <br/>
    Note that providing `y` is sufficient to generate the splits and
    hence `np.zeros(n_samples)` may be used as a placeholder for
    `X` instead of actual training data.

  **y**
  : The target variable for supervised learning problems.
    Stratification is done based on the y labels.

  **groups**
  : Always ignored, exists for compatibility.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

### Notes

Randomized CV splitters may return different results for each call of
split. You can make the results identical by setting `random_state`
to an integer.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A Recursive Feature Elimination (RFE) example with automatic tuning of the number of features selected with cross-validation.">  <div class="sphx-glr-thumbnail-title">Recursive feature elimination with cross-validation</div>
</div>
* [Recursive feature elimination with cross-validation](../../auto_examples/feature_selection/plot_rfe_with_cross_validation.md#sphx-glr-auto-examples-feature-selection-plot-rfe-with-cross-validation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Demonstration of several covariances types for Gaussian mixture models.">  <div class="sphx-glr-thumbnail-title">GMM covariances</div>
</div>
* [GMM covariances](../../auto_examples/mixture/plot_gmm_covariances.md#sphx-glr-auto-examples-mixture-plot-gmm-covariances-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents how to estimate and visualize the variance of the Receiver Operating Characteristic (ROC) metric using cross-validation.">  <div class="sphx-glr-thumbnail-title">Receiver Operating Characteristic (ROC) with cross validation</div>
</div>
* [Receiver Operating Characteristic (ROC) with cross validation](../../auto_examples/model_selection/plot_roc_crossval.md#sphx-glr-auto-examples-model-selection-plot-roc-crossval-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the use of permutation_test_score to evaluate the significance of a cross-validated score using permutations.">  <div class="sphx-glr-thumbnail-title">Test with permutations the significance of a classification score</div>
</div>
* [Test with permutations the significance of a classification score](../../auto_examples/model_selection/plot_permutation_tests_for_classification.md#sphx-glr-auto-examples-model-selection-plot-permutation-tests-for-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Choosing the right cross-validation object is a crucial part of fitting a model properly. There are many ways to split data into training and test sets in order to avoid model overfitting, to standardize the number of groups in test sets, etc.">  <div class="sphx-glr-thumbnail-title">Visualizing cross-validation behavior in scikit-learn</div>
</div>
* [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of a varying threshold on self-training. The breast_cancer dataset is loaded, and labels are deleted such that only 50 out of 569 samples have labels. A SelfTrainingClassifier is fitted on this dataset, with varying thresholds.">  <div class="sphx-glr-thumbnail-title">Effect of varying threshold for self-training</div>
</div>
* [Effect of varying threshold for self-training](../../auto_examples/semi_supervised/plot_self_training_varying_threshold.md#sphx-glr-auto-examples-semi-supervised-plot-self-training-varying-threshold-py)

<!-- thumbnail-parent-div-close --></div>
