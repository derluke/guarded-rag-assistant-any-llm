# AffinityPropagation

### *class* sklearn.cluster.AffinityPropagation(\*, damping=0.5, max_iter=200, convergence_iter=15, copy=True, preference=None, affinity='euclidean', verbose=False, random_state=None)

Perform Affinity Propagation Clustering of data.

Read more in the [User Guide](../clustering.md#affinity-propagation).

* **Parameters:**
  **damping**
  : Damping factor in the range `[0.5, 1.0)` is the extent to
    which the current value is maintained relative to
    incoming values (weighted 1 - damping). This in order
    to avoid numerical oscillations when updating these
    values (messages).

  **max_iter**
  : Maximum number of iterations.

  **convergence_iter**
  : Number of iterations with no change in the number
    of estimated clusters that stops the convergence.

  **copy**
  : Make a copy of input data.

  **preference**
  : Preferences for each point - points with larger values of
    preferences are more likely to be chosen as exemplars. The number
    of exemplars, ie of clusters, is influenced by the input
    preferences value. If the preferences are not passed as arguments,
    they will be set to the median of the input similarities.

  **affinity**
  : Which affinity to use. At the moment ‘precomputed’ and
    `euclidean` are supported. ‘euclidean’ uses the
    negative squared euclidean distance between points.

  **verbose**
  : Whether to be verbose.

  **random_state**
  : Pseudo-random number generator to control the starting state.
    Use an int for reproducible results across function calls.
    See the [Glossary](../../glossary.md#term-random_state).
    <br/>
    #### Versionadded
    Added in version 0.23: this parameter was previously hardcoded as 0.
* **Attributes:**
  **cluster_centers_indices_**
  : Indices of cluster centers.

  **cluster_centers_**
  : Cluster centers (if affinity != `precomputed`).

  **labels_**
  : Labels of each point.

  **affinity_matrix_**
  : Stores the affinity matrix used in `fit`.

  **n_iter_**
  : Number of iterations taken to converge.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`AgglomerativeClustering`](sklearn.cluster.AgglomerativeClustering.md#sklearn.cluster.AgglomerativeClustering)
: Recursively merges the pair of clusters that minimally increases a given linkage distance.

[`FeatureAgglomeration`](sklearn.cluster.FeatureAgglomeration.md#sklearn.cluster.FeatureAgglomeration)
: Similar to AgglomerativeClustering, but recursively merges features instead of samples.

[`KMeans`](sklearn.cluster.KMeans.md#sklearn.cluster.KMeans)
: K-Means clustering.

[`MiniBatchKMeans`](sklearn.cluster.MiniBatchKMeans.md#sklearn.cluster.MiniBatchKMeans)
: Mini-Batch K-Means clustering.

[`MeanShift`](sklearn.cluster.MeanShift.md#sklearn.cluster.MeanShift)
: Mean shift clustering using a flat kernel.

[`SpectralClustering`](sklearn.cluster.SpectralClustering.md#sklearn.cluster.SpectralClustering)
: Apply clustering to a projection of the normalized Laplacian.

### Notes

For an example usage,
see [Demo of affinity propagation clustering algorithm](../../auto_examples/cluster/plot_affinity_propagation.md#sphx-glr-auto-examples-cluster-plot-affinity-propagation-py).

The algorithmic complexity of affinity propagation is quadratic
in the number of points.

When the algorithm does not converge, it will still return a arrays of
`cluster_center_indices` and labels if there are any exemplars/clusters,
however they may be degenerate and should be used with caution.

When `fit` does not converge, `cluster_centers_` is still populated
however it may be degenerate. In such a case, proceed with caution.
If `fit` does not converge and fails to produce any `cluster_centers_`
then `predict` will label every sample as `-1`.

When all training samples have equal similarities and equal preferences,
the assignment of cluster centers and labels depends on the preference.
If the preference is smaller than the similarities, `fit` will result in
a single cluster center and label `0` for every sample. Otherwise, every
training sample becomes its own cluster center and is assigned a unique
label.

### References

Brendan J. Frey and Delbert Dueck, “Clustering by Passing Messages
Between Data Points”, Science Feb. 2007

### Examples

```pycon
>>> from sklearn.cluster import AffinityPropagation
>>> import numpy as np
>>> X = np.array([[1, 2], [1, 4], [1, 0],
...               [4, 2], [4, 4], [4, 0]])
>>> clustering = AffinityPropagation(random_state=5).fit(X)
>>> clustering
AffinityPropagation(random_state=5)
>>> clustering.labels_
array([0, 0, 0, 1, 1, 1])
>>> clustering.predict([[0, 0], [4, 4]])
array([0, 1])
>>> clustering.cluster_centers_
array([[1, 2],
       [4, 2]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the clustering from features, or affinity matrix.

* **Parameters:**
  **X**
  : Training instances to cluster, or similarities / affinities between
    instances if `affinity='precomputed'`. If a sparse feature matrix
    is provided, it will be converted into a sparse `csr_matrix`.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  self
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None)

Fit clustering from features/affinity matrix; return cluster labels.

* **Parameters:**
  **X**
  : Training instances to cluster, or similarities / affinities between
    instances if `affinity='precomputed'`. If a sparse feature matrix
    is provided, it will be converted into a sparse `csr_matrix`.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **labels**
  : Cluster labels.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict the closest cluster each sample in X belongs to.

* **Parameters:**
  **X**
  : New data to predict. If a sparse matrix is provided, it will be
    converted into a sparse `csr_matrix`.
* **Returns:**
  **labels**
  : Cluster labels.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Reference: Brendan J. Frey and Delbert Dueck, &quot;Clustering by Passing Messages Between Data Points&quot;, Science Feb. 2007">  <div class="sphx-glr-thumbnail-title">Demo of affinity propagation clustering algorithm</div>
</div>
* [Demo of affinity propagation clustering algorithm](../../auto_examples/cluster/plot_affinity_propagation.md#sphx-glr-auto-examples-cluster-plot-affinity-propagation-py)

<!-- thumbnail-parent-div-close --></div>
