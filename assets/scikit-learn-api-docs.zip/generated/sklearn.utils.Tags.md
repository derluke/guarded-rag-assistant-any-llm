# Tags

### *class* sklearn.utils.Tags(estimator_type: str | None, target_tags: TargetTags, transformer_tags: TransformerTags | None = None, classifier_tags: ClassifierTags | None = None, regressor_tags: RegressorTags | None = None, array_api_support: bool = False, no_validation: bool = False, non_deterministic: bool = False, requires_fit: bool = True, \_skip_test: bool = False, input_tags: InputTags = <factory>)

Tags for the estimator.

See [Estimator Tags](../../developers/develop.md#estimator-tags) for more information.

* **Parameters:**
  **estimator_type**
  : The type of the estimator. Can be one of:
    - “classifier”
    - “regressor”
    - “transformer”
    - “clusterer”
    - “outlier_detector”
    - “density_estimator”

  **target_tags**
  : The target(y) tags.

  **transformer_tags**
  : The transformer tags.

  **classifier_tags**
  : The classifier tags.

  **regressor_tags**
  : The regressor tags.

  **array_api_support**
  : Whether the estimator supports Array API compatible inputs.

  **no_validation**
  : Whether the estimator skips input-validation. This is only meant for
    stateless and dummy transformers!

  **non_deterministic**
  : Whether the estimator is not deterministic given a fixed `random_state`.

  **requires_fit**
  : Whether the estimator requires to be fitted before calling one of
    `transform`, `predict`, `predict_proba`, or `decision_function`.

  **\_skip_test**
  : Whether to skip common tests entirely. Don’t use this unless
    you have a *very good* reason.

  **input_tags**
  : The input data(X) tags.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.6! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_6&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.6</div>
</div>
* [Release Highlights for scikit-learn 1.6](../../auto_examples/release_highlights/plot_release_highlights_1_6_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-6-0-py)

<!-- thumbnail-parent-div-close --></div>
