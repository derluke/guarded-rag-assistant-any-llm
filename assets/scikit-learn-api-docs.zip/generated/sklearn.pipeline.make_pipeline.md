# make_pipeline

### sklearn.pipeline.make_pipeline(\*steps, memory=None, transform_input=None, verbose=False)

Construct a [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline) from the given estimators.

This is a shorthand for the [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline) constructor; it does not
require, and does not permit, naming the estimators. Instead, their names
will be set to the lowercase of their types automatically.

* **Parameters:**
  **\*steps**
  : List of the scikit-learn estimators that are chained together.

  **memory**
  : Used to cache the fitted transformers of the pipeline. The last step
    will never be cached, even if it is a transformer. By default, no
    caching is performed. If a string is given, it is the path to the
    caching directory. Enabling caching triggers a clone of the transformers
    before fitting. Therefore, the transformer instance given to the
    pipeline cannot be inspected directly. Use the attribute `named_steps`
    or `steps` to inspect estimators within the pipeline. Caching the
    transformers is advantageous when fitting is time consuming.

  **transform_input**
  : This enables transforming some input arguments to `fit` (other than `X`)
    to be transformed by the steps of the pipeline up to the step which requires
    them. Requirement is defined via [metadata routing](../../metadata_routing.md#metadata-routing).
    This can be used to pass a validation set through the pipeline for instance.
    <br/>
    You can only set this if metadata routing is enabled, which you
    can enable using `sklearn.set_config(enable_metadata_routing=True)`.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **verbose**
  : If True, the time elapsed while fitting each step will be printed as it
    is completed.
* **Returns:**
  **p**
  : Returns a scikit-learn [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline) object.

#### SEE ALSO
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)
: Class for creating a pipeline of transforms with a final estimator.

### Examples

```pycon
>>> from sklearn.naive_bayes import GaussianNB
>>> from sklearn.preprocessing import StandardScaler
>>> from sklearn.pipeline import make_pipeline
>>> make_pipeline(StandardScaler(), GaussianNB(priors=None))
Pipeline(steps=[('standardscaler', StandardScaler()),
                ('gaussiannb', GaussianNB())])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the various initialization strategies for K-means in terms of runtime and quality of the results.">  <div class="sphx-glr-thumbnail-title">A demo of K-Means clustering on the handwritten digits data</div>
</div>
* [A demo of K-Means clustering on the handwritten digits data](../../auto_examples/cluster/plot_kmeans_digits.md#sphx-glr-auto-examples-cluster-plot-kmeans-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares Principal Component Regression (PCR) and Partial Least Squares Regression (PLS) on a toy dataset. Our goal is to illustrate how PLS can outperform PCR when the target is strongly correlated with some directions in the data that have a low variance.">  <div class="sphx-glr-thumbnail-title">Principal Component Regression vs Partial Least Squares Regression</div>
</div>
* [Principal Component Regression vs Partial Least Squares Regression](../../auto_examples/cross_decomposition/plot_pcr_vs_pls.md#sphx-glr-auto-examples-cross-decomposition-plot-pcr-vs-pls-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the training times and prediction performances of HistGradientBoostingRegressor with different encoding strategies for categorical features. In particular, we will evaluate:">  <div class="sphx-glr-thumbnail-title">Categorical Feature Support in Gradient Boosting</div>
</div>
* [Categorical Feature Support in Gradient Boosting](../../auto_examples/ensemble/plot_gradient_boosting_categorical.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-categorical-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="Transform your features into a higher dimensional, sparse space. Then train a linear model on these features.">  <div class="sphx-glr-thumbnail-title">Feature transformations with ensembles of trees</div>
</div>
* [Feature transformations with ensembles of trees](../../auto_examples/ensemble/plot_feature_transformation.md#sphx-glr-auto-examples-ensemble-plot-feature-transformation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares two approaches for feature selection: SelectFromModel which is based on feature importance, and SequentialFeatureSelector which relies on a greedy approach.">  <div class="sphx-glr-thumbnail-title">Model-based and sequential feature selection</div>
</div>
* [Model-based and sequential feature selection](../../auto_examples/feature_selection/plot_select_from_model_diabetes.md#sphx-glr-auto-examples-feature-selection-plot-select-from-model-diabetes-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how a feature selection can be easily integrated within a machine learning pipeline.">  <div class="sphx-glr-thumbnail-title">Pipeline ANOVA SVM</div>
</div>
* [Pipeline ANOVA SVM](../../auto_examples/feature_selection/plot_feature_selection_pipeline.md#sphx-glr-auto-examples-feature-selection-plot-feature-selection-pipeline-py)

<div class="sphx-glr-thumbcontainer" tooltip="This notebook is an example of using univariate feature selection to improve classification accuracy on a noisy dataset.">  <div class="sphx-glr-thumbnail-title">Univariate Feature Selection</div>
</div>
* [Univariate Feature Selection](../../auto_examples/feature_selection/plot_feature_selection.md#sphx-glr-auto-examples-feature-selection-plot-feature-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="Missing values can be replaced by the mean, the median or the most frequent value using the basic SimpleImputer.">  <div class="sphx-glr-thumbnail-title">Imputing missing values before building an estimator</div>
</div>
* [Imputing missing values before building an estimator](../../auto_examples/impute/plot_missing_values.md#sphx-glr-auto-examples-impute-plot-missing-values-py)

<div class="sphx-glr-thumbcontainer" tooltip="The IterativeImputer class is very flexible - it can be used with a variety of estimators to do round-robin regression, treating every variable as an output in turn.">  <div class="sphx-glr-thumbnail-title">Imputing missing values with variants of IterativeImputer</div>
</div>
* [Imputing missing values with variants of IterativeImputer](../../auto_examples/impute/plot_iterative_imputer_variants_comparison.md#sphx-glr-auto-examples-impute-plot-iterative-imputer-variants-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Partial dependence plots show the dependence between the target function [2]_ and a set of features of interest, marginalizing over the values of all other features (the complement features). Due to the limits of human perception, the size of the set of features of interest must be small (usually, one or two) thus they are usually chosen among the most important features.">  <div class="sphx-glr-thumbnail-title">Partial Dependence and Individual Conditional Expectation Plots</div>
</div>
* [Partial Dependence and Individual Conditional Expectation Plots](../../auto_examples/inspection/plot_partial_dependence.md#sphx-glr-auto-examples-inspection-plot-partial-dependence-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of PolynomialCountSketch to efficiently generate polynomial kernel feature-space approximations. This is used to train linear classifiers that approximate the accuracy of kernelized ones.">  <div class="sphx-glr-thumbnail-title">Scalable learning with polynomial kernel approximation</div>
</div>
* [Scalable learning with polynomial kernel approximation](../../auto_examples/kernel_approximation/plot_scalable_poly_kernels.md#sphx-glr-auto-examples-kernel-approximation-plot-scalable-poly-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two different bayesian regressors:">  <div class="sphx-glr-thumbnail-title">Comparing Linear Bayesian Regressors</div>
</div>
* [Comparing Linear Bayesian Regressors](../../auto_examples/linear_model/plot_ard.md#sphx-glr-auto-examples-linear-model-plot-ard-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example reproduces the example of Fig. 2 of [ZHT2007]_. A LassoLarsIC estimator is fit on a diabetes dataset and the AIC and the BIC criteria are used to select the best model.">  <div class="sphx-glr-thumbnail-title">Lasso model selection via information criteria</div>
</div>
* [Lasso model selection via information criteria](../../auto_examples/linear_model/plot_lasso_lars_ic.md#sphx-glr-auto-examples-linear-model-plot-lasso-lars-ic-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example focuses on model selection for Lasso models that are linear models with an L1 penalty for regression problems.">  <div class="sphx-glr-thumbnail-title">Lasso model selection: AIC-BIC / cross-validation</div>
</div>
* [Lasso model selection: AIC-BIC / cross-validation](../../auto_examples/linear_model/plot_lasso_model_selection.md#sphx-glr-auto-examples-linear-model-plot-lasso-model-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to approximate the solution of sklearn.svm.OneClassSVM in the case of an RBF kernel with sklearn.linear_model.SGDOneClassSVM, a Stochastic Gradient Descent (SGD) version of the One-Class SVM. A kernel approximation is first used in order to apply sklearn.linear_model.SGDOneClassSVM which implements a linear One-Class SVM using SGD.">  <div class="sphx-glr-thumbnail-title">One-Class SVM versus One-Class SVM using Stochastic Gradient Descent</div>
</div>
* [One-Class SVM versus One-Class SVM using Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgdocsvm_vs_ocsvm.md#sphx-glr-auto-examples-linear-model-plot-sgdocsvm-vs-ocsvm-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to approximate a function with polynomials up to degree degree by using ridge regression. We show two different ways given n_samples of 1d points x_i:">  <div class="sphx-glr-thumbnail-title">Polynomial and Spline interpolation</div>
</div>
* [Polynomial and Spline interpolation](../../auto_examples/linear_model/plot_polynomial_interpolation.md#sphx-glr-auto-examples-linear-model-plot-polynomial-interpolation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Here a sine function is fit with a polynomial of order 3, for values close to zero.">  <div class="sphx-glr-thumbnail-title">Robust linear estimator fitting</div>
</div>
* [Robust linear estimator fitting](../../auto_examples/linear_model/plot_robust_fit.md#sphx-glr-auto-examples-linear-model-plot-robust-fit-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Poisson, Gamma and Tweedie regression on the French Motor Third-Party Liability Claims dataset, and is inspired by an R tutorial [1]_.">  <div class="sphx-glr-thumbnail-title">Tweedie regression on insurance claims</div>
</div>
* [Tweedie regression on insurance claims](../../auto_examples/linear_model/plot_tweedie_regression_insurance_claims.md#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py)

<div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="    See also sphx_glr_auto_examples_miscellaneous_plot_roc_curve_visualization_api.py">  <div class="sphx-glr-thumbnail-title">Advanced Plotting With Partial Dependence</div>
</div>
* [Advanced Plotting With Partial Dependence](../../auto_examples/miscellaneous/plot_partial_dependence_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-partial-dependence-visualization-api-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different anomaly detection algorithms on 2D datasets. Datasets contain one or two modes (regions of high density) to illustrate the ability of algorithms to cope with multimodal data.">  <div class="sphx-glr-thumbnail-title">Comparing anomaly detection algorithms for outlier detection on toy datasets</div>
</div>
* [Comparing anomaly detection algorithms for outlier detection on toy datasets](../../auto_examples/miscellaneous/plot_anomaly_comparison.md#sphx-glr-auto-examples-miscellaneous-plot-anomaly-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="The default configuration for displaying a pipeline in a Jupyter Notebook is &#x27;diagram&#x27; where set_config(display=&#x27;diagram&#x27;). To deactivate HTML representation, use set_config(display=&#x27;text&#x27;).">  <div class="sphx-glr-thumbnail-title">Displaying Pipelines</div>
</div>
* [Displaying Pipelines](../../auto_examples/miscellaneous/plot_pipeline_display.md#sphx-glr-auto-examples-miscellaneous-plot-pipeline-display-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates different ways estimators and pipelines can be displayed.">  <div class="sphx-glr-thumbnail-title">Displaying estimators and complex pipelines</div>
</div>
* [Displaying estimators and complex pipelines](../../auto_examples/miscellaneous/plot_estimator_representation.md#sphx-glr-auto-examples-miscellaneous-plot-estimator-representation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example will demonstrate the set_output API to configure transformers to output pandas DataFrames. set_output can be configured per estimator by calling the set_output method or globally by setting set_config(transform_output=&quot;pandas&quot;). For details, see SLEP018.">  <div class="sphx-glr-thumbnail-title">Introducing the set_output API</div>
</div>
* [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we compare two binary classification multi-threshold metrics: the Receiver Operating Characteristic (ROC) and the Detection Error Tradeoff (DET). For such purpose, we evaluate two different classifiers for the same classification task.">  <div class="sphx-glr-thumbnail-title">Detection error tradeoff (DET) curve</div>
</div>
* [Detection error tradeoff (DET) curve](../../auto_examples/model_selection/plot_det.md#sphx-glr-auto-examples-model-selection-plot-det-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a binary classifier is trained, the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. The default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0. However, this default strategy may not be optimal for the task at hand.">  <div class="sphx-glr-thumbnail-title">Post-hoc tuning the cut-off point of decision function</div>
</div>
* [Post-hoc tuning the cut-off point of decision function](../../auto_examples/model_selection/plot_tuned_decision_threshold.md#sphx-glr-auto-examples-model-selection-plot-tuned-decision-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents how to chain KNeighborsTransformer and TSNE in a pipeline. It also shows how to wrap the packages nmslib and pynndescent to replace KNeighborsTransformer and perform approximate nearest neighbors. These packages can be installed with pip install nmslib pynndescent.">  <div class="sphx-glr-thumbnail-title">Approximate nearest neighbors in TSNE</div>
</div>
* [Approximate nearest neighbors in TSNE](../../auto_examples/neighbors/approximate_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-approximate-nearest-neighbors-py)

<div class="sphx-glr-thumbcontainer" tooltip="Sample usage of Neighborhood Components Analysis for dimensionality reduction.">  <div class="sphx-glr-thumbnail-title">Dimensionality Reduction with Neighborhood Components Analysis</div>
</div>
* [Dimensionality Reduction with Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_dim_reduction.md#sphx-glr-auto-examples-neighbors-plot-nca-dim-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="A comparison of different values for regularization parameter &#x27;alpha&#x27; on synthetic datasets. The plot shows that different alphas yield different decision functions.">  <div class="sphx-glr-thumbnail-title">Varying regularization in Multi-layer Perceptron</div>
</div>
* [Varying regularization in Multi-layer Perceptron](../../auto_examples/neural_networks/plot_mlp_alpha.md#sphx-glr-auto-examples-neural-networks-plot-mlp-alpha-py)

<div class="sphx-glr-thumbcontainer" tooltip="The TargetEncoder uses the value of the target to encode each categorical feature. In this example, we will compare three different approaches for handling categorical features: TargetEncoder, OrdinalEncoder, OneHotEncoder and dropping the category.">  <div class="sphx-glr-thumbnail-title">Comparing Target Encoder with Other Encoders</div>
</div>
* [Comparing Target Encoder with Other Encoders](../../auto_examples/preprocessing/plot_target_encoder.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-py)

<div class="sphx-glr-thumbcontainer" tooltip="A demonstration of feature discretization on synthetic classification datasets. Feature discretization decomposes each feature into a set of bins, here equally distributed in width. The discrete values are then one-hot encoded, and given to a linear classifier. This preprocessing enables a non-linear behavior even though the classifier is linear.">  <div class="sphx-glr-thumbnail-title">Feature discretization</div>
</div>
* [Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature scaling through standardization, also called Z-score normalization, is an important preprocessing step for many machine learning algorithms. It involves rescaling each feature such that it has a standard deviation of 1 and a mean of 0.">  <div class="sphx-glr-thumbnail-title">Importance of Feature Scaling</div>
</div>
* [Importance of Feature Scaling](../../auto_examples/preprocessing/plot_scaling_importance.md#sphx-glr-auto-examples-preprocessing-plot-scaling-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="The TargetEncoder replaces each category of a categorical feature with the shrunk mean of the target variable for that category. This method is useful in cases where there is a strong relationship between the categorical feature and the target. To prevent overfitting, TargetEncoder.fit_transform uses an internal cross fitting scheme to encode the training data to be used by a downstream model. This scheme involves splitting the data into k folds and encoding each fold using the encodings learnt using the other k-1 folds. In this example, we demonstrate the importance of the cross fitting procedure to prevent overfitting.">  <div class="sphx-glr-thumbnail-title">Target Encoder's Internal Cross fitting</div>
</div>
* [Target Encoder’s Internal Cross fitting](../../auto_examples/preprocessing/plot_target_encoder_cross_val.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-cross-val-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how the scikit-learn API can be used to cluster documents by topics using a Bag of Words approach.">  <div class="sphx-glr-thumbnail-title">Clustering text documents using k-means</div>
</div>
* [Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.2! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_2&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.2</div>
</div>
* [Release Highlights for scikit-learn 1.2](../../auto_examples/release_highlights/plot_release_highlights_1_2_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-2-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are very pleased to announce the release of scikit-learn 1.0! The library has been stable for quite some time, releasing version 1.0 is recognizing that and signalling it to our users. This release does not include any breaking changes apart from the usual two-release deprecation cycle. For the future, we do our best to keep this pattern.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.0</div>
</div>
* [Release Highlights for scikit-learn 1.0](../../auto_examples/release_highlights/plot_release_highlights_1_0_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-0-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
