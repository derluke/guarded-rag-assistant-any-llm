# OrdinalEncoder

### *class* sklearn.preprocessing.OrdinalEncoder(\*, categories='auto', dtype=<class 'numpy.float64'>, handle_unknown='error', unknown_value=None, encoded_missing_value=nan, min_frequency=None, max_categories=None)

Encode categorical features as an integer array.

The input to this transformer should be an array-like of integers or
strings, denoting the values taken on by categorical (discrete) features.
The features are converted to ordinal integers. This results in
a single column of integers (0 to n_categories - 1) per feature.

Read more in the [User Guide](../preprocessing.md#preprocessing-categorical-features).
For a comparison of different encoders, refer to:
[Comparing Target Encoder with Other Encoders](../../auto_examples/preprocessing/plot_target_encoder.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-py).

#### Versionadded
Added in version 0.20.

* **Parameters:**
  **categories**
  : Categories (unique values) per feature:
    - ‘auto’ : Determine categories automatically from the training data.
    - list : `categories[i]` holds the categories expected in the ith
      column. The passed categories should not mix strings and numeric
      values, and should be sorted in case of numeric values.
    <br/>
    The used categories can be found in the `categories_` attribute.

  **dtype**
  : Desired dtype of output.

  **handle_unknown**
  : When set to ‘error’ an error will be raised in case an unknown
    categorical feature is present during transform. When set to
    ‘use_encoded_value’, the encoded value of unknown categories will be
    set to the value given for the parameter `unknown_value`. In
    [`inverse_transform`](#sklearn.preprocessing.OrdinalEncoder.inverse_transform), an unknown category will be denoted as None.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **unknown_value**
  : When the parameter handle_unknown is set to ‘use_encoded_value’, this
    parameter is required and will set the encoded value of unknown
    categories. It has to be distinct from the values used to encode any of
    the categories in `fit`. If set to np.nan, the `dtype` parameter must
    be a float dtype.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **encoded_missing_value**
  : Encoded value of missing categories. If set to `np.nan`, then the `dtype`
    parameter must be a float dtype.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **min_frequency**
  : Specifies the minimum frequency below which a category will be
    considered infrequent.
    - If `int`, categories with a smaller cardinality will be considered
      infrequent.
    - If `float`, categories with a smaller cardinality than
      `min_frequency * n_samples`  will be considered infrequent.
    <br/>
    #### Versionadded
    Added in version 1.3: Read more in the [User Guide](../preprocessing.md#encoder-infrequent-categories).

  **max_categories**
  : Specifies an upper limit to the number of output categories for each input
    feature when considering infrequent categories. If there are infrequent
    categories, `max_categories` includes the category representing the
    infrequent categories along with the frequent categories. If `None`,
    there is no limit to the number of output features.
    <br/>
    `max_categories` do **not** take into account missing or unknown
    categories. Setting `unknown_value` or `encoded_missing_value` to an
    integer will increase the number of unique integer codes by one each.
    This can result in up to `max_categories + 2` integer codes.
    <br/>
    #### Versionadded
    Added in version 1.3: Read more in the [User Guide](../preprocessing.md#encoder-infrequent-categories).
* **Attributes:**
  **categories_**
  : The categories of each feature determined during `fit` (in order of
    the features in X and corresponding with the output of `transform`).
    This does not include categories that weren’t seen during `fit`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 1.0.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  [`infrequent_categories_`](#sklearn.preprocessing.OrdinalEncoder.infrequent_categories_)
  : Infrequent categories for each feature.

#### SEE ALSO
[`OneHotEncoder`](sklearn.preprocessing.OneHotEncoder.md#sklearn.preprocessing.OneHotEncoder)
: Performs a one-hot encoding of categorical features. This encoding is suitable for low to medium cardinality categorical variables, both in supervised and unsupervised settings.

[`TargetEncoder`](sklearn.preprocessing.TargetEncoder.md#sklearn.preprocessing.TargetEncoder)
: Encodes categorical features using supervised signal in a classification or regression pipeline. This encoding is typically suitable for high cardinality categorical variables.

[`LabelEncoder`](sklearn.preprocessing.LabelEncoder.md#sklearn.preprocessing.LabelEncoder)
: Encodes target labels with values between 0 and `n_classes-1`.

### Notes

With a high proportion of `nan` values, inferring categories becomes slow with
Python versions before 3.10. The handling of `nan` values was improved
from Python 3.10 onwards, (c.f.
[bpo-43475](https://github.com/python/cpython/issues/87641)).

### Examples

Given a dataset with two features, we let the encoder find the unique
values per feature and transform the data to an ordinal encoding.

```pycon
>>> from sklearn.preprocessing import OrdinalEncoder
>>> enc = OrdinalEncoder()
>>> X = [['Male', 1], ['Female', 3], ['Female', 2]]
>>> enc.fit(X)
OrdinalEncoder()
>>> enc.categories_
[array(['Female', 'Male'], dtype=object), array([1, 2, 3], dtype=object)]
>>> enc.transform([['Female', 3], ['Male', 1]])
array([[0., 2.],
       [1., 0.]])
```

```pycon
>>> enc.inverse_transform([[1, 0], [0, 1]])
array([['Male', 1],
       ['Female', 2]], dtype=object)
```

By default, [`OrdinalEncoder`](#sklearn.preprocessing.OrdinalEncoder) is lenient towards missing values by
propagating them.

```pycon
>>> import numpy as np
>>> X = [['Male', 1], ['Female', 3], ['Female', np.nan]]
>>> enc.fit_transform(X)
array([[ 1.,  0.],
       [ 0.,  1.],
       [ 0., nan]])
```

You can use the parameter `encoded_missing_value` to encode missing values.

```pycon
>>> enc.set_params(encoded_missing_value=-1).fit_transform(X)
array([[ 1.,  0.],
       [ 0.,  1.],
       [ 0., -1.]])
```

Infrequent categories are enabled by setting `max_categories` or `min_frequency`.
In the following example, “a” and “d” are considered infrequent and grouped
together into a single category, “b” and “c” are their own categories, unknown
values are encoded as 3 and missing values are encoded as 4.

```pycon
>>> X_train = np.array(
...     [["a"] * 5 + ["b"] * 20 + ["c"] * 10 + ["d"] * 3 + [np.nan]],
...     dtype=object).T
>>> enc = OrdinalEncoder(
...     handle_unknown="use_encoded_value", unknown_value=3,
...     max_categories=3, encoded_missing_value=4)
>>> _ = enc.fit(X_train)
>>> X_test = np.array([["a"], ["b"], ["c"], ["d"], ["e"], [np.nan]], dtype=object)
>>> enc.transform(X_test)
array([[2.],
       [0.],
       [1.],
       [2.],
       [3.],
       [4.]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the OrdinalEncoder to X.

* **Parameters:**
  **X**
  : The data to determine the categories of each feature.

  **y**
  : Ignored. This parameter exists only for compatibility with
    [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline).
* **Returns:**
  **self**
  : Fitted encoder.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Same as input features.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* infrequent_categories_

Infrequent categories for each feature.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Convert the data back to the original representation.

* **Parameters:**
  **X**
  : The transformed data.
* **Returns:**
  **X_tr**
  : Inverse transformed array.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform X to ordinal codes.

* **Parameters:**
  **X**
  : The data to encode.
* **Returns:**
  **X_out**
  : Transformed input.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the training times and prediction performances of HistGradientBoostingRegressor with different encoding strategies for categorical features. In particular, we will evaluate:">  <div class="sphx-glr-thumbnail-title">Categorical Feature Support in Gradient Boosting</div>
</div>
* [Categorical Feature Support in Gradient Boosting](../../auto_examples/ensemble/plot_gradient_boosting_categorical.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-categorical-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="Partial dependence plots show the dependence between the target function [2]_ and a set of features of interest, marginalizing over the values of all other features (the complement features). Due to the limits of human perception, the size of the set of features of interest must be small (usually, one or two) thus they are usually chosen among the most important features.">  <div class="sphx-glr-thumbnail-title">Partial Dependence and Individual Conditional Expectation Plots</div>
</div>
* [Partial Dependence and Individual Conditional Expectation Plots](../../auto_examples/inspection/plot_partial_dependence.md#sphx-glr-auto-examples-inspection-plot-partial-dependence-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will compare the impurity-based feature importance of RandomForestClassifier with the permutation importance on the titanic dataset using permutation_importance. We will show that the impurity-based feature importance can inflate the importance of numerical features.">  <div class="sphx-glr-thumbnail-title">Permutation Importance vs Random Forest Feature Importance (MDI)</div>
</div>
* [Permutation Importance vs Random Forest Feature Importance (MDI)](../../auto_examples/inspection/plot_permutation_importance.md#sphx-glr-auto-examples-inspection-plot-permutation-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="The TargetEncoder uses the value of the target to encode each categorical feature. In this example, we will compare three different approaches for handling categorical features: TargetEncoder, OrdinalEncoder, OneHotEncoder and dropping the category.">  <div class="sphx-glr-thumbnail-title">Comparing Target Encoder with Other Encoders</div>
</div>
* [Comparing Target Encoder with Other Encoders](../../auto_examples/preprocessing/plot_target_encoder.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.3! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_3&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.3</div>
</div>
* [Release Highlights for scikit-learn 1.3](../../auto_examples/release_highlights/plot_release_highlights_1_3_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-3-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.2! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_2&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.2</div>
</div>
* [Release Highlights for scikit-learn 1.2](../../auto_examples/release_highlights/plot_release_highlights_1_2_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-2-0-py)

<!-- thumbnail-parent-div-close --></div>
