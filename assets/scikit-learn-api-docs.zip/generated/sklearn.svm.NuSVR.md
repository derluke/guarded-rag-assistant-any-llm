# NuSVR

### *class* sklearn.svm.NuSVR(\*, nu=0.5, C=1.0, kernel='rbf', degree=3, gamma='scale', coef0=0.0, shrinking=True, tol=0.001, cache_size=200, verbose=False, max_iter=-1)

Nu Support Vector Regression.

Similar to NuSVC, for regression, uses a parameter nu to control
the number of support vectors. However, unlike NuSVC, where nu
replaces C, here nu replaces the parameter epsilon of epsilon-SVR.

The implementation is based on libsvm.

Read more in the [User Guide](../svm.md#svm-regression).

* **Parameters:**
  **nu**
  : An upper bound on the fraction of training errors and a lower bound of
    the fraction of support vectors. Should be in the interval (0, 1].  By
    default 0.5 will be taken.

  **C**
  : Penalty parameter C of the error term. For an intuitive visualization
    of the effects of scaling the regularization parameter C, see
    [Scaling the regularization parameter for SVCs](../../auto_examples/svm/plot_svm_scale_c.md#sphx-glr-auto-examples-svm-plot-svm-scale-c-py).

  **kernel**
  : Specifies the kernel type to be used in the algorithm.
    If none is given, ‘rbf’ will be used. If a callable is given it is
    used to precompute the kernel matrix.
    For an intuitive visualization of different kernel types see
    See [Support Vector Regression (SVR) using linear and non-linear kernels](../../auto_examples/svm/plot_svm_regression.md#sphx-glr-auto-examples-svm-plot-svm-regression-py)

  **degree**
  : Degree of the polynomial kernel function (‘poly’).
    Must be non-negative. Ignored by all other kernels.

  **gamma**
  : Kernel coefficient for ‘rbf’, ‘poly’ and ‘sigmoid’.
    - if `gamma='scale'` (default) is passed then it uses
      1 / (n_features \* X.var()) as value of gamma,
    - if ‘auto’, uses 1 / n_features
    - if float, must be non-negative.
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default value of `gamma` changed from ‘auto’ to ‘scale’.

  **coef0**
  : Independent term in kernel function.
    It is only significant in ‘poly’ and ‘sigmoid’.

  **shrinking**
  : Whether to use the shrinking heuristic.
    See the [User Guide](../svm.md#shrinking-svm).

  **tol**
  : Tolerance for stopping criterion.

  **cache_size**
  : Specify the size of the kernel cache (in MB).

  **verbose**
  : Enable verbose output. Note that this setting takes advantage of a
    per-process runtime setting in libsvm that, if enabled, may not work
    properly in a multithreaded context.

  **max_iter**
  : Hard limit on iterations within solver, or -1 for no limit.
* **Attributes:**
  [`coef_`](#sklearn.svm.NuSVR.coef_)
  : Weights assigned to the features when `kernel="linear"`.

  **dual_coef_**
  : Coefficients of the support vector in the decision function.

  **fit_status_**
  : 0 if correctly fitted, 1 otherwise (will raise warning)

  **intercept_**
  : Constants in decision function.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Number of iterations run by the optimization routine to fit the model.
    <br/>
    #### Versionadded
    Added in version 1.1.

  [`n_support_`](#sklearn.svm.NuSVR.n_support_)
  : Number of support vectors for each class.

  **shape_fit_**
  : Array dimensions of training vector `X`.

  **support_**
  : Indices of support vectors.

  **support_vectors_**
  : Support vectors.

#### SEE ALSO
[`NuSVC`](sklearn.svm.NuSVC.md#sklearn.svm.NuSVC)
: Support Vector Machine for classification implemented with libsvm with a parameter to control the number of support vectors.

[`SVR`](sklearn.svm.SVR.md#sklearn.svm.SVR)
: Epsilon Support Vector Machine for regression implemented with libsvm.

### References

### Examples

```pycon
>>> from sklearn.svm import NuSVR
>>> from sklearn.pipeline import make_pipeline
>>> from sklearn.preprocessing import StandardScaler
>>> import numpy as np
>>> n_samples, n_features = 10, 5
>>> np.random.seed(0)
>>> y = np.random.randn(n_samples)
>>> X = np.random.randn(n_samples, n_features)
>>> regr = make_pipeline(StandardScaler(), NuSVR(C=1.0, nu=0.1))
>>> regr.fit(X, y)
Pipeline(steps=[('standardscaler', StandardScaler()),
                ('nusvr', NuSVR(nu=0.1))])
```

<!-- !! processed by numpydoc !! -->

#### *property* coef_

Weights assigned to the features when `kernel="linear"`.

* **Returns:**
  ndarray of shape (n_features, n_classes)

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the SVM model according to the given training data.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples
    and `n_features` is the number of features.
    For kernel=”precomputed”, the expected shape of X is
    (n_samples, n_samples).

  **y**
  : Target values (class labels in classification, real numbers in
    regression).

  **sample_weight**
  : Per-sample weights. Rescale C per sample. Higher weights
    force the classifier to put more emphasis on these points.
* **Returns:**
  **self**
  : Fitted estimator.

### Notes

If X and y are not C-ordered and contiguous arrays of np.float64 and
X is not a scipy.sparse.csr_matrix, X and/or y may be copied.

If X is a dense array, then the other methods will not support sparse
matrices as input.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_support_

Number of support vectors for each class.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Perform regression on samples in X.

For an one-class model, +1 (inlier) or -1 (outlier) is returned.

* **Parameters:**
  **X**
  : For kernel=”precomputed”, the expected shape of X is
    (n_samples_test, n_samples_train).
* **Returns:**
  **y_pred**
  : The predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [NuSVR](#sklearn.svm.NuSVR)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [NuSVR](#sklearn.svm.NuSVR)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Demonstrate how model complexity influences both prediction accuracy and computational performance.">  <div class="sphx-glr-thumbnail-title">Model Complexity Influence</div>
</div>
* [Model Complexity Influence](../../auto_examples/applications/plot_model_complexity_influence.md#sphx-glr-auto-examples-applications-plot-model-complexity-influence-py)

<!-- thumbnail-parent-div-close --></div>
