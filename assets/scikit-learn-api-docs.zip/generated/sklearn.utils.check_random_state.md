# check_random_state

### sklearn.utils.check_random_state(seed)

Turn seed into a np.random.RandomState instance.

* **Parameters:**
  **seed**
  : If seed is None, return the RandomState singleton used by np.random.
    If seed is an int, return a new RandomState instance seeded with seed.
    If seed is already a RandomState instance, return it.
    Otherwise raise ValueError.
* **Returns:**
  [`numpy.random.RandomState`](https://numpy.org/doc/stable/reference/random/legacy.html#numpy.random.RandomState)
  : The random state object based on `seed` parameter.

### Examples

```pycon
>>> from sklearn.utils.validation import check_random_state
>>> check_random_state(42)
RandomState(MT19937) at 0x...
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Evaluate the ability of k-means initializations strategies to make the algorithm convergence robust, as measured by the relative standard deviation of the inertia of the clustering (i.e. the sum of squared distances to the nearest cluster center).">  <div class="sphx-glr-thumbnail-title">Empirical evaluation of the impact of k-means initialization</div>
</div>
* [Empirical evaluation of the impact of k-means initialization](../../auto_examples/cluster/plot_kmeans_stability_low_dim_dense.md#sphx-glr-auto-examples-cluster-plot-kmeans-stability-low-dim-dense-py)

<div class="sphx-glr-thumbcontainer" tooltip="Here we fit a multinomial logistic regression with L1 penalty on a subset of the MNIST digits classification task. We use the SAGA algorithm for this purpose: this a solver that is fast when the number of samples is significantly larger than the number of features and is able to finely optimize non-smooth objective functions which is the case with the l1-penalty. Test accuracy reaches &gt; 0.8, while weight vectors remains sparse and therefore more easily interpretable.">  <div class="sphx-glr-thumbnail-title">MNIST classification using multinomial logistic + L1</div>
</div>
* [MNIST classification using multinomial logistic + L1](../../auto_examples/linear_model/plot_sparse_logistic_regression_mnist.md#sphx-glr-auto-examples-linear-model-plot-sparse-logistic-regression-mnist-py)

<div class="sphx-glr-thumbcontainer" tooltip="An application of the different manifold techniques on a spherical data-set. Here one can see the use of dimensionality reduction in order to gain some intuition regarding the manifold learning methods. Regarding the dataset, the poles are cut from the sphere, as well as a thin slice down its side. This enables the manifold learning techniques to &#x27;spread it open&#x27; whilst projecting it onto two dimensions.">  <div class="sphx-glr-thumbnail-title">Manifold Learning methods on a severed sphere</div>
</div>
* [Manifold Learning methods on a severed sphere](../../auto_examples/manifold/plot_manifold_sphere.md#sphx-glr-auto-examples-manifold-plot-manifold-sphere-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows the use of multi-output estimator to complete images. The goal is to predict the lower half of a face given its upper half.">  <div class="sphx-glr-thumbnail-title">Face completion with a multi-output estimators</div>
</div>
* [Face completion with a multi-output estimators](../../auto_examples/miscellaneous/plot_multioutput_face_completion.md#sphx-glr-auto-examples-miscellaneous-plot-multioutput-face-completion-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of the isotonic regression on generated data (non-linear monotonic trend with homoscedastic uniform noise).">  <div class="sphx-glr-thumbnail-title">Isotonic Regression</div>
</div>
* [Isotonic Regression](../../auto_examples/miscellaneous/plot_isotonic_regression.md#sphx-glr-auto-examples-miscellaneous-plot-isotonic-regression-py)

<!-- thumbnail-parent-div-close --></div>
