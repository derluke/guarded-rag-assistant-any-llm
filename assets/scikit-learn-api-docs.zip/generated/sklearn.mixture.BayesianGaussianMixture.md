# BayesianGaussianMixture

### *class* sklearn.mixture.BayesianGaussianMixture(\*, n_components=1, covariance_type='full', tol=0.001, reg_covar=1e-06, max_iter=100, n_init=1, init_params='kmeans', weight_concentration_prior_type='dirichlet_process', weight_concentration_prior=None, mean_precision_prior=None, mean_prior=None, degrees_of_freedom_prior=None, covariance_prior=None, random_state=None, warm_start=False, verbose=0, verbose_interval=10)

Variational Bayesian estimation of a Gaussian mixture.

This class allows to infer an approximate posterior distribution over the
parameters of a Gaussian mixture distribution. The effective number of
components can be inferred from the data.

This class implements two types of prior for the weights distribution: a
finite mixture model with Dirichlet distribution and an infinite mixture
model with the Dirichlet Process. In practice Dirichlet Process inference
algorithm is approximated and uses a truncated distribution with a fixed
maximum number of components (called the Stick-breaking representation).
The number of components actually used almost always depends on the data.

#### Versionadded
Added in version 0.18.

Read more in the [User Guide](../mixture.md#bgmm).

* **Parameters:**
  **n_components**
  : The number of mixture components. Depending on the data and the value
    of the `weight_concentration_prior` the model can decide to not use
    all the components by setting some component `weights_` to values very
    close to zero. The number of effective components is therefore smaller
    than n_components.

  **covariance_type**
  : String describing the type of covariance parameters to use.
    Must be one of:
    - ‘full’ (each component has its own general covariance matrix),
    - ‘tied’ (all components share the same general covariance matrix),
    - ‘diag’ (each component has its own diagonal covariance matrix),
    - ‘spherical’ (each component has its own single variance).

  **tol**
  : The convergence threshold. EM iterations will stop when the
    lower bound average gain on the likelihood (of the training data with
    respect to the model) is below this threshold.

  **reg_covar**
  : Non-negative regularization added to the diagonal of covariance.
    Allows to assure that the covariance matrices are all positive.

  **max_iter**
  : The number of EM iterations to perform.

  **n_init**
  : The number of initializations to perform. The result with the highest
    lower bound value on the likelihood is kept.

  **init_params**
  : The method used to initialize the weights, the means and the
    covariances. String must be one of:
    - ‘kmeans’: responsibilities are initialized using kmeans.
    - ‘k-means++’: use the k-means++ method to initialize.
    - ‘random’: responsibilities are initialized randomly.
    - ‘random_from_data’: initial means are randomly selected data points.
    <br/>
    #### Versionchanged
    Changed in version v1.1: `init_params` now accepts ‘random_from_data’ and ‘k-means++’ as
    initialization methods.

  **weight_concentration_prior_type**
  : String describing the type of the weight concentration prior.

  **weight_concentration_prior**
  : The dirichlet concentration of each component on the weight
    distribution (Dirichlet). This is commonly called gamma in the
    literature. The higher concentration puts more mass in
    the center and will lead to more components being active, while a lower
    concentration parameter will lead to more mass at the edge of the
    mixture weights simplex. The value of the parameter must be greater
    than 0. If it is None, it’s set to `1. / n_components`.

  **mean_precision_prior**
  : The precision prior on the mean distribution (Gaussian).
    Controls the extent of where means can be placed. Larger
    values concentrate the cluster means around `mean_prior`.
    The value of the parameter must be greater than 0.
    If it is None, it is set to 1.

  **mean_prior**
  : The prior on the mean distribution (Gaussian).
    If it is None, it is set to the mean of X.

  **degrees_of_freedom_prior**
  : The prior of the number of degrees of freedom on the covariance
    distributions (Wishart). If it is None, it’s set to `n_features`.

  **covariance_prior**
  : The prior on the covariance distribution (Wishart).
    If it is None, the emiprical covariance prior is initialized using the
    covariance of X. The shape depends on `covariance_type`:
    ```default
    (n_features, n_features) if 'full',
    (n_features, n_features) if 'tied',
    (n_features)             if 'diag',
    float                    if 'spherical'
    ```

  **random_state**
  : Controls the random seed given to the method chosen to initialize the
    parameters (see `init_params`).
    In addition, it controls the generation of random samples from the
    fitted distribution (see the method `sample`).
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **warm_start**
  : If ‘warm_start’ is True, the solution of the last fitting is used as
    initialization for the next call of fit(). This can speed up
    convergence when fit is called several times on similar problems.
    See [the Glossary](../../glossary.md#term-warm_start).

  **verbose**
  : Enable verbose output. If 1 then it prints the current
    initialization and each iteration step. If greater than 1 then
    it prints also the log probability and the time needed
    for each step.

  **verbose_interval**
  : Number of iteration done before the next print.
* **Attributes:**
  **weights_**
  : The weights of each mixture components.

  **means_**
  : The mean of each mixture component.

  **covariances_**
  : The covariance of each mixture component.
    The shape depends on `covariance_type`:
    ```default
    (n_components,)                        if 'spherical',
    (n_features, n_features)               if 'tied',
    (n_components, n_features)             if 'diag',
    (n_components, n_features, n_features) if 'full'
    ```

  **precisions_**
  : The precision matrices for each component in the mixture. A precision
    matrix is the inverse of a covariance matrix. A covariance matrix is
    symmetric positive definite so the mixture of Gaussian can be
    equivalently parameterized by the precision matrices. Storing the
    precision matrices instead of the covariance matrices makes it more
    efficient to compute the log-likelihood of new samples at test time.
    The shape depends on `covariance_type`:
    ```default
    (n_components,)                        if 'spherical',
    (n_features, n_features)               if 'tied',
    (n_components, n_features)             if 'diag',
    (n_components, n_features, n_features) if 'full'
    ```

  **precisions_cholesky_**
  : The cholesky decomposition of the precision matrices of each mixture
    component. A precision matrix is the inverse of a covariance matrix.
    A covariance matrix is symmetric positive definite so the mixture of
    Gaussian can be equivalently parameterized by the precision matrices.
    Storing the precision matrices instead of the covariance matrices makes
    it more efficient to compute the log-likelihood of new samples at test
    time. The shape depends on `covariance_type`:
    ```default
    (n_components,)                        if 'spherical',
    (n_features, n_features)               if 'tied',
    (n_components, n_features)             if 'diag',
    (n_components, n_features, n_features) if 'full'
    ```

  **converged_**
  : True when convergence of the best fit of inference was reached, False otherwise.

  **n_iter_**
  : Number of step used by the best fit of inference to reach the
    convergence.

  **lower_bound_**
  : Lower bound value on the model evidence (of the training data) of the
    best fit of inference.

  **weight_concentration_prior_**
  : The dirichlet concentration of each component on the weight
    distribution (Dirichlet). The type depends on
    `weight_concentration_prior_type`:
    ```default
    (float, float) if 'dirichlet_process' (Beta parameters),
    float          if 'dirichlet_distribution' (Dirichlet parameters).
    ```
    <br/>
    The higher concentration puts more mass in
    the center and will lead to more components being active, while a lower
    concentration parameter will lead to more mass at the edge of the
    simplex.

  **weight_concentration_**
  : The dirichlet concentration of each component on the weight
    distribution (Dirichlet).

  **mean_precision_prior_**
  : The precision prior on the mean distribution (Gaussian).
    Controls the extent of where means can be placed.
    Larger values concentrate the cluster means around `mean_prior`.
    If mean_precision_prior is set to None, `mean_precision_prior_` is set
    to 1.

  **mean_precision_**
  : The precision of each components on the mean distribution (Gaussian).

  **mean_prior_**
  : The prior on the mean distribution (Gaussian).

  **degrees_of_freedom_prior_**
  : The prior of the number of degrees of freedom on the covariance
    distributions (Wishart).

  **degrees_of_freedom_**
  : The number of degrees of freedom of each components in the model.

  **covariance_prior_**
  : The prior on the covariance distribution (Wishart).
    The shape depends on `covariance_type`:
    ```default
    (n_features, n_features) if 'full',
    (n_features, n_features) if 'tied',
    (n_features)             if 'diag',
    float                    if 'spherical'
    ```

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`GaussianMixture`](sklearn.mixture.GaussianMixture.md#sklearn.mixture.GaussianMixture)
: Finite Gaussian mixture fit with EM.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.mixture import BayesianGaussianMixture
>>> X = np.array([[1, 2], [1, 4], [1, 0], [4, 2], [12, 4], [10, 7]])
>>> bgm = BayesianGaussianMixture(n_components=2, random_state=42).fit(X)
>>> bgm.means_
array([[2.49... , 2.29...],
       [8.45..., 4.52... ]])
>>> bgm.predict([[0, 0], [9, 3]])
array([0, 1])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Estimate model parameters with the EM algorithm.

The method fits the model `n_init` times and sets the parameters with
which the model has the largest likelihood or lower bound. Within each
trial, the method iterates between E-step and M-step for `max_iter`
times until the change of likelihood or lower bound is less than
`tol`, otherwise, a `ConvergenceWarning` is raised.
If `warm_start` is `True`, then `n_init` is ignored and a single
initialization is performed upon the first call. Upon consecutive
calls, training starts where it left off.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : The fitted mixture.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None)

Estimate model parameters using X and predict the labels for X.

The method fits the model n_init times and sets the parameters with
which the model has the largest likelihood or lower bound. Within each
trial, the method iterates between E-step and M-step for `max_iter`
times until the change of likelihood or lower bound is less than
`tol`, otherwise, a [`ConvergenceWarning`](sklearn.exceptions.ConvergenceWarning.md#sklearn.exceptions.ConvergenceWarning) is
raised. After fitting, it predicts the most probable label for the
input data points.

#### Versionadded
Added in version 0.20.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **labels**
  : Component labels.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict the labels for the data samples in X using trained model.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.
* **Returns:**
  **labels**
  : Component labels.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Evaluate the components’ density for each sample.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.
* **Returns:**
  **resp**
  : Density of each Gaussian component for each sample in X.

<!-- !! processed by numpydoc !! -->

#### sample(n_samples=1)

Generate random samples from the fitted Gaussian distribution.

* **Parameters:**
  **n_samples**
  : Number of samples to generate.
* **Returns:**
  **X**
  : Randomly generated sample.

  **y**
  : Component labels.

<!-- !! processed by numpydoc !! -->

#### score(X, y=None)

Compute the per-sample average log-likelihood of the given data X.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **log_likelihood**
  : Log-likelihood of `X` under the Gaussian mixture model.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Compute the log-likelihood of each sample.

* **Parameters:**
  **X**
  : List of n_features-dimensional data points. Each row
    corresponds to a single data point.
* **Returns:**
  **log_prob**
  : Log-likelihood of each sample in `X` under the current model.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example plots the ellipsoids obtained from a toy dataset (mixture of three Gaussians) fitted by the BayesianGaussianMixture class models with a Dirichlet distribution prior (\`\`weight_concentration_prior_type=&#x27;dirichlet_distribution&#x27;\`\`) and a Dirichlet process prior (\`\`weight_concentration_prior_type=&#x27;dirichlet_process&#x27;\`\`). On each figure, we plot the results for three different values of the weight concentration prior.">  <div class="sphx-glr-thumbnail-title">Concentration Prior Type Analysis of Variation Bayesian Gaussian Mixture</div>
</div>
* [Concentration Prior Type Analysis of Variation Bayesian Gaussian Mixture](../../auto_examples/mixture/plot_concentration_prior.md#sphx-glr-auto-examples-mixture-plot-concentration-prior-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the confidence ellipsoids of a mixture of two Gaussians obtained with Expectation Maximisation (\`\`GaussianMixture\`\` class) and Variational Inference (\`\`BayesianGaussianMixture\`\` class models with a Dirichlet process prior).">  <div class="sphx-glr-thumbnail-title">Gaussian Mixture Model Ellipsoids</div>
</div>
* [Gaussian Mixture Model Ellipsoids](../../auto_examples/mixture/plot_gmm.md#sphx-glr-auto-examples-mixture-plot-gmm-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the behavior of Gaussian mixture models fit on data that was not sampled from a mixture of Gaussian random variables. The dataset is formed by 100 points loosely spaced following a noisy sine curve. There is therefore no ground truth value for the number of Gaussian components.">  <div class="sphx-glr-thumbnail-title">Gaussian Mixture Model Sine Curve</div>
</div>
* [Gaussian Mixture Model Sine Curve](../../auto_examples/mixture/plot_gmm_sin.md#sphx-glr-auto-examples-mixture-plot-gmm-sin-py)

<!-- thumbnail-parent-div-close --></div>
