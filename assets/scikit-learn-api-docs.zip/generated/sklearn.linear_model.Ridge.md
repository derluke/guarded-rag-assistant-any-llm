# Ridge

### *class* sklearn.linear_model.Ridge(alpha=1.0, \*, fit_intercept=True, copy_X=True, max_iter=None, tol=0.0001, solver='auto', positive=False, random_state=None)

Linear least squares with l2 regularization.

Minimizes the objective function:

```default
||y - Xw||^2_2 + alpha * ||w||^2_2
```

This model solves a regression model where the loss function is
the linear least squares function and regularization is given by
the l2-norm. Also known as Ridge Regression or Tikhonov regularization.
This estimator has built-in support for multi-variate regression
(i.e., when y is a 2d-array of shape (n_samples, n_targets)).

Read more in the [User Guide](../linear_model.md#ridge-regression).

* **Parameters:**
  **alpha**
  : Constant that multiplies the L2 term, controlling regularization
    strength. `alpha` must be a non-negative float i.e. in `[0, inf)`.
    <br/>
    When `alpha = 0`, the objective is equivalent to ordinary least
    squares, solved by the [`LinearRegression`](sklearn.linear_model.LinearRegression.md#sklearn.linear_model.LinearRegression) object. For numerical
    reasons, using `alpha = 0` with the `Ridge` object is not advised.
    Instead, you should use the [`LinearRegression`](sklearn.linear_model.LinearRegression.md#sklearn.linear_model.LinearRegression) object.
    <br/>
    If an array is passed, penalties are assumed to be specific to the
    targets. Hence they must correspond in number.

  **fit_intercept**
  : Whether to fit the intercept for this model. If set
    to false, no intercept will be used in calculations
    (i.e. `X` and `y` are expected to be centered).

  **copy_X**
  : If True, X will be copied; else, it may be overwritten.

  **max_iter**
  : Maximum number of iterations for conjugate gradient solver.
    For ‘sparse_cg’ and ‘lsqr’ solvers, the default value is determined
    by scipy.sparse.linalg. For ‘sag’ solver, the default value is 1000.
    For ‘lbfgs’ solver, the default value is 15000.

  **tol**
  : The precision of the solution (`coef_`) is determined by `tol` which
    specifies a different convergence criterion for each solver:
    - ‘svd’: `tol` has no impact.
    - ‘cholesky’: `tol` has no impact.
    - ‘sparse_cg’: norm of residuals smaller than `tol`.
    - ‘lsqr’: `tol` is set as atol and btol of scipy.sparse.linalg.lsqr,
      which control the norm of the residual vector in terms of the norms of
      matrix and coefficients.
    - ‘sag’ and ‘saga’: relative change of coef smaller than `tol`.
    - ‘lbfgs’: maximum of the absolute (projected) gradient=max|residuals|
      smaller than `tol`.
    <br/>
    #### Versionchanged
    Changed in version 1.2: Default value changed from 1e-3 to 1e-4 for consistency with other linear
    models.

  **solver**
  : Solver to use in the computational routines:
    - ‘auto’ chooses the solver automatically based on the type of data.
    - ‘svd’ uses a Singular Value Decomposition of X to compute the Ridge
      coefficients. It is the most stable solver, in particular more stable
      for singular matrices than ‘cholesky’ at the cost of being slower.
    - ‘cholesky’ uses the standard scipy.linalg.solve function to
      obtain a closed-form solution.
    - ‘sparse_cg’ uses the conjugate gradient solver as found in
      scipy.sparse.linalg.cg. As an iterative algorithm, this solver is
      more appropriate than ‘cholesky’ for large-scale data
      (possibility to set `tol` and `max_iter`).
    - ‘lsqr’ uses the dedicated regularized least-squares routine
      scipy.sparse.linalg.lsqr. It is the fastest and uses an iterative
      procedure.
    - ‘sag’ uses a Stochastic Average Gradient descent, and ‘saga’ uses
      its improved, unbiased version named SAGA. Both methods also use an
      iterative procedure, and are often faster than other solvers when
      both n_samples and n_features are large. Note that ‘sag’ and
      ‘saga’ fast convergence is only guaranteed on features with
      approximately the same scale. You can preprocess the data with a
      scaler from sklearn.preprocessing.
    - ‘lbfgs’ uses L-BFGS-B algorithm implemented in
      `scipy.optimize.minimize`. It can be used only when `positive`
      is True.
    <br/>
    All solvers except ‘svd’ support both dense and sparse data. However, only
    ‘lsqr’, ‘sag’, ‘sparse_cg’, and ‘lbfgs’ support sparse input when
    `fit_intercept` is True.
    <br/>
    #### Versionadded
    Added in version 0.17: Stochastic Average Gradient descent solver.
    <br/>
    #### Versionadded
    Added in version 0.19: SAGA solver.

  **positive**
  : When set to `True`, forces the coefficients to be positive.
    Only ‘lbfgs’ solver is supported in this case.

  **random_state**
  : Used when `solver` == ‘sag’ or ‘saga’ to shuffle the data.
    See [Glossary](../../glossary.md#term-random_state) for details.
    <br/>
    #### Versionadded
    Added in version 0.17: `random_state` to support Stochastic Average Gradient.
* **Attributes:**
  **coef_**
  : Weight vector(s).

  **intercept_**
  : Independent term in decision function. Set to 0.0 if
    `fit_intercept = False`.

  **n_iter_**
  : Actual number of iterations for each target. Available only for
    sag and lsqr solvers. Other solvers will return None.
    <br/>
    #### Versionadded
    Added in version 0.17.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **solver_**
  : The solver that was used at fit time by the computational
    routines.
    <br/>
    #### Versionadded
    Added in version 1.5.

#### SEE ALSO
[`RidgeClassifier`](sklearn.linear_model.RidgeClassifier.md#sklearn.linear_model.RidgeClassifier)
: Ridge classifier.

[`RidgeCV`](sklearn.linear_model.RidgeCV.md#sklearn.linear_model.RidgeCV)
: Ridge regression with built-in cross validation.

[`KernelRidge`](sklearn.kernel_ridge.KernelRidge.md#sklearn.kernel_ridge.KernelRidge)
: Kernel ridge regression combines ridge regression with the kernel trick.

### Notes

Regularization improves the conditioning of the problem and
reduces the variance of the estimates. Larger values specify stronger
regularization. Alpha corresponds to `1 / (2C)` in other linear
models such as [`LogisticRegression`](sklearn.linear_model.LogisticRegression.md#sklearn.linear_model.LogisticRegression) or
[`LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC).

### Examples

```pycon
>>> from sklearn.linear_model import Ridge
>>> import numpy as np
>>> n_samples, n_features = 10, 5
>>> rng = np.random.RandomState(0)
>>> y = rng.randn(n_samples)
>>> X = rng.randn(n_samples, n_features)
>>> clf = Ridge(alpha=1.0)
>>> clf.fit(X, y)
Ridge()
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit Ridge regression model.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **sample_weight**
  : Individual weights for each sample. If given a float, every sample
    will have the same weight.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [Ridge](#sklearn.linear_model.Ridge)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [Ridge](#sklearn.linear_model.Ridge)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows the reconstruction of an image from a set of parallel projections, acquired along different angles. Such a dataset is acquired in computed tomography (CT).">  <div class="sphx-glr-thumbnail-title">Compressive sensing: tomography reconstruction with L1 prior (Lasso)</div>
</div>
* [Compressive sensing: tomography reconstruction with L1 prior (Lasso)](../../auto_examples/applications/plot_tomography_l1_reconstruction.md#sphx-glr-auto-examples-applications-plot-tomography-l1-reconstruction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing the prediction latency of various scikit-learn estimators.">  <div class="sphx-glr-thumbnail-title">Prediction Latency</div>
</div>
* [Prediction Latency](../../auto_examples/applications/plot_prediction_latency.md#sphx-glr-auto-examples-applications-plot-prediction-latency-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates differences between a kernel ridge regression and a Gaussian process regression.">  <div class="sphx-glr-thumbnail-title">Comparison of kernel ridge and Gaussian process regression</div>
</div>
* [Comparison of kernel ridge and Gaussian process regression](../../auto_examples/gaussian_process/plot_compare_gpr_krr.md#sphx-glr-auto-examples-gaussian-process-plot-compare-gpr-krr-py)

<div class="sphx-glr-thumbcontainer" tooltip="The IterativeImputer class is very flexible - it can be used with a variety of estimators to do round-robin regression, treating every variable as an output in turn.">  <div class="sphx-glr-thumbnail-title">Imputing missing values with variants of IterativeImputer</div>
</div>
* [Imputing missing values with variants of IterativeImputer](../../auto_examples/impute/plot_iterative_imputer_variants_comparison.md#sphx-glr-auto-examples-impute-plot-iterative-imputer-variants-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Fit Ridge and HuberRegressor on a dataset with outliers.">  <div class="sphx-glr-thumbnail-title">HuberRegressor vs Ridge on dataset with strong outliers</div>
</div>
* [HuberRegressor vs Ridge on dataset with strong outliers](../../auto_examples/linear_model/plot_huber_vs_ridge.md#sphx-glr-auto-examples-linear-model-plot-huber-vs-ridge-py)

<div class="sphx-glr-thumbcontainer" tooltip="The present example compares three l1-based regression models on a synthetic signal obtained from sparse and correlated features that are further corrupted with additive gaussian noise:">  <div class="sphx-glr-thumbnail-title">L1-based models for Sparse Signals</div>
</div>
* [L1-based models for Sparse Signals](../../auto_examples/linear_model/plot_lasso_and_elasticnet.md#sphx-glr-auto-examples-linear-model-plot-lasso-and-elasticnet-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use the ordinary least squares (OLS) model called LinearRegression in scikit-learn.">  <div class="sphx-glr-thumbnail-title">Ordinary Least Squares Example</div>
</div>
* [Ordinary Least Squares Example](../../auto_examples/linear_model/plot_ols.md#sphx-glr-auto-examples-linear-model-plot-ols-py)

<div class="sphx-glr-thumbcontainer" tooltip="Ridge regression is basically minimizing a penalised version of the least-squared function. The penalising shrinks the value of the regression coefficients. Despite the few data points in each dimension, the slope of the prediction is much more stable and the variance in the line itself is greatly reduced, in comparison to that of the standard linear regression">  <div class="sphx-glr-thumbnail-title">Ordinary Least Squares and Ridge Regression Variance</div>
</div>
* [Ordinary Least Squares and Ridge Regression Variance](../../auto_examples/linear_model/plot_ols_ridge_variance.md#sphx-glr-auto-examples-linear-model-plot-ols-ridge-variance-py)

<div class="sphx-glr-thumbcontainer" tooltip="Shows the effect of collinearity in the coefficients of an estimator.">  <div class="sphx-glr-thumbnail-title">Plot Ridge coefficients as a function of the regularization</div>
</div>
* [Plot Ridge coefficients as a function of the regularization](../../auto_examples/linear_model/plot_ridge_path.md#sphx-glr-auto-examples-linear-model-plot-ridge-path-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to approximate a function with polynomials up to degree degree by using ridge regression. We show two different ways given n_samples of 1d points x_i:">  <div class="sphx-glr-thumbnail-title">Polynomial and Spline interpolation</div>
</div>
* [Polynomial and Spline interpolation](../../auto_examples/linear_model/plot_polynomial_interpolation.md#sphx-glr-auto-examples-linear-model-plot-polynomial-interpolation-py)

<div class="sphx-glr-thumbcontainer" tooltip="A model that overfits learns the training data too well, capturing both the underlying patterns and the noise in the data. However, when applied to unseen data, the learned associations may not hold. We normally detect this when we apply our trained predictions to the test data and see the statistical performance drop significantly compared to the training data.">  <div class="sphx-glr-thumbnail-title">Ridge coefficients as a function of the L2 Regularization</div>
</div>
* [Ridge coefficients as a function of the L2 Regularization](../../auto_examples/linear_model/plot_ridge_coeffs.md#sphx-glr-auto-examples-linear-model-plot-ridge-coeffs-py)

<div class="sphx-glr-thumbcontainer" tooltip="The TargetEncoder replaces each category of a categorical feature with the shrunk mean of the target variable for that category. This method is useful in cases where there is a strong relationship between the categorical feature and the target. To prevent overfitting, TargetEncoder.fit_transform uses an internal cross fitting scheme to encode the training data to be used by a downstream model. This scheme involves splitting the data into k folds and encoding each fold using the encodings learnt using the other k-1 folds. In this example, we demonstrate the importance of the cross fitting procedure to prevent overfitting.">  <div class="sphx-glr-thumbnail-title">Target Encoder's Internal Cross fitting</div>
</div>
* [Target Encoder’s Internal Cross fitting](../../auto_examples/preprocessing/plot_target_encoder_cross_val.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-cross-val-py)

<!-- thumbnail-parent-div-close --></div>
