# KNNImputer

### *class* sklearn.impute.KNNImputer(\*, missing_values=nan, n_neighbors=5, weights='uniform', metric='nan_euclidean', copy=True, add_indicator=False, keep_empty_features=False)

Imputation for completing missing values using k-Nearest Neighbors.

Each sample’s missing values are imputed using the mean value from
`n_neighbors` nearest neighbors found in the training set. Two samples are
close if the features that neither is missing are close.

Read more in the [User Guide](../impute.md#knnimpute).

#### Versionadded
Added in version 0.22.

* **Parameters:**
  **missing_values**
  : The placeholder for the missing values. All occurrences of
    `missing_values` will be imputed. For pandas’ dataframes with
    nullable integer dtypes with missing values, `missing_values`
    should be set to np.nan, since `pd.NA` will be converted to np.nan.

  **n_neighbors**
  : Number of neighboring samples to use for imputation.

  **weights**
  : Weight function used in prediction.  Possible values:
    - ‘uniform’ : uniform weights. All points in each neighborhood are
      weighted equally.
    - ‘distance’ : weight points by the inverse of their distance.
      in this case, closer neighbors of a query point will have a
      greater influence than neighbors which are further away.
    - callable : a user-defined function which accepts an
      array of distances, and returns an array of the same shape
      containing the weights.

  **metric**
  : Distance metric for searching neighbors. Possible values:
    - ‘nan_euclidean’
    - callable : a user-defined function which conforms to the definition
      of `func_metric(x, y, *, missing_values=np.nan)`. `x` and `y`
      corresponds to a row (i.e. 1-D arrays) of `X` and `Y`, respectively.
      The callable should returns a scalar distance value.

  **copy**
  : If True, a copy of X will be created. If False, imputation will
    be done in-place whenever possible.

  **add_indicator**
  : If True, a [`MissingIndicator`](sklearn.impute.MissingIndicator.md#sklearn.impute.MissingIndicator) transform will stack onto the
    output of the imputer’s transform. This allows a predictive estimator
    to account for missingness despite imputation. If a feature has no
    missing values at fit/train time, the feature won’t appear on the
    missing indicator even if there are missing values at transform/test
    time.

  **keep_empty_features**
  : If True, features that consist exclusively of missing values when
    `fit` is called are returned in results when `transform` is called.
    The imputed value is always `0`.
    <br/>
    #### Versionadded
    Added in version 1.2.
* **Attributes:**
  **indicator_**
  : Indicator used to add binary indicators for missing values.
    `None` if add_indicator is False.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`SimpleImputer`](sklearn.impute.SimpleImputer.md#sklearn.impute.SimpleImputer)
: Univariate imputer for completing missing values with simple strategies.

[`IterativeImputer`](sklearn.impute.IterativeImputer.md#sklearn.impute.IterativeImputer)
: Multivariate imputer that estimates values to impute for each feature with missing values from all the others.

### References

* [Olga Troyanskaya, Michael Cantor, Gavin Sherlock, Pat Brown, Trevor
  Hastie, Robert Tibshirani, David Botstein and Russ B. Altman, Missing
  value estimation methods for DNA microarrays, BIOINFORMATICS Vol. 17
  no. 6, 2001 Pages 520-525.](https://academic.oup.com/bioinformatics/article/17/6/520/272365)

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.impute import KNNImputer
>>> X = [[1, 2, np.nan], [3, 4, 3], [np.nan, 6, 5], [8, 8, 7]]
>>> imputer = KNNImputer(n_neighbors=2)
>>> imputer.fit_transform(X)
array([[1. , 2. , 4. ],
       [3. , 4. , 3. ],
       [5.5, 6. , 5. ],
       [8. , 8. , 7. ]])
```

For a more detailed example see
[Imputing missing values before building an estimator](../../auto_examples/impute/plot_missing_values.md#sphx-glr-auto-examples-impute-plot-missing-values-py).

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the imputer on X.

* **Parameters:**
  **X**
  : Input data, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : The fitted `KNNImputer` class instance.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Impute all missing values in X.

* **Parameters:**
  **X**
  : The input data to complete.
* **Returns:**
  **X**
  : The imputed dataset. `n_output_features` is the number of features
    that is not always missing during `fit`.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Missing values can be replaced by the mean, the median or the most frequent value using the basic SimpleImputer.">  <div class="sphx-glr-thumbnail-title">Imputing missing values before building an estimator</div>
</div>
* [Imputing missing values before building an estimator](../../auto_examples/impute/plot_missing_values.md#sphx-glr-auto-examples-impute-plot-missing-values-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
