# cosine_distances

### sklearn.metrics.pairwise.cosine_distances(X, Y=None)

Compute cosine distance between samples in X and Y.

Cosine distance is defined as 1.0 minus the cosine similarity.

Read more in the [User Guide](../metrics.md#metrics).

* **Parameters:**
  **X**
  : Matrix `X`.

  **Y**
  : Matrix `Y`.
* **Returns:**
  **distances**
  : Returns the cosine distance between samples in X and Y.

#### SEE ALSO
[`cosine_similarity`](sklearn.metrics.pairwise.cosine_similarity.md#sklearn.metrics.pairwise.cosine_similarity)
: Compute cosine similarity between samples in X and Y.

[`scipy.spatial.distance.cosine`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.distance.cosine.html#scipy.spatial.distance.cosine)
: Dense matrices only.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import cosine_distances
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> cosine_distances(X, Y)
array([[1.     , 1.     ],
       [0.42..., 0.18...]])
```

<!-- !! processed by numpydoc !! -->
