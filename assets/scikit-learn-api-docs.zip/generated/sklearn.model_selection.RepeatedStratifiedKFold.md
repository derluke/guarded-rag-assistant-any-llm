# RepeatedStratifiedKFold

### *class* sklearn.model_selection.RepeatedStratifiedKFold(\*, n_splits=5, n_repeats=10, random_state=None)

Repeated Stratified K-Fold cross validator.

Repeats Stratified K-Fold n times with different randomization in each
repetition.

Read more in the [User Guide](../cross_validation.md#repeated-k-fold).

* **Parameters:**
  **n_splits**
  : Number of folds. Must be at least 2.

  **n_repeats**
  : Number of times cross-validator needs to be repeated.

  **random_state**
  : Controls the generation of the random states for each repetition.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

#### SEE ALSO
[`RepeatedKFold`](sklearn.model_selection.RepeatedKFold.md#sklearn.model_selection.RepeatedKFold)
: Repeats K-Fold n times.

### Notes

Randomized CV splitters may return different results for each call of
split. You can make the results identical by setting `random_state`
to an integer.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import RepeatedStratifiedKFold
>>> X = np.array([[1, 2], [3, 4], [1, 2], [3, 4]])
>>> y = np.array([0, 0, 1, 1])
>>> rskf = RepeatedStratifiedKFold(n_splits=2, n_repeats=2,
...     random_state=36851234)
>>> rskf.get_n_splits(X, y)
4
>>> print(rskf)
RepeatedStratifiedKFold(n_repeats=2, n_splits=2, random_state=36851234)
>>> for i, (train_index, test_index) in enumerate(rskf.split(X, y)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}")
...     print(f"  Test:  index={test_index}")
...
Fold 0:
  Train: index=[1 2]
  Test:  index=[0 3]
Fold 1:
  Train: index=[0 3]
  Test:  index=[1 2]
Fold 2:
  Train: index=[1 3]
  Test:  index=[0 2]
Fold 3:
  Train: index=[0 2]
  Test:  index=[1 3]
```

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X=None, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.
    `np.zeros(n_samples)` may be used as a placeholder.

  **y**
  : Always ignored, exists for compatibility.
    `np.zeros(n_samples)` may be used as a placeholder.

  **groups**
  : Group labels for the samples used while splitting the dataset into
    train/test set.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### split(X, y, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.
    <br/>
    Note that providing `y` is sufficient to generate the splits and
    hence `np.zeros(n_samples)` may be used as a placeholder for
    `X` instead of actual training data.

  **y**
  : The target variable for supervised learning problems.
    Stratification is done based on the y labels.

  **groups**
  : Always ignored, exists for compatibility.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

### Notes

Randomized CV splitters may return different results for each call of
split. You can make the results identical by setting `random_state`
to an integer.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Once a binary classifier is trained, the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. The default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0. However, this default strategy may not be optimal for the task at hand.">  <div class="sphx-glr-thumbnail-title">Post-hoc tuning the cut-off point of decision function</div>
</div>
* [Post-hoc tuning the cut-off point of decision function](../../auto_examples/model_selection/plot_tuned_decision_threshold.md#sphx-glr-auto-examples-model-selection-plot-tuned-decision-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to statistically compare the performance of models trained and evaluated using GridSearchCV.">  <div class="sphx-glr-thumbnail-title">Statistical comparison of models using grid search</div>
</div>
* [Statistical comparison of models using grid search](../../auto_examples/model_selection/plot_grid_search_stats.md#sphx-glr-auto-examples-model-selection-plot-grid-search-stats-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we discuss the problem of classification when the target variable is composed of more than two classes. This is called multiclass classification.">  <div class="sphx-glr-thumbnail-title">Overview of multiclass training meta-estimators</div>
</div>
* [Overview of multiclass training meta-estimators](../../auto_examples/multiclass/plot_multiclass_overview.md#sphx-glr-auto-examples-multiclass-plot-multiclass-overview-py)

<!-- thumbnail-parent-div-close --></div>
