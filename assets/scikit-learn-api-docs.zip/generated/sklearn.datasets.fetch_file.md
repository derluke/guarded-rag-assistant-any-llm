# fetch_file

### sklearn.datasets.fetch_file(url, folder=None, local_filename=None, sha256=None, n_retries=3, delay=1)

Fetch a file from the web if not already present in the local folder.

If the file already exists locally (and the SHA256 checksums match when
provided), the path to the local file is returned without re-downloading.

#### Versionadded
Added in version 1.6.

* **Parameters:**
  **url**
  : URL of the file to download.

  **folder**
  : Directory to save the file to. If None, the file is downloaded in a
    folder with a name derived from the URL host name and path under
    scikit-learn data home folder.

  **local_filename**
  : Name of the file to save. If None, the filename is inferred from the
    URL.

  **sha256**
  : SHA256 checksum of the file. If None, no checksum is verified.

  **n_retries**
  : Number of retries when HTTP errors are encountered.

  **delay**
  : Number of seconds between retries.
* **Returns:**
  **file_path**
  : Full path of the downloaded file.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Polars-engineered lagged features can be used for time series forecasting with HistGradientBoostingRegressor on the Bike Sharing Demand dataset.">  <div class="sphx-glr-thumbnail-title">Lagged features for time series forecasting</div>
</div>
* [Lagged features for time series forecasting](../../auto_examples/applications/plot_time_series_lagged_features.md#sphx-glr-auto-examples-applications-plot-time-series-lagged-features-py)

<!-- thumbnail-parent-div-close --></div>
