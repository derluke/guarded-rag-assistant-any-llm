# cohen_kappa_score

### sklearn.metrics.cohen_kappa_score(y1, y2, \*, labels=None, weights=None, sample_weight=None)

Compute Cohen’s kappa: a statistic that measures inter-annotator agreement.

This function computes Cohen’s kappa [[1]](#r219a3b9132e1-1), a score that expresses the level
of agreement between two annotators on a classification problem. It is
defined as

$$
\kappa = (p_o - p_e) / (1 - p_e)

$$

where $p_o$ is the empirical probability of agreement on the label
assigned to any sample (the observed agreement ratio), and $p_e$ is
the expected agreement when both annotators assign labels randomly.
$p_e$ is estimated using a per-annotator empirical prior over the
class labels [[2]](#r219a3b9132e1-2).

Read more in the [User Guide](../model_evaluation.md#cohen-kappa).

* **Parameters:**
  **y1**
  : Labels assigned by the first annotator.

  **y2**
  : Labels assigned by the second annotator. The kappa statistic is
    symmetric, so swapping `y1` and `y2` doesn’t change the value.

  **labels**
  : List of labels to index the matrix. This may be used to select a
    subset of labels. If `None`, all labels that appear at least once in
    `y1` or `y2` are used.

  **weights**
  : Weighting type to calculate the score. `None` means not weighted;
    “linear” means linear weighting; “quadratic” means quadratic weighting.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **kappa**
  : The kappa statistic, which is a number between -1 and 1. The maximum
    value means complete agreement; zero or lower means chance agreement.

### References

### Examples

```pycon
>>> from sklearn.metrics import cohen_kappa_score
>>> y1 = ["negative", "positive", "negative", "neutral", "positive"]
>>> y2 = ["negative", "positive", "negative", "neutral", "negative"]
>>> cohen_kappa_score(y1, y2)
np.float64(0.6875)
```

<!-- !! processed by numpydoc !! -->
