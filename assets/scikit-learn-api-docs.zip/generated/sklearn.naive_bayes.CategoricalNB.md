# CategoricalNB

### *class* sklearn.naive_bayes.CategoricalNB(\*, alpha=1.0, force_alpha=True, fit_prior=True, class_prior=None, min_categories=None)

Naive Bayes classifier for categorical features.

The categorical Naive Bayes classifier is suitable for classification with
discrete features that are categorically distributed. The categories of
each feature are drawn from a categorical distribution.

Read more in the [User Guide](../naive_bayes.md#categorical-naive-bayes).

* **Parameters:**
  **alpha**
  : Additive (Laplace/Lidstone) smoothing parameter
    (set alpha=0 and force_alpha=True, for no smoothing).

  **force_alpha**
  : If False and alpha is less than 1e-10, it will set alpha to
    1e-10. If True, alpha will remain unchanged. This may cause
    numerical errors if alpha is too close to 0.
    <br/>
    #### Versionadded
    Added in version 1.2.
    <br/>
    #### Versionchanged
    Changed in version 1.4: The default value of `force_alpha` changed to `True`.

  **fit_prior**
  : Whether to learn class prior probabilities or not.
    If false, a uniform prior will be used.

  **class_prior**
  : Prior probabilities of the classes. If specified, the priors are not
    adjusted according to the data.

  **min_categories**
  : Minimum number of categories per feature.
    - integer: Sets the minimum number of categories per feature to
      `n_categories` for each features.
    - array-like: shape (n_features,) where `n_categories[i]` holds the
      minimum number of categories for the ith column of the input.
    - None (default): Determines the number of categories automatically
      from the training data.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  **category_count_**
  : Holds arrays of shape (n_classes, n_categories of respective feature)
    for each feature. Each array provides the number of samples
    encountered for each class and category of the specific feature.

  **class_count_**
  : Number of samples encountered for each class during fitting. This
    value is weighted by the sample weight when provided.

  **class_log_prior_**
  : Smoothed empirical log probability for each class.

  **classes_**
  : Class labels known to the classifier

  **feature_log_prob_**
  : Holds arrays of shape (n_classes, n_categories of respective feature)
    for each feature. Each array provides the empirical log probability
    of categories given the respective feature and class, `P(x_i|y)`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_categories_**
  : Number of categories for each feature. This value is
    inferred from the data or set by the minimum number of categories.
    <br/>
    #### Versionadded
    Added in version 0.24.

#### SEE ALSO
[`BernoulliNB`](sklearn.naive_bayes.BernoulliNB.md#sklearn.naive_bayes.BernoulliNB)
: Naive Bayes classifier for multivariate Bernoulli models.

[`ComplementNB`](sklearn.naive_bayes.ComplementNB.md#sklearn.naive_bayes.ComplementNB)
: Complement Naive Bayes classifier.

[`GaussianNB`](sklearn.naive_bayes.GaussianNB.md#sklearn.naive_bayes.GaussianNB)
: Gaussian Naive Bayes.

[`MultinomialNB`](sklearn.naive_bayes.MultinomialNB.md#sklearn.naive_bayes.MultinomialNB)
: Naive Bayes classifier for multinomial models.

### Examples

```pycon
>>> import numpy as np
>>> rng = np.random.RandomState(1)
>>> X = rng.randint(5, size=(6, 100))
>>> y = np.array([1, 2, 3, 4, 5, 6])
>>> from sklearn.naive_bayes import CategoricalNB
>>> clf = CategoricalNB()
>>> clf.fit(X, y)
CategoricalNB()
>>> print(clf.predict(X[2:3]))
[3]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit Naive Bayes classifier according to X, y.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features. Here, each feature of X is
    assumed to be from a different categorical distribution.
    It is further assumed that all categories of each feature are
    represented by the numbers 0, …, n - 1, where n refers to the
    total number of categories for the given feature. This can, for
    instance, be achieved with the help of OrdinalEncoder.

  **y**
  : Target values.

  **sample_weight**
  : Weights applied to individual samples (1. for unweighted).
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y, classes=None, sample_weight=None)

Incremental fit on a batch of samples.

This method is expected to be called several times consecutively
on different chunks of a dataset so as to implement out-of-core
or online learning.

This is especially useful when the whole dataset is too big to fit in
memory at once.

This method has some performance overhead hence it is better to call
partial_fit on chunks of data that are as large as possible
(as long as fitting in the memory budget) to hide the overhead.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features. Here, each feature of X is
    assumed to be from a different categorical distribution.
    It is further assumed that all categories of each feature are
    represented by the numbers 0, …, n - 1, where n refers to the
    total number of categories for the given feature. This can, for
    instance, be achieved with the help of OrdinalEncoder.

  **y**
  : Target values.

  **classes**
  : List of all the classes that can possibly appear in the y vector.
    <br/>
    Must be provided at the first call to partial_fit, can be omitted
    in subsequent calls.

  **sample_weight**
  : Weights applied to individual samples (1. for unweighted).
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Perform classification on an array of test vectors X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **C**
  : Predicted target values for X.

<!-- !! processed by numpydoc !! -->

#### predict_joint_log_proba(X)

Return joint log probability estimates for the test vector X.

For each row x of X and class y, the joint log probability is given by
`log P(x, y) = log P(y) + log P(x|y),`
where `log P(y)` is the class prior probability and `log P(x|y)` is
the class-conditional probability.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **C**
  : Returns the joint log-probability of the samples for each class in
    the model. The columns correspond to the classes in sorted
    order, as they appear in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Return log-probability estimates for the test vector X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **C**
  : Returns the log-probability of the samples for each class in
    the model. The columns correspond to the classes in sorted
    order, as they appear in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Return probability estimates for the test vector X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **C**
  : Returns the probability of the samples for each class in
    the model. The columns correspond to the classes in sorted
    order, as they appear in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [CategoricalNB](#sklearn.naive_bayes.CategoricalNB)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, classes: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [CategoricalNB](#sklearn.naive_bayes.CategoricalNB)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **classes**
  : Metadata routing for `classes` parameter in `partial_fit`.

  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [CategoricalNB](#sklearn.naive_bayes.CategoricalNB)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->
