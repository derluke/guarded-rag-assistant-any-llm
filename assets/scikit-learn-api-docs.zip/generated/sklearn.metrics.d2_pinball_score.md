# d2_pinball_score

### sklearn.metrics.d2_pinball_score(y_true, y_pred, \*, sample_weight=None, alpha=0.5, multioutput='uniform_average')

$D^2$ regression score function, fraction of pinball loss explained.

Best possible score is 1.0 and it can be negative (because the model can be
arbitrarily worse). A model that always uses the empirical alpha-quantile of
`y_true` as constant prediction, disregarding the input features,
gets a $D^2$ score of 0.0.

Read more in the [User Guide](../model_evaluation.md#d2-score).

#### Versionadded
Added in version 1.1.

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated target values.

  **sample_weight**
  : Sample weights.

  **alpha**
  : Slope of the pinball deviance. It determines the quantile level alpha
    for which the pinball deviance and also D2 are optimal.
    The default `alpha=0.5` is equivalent to `d2_absolute_error_score`.

  **multioutput**
  : Defines aggregating of multiple output values.
    Array-like value defines weights used to average scores.
    <br/>
    ‘raw_values’ :
    : Returns a full set of errors in case of multioutput input.
    <br/>
    ‘uniform_average’ :
    : Scores of all outputs are averaged with uniform weight.
* **Returns:**
  **score**
  : The $D^2$ score with a pinball deviance
    or ndarray of scores if `multioutput='raw_values'`.

### Notes

Like $R^2$, $D^2$ score may be negative
(it need not actually be the square of a quantity D).

This metric is not well-defined for a single point and will return a NaN
value if n_samples is less than two.

### References

### Examples

```pycon
>>> from sklearn.metrics import d2_pinball_score
>>> y_true = [1, 2, 3]
>>> y_pred = [1, 3, 3]
>>> d2_pinball_score(y_true, y_pred)
np.float64(0.5)
>>> d2_pinball_score(y_true, y_pred, alpha=0.9)
np.float64(0.772...)
>>> d2_pinball_score(y_true, y_pred, alpha=0.1)
np.float64(-1.045...)
>>> d2_pinball_score(y_true, y_true, alpha=0.1)
np.float64(1.0)
```

<!-- !! processed by numpydoc !! -->
