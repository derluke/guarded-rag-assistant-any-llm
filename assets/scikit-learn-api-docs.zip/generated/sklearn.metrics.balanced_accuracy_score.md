# balanced_accuracy_score

### sklearn.metrics.balanced_accuracy_score(y_true, y_pred, \*, sample_weight=None, adjusted=False)

Compute the balanced accuracy.

The balanced accuracy in binary and multiclass classification problems to
deal with imbalanced datasets. It is defined as the average of recall
obtained on each class.

The best value is 1 and the worst value is 0 when `adjusted=False`.

Read more in the [User Guide](../model_evaluation.md#balanced-accuracy-score).

#### Versionadded
Added in version 0.20.

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated targets as returned by a classifier.

  **sample_weight**
  : Sample weights.

  **adjusted**
  : When true, the result is adjusted for chance, so that random
    performance would score 0, while keeping perfect performance at a score
    of 1.
* **Returns:**
  **balanced_accuracy**
  : Balanced accuracy score.

#### SEE ALSO
[`average_precision_score`](sklearn.metrics.average_precision_score.md#sklearn.metrics.average_precision_score)
: Compute average precision (AP) from prediction scores.

[`precision_score`](sklearn.metrics.precision_score.md#sklearn.metrics.precision_score)
: Compute the precision score.

[`recall_score`](sklearn.metrics.recall_score.md#sklearn.metrics.recall_score)
: Compute the recall score.

[`roc_auc_score`](sklearn.metrics.roc_auc_score.md#sklearn.metrics.roc_auc_score)
: Compute Area Under the Receiver Operating Characteristic Curve (ROC AUC) from prediction scores.

### Notes

Some literature promotes alternative definitions of balanced accuracy. Our
definition is equivalent to [`accuracy_score`](sklearn.metrics.accuracy_score.md#sklearn.metrics.accuracy_score) with class-balanced
sample weights, and shares desirable properties with the binary case.
See the [User Guide](../model_evaluation.md#balanced-accuracy-score).

### References

### Examples

```pycon
>>> from sklearn.metrics import balanced_accuracy_score
>>> y_true = [0, 1, 0, 0, 1, 0]
>>> y_pred = [0, 1, 0, 0, 0, 1]
>>> balanced_accuracy_score(y_true, y_pred)
np.float64(0.625)
```

<!-- !! processed by numpydoc !! -->
