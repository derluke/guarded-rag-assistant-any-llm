# InconsistentVersionWarning

### *exception* sklearn.exceptions.InconsistentVersionWarning(\*, estimator_name, current_sklearn_version, original_sklearn_version)

Warning raised when an estimator is unpickled with a inconsistent version.

* **Parameters:**
  **estimator_name**
  : Estimator name.

  **current_sklearn_version**
  : Current scikit-learn version.

  **original_sklearn_version**
  : Original scikit-learn version.

<!-- !! processed by numpydoc !! -->
