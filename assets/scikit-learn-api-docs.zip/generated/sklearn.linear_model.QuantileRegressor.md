# QuantileRegressor

### *class* sklearn.linear_model.QuantileRegressor(\*, quantile=0.5, alpha=1.0, fit_intercept=True, solver='highs', solver_options=None)

Linear regression model that predicts conditional quantiles.

The linear [`QuantileRegressor`](#sklearn.linear_model.QuantileRegressor) optimizes the pinball loss for a
desired `quantile` and is robust to outliers.

This model uses an L1 regularization like
[`Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso).

Read more in the [User Guide](../linear_model.md#quantile-regression).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **quantile**
  : The quantile that the model tries to predict. It must be strictly
    between 0 and 1. If 0.5 (default), the model predicts the 50%
    quantile, i.e. the median.

  **alpha**
  : Regularization constant that multiplies the L1 penalty term.

  **fit_intercept**
  : Whether or not to fit the intercept.

  **solver**
  : Method used by [`scipy.optimize.linprog`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linprog.html#scipy.optimize.linprog) to solve the linear
    programming formulation.
    <br/>
    It is recommended to use the highs methods because
    they are the fastest ones. Solvers “highs-ds”, “highs-ipm” and “highs”
    support sparse input data and, in fact, always convert to sparse csc.
    <br/>
    From `scipy>=1.11.0`, “interior-point” is not available anymore.
    <br/>
    #### Versionchanged
    Changed in version 1.4: The default of `solver` changed to `"highs"` in version 1.4.

  **solver_options**
  : Additional parameters passed to [`scipy.optimize.linprog`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linprog.html#scipy.optimize.linprog) as
    options. If `None` and if `solver='interior-point'`, then
    `{"lstsq": True}` is passed to [`scipy.optimize.linprog`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.linprog.html#scipy.optimize.linprog) for the
    sake of stability.
* **Attributes:**
  **coef_**
  : Estimated coefficients for the features.

  **intercept_**
  : The intercept of the model, aka bias term.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : The actual number of iterations performed by the solver.

#### SEE ALSO
[`Lasso`](sklearn.linear_model.Lasso.md#sklearn.linear_model.Lasso)
: The Lasso is a linear model that estimates sparse coefficients with l1 regularization.

[`HuberRegressor`](sklearn.linear_model.HuberRegressor.md#sklearn.linear_model.HuberRegressor)
: Linear regression model that is robust to outliers.

### Examples

```pycon
>>> from sklearn.linear_model import QuantileRegressor
>>> import numpy as np
>>> n_samples, n_features = 10, 2
>>> rng = np.random.RandomState(0)
>>> y = rng.randn(n_samples)
>>> X = rng.randn(n_samples, n_features)
>>> # the two following lines are optional in practice
>>> from sklearn.utils.fixes import sp_version, parse_version
>>> reg = QuantileRegressor(quantile=0.8).fit(X, y)
>>> np.mean(y <= reg.predict(X))
np.float64(0.8)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the model according to the given training data.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **self**
  : Returns self.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [QuantileRegressor](#sklearn.linear_model.QuantileRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [QuantileRegressor](#sklearn.linear_model.QuantileRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how quantile regression can predict non-trivial conditional quantiles.">  <div class="sphx-glr-thumbnail-title">Quantile regression</div>
</div>
* [Quantile regression](../../auto_examples/linear_model/plot_quantile_regression.md#sphx-glr-auto-examples-linear-model-plot-quantile-regression-py)

<!-- thumbnail-parent-div-close --></div>
