# RANSACRegressor

### *class* sklearn.linear_model.RANSACRegressor(estimator=None, \*, min_samples=None, residual_threshold=None, is_data_valid=None, is_model_valid=None, max_trials=100, max_skips=inf, stop_n_inliers=inf, stop_score=inf, stop_probability=0.99, loss='absolute_error', random_state=None)

RANSAC (RANdom SAmple Consensus) algorithm.

RANSAC is an iterative algorithm for the robust estimation of parameters
from a subset of inliers from the complete data set.

Read more in the [User Guide](../linear_model.md#ransac-regression).

* **Parameters:**
  **estimator**
  : Base estimator object which implements the following methods:
    * `fit(X, y)`: Fit model to given training data and target values.
    * `score(X, y)`: Returns the mean accuracy on the given test data,
      which is used for the stop criterion defined by `stop_score`.
      Additionally, the score is used to decide which of two equally
      large consensus sets is chosen as the better one.
    * `predict(X)`: Returns predicted values using the linear model,
      which is used to compute residual error using loss function.
    <br/>
    If `estimator` is None, then
    [`LinearRegression`](sklearn.linear_model.LinearRegression.md#sklearn.linear_model.LinearRegression) is used for
    target values of dtype float.
    <br/>
    Note that the current implementation only supports regression
    estimators.

  **min_samples**
  : Minimum number of samples chosen randomly from original data. Treated
    as an absolute number of samples for `min_samples >= 1`, treated as a
    relative number `ceil(min_samples * X.shape[0])` for
    `min_samples < 1`. This is typically chosen as the minimal number of
    samples necessary to estimate the given `estimator`. By default a
    [`LinearRegression`](sklearn.linear_model.LinearRegression.md#sklearn.linear_model.LinearRegression) estimator is assumed and
    `min_samples` is chosen as `X.shape[1] + 1`. This parameter is highly
    dependent upon the model, so if a `estimator` other than
    [`LinearRegression`](sklearn.linear_model.LinearRegression.md#sklearn.linear_model.LinearRegression) is used, the user must
    provide a value.

  **residual_threshold**
  : Maximum residual for a data sample to be classified as an inlier.
    By default the threshold is chosen as the MAD (median absolute
    deviation) of the target values `y`. Points whose residuals are
    strictly equal to the threshold are considered as inliers.

  **is_data_valid**
  : This function is called with the randomly selected data before the
    model is fitted to it: `is_data_valid(X, y)`. If its return value is
    False the current randomly chosen sub-sample is skipped.

  **is_model_valid**
  : This function is called with the estimated model and the randomly
    selected data: `is_model_valid(model, X, y)`. If its return value is
    False the current randomly chosen sub-sample is skipped.
    Rejecting samples with this function is computationally costlier than
    with `is_data_valid`. `is_model_valid` should therefore only be used if
    the estimated model is needed for making the rejection decision.

  **max_trials**
  : Maximum number of iterations for random sample selection.

  **max_skips**
  : Maximum number of iterations that can be skipped due to finding zero
    inliers or invalid data defined by `is_data_valid` or invalid models
    defined by `is_model_valid`.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **stop_n_inliers**
  : Stop iteration if at least this number of inliers are found.

  **stop_score**
  : Stop iteration if score is greater equal than this threshold.

  **stop_probability**
  : RANSAC iteration stops if at least one outlier-free set of the training
    data is sampled in RANSAC. This requires to generate at least N
    samples (iterations):
    ```default
    N >= log(1 - probability) / log(1 - e**m)
    ```
    <br/>
    where the probability (confidence) is typically set to high value such
    as 0.99 (the default) and e is the current fraction of inliers w.r.t.
    the total number of samples.

  **loss**
  : String inputs, ‘absolute_error’ and ‘squared_error’ are supported which
    find the absolute error and squared error per sample respectively.
    <br/>
    If `loss` is a callable, then it should be a function that takes
    two arrays as inputs, the true and predicted value and returns a 1-D
    array with the i-th value of the array corresponding to the loss
    on `X[i]`.
    <br/>
    If the loss on a sample is greater than the `residual_threshold`,
    then this sample is classified as an outlier.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **random_state**
  : The generator used to initialize the centers.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **estimator_**
  : Final model fitted on the inliers predicted by the “best” model found
    during RANSAC sampling (copy of the `estimator` object).

  **n_trials_**
  : Number of random selection trials until one of the stop criteria is
    met. It is always `<= max_trials`.

  **inlier_mask_**
  : Boolean mask of inliers classified as `True`.

  **n_skips_no_inliers_**
  : Number of iterations skipped due to finding zero inliers.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **n_skips_invalid_data_**
  : Number of iterations skipped due to invalid data defined by
    `is_data_valid`.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **n_skips_invalid_model_**
  : Number of iterations skipped due to an invalid model defined by
    `is_model_valid`.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`HuberRegressor`](sklearn.linear_model.HuberRegressor.md#sklearn.linear_model.HuberRegressor)
: Linear regression model that is robust to outliers.

[`TheilSenRegressor`](sklearn.linear_model.TheilSenRegressor.md#sklearn.linear_model.TheilSenRegressor)
: Theil-Sen Estimator robust multivariate regression model.

[`SGDRegressor`](sklearn.linear_model.SGDRegressor.md#sklearn.linear_model.SGDRegressor)
: Fitted by minimizing a regularized empirical loss with SGD.

### References

### Examples

```pycon
>>> from sklearn.linear_model import RANSACRegressor
>>> from sklearn.datasets import make_regression
>>> X, y = make_regression(
...     n_samples=200, n_features=2, noise=4.0, random_state=0)
>>> reg = RANSACRegressor(random_state=0).fit(X, y)
>>> reg.score(X, y)
0.9885...
>>> reg.predict(X[:1,])
array([-31.9417...])
```

For a more detailed example, see
[Robust linear model estimation using RANSAC](../../auto_examples/linear_model/plot_ransac.md#sphx-glr-auto-examples-linear-model-plot-ransac-py)

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*, sample_weight=None, \*\*fit_params)

Fit estimator using RANSAC algorithm.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **sample_weight**
  : Individual weights for each sample
    raises error if sample_weight is passed and estimator
    fit method does not support it.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **\*\*fit_params**
  : Parameters routed to the `fit` method of the sub-estimator via the
    metadata routing API.
    <br/>
    #### Versionadded
    Added in version 1.5: Only available if
    `sklearn.set_config(enable_metadata_routing=True)` is set. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **self**
  : Fitted `RANSACRegressor` estimator.
* **Raises:**
  ValueError
  : If no valid consensus set could be found. This occurs if
    `is_data_valid` and `is_model_valid` return False for all
    `max_trials` randomly chosen sub-samples.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.5.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X, \*\*params)

Predict using the estimated model.

This is a wrapper for `estimator_.predict(X)`.

* **Parameters:**
  **X**
  : Input data.

  **\*\*params**
  : Parameters routed to the `predict` method of the sub-estimator via
    the metadata routing API.
    <br/>
    #### Versionadded
    Added in version 1.5: Only available if
    `sklearn.set_config(enable_metadata_routing=True)` is set. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **y**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, \*\*params)

Return the score of the prediction.

This is a wrapper for `estimator_.score(X, y)`.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **\*\*params**
  : Parameters routed to the `score` method of the sub-estimator via
    the metadata routing API.
    <br/>
    #### Versionadded
    Added in version 1.5: Only available if
    `sklearn.set_config(enable_metadata_routing=True)` is set. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **z**
  : Score of the prediction.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RANSACRegressor](#sklearn.linear_model.RANSACRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Here a sine function is fit with a polynomial of order 3, for values close to zero.">  <div class="sphx-glr-thumbnail-title">Robust linear estimator fitting</div>
</div>
* [Robust linear estimator fitting](../../auto_examples/linear_model/plot_robust_fit.md#sphx-glr-auto-examples-linear-model-plot-robust-fit-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we see how to robustly fit a linear model to faulty data using the ransac_regression algorithm.">  <div class="sphx-glr-thumbnail-title">Robust linear model estimation using RANSAC</div>
</div>
* [Robust linear model estimation using RANSAC](../../auto_examples/linear_model/plot_ransac.md#sphx-glr-auto-examples-linear-model-plot-ransac-py)

<div class="sphx-glr-thumbcontainer" tooltip="Computes a Theil-Sen Regression on a synthetic dataset.">  <div class="sphx-glr-thumbnail-title">Theil-Sen Regression</div>
</div>
* [Theil-Sen Regression](../../auto_examples/linear_model/plot_theilsen.md#sphx-glr-auto-examples-linear-model-plot-theilsen-py)

<!-- thumbnail-parent-div-close --></div>
