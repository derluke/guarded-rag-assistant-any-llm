# inplace_column_scale

### sklearn.utils.sparsefuncs.inplace_column_scale(X, scale)

Inplace column scaling of a CSC/CSR matrix.

Scale each feature of the data matrix by multiplying with specific scale
provided by the caller assuming a (n_samples, n_features) shape.

* **Parameters:**
  **X**
  : Matrix to normalize using the variance of the features. It should be
    of CSC or CSR format.

  **scale**
  : Array of precomputed feature-wise values to use for scaling.

### Examples

```pycon
>>> from sklearn.utils import sparsefuncs
>>> from scipy import sparse
>>> import numpy as np
>>> indptr = np.array([0, 3, 4, 4, 4])
>>> indices = np.array([0, 1, 2, 2])
>>> data = np.array([8, 1, 2, 5])
>>> scale = np.array([2, 3, 2])
>>> csr = sparse.csr_matrix((data, indices, indptr))
>>> csr.todense()
matrix([[8, 1, 2],
        [0, 0, 5],
        [0, 0, 0],
        [0, 0, 0]])
>>> sparsefuncs.inplace_column_scale(csr, scale)
>>> csr.todense()
matrix([[16,  3,  4],
        [ 0,  0, 10],
        [ 0,  0,  0],
        [ 0,  0,  0]])
```

<!-- !! processed by numpydoc !! -->
