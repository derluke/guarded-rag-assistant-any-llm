# SelectFwe

### *class* sklearn.feature_selection.SelectFwe(score_func=<function f_classif>, \*, alpha=0.05)

Filter: Select the p-values corresponding to Family-wise error rate.

Read more in the [User Guide](../feature_selection.md#univariate-feature-selection).

* **Parameters:**
  **score_func**
  : Function taking two arrays X and y, and returning a pair of arrays
    (scores, pvalues).
    Default is f_classif (see below “See Also”). The default function only
    works with classification tasks.

  **alpha**
  : The highest uncorrected p-value for features to keep.
* **Attributes:**
  **scores_**
  : Scores of features.

  **pvalues_**
  : p-values of feature scores.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`f_classif`](sklearn.feature_selection.f_classif.md#sklearn.feature_selection.f_classif)
: ANOVA F-value between label/feature for classification tasks.

[`chi2`](sklearn.feature_selection.chi2.md#sklearn.feature_selection.chi2)
: Chi-squared stats of non-negative features for classification tasks.

[`f_regression`](sklearn.feature_selection.f_regression.md#sklearn.feature_selection.f_regression)
: F-value between label/feature for regression tasks.

[`SelectPercentile`](sklearn.feature_selection.SelectPercentile.md#sklearn.feature_selection.SelectPercentile)
: Select features based on percentile of the highest scores.

[`SelectKBest`](sklearn.feature_selection.SelectKBest.md#sklearn.feature_selection.SelectKBest)
: Select features based on the k highest scores.

[`SelectFpr`](sklearn.feature_selection.SelectFpr.md#sklearn.feature_selection.SelectFpr)
: Select features based on a false positive rate test.

[`SelectFdr`](sklearn.feature_selection.SelectFdr.md#sklearn.feature_selection.SelectFdr)
: Select features based on an estimated false discovery rate.

[`GenericUnivariateSelect`](sklearn.feature_selection.GenericUnivariateSelect.md#sklearn.feature_selection.GenericUnivariateSelect)
: Univariate feature selector with configurable mode.

### Examples

```pycon
>>> from sklearn.datasets import load_breast_cancer
>>> from sklearn.feature_selection import SelectFwe, chi2
>>> X, y = load_breast_cancer(return_X_y=True)
>>> X.shape
(569, 30)
>>> X_new = SelectFwe(chi2, alpha=0.01).fit_transform(X, y)
>>> X_new.shape
(569, 15)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Run score function on (X, y) and get the appropriate features.

* **Parameters:**
  **X**
  : The training input samples.

  **y**
  : The target values (class labels in classification, real numbers in
    regression). If the selector is unsupervised then `y` can be set to `None`.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Mask feature names according to selected features.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_support(indices=False)

Get a mask, or integer index, of the features selected.

* **Parameters:**
  **indices**
  : If True, the return value will be an array of integers, rather
    than a boolean mask.
* **Returns:**
  **support**
  : An index that selects the retained features from a feature vector.
    If `indices` is False, this is a boolean array of shape
    [# input features], in which an element is True iff its
    corresponding feature is selected for retention. If `indices` is
    True, this is an integer array of shape [# output features] whose
    values are indices into the input feature vector.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Reverse the transformation operation.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : `X` with columns of zeros inserted where features would have
    been removed by [`transform`](#sklearn.feature_selection.SelectFwe.transform).

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Reduce X to the selected features.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : The input samples with only the selected features.

<!-- !! processed by numpydoc !! -->
