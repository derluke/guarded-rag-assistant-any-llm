# MDS

### *class* sklearn.manifold.MDS(n_components=2, \*, metric=True, n_init=4, max_iter=300, verbose=0, eps=0.001, n_jobs=None, random_state=None, dissimilarity='euclidean', normalized_stress='auto')

Multidimensional scaling.

Read more in the [User Guide](../manifold.md#multidimensional-scaling).

* **Parameters:**
  **n_components**
  : Number of dimensions in which to immerse the dissimilarities.

  **metric**
  : If `True`, perform metric MDS; otherwise, perform nonmetric MDS.
    When `False` (i.e. non-metric MDS), dissimilarities with 0 are considered as
    missing values.

  **n_init**
  : Number of times the SMACOF algorithm will be run with different
    initializations. The final results will be the best output of the runs,
    determined by the run with the smallest final stress.

  **max_iter**
  : Maximum number of iterations of the SMACOF algorithm for a single run.

  **verbose**
  : Level of verbosity.

  **eps**
  : Relative tolerance with respect to stress at which to declare
    convergence. The value of `eps` should be tuned separately depending
    on whether or not `normalized_stress` is being used.

  **n_jobs**
  : The number of jobs to use for the computation. If multiple
    initializations are used (`n_init`), each run of the algorithm is
    computed in parallel.
    <br/>
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **random_state**
  : Determines the random number generator used to initialize the centers.
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **dissimilarity**
  : Dissimilarity measure to use:
    - ‘euclidean’:
      : Pairwise Euclidean distances between points in the dataset.
    - ‘precomputed’:
      : Pre-computed dissimilarities are passed directly to `fit` and
        `fit_transform`.

  **normalized_stress**
  : Whether use and return normed stress value (Stress-1) instead of raw
    stress calculated by default. Only supported in non-metric MDS.
    <br/>
    #### Versionadded
    Added in version 1.2.
    <br/>
    #### Versionchanged
    Changed in version 1.4: The default value changed from `False` to `"auto"` in version 1.4.
* **Attributes:**
  **embedding_**
  : Stores the position of the dataset in the embedding space.

  **stress_**
  : The final value of the stress (sum of squared distance of the
    disparities and the distances for all constrained points).
    If `normalized_stress=True`, and `metric=False` returns Stress-1.
    A value of 0 indicates “perfect” fit, 0.025 excellent, 0.05 good,
    0.1 fair, and 0.2 poor [[1]](#r77760563872b-1).

  **dissimilarity_matrix_**
  : Pairwise dissimilarities between the points. Symmetric matrix that:
    - either uses a custom dissimilarity matrix by setting `dissimilarity`
      to ‘precomputed’;
    - or constructs a dissimilarity matrix from data using
      Euclidean distances.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : The number of iterations corresponding to the best stress.

#### SEE ALSO
[`sklearn.decomposition.PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA)
: Principal component analysis that is a linear dimensionality reduction method.

[`sklearn.decomposition.KernelPCA`](sklearn.decomposition.KernelPCA.md#sklearn.decomposition.KernelPCA)
: Non-linear dimensionality reduction using kernels and PCA.

[`TSNE`](sklearn.manifold.TSNE.md#sklearn.manifold.TSNE)
: T-distributed Stochastic Neighbor Embedding.

[`Isomap`](sklearn.manifold.Isomap.md#sklearn.manifold.Isomap)
: Manifold learning based on Isometric Mapping.

[`LocallyLinearEmbedding`](sklearn.manifold.LocallyLinearEmbedding.md#sklearn.manifold.LocallyLinearEmbedding)
: Manifold learning using Locally Linear Embedding.

[`SpectralEmbedding`](sklearn.manifold.SpectralEmbedding.md#sklearn.manifold.SpectralEmbedding)
: Spectral embedding for non-linear dimensionality.

### References

### Examples

```pycon
>>> from sklearn.datasets import load_digits
>>> from sklearn.manifold import MDS
>>> X, _ = load_digits(return_X_y=True)
>>> X.shape
(1797, 64)
>>> embedding = MDS(n_components=2, normalized_stress='auto')
>>> X_transformed = embedding.fit_transform(X[:100])
>>> X_transformed.shape
(100, 2)
```

For a more detailed example of usage, see
[Multi-dimensional scaling](../../auto_examples/manifold/plot_mds.md#sphx-glr-auto-examples-manifold-plot-mds-py).

For a comparison of manifold learning techniques, see
[Comparison of Manifold Learning methods](../../auto_examples/manifold/plot_compare_methods.md#sphx-glr-auto-examples-manifold-plot-compare-methods-py).

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, init=None)

Compute the position of the points in the embedding space.

* **Parameters:**
  **X**
  : Input data. If `dissimilarity=='precomputed'`, the input should
    be the dissimilarity matrix.

  **y**
  : Not used, present for API consistency by convention.

  **init**
  : Starting configuration of the embedding to initialize the SMACOF
    algorithm. By default, the algorithm is initialized with a randomly
    chosen array.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, init=None)

Fit the data from `X`, and returns the embedded coordinates.

* **Parameters:**
  **X**
  : Input data. If `dissimilarity=='precomputed'`, the input should
    be the dissimilarity matrix.

  **y**
  : Not used, present for API consistency by convention.

  **init**
  : Starting configuration of the embedding to initialize the SMACOF
    algorithm. By default, the algorithm is initialized with a randomly
    chosen array.
* **Returns:**
  **X_new**
  : X transformed in the new space.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [MDS](#sklearn.manifold.MDS)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **init**
  : Metadata routing for `init` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An illustration of dimensionality reduction on the S-curve dataset with various manifold learning methods.">  <div class="sphx-glr-thumbnail-title">Comparison of Manifold Learning methods</div>
</div>
* [Comparison of Manifold Learning methods](../../auto_examples/manifold/plot_compare_methods.md#sphx-glr-auto-examples-manifold-plot-compare-methods-py)

<div class="sphx-glr-thumbcontainer" tooltip="An application of the different manifold techniques on a spherical data-set. Here one can see the use of dimensionality reduction in order to gain some intuition regarding the manifold learning methods. Regarding the dataset, the poles are cut from the sphere, as well as a thin slice down its side. This enables the manifold learning techniques to &#x27;spread it open&#x27; whilst projecting it onto two dimensions.">  <div class="sphx-glr-thumbnail-title">Manifold Learning methods on a severed sphere</div>
</div>
* [Manifold Learning methods on a severed sphere](../../auto_examples/manifold/plot_manifold_sphere.md#sphx-glr-auto-examples-manifold-plot-manifold-sphere-py)

<div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of the metric and non-metric MDS on generated noisy data.">  <div class="sphx-glr-thumbnail-title">Multi-dimensional scaling</div>
</div>
* [Multi-dimensional scaling](../../auto_examples/manifold/plot_mds.md#sphx-glr-auto-examples-manifold-plot-mds-py)

<!-- thumbnail-parent-div-close --></div>
