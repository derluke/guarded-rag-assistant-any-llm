# FixedThresholdClassifier

### *class* sklearn.model_selection.FixedThresholdClassifier(estimator, \*, threshold='auto', pos_label=None, response_method='auto')

Binary classifier that manually sets the decision threshold.

This classifier allows to change the default decision threshold used for
converting posterior probability estimates (i.e. output of `predict_proba`) or
decision scores (i.e. output of `decision_function`) into a class label.

Here, the threshold is not optimized and is set to a constant value.

Read more in the [User Guide](../classification_threshold.md#fixedthresholdclassifier).

#### Versionadded
Added in version 1.5.

* **Parameters:**
  **estimator**
  : The binary classifier, fitted or not, for which we want to optimize
    the decision threshold used during `predict`.

  **threshold**
  : The decision threshold to use when converting posterior probability estimates
    (i.e. output of `predict_proba`) or decision scores (i.e. output of
    `decision_function`) into a class label. When `"auto"`, the threshold is set
    to 0.5 if `predict_proba` is used as `response_method`, otherwise it is set to
    0 (i.e. the default threshold for `decision_function`).

  **pos_label**
  : The label of the positive class. Used to process the output of the
    `response_method` method. When `pos_label=None`, if `y_true` is in `{-1, 1}` or
    `{0, 1}`, `pos_label` is set to 1, otherwise an error will be raised.

  **response_method**
  : Methods by the classifier `estimator` corresponding to the
    decision function for which we want to find a threshold. It can be:
    * if `"auto"`, it will try to invoke `"predict_proba"` or `"decision_function"`
      in that order.
    * otherwise, one of `"predict_proba"` or `"decision_function"`.
      If the method is not implemented by the classifier, it will raise an
      error.
* **Attributes:**
  **estimator_**
  : The fitted classifier used when predicting.

  [`classes_`](#sklearn.model_selection.FixedThresholdClassifier.classes_)
  : Classes labels.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.

#### SEE ALSO
[`sklearn.model_selection.TunedThresholdClassifierCV`](sklearn.model_selection.TunedThresholdClassifierCV.md#sklearn.model_selection.TunedThresholdClassifierCV)
: Classifier that post-tunes the decision threshold based on some metrics and using cross-validation.

[`sklearn.calibration.CalibratedClassifierCV`](sklearn.calibration.CalibratedClassifierCV.md#sklearn.calibration.CalibratedClassifierCV)
: Estimator that calibrates probabilities.

### Examples

```pycon
>>> from sklearn.datasets import make_classification
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.metrics import confusion_matrix
>>> from sklearn.model_selection import FixedThresholdClassifier, train_test_split
>>> X, y = make_classification(
...     n_samples=1_000, weights=[0.9, 0.1], class_sep=0.8, random_state=42
... )
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, stratify=y, random_state=42
... )
>>> classifier = LogisticRegression(random_state=0).fit(X_train, y_train)
>>> print(confusion_matrix(y_test, classifier.predict(X_test)))
[[217   7]
 [ 19   7]]
>>> classifier_other_threshold = FixedThresholdClassifier(
...     classifier, threshold=0.1, response_method="predict_proba"
... ).fit(X_train, y_train)
>>> print(confusion_matrix(y_test, classifier_other_threshold.predict(X_test)))
[[184  40]
 [  6  20]]
```

<!-- !! processed by numpydoc !! -->

#### *property* classes_

Classes labels.

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Decision function for samples in `X` using the fitted estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **decisions**
  : The decision function computed the fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*\*params)

Fit the classifier.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **\*\*params**
  : Parameters to pass to the `fit` method of the underlying
    classifier.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict the target of new samples.

* **Parameters:**
  **X**
  : The samples, as accepted by `estimator.predict`.
* **Returns:**
  **class_labels**
  : The predicted class.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Predict logarithm class probabilities for `X` using the fitted estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **log_probabilities**
  : The logarithm class probabilities of the input samples.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict class probabilities for `X` using the fitted estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **probabilities**
  : The class probabilities of the input samples.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [FixedThresholdClassifier](#sklearn.model_selection.FixedThresholdClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This examples showcases some use cases of FrozenEstimator.">  <div class="sphx-glr-thumbnail-title">Examples of Using FrozenEstimator</div>
</div>
* [Examples of Using FrozenEstimator](../../auto_examples/frozen/plot_frozen_examples.md#sphx-glr-auto-examples-frozen-plot-frozen-examples-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.6! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_6&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.6</div>
</div>
* [Release Highlights for scikit-learn 1.6](../../auto_examples/release_highlights/plot_release_highlights_1_6_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-6-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<!-- thumbnail-parent-div-close --></div>
