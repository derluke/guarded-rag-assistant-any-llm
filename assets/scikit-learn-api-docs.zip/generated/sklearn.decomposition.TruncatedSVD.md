# TruncatedSVD

### *class* sklearn.decomposition.TruncatedSVD(n_components=2, \*, algorithm='randomized', n_iter=5, n_oversamples=10, power_iteration_normalizer='auto', random_state=None, tol=0.0)

Dimensionality reduction using truncated SVD (aka LSA).

This transformer performs linear dimensionality reduction by means of
truncated singular value decomposition (SVD). Contrary to PCA, this
estimator does not center the data before computing the singular value
decomposition. This means it can work with sparse matrices
efficiently.

In particular, truncated SVD works on term count/tf-idf matrices as
returned by the vectorizers in [`sklearn.feature_extraction.text`](../../api/sklearn.feature_extraction.md#module-sklearn.feature_extraction.text). In
that context, it is known as latent semantic analysis (LSA).

This estimator supports two algorithms: a fast randomized SVD solver, and
a “naive” algorithm that uses ARPACK as an eigensolver on `X * X.T` or
`X.T * X`, whichever is more efficient.

Read more in the [User Guide](../decomposition.md#lsa).

* **Parameters:**
  **n_components**
  : Desired dimensionality of output data.
    If algorithm=’arpack’, must be strictly less than the number of features.
    If algorithm=’randomized’, must be less than or equal to the number of features.
    The default value is useful for visualisation. For LSA, a value of
    100 is recommended.

  **algorithm**
  : SVD solver to use. Either “arpack” for the ARPACK wrapper in SciPy
    (scipy.sparse.linalg.svds), or “randomized” for the randomized
    algorithm due to Halko (2009).

  **n_iter**
  : Number of iterations for randomized SVD solver. Not used by ARPACK. The
    default is larger than the default in
    [`randomized_svd`](sklearn.utils.extmath.randomized_svd.md#sklearn.utils.extmath.randomized_svd) to handle sparse
    matrices that may have large slowly decaying spectrum.

  **n_oversamples**
  : Number of oversamples for randomized SVD solver. Not used by ARPACK.
    See [`randomized_svd`](sklearn.utils.extmath.randomized_svd.md#sklearn.utils.extmath.randomized_svd) for a complete
    description.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **power_iteration_normalizer**
  : Power iteration normalizer for randomized SVD solver.
    Not used by ARPACK. See [`randomized_svd`](sklearn.utils.extmath.randomized_svd.md#sklearn.utils.extmath.randomized_svd)
    for more details.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **random_state**
  : Used during randomized svd. Pass an int for reproducible results across
    multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **tol**
  : Tolerance for ARPACK. 0 means machine precision. Ignored by randomized
    SVD solver.
* **Attributes:**
  **components_**
  : The right singular vectors of the input data.

  **explained_variance_**
  : The variance of the training samples transformed by a projection to
    each component.

  **explained_variance_ratio_**
  : Percentage of variance explained by each of the selected components.

  **singular_values_**
  : The singular values corresponding to each of the selected components.
    The singular values are equal to the 2-norms of the `n_components`
    variables in the lower-dimensional space.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`DictionaryLearning`](sklearn.decomposition.DictionaryLearning.md#sklearn.decomposition.DictionaryLearning)
: Find a dictionary that sparsely encodes data.

[`FactorAnalysis`](sklearn.decomposition.FactorAnalysis.md#sklearn.decomposition.FactorAnalysis)
: A simple linear generative model with Gaussian latent variables.

[`IncrementalPCA`](sklearn.decomposition.IncrementalPCA.md#sklearn.decomposition.IncrementalPCA)
: Incremental principal components analysis.

[`KernelPCA`](sklearn.decomposition.KernelPCA.md#sklearn.decomposition.KernelPCA)
: Kernel Principal component analysis.

[`NMF`](sklearn.decomposition.NMF.md#sklearn.decomposition.NMF)
: Non-Negative Matrix Factorization.

[`PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA)
: Principal component analysis.

### Notes

SVD suffers from a problem called “sign indeterminacy”, which means the
sign of the `components_` and the output from transform depend on the
algorithm and random state. To work around this, fit instances of this
class to data once, then keep the instance around to do transformations.

### References

[Halko, et al. (2009). “Finding structure with randomness:
Stochastic algorithms for constructing approximate matrix decompositions”](https://arxiv.org/abs/0909.4061)

### Examples

```pycon
>>> from sklearn.decomposition import TruncatedSVD
>>> from scipy.sparse import csr_matrix
>>> import numpy as np
>>> np.random.seed(0)
>>> X_dense = np.random.rand(100, 100)
>>> X_dense[:, 2 * np.arange(50)] = 0
>>> X = csr_matrix(X_dense)
>>> svd = TruncatedSVD(n_components=5, n_iter=7, random_state=42)
>>> svd.fit(X)
TruncatedSVD(n_components=5, n_iter=7, random_state=42)
>>> print(svd.explained_variance_ratio_)
[0.0157... 0.0512... 0.0499... 0.0479... 0.0453...]
>>> print(svd.explained_variance_ratio_.sum())
0.2102...
>>> print(svd.singular_values_)
[35.2410...  4.5981...   4.5420...  4.4486...  4.3288...]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit model on training data X.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : Returns the transformer object.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Fit model to X and perform dimensionality reduction on X.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **X_new**
  : Reduced version of X. This will always be a dense array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Transform X back to its original space.

Returns an array X_original whose transform would be X.

* **Parameters:**
  **X**
  : New data.
* **Returns:**
  **X_original**
  : Note that this is always a dense array.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Perform dimensionality reduction on X.

* **Parameters:**
  **X**
  : New data.
* **Returns:**
  **X_new**
  : Reduced version of X. This will always be a dense array.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="RandomTreesEmbedding provides a way to map data to a very high-dimensional, sparse representation, which might be beneficial for classification. The mapping is completely unsupervised and very efficient.">  <div class="sphx-glr-thumbnail-title">Hashing feature transformation using Totally Random Trees</div>
</div>
* [Hashing feature transformation using Totally Random Trees](../../auto_examples/ensemble/plot_random_forest_embedding.md#sphx-glr-auto-examples-ensemble-plot-random-forest-embedding-py)

<div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how the scikit-learn API can be used to cluster documents by topics using a Bag of Words approach.">  <div class="sphx-glr-thumbnail-title">Clustering text documents using k-means</div>
</div>
* [Clustering text documents using k-means](../../auto_examples/text/plot_document_clustering.md#sphx-glr-auto-examples-text-plot-document-clustering-py)

<!-- thumbnail-parent-div-close --></div>
