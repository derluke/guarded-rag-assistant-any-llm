# LabelBinarizer

### *class* sklearn.preprocessing.LabelBinarizer(\*, neg_label=0, pos_label=1, sparse_output=False)

Binarize labels in a one-vs-all fashion.

Several regression and binary classification algorithms are
available in scikit-learn. A simple way to extend these algorithms
to the multi-class classification case is to use the so-called
one-vs-all scheme.

At learning time, this simply consists in learning one regressor
or binary classifier per class. In doing so, one needs to convert
multi-class labels to binary labels (belong or does not belong
to the class). `LabelBinarizer` makes this process easy with the
transform method.

At prediction time, one assigns the class for which the corresponding
model gave the greatest confidence. `LabelBinarizer` makes this easy
with the [`inverse_transform`](#sklearn.preprocessing.LabelBinarizer.inverse_transform) method.

Read more in the [User Guide](../preprocessing_targets.md#preprocessing-targets).

* **Parameters:**
  **neg_label**
  : Value with which negative labels must be encoded.

  **pos_label**
  : Value with which positive labels must be encoded.

  **sparse_output**
  : True if the returned array from transform is desired to be in sparse
    CSR format.
* **Attributes:**
  **classes_**
  : Holds the label for each class.

  **y_type_**
  : Represents the type of the target data as evaluated by
    [`type_of_target`](sklearn.utils.multiclass.type_of_target.md#sklearn.utils.multiclass.type_of_target). Possible type are
    ‘continuous’, ‘continuous-multioutput’, ‘binary’, ‘multiclass’,
    ‘multiclass-multioutput’, ‘multilabel-indicator’, and ‘unknown’.

  **sparse_input_**
  : `True` if the input data to transform is given as a sparse matrix,
    : `False` otherwise.

#### SEE ALSO
[`label_binarize`](sklearn.preprocessing.label_binarize.md#sklearn.preprocessing.label_binarize)
: Function to perform the transform operation of LabelBinarizer with fixed classes.

[`OneHotEncoder`](sklearn.preprocessing.OneHotEncoder.md#sklearn.preprocessing.OneHotEncoder)
: Encode categorical features using a one-hot aka one-of-K scheme.

### Examples

```pycon
>>> from sklearn.preprocessing import LabelBinarizer
>>> lb = LabelBinarizer()
>>> lb.fit([1, 2, 6, 4, 2])
LabelBinarizer()
>>> lb.classes_
array([1, 2, 4, 6])
>>> lb.transform([1, 6])
array([[1, 0, 0, 0],
       [0, 0, 0, 1]])
```

Binary targets transform to a column vector

```pycon
>>> lb = LabelBinarizer()
>>> lb.fit_transform(['yes', 'no', 'no', 'yes'])
array([[1],
       [0],
       [0],
       [1]])
```

Passing a 2D matrix for multilabel classification

```pycon
>>> import numpy as np
>>> lb.fit(np.array([[0, 1, 1], [1, 0, 0]]))
LabelBinarizer()
>>> lb.classes_
array([0, 1, 2])
>>> lb.transform([0, 1, 2, 1])
array([[1, 0, 0],
       [0, 1, 0],
       [0, 0, 1],
       [0, 1, 0]])
```

<!-- !! processed by numpydoc !! -->

#### fit(y)

Fit label binarizer.

* **Parameters:**
  **y**
  : Target values. The 2-d matrix should only contain 0 and 1,
    represents multilabel classification.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(y)

Fit label binarizer/transform multi-class labels to binary labels.

The output of transform is sometimes referred to as
the 1-of-K coding scheme.

* **Parameters:**
  **y**
  : Target values. The 2-d matrix should only contain 0 and 1,
    represents multilabel classification. Sparse matrix can be
    CSR, CSC, COO, DOK, or LIL.
* **Returns:**
  **Y**
  : Shape will be (n_samples, 1) for binary problems. Sparse matrix
    will be of CSR format.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(Y, threshold=None)

Transform binary labels back to multi-class labels.

* **Parameters:**
  **Y**
  : Target values. All sparse matrices are converted to CSR before
    inverse transformation.

  **threshold**
  : Threshold used in the binary and multi-label cases.
    <br/>
    Use 0 when `Y` contains the output of [decision_function](../../glossary.md#term-decision_function)
    (classifier).
    Use 0.5 when `Y` contains the output of [predict_proba](../../glossary.md#term-predict_proba).
    <br/>
    If None, the threshold is assumed to be half way between
    neg_label and pos_label.
* **Returns:**
  **y**
  : Target values. Sparse matrix will be of CSR format.

### Notes

In the case when the binary labels are fractional
(probabilistic), [`inverse_transform`](#sklearn.preprocessing.LabelBinarizer.inverse_transform) chooses the class with the
greatest value. Typically, this allows to use the output of a
linear model’s [decision_function](../../glossary.md#term-decision_function) method directly as the input
of [`inverse_transform`](#sklearn.preprocessing.LabelBinarizer.inverse_transform).

<!-- !! processed by numpydoc !! -->

#### set_inverse_transform_request(\*, threshold: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LabelBinarizer](#sklearn.preprocessing.LabelBinarizer)

Request metadata passed to the `inverse_transform` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `inverse_transform` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `inverse_transform`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **threshold**
  : Metadata routing for `threshold` parameter in `inverse_transform`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(y)

Transform multi-class labels to binary labels.

The output of transform is sometimes referred to by some authors as
the 1-of-K coding scheme.

* **Parameters:**
  **y**
  : Target values. The 2-d matrix should only contain 0 and 1,
    represents multilabel classification. Sparse matrix can be
    CSR, CSC, COO, DOK, or LIL.
* **Returns:**
  **Y**
  : Shape will be (n_samples, 1) for binary problems. Sparse matrix
    will be of CSR format.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example describes the use of the Receiver Operating Characteristic (ROC) metric to evaluate the quality of multiclass classifiers.">  <div class="sphx-glr-thumbnail-title">Multiclass Receiver Operating Characteristic (ROC)</div>
</div>
* [Multiclass Receiver Operating Characteristic (ROC)](../../auto_examples/model_selection/plot_roc.md#sphx-glr-auto-examples-model-selection-plot-roc-py)

<!-- thumbnail-parent-div-close --></div>
