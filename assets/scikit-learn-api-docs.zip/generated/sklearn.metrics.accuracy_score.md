# accuracy_score

### sklearn.metrics.accuracy_score(y_true, y_pred, \*, normalize=True, sample_weight=None)

Accuracy classification score.

In multilabel classification, this function computes subset accuracy:
the set of labels predicted for a sample must *exactly* match the
corresponding set of labels in y_true.

Read more in the [User Guide](../model_evaluation.md#accuracy-score).

* **Parameters:**
  **y_true**
  : Ground truth (correct) labels.

  **y_pred**
  : Predicted labels, as returned by a classifier.

  **normalize**
  : If `False`, return the number of correctly classified samples.
    Otherwise, return the fraction of correctly classified samples.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : If `normalize == True`, return the fraction of correctly
    classified samples (float), else returns the number of correctly
    classified samples (int).
    <br/>
    The best performance is 1 with `normalize == True` and the number
    of samples with `normalize == False`.

#### SEE ALSO
[`balanced_accuracy_score`](sklearn.metrics.balanced_accuracy_score.md#sklearn.metrics.balanced_accuracy_score)
: Compute the balanced accuracy to deal with imbalanced datasets.

[`jaccard_score`](sklearn.metrics.jaccard_score.md#sklearn.metrics.jaccard_score)
: Compute the Jaccard similarity coefficient score.

[`hamming_loss`](sklearn.metrics.hamming_loss.md#sklearn.metrics.hamming_loss)
: Compute the average Hamming loss or Hamming distance between two sets of samples.

[`zero_one_loss`](sklearn.metrics.zero_one_loss.md#sklearn.metrics.zero_one_loss)
: Compute the Zero-one classification loss. By default, the function will return the percentage of imperfectly predicted subsets.

### Examples

```pycon
>>> from sklearn.metrics import accuracy_score
>>> y_pred = [0, 2, 1, 3]
>>> y_true = [0, 1, 2, 3]
>>> accuracy_score(y_true, y_pred)
0.5
>>> accuracy_score(y_true, y_pred, normalize=False)
2.0
```

In the multilabel case with binary label indicators:

```pycon
>>> import numpy as np
>>> accuracy_score(np.array([[0, 1], [1, 1]]), np.ones((2, 2)))
0.5
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Plot the classification probability for different classifiers. We use a 3 class dataset, and we classify it with a Support Vector classifier, L1 and L2 penalized logistic regression (multinomial multiclass), a One-Vs-Rest version with logistic regression, and Gaussian process classification.">  <div class="sphx-glr-thumbnail-title">Plot classification probability</div>
</div>
* [Plot classification probability](../../auto_examples/classification/plot_classification_probability.md#sphx-glr-auto-examples-classification-plot-classification-probability-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how boosting can improve the prediction accuracy on a multi-label classification problem. It reproduces a similar experiment as depicted by Figure 1 in Zhu et al [1]_.">  <div class="sphx-glr-thumbnail-title">Multi-class AdaBoosted Decision Trees</div>
</div>
* [Multi-class AdaBoosted Decision Trees](../../auto_examples/ensemble/plot_adaboost_multiclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-multiclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the predicted probability of GPC for an RBF kernel with different choices of the hyperparameters. The first figure shows the predicted probability of GPC with arbitrarily chosen hyperparameters and with the hyperparameters corresponding to the maximum log-marginal-likelihood (LML).">  <div class="sphx-glr-thumbnail-title">Probabilistic predictions with Gaussian process classification (GPC)</div>
</div>
* [Probabilistic predictions with Gaussian process classification (GPC)](../../auto_examples/gaussian_process/plot_gpc.md#sphx-glr-auto-examples-gaussian-process-plot-gpc-py)

<div class="sphx-glr-thumbcontainer" tooltip="Multiple metric parameter search can be done by setting the scoring parameter to a list of metric scorer names or a dict mapping the scorer names to the scorer callables.">  <div class="sphx-glr-thumbnail-title">Demonstration of multi-metric evaluation on cross_val_score and GridSearchCV</div>
</div>
* [Demonstration of multi-metric evaluation on cross_val_score and GridSearchCV](../../auto_examples/model_selection/plot_multi_metric_evaluation.md#sphx-glr-auto-examples-model-selection-plot-multi-metric-evaluation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature scaling through standardization, also called Z-score normalization, is an important preprocessing step for many machine learning algorithms. It involves rescaling each feature such that it has a standard deviation of 1 and a mean of 0.">  <div class="sphx-glr-thumbnail-title">Importance of Feature Scaling</div>
</div>
* [Importance of Feature Scaling](../../auto_examples/preprocessing/plot_scaling_importance.md#sphx-glr-auto-examples-preprocessing-plot-scaling-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of a varying threshold on self-training. The breast_cancer dataset is loaded, and labels are deleted such that only 50 out of 569 samples have labels. A SelfTrainingClassifier is fitted on this dataset, with varying thresholds.">  <div class="sphx-glr-thumbnail-title">Effect of varying threshold for self-training</div>
</div>
* [Effect of varying threshold for self-training](../../auto_examples/semi_supervised/plot_self_training_varying_threshold.md#sphx-glr-auto-examples-semi-supervised-plot-self-training-varying-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<!-- thumbnail-parent-div-close --></div>
