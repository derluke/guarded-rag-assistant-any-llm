# OrthogonalMatchingPursuitCV

### *class* sklearn.linear_model.OrthogonalMatchingPursuitCV(\*, copy=True, fit_intercept=True, max_iter=None, cv=None, n_jobs=None, verbose=False)

Cross-validated Orthogonal Matching Pursuit model (OMP).

See glossary entry for [cross-validation estimator](../../glossary.md#term-cross-validation-estimator).

Read more in the [User Guide](../linear_model.md#omp).

* **Parameters:**
  **copy**
  : Whether the design matrix X must be copied by the algorithm. A false
    value is only helpful if X is already Fortran-ordered, otherwise a
    copy is made anyway.

  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to false, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **max_iter**
  : Maximum numbers of iterations to perform, therefore maximum features
    to include. 10% of `n_features` but at least 5 if available.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross-validation,
    - integer, to specify the number of folds.
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value if None changed from 3-fold to 5-fold.

  **n_jobs**
  : Number of CPUs to use during the cross validation.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **verbose**
  : Sets the verbosity amount.
* **Attributes:**
  **intercept_**
  : Independent term in decision function.

  **coef_**
  : Parameter vector (w in the problem formulation).

  **n_nonzero_coefs_**
  : Estimated number of non-zero coefficients giving the best mean squared
    error over the cross-validation folds.

  **n_iter_**
  : Number of active features across every target for the model refit with
    the best hyperparameters got by cross-validating across all folds.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`orthogonal_mp`](sklearn.linear_model.orthogonal_mp.md#sklearn.linear_model.orthogonal_mp)
: Solves n_targets Orthogonal Matching Pursuit problems.

[`orthogonal_mp_gram`](sklearn.linear_model.orthogonal_mp_gram.md#sklearn.linear_model.orthogonal_mp_gram)
: Solves n_targets Orthogonal Matching Pursuit problems using only the Gram matrix X.T \* X and the product X.T \* y.

[`lars_path`](sklearn.linear_model.lars_path.md#sklearn.linear_model.lars_path)
: Compute Least Angle Regression or Lasso path using LARS algorithm.

[`Lars`](sklearn.linear_model.Lars.md#sklearn.linear_model.Lars)
: Least Angle Regression model a.k.a. LAR.

[`LassoLars`](sklearn.linear_model.LassoLars.md#sklearn.linear_model.LassoLars)
: Lasso model fit with Least Angle Regression a.k.a. Lars.

[`OrthogonalMatchingPursuit`](sklearn.linear_model.OrthogonalMatchingPursuit.md#sklearn.linear_model.OrthogonalMatchingPursuit)
: Orthogonal Matching Pursuit model (OMP).

[`LarsCV`](sklearn.linear_model.LarsCV.md#sklearn.linear_model.LarsCV)
: Cross-validated Least Angle Regression model.

[`LassoLarsCV`](sklearn.linear_model.LassoLarsCV.md#sklearn.linear_model.LassoLarsCV)
: Cross-validated Lasso model fit with Least Angle Regression.

[`sklearn.decomposition.sparse_encode`](sklearn.decomposition.sparse_encode.md#sklearn.decomposition.sparse_encode)
: Generic sparse coding. Each column of the result is the solution to a Lasso problem.

### Notes

In `fit`, once the optimal number of non-zero coefficients is found through
cross-validation, the model is fit again using the entire training set.

### Examples

```pycon
>>> from sklearn.linear_model import OrthogonalMatchingPursuitCV
>>> from sklearn.datasets import make_regression
>>> X, y = make_regression(n_features=100, n_informative=10,
...                        noise=4, random_state=0)
>>> reg = OrthogonalMatchingPursuitCV(cv=5).fit(X, y)
>>> reg.score(X, y)
0.9991...
>>> reg.n_nonzero_coefs_
np.int64(10)
>>> reg.predict(X[:1,])
array([-78.3854...])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*\*fit_params)

Fit the model using X, y as training data.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values. Will be cast to X’s dtype if necessary.

  **\*\*fit_params**
  : Parameters to pass to the underlying splitter.
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.4.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [OrthogonalMatchingPursuitCV](#sklearn.linear_model.OrthogonalMatchingPursuitCV)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Using orthogonal matching pursuit for recovering a sparse signal from a noisy measurement encoded with a dictionary">  <div class="sphx-glr-thumbnail-title">Orthogonal Matching Pursuit</div>
</div>
* [Orthogonal Matching Pursuit](../../auto_examples/linear_model/plot_omp.md#sphx-glr-auto-examples-linear-model-plot-omp-py)

<!-- thumbnail-parent-div-close --></div>
