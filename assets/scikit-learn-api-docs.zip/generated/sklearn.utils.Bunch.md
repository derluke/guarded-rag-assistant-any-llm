# Bunch

### *class* sklearn.utils.Bunch(\*\*kwargs)

Container object exposing keys as attributes.

Bunch objects are sometimes used as an output for functions and methods.
They extend dictionaries by enabling values to be accessed by key,
`bunch["value_key"]`, or by an attribute, `bunch.value_key`.

### Examples

```pycon
>>> from sklearn.utils import Bunch
>>> b = Bunch(a=1, b=2)
>>> b['b']
2
>>> b.b
2
>>> b.a = 3
>>> b['a']
3
>>> b.c = 6
>>> b['c']
6
```

<!-- !! processed by numpydoc !! -->

#### clear() → None.  Remove all items from D.

<!-- !! processed by numpydoc !! -->

#### copy() → a shallow copy of D

<!-- !! processed by numpydoc !! -->

#### fromkeys(iterable, value=None, /)

Create a new dictionary with keys from iterable and values set to value.

<!-- !! processed by numpydoc !! -->

#### get(key, default=None, /)

Return the value for key if key is in the dictionary, else default.

<!-- !! processed by numpydoc !! -->

#### items() → a set-like object providing a view on D's items

<!-- !! processed by numpydoc !! -->

#### keys() → a set-like object providing a view on D's keys

<!-- !! processed by numpydoc !! -->

#### pop(key, default=<unrepresentable>, /)

If key is not found, default is returned if given, otherwise KeyError is raised

<!-- !! processed by numpydoc !! -->

#### popitem(/)

Remove and return a (key, value) pair as a 2-tuple.

Pairs are returned in LIFO (last-in, first-out) order.
Raises KeyError if the dict is empty.

<!-- !! processed by numpydoc !! -->

#### setdefault(key, default=None, /)

Insert key with a value of default if key is not in the dictionary.

Return the value for key if key is in the dictionary, else default.

<!-- !! processed by numpydoc !! -->

#### update(\*\*F) → None.  Update D from dict/iterable E and F.

If E is present and has a .keys() method, then does:  for k in E: D[k] = E[k]
If E is present and lacks a .keys() method, then does:  for k, v in E: D[k] = v
In either case, this is followed by: for k in F:  D[k] = F[k]

<!-- !! processed by numpydoc !! -->

#### values() → an object providing a view on D's values

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Modeling species&#x27; geographic distributions is an important problem in conservation biology. In this example, we model the geographic distribution of two South American mammals given past observations and 14 environmental variables. Since we have only positive examples (there are no unsuccessful observations), we cast this problem as a density estimation problem and use the OneClassSVM as our modeling tool. The dataset is provided by Phillips et. al. (2006). If available, the example uses basemap to plot the coast lines and national boundaries of South America.">  <div class="sphx-glr-thumbnail-title">Species distribution modeling</div>
</div>
* [Species distribution modeling](../../auto_examples/applications/plot_species_distribution_modeling.md#sphx-glr-auto-examples-applications-plot-species-distribution-modeling-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows a well known decomposition technique known as Principal Component Analysis (PCA) on the Iris dataset.">  <div class="sphx-glr-thumbnail-title">Principal Component Analysis (PCA) on Iris Dataset</div>
</div>
* [Principal Component Analysis (PCA) on Iris Dataset](../../auto_examples/decomposition/plot_pca_iris.md#sphx-glr-auto-examples-decomposition-plot-pca-iris-py)

<!-- thumbnail-parent-div-close --></div>
