# get_config

### sklearn.get_config()

Retrieve current values for configuration set by [`set_config`](sklearn.set_config.md#sklearn.set_config).

* **Returns:**
  **config**
  : Keys are parameter names that can be passed to [`set_config`](sklearn.set_config.md#sklearn.set_config).

#### SEE ALSO
[`config_context`](sklearn.config_context.md#sklearn.config_context)
: Context manager for global scikit-learn configuration.

[`set_config`](sklearn.set_config.md#sklearn.set_config)
: Set global scikit-learn configuration.

### Examples

```pycon
>>> import sklearn
>>> config = sklearn.get_config()
>>> config.keys()
dict_keys([...])
```

<!-- !! processed by numpydoc !! -->
