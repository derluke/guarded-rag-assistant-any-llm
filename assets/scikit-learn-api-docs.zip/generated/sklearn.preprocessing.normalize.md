# normalize

### sklearn.preprocessing.normalize(X, norm='l2', \*, axis=1, copy=True, return_norm=False)

Scale input vectors individually to unit norm (vector length).

Read more in the [User Guide](../preprocessing.md#preprocessing-normalization).

* **Parameters:**
  **X**
  : The data to normalize, element by element.
    scipy.sparse matrices should be in CSR format to avoid an
    un-necessary copy.

  **norm**
  : The norm to use to normalize each non zero sample (or each non-zero
    feature if axis is 0).

  **axis**
  : Define axis used to normalize the data along. If 1, independently
    normalize each sample, otherwise (if 0) normalize each feature.

  **copy**
  : If False, try to avoid a copy and normalize in place.
    This is not guaranteed to always work in place; e.g. if the data is
    a numpy array with an int dtype, a copy will be returned even with
    copy=False.

  **return_norm**
  : Whether to return the computed norms.
* **Returns:**
  **X**
  : Normalized input X.

  **norms**
  : An array of norms along given axis for X.
    When X is sparse, a NotImplementedError will be raised
    for norm ‘l1’ or ‘l2’.

#### SEE ALSO
[`Normalizer`](sklearn.preprocessing.Normalizer.md#sklearn.preprocessing.Normalizer)
: Performs normalization using the Transformer API (e.g. as part of a preprocessing [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)).

### Notes

For a comparison of the different scalers, transformers, and normalizers,
see: [Compare the effect of different scalers on data with outliers](../../auto_examples/preprocessing/plot_all_scaling.md#sphx-glr-auto-examples-preprocessing-plot-all-scaling-py).

### Examples

```pycon
>>> from sklearn.preprocessing import normalize
>>> X = [[-2, 1, 2], [-1, 0, 1]]
>>> normalize(X, norm="l1")  # L1 normalization each row independently
array([[-0.4,  0.2,  0.4],
       [-0.5,  0. ,  0.5]])
>>> normalize(X, norm="l2")  # L2 normalization each row independently
array([[-0.66...,  0.33...,  0.66...],
       [-0.70...,  0.     ,  0.70...]])
```

<!-- !! processed by numpydoc !! -->
