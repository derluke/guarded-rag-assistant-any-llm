# grid_to_graph

### sklearn.feature_extraction.image.grid_to_graph(n_x, n_y, n_z=1, \*, mask=None, return_as=<class 'scipy.sparse._coo.coo_matrix'>, dtype=<class 'int'>)

Graph of the pixel-to-pixel connections.

Edges exist if 2 voxels are connected.

* **Parameters:**
  **n_x**
  : Dimension in x axis.

  **n_y**
  : Dimension in y axis.

  **n_z**
  : Dimension in z axis.

  **mask**
  : An optional mask of the image, to consider only part of the
    pixels.

  **return_as**
  : The class to use to build the returned adjacency matrix.

  **dtype**
  : The data of the returned sparse matrix. By default it is int.
* **Returns:**
  **graph**
  : The computed adjacency matrix.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.feature_extraction.image import grid_to_graph
>>> shape_img = (4, 4, 1)
>>> mask = np.zeros(shape=shape_img, dtype=bool)
>>> mask[[1, 2], [1, 2], :] = True
>>> graph = grid_to_graph(*shape_img, mask=mask)
>>> print(graph)
<COOrdinate sparse matrix of dtype 'int64'
  with 2 stored elements and shape (2, 2)>
  Coords    Values
  (0, 0)    1
  (1, 1)    1
```

<!-- !! processed by numpydoc !! -->
