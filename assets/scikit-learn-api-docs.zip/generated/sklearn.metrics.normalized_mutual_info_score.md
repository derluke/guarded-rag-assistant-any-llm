# normalized_mutual_info_score

### sklearn.metrics.normalized_mutual_info_score(labels_true, labels_pred, \*, average_method='arithmetic')

Normalized Mutual Information between two clusterings.

Normalized Mutual Information (NMI) is a normalization of the Mutual
Information (MI) score to scale the results between 0 (no mutual
information) and 1 (perfect correlation). In this function, mutual
information is normalized by some generalized mean of `H(labels_true)`
and `H(labels_pred))`, defined by the `average_method`.

This measure is not adjusted for chance. Therefore
[`adjusted_mutual_info_score`](sklearn.metrics.adjusted_mutual_info_score.md#sklearn.metrics.adjusted_mutual_info_score) might be preferred.

This metric is independent of the absolute values of the labels:
a permutation of the class or cluster label values won’t change the
score value in any way.

This metric is furthermore symmetric: switching `label_true` with
`label_pred` will return the same score value. This can be useful to
measure the agreement of two independent label assignments strategies
on the same dataset when the real ground truth is not known.

Read more in the [User Guide](../clustering.md#mutual-info-score).

* **Parameters:**
  **labels_true**
  : A clustering of the data into disjoint subsets.

  **labels_pred**
  : A clustering of the data into disjoint subsets.

  **average_method**
  : How to compute the normalizer in the denominator.
    <br/>
    #### Versionadded
    Added in version 0.20.
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default value of `average_method` changed from ‘geometric’ to
    ‘arithmetic’.
* **Returns:**
  **nmi**
  : Score between 0.0 and 1.0 in normalized nats (based on the natural
    logarithm). 1.0 stands for perfectly complete labeling.

#### SEE ALSO
[`v_measure_score`](sklearn.metrics.v_measure_score.md#sklearn.metrics.v_measure_score)
: V-Measure (NMI with arithmetic mean option).

[`adjusted_rand_score`](sklearn.metrics.adjusted_rand_score.md#sklearn.metrics.adjusted_rand_score)
: Adjusted Rand Index.

[`adjusted_mutual_info_score`](sklearn.metrics.adjusted_mutual_info_score.md#sklearn.metrics.adjusted_mutual_info_score)
: Adjusted Mutual Information (adjusted against chance).

### Examples

Perfect labelings are both homogeneous and complete, hence have
score 1.0:

```default
>>> from sklearn.metrics.cluster import normalized_mutual_info_score
>>> normalized_mutual_info_score([0, 0, 1, 1], [0, 0, 1, 1])
... 
1.0
>>> normalized_mutual_info_score([0, 0, 1, 1], [1, 1, 0, 0])
... 
1.0
```

If classes members are completely split across different clusters,
the assignment is totally in-complete, hence the NMI is null:

```default
>>> normalized_mutual_info_score([0, 0, 0, 0], [0, 1, 2, 3])
... 
0.0
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="- a first experiment with fixed &quot;ground truth labels&quot; (and therefore fixed   number of classes) and randomly &quot;predicted labels&quot;; - a second experiment with varying &quot;ground truth labels&quot;, randomly &quot;predicted   labels&quot;. The &quot;predicted labels&quot; have the same number of classes and clusters   as the &quot;ground truth labels&quot;.">  <div class="sphx-glr-thumbnail-title">Adjustment for chance in clustering performance evaluation</div>
</div>
* [Adjustment for chance in clustering performance evaluation](../../auto_examples/cluster/plot_adjusted_for_chance_measures.md#sphx-glr-auto-examples-cluster-plot-adjusted-for-chance-measures-py)

<!-- thumbnail-parent-div-close --></div>
