# RobustScaler

### *class* sklearn.preprocessing.RobustScaler(\*, with_centering=True, with_scaling=True, quantile_range=(25.0, 75.0), copy=True, unit_variance=False)

Scale features using statistics that are robust to outliers.

This Scaler removes the median and scales the data according to
the quantile range (defaults to IQR: Interquartile Range).
The IQR is the range between the 1st quartile (25th quantile)
and the 3rd quartile (75th quantile).

Centering and scaling happen independently on each feature by
computing the relevant statistics on the samples in the training
set. Median and interquartile range are then stored to be used on
later data using the [`transform`](#sklearn.preprocessing.RobustScaler.transform) method.

Standardization of a dataset is a common preprocessing for many machine
learning estimators. Typically this is done by removing the mean and
scaling to unit variance. However, outliers can often influence the sample
mean / variance in a negative way. In such cases, using the median and the
interquartile range often give better results. For an example visualization
and comparison to other scalers, refer to [Compare RobustScaler with
other scalers](../../auto_examples/preprocessing/plot_all_scaling.md#plot-all-scaling-robust-scaler-section).

#### Versionadded
Added in version 0.17.

Read more in the [User Guide](../preprocessing.md#preprocessing-scaler).

* **Parameters:**
  **with_centering**
  : If `True`, center the data before scaling.
    This will cause [`transform`](#sklearn.preprocessing.RobustScaler.transform) to raise an exception when attempted
    on sparse matrices, because centering them entails building a dense
    matrix which in common use cases is likely to be too large to fit in
    memory.

  **with_scaling**
  : If `True`, scale the data to interquartile range.

  **quantile_range**
  : Quantile range used to calculate `scale_`. By default this is equal to
    the IQR, i.e., `q_min` is the first quantile and `q_max` is the third
    quantile.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **copy**
  : If `False`, try to avoid a copy and do inplace scaling instead.
    This is not guaranteed to always work inplace; e.g. if the data is
    not a NumPy array or scipy.sparse CSR matrix, a copy may still be
    returned.

  **unit_variance**
  : If `True`, scale data so that normally distributed features have a
    variance of 1. In general, if the difference between the x-values of
    `q_max` and `q_min` for a standard normal distribution is greater
    than 1, the dataset will be scaled down. If less than 1, the dataset
    will be scaled up.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  **center_**
  : The median value for each feature in the training set.

  **scale_**
  : The (scaled) interquartile range for each feature in the training set.
    <br/>
    #### Versionadded
    Added in version 0.17: *scale_* attribute.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`robust_scale`](sklearn.preprocessing.robust_scale.md#sklearn.preprocessing.robust_scale)
: Equivalent function without the estimator API.

[`sklearn.decomposition.PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA)
: Further removes the linear correlation across features with ‘whiten=True’.

### Notes

[https://en.wikipedia.org/wiki/Median](https://en.wikipedia.org/wiki/Median)
[https://en.wikipedia.org/wiki/Interquartile_range](https://en.wikipedia.org/wiki/Interquartile_range)

### Examples

```pycon
>>> from sklearn.preprocessing import RobustScaler
>>> X = [[ 1., -2.,  2.],
...      [ -2.,  1.,  3.],
...      [ 4.,  1., -2.]]
>>> transformer = RobustScaler().fit(X)
>>> transformer
RobustScaler()
>>> transformer.transform(X)
array([[ 0. , -2. ,  0. ],
       [-1. ,  0. ,  0.4],
       [ 1. ,  0. , -1.6]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Compute the median and quantiles to be used for scaling.

* **Parameters:**
  **X**
  : The data used to compute the median and quantiles
    used for later scaling along the features axis.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : Fitted scaler.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Same as input features.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Scale back the data to the original representation.

* **Parameters:**
  **X**
  : The rescaled data to be transformed back.
* **Returns:**
  **X_tr**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Center and scale the data.

* **Parameters:**
  **X**
  : The data used to scale along the specified axis.
* **Returns:**
  **X_tr**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature 0 (median income in a block) and feature 5 (average house occupancy) of the california_housing_dataset have very different scales and contain some very large outliers. These two characteristics lead to difficulties to visualize the data and, more importantly, they can degrade the predictive performance of many machine learning algorithms. Unscaled data can also slow down or even prevent the convergence of many gradient-based estimators.">  <div class="sphx-glr-thumbnail-title">Compare the effect of different scalers on data with outliers</div>
</div>
* [Compare the effect of different scalers on data with outliers](../../auto_examples/preprocessing/plot_all_scaling.md#sphx-glr-auto-examples-preprocessing-plot-all-scaling-py)

<!-- thumbnail-parent-div-close --></div>
