# HistGradientBoostingClassifier

### *class* sklearn.ensemble.HistGradientBoostingClassifier(loss='log_loss', \*, learning_rate=0.1, max_iter=100, max_leaf_nodes=31, max_depth=None, min_samples_leaf=20, l2_regularization=0.0, max_features=1.0, max_bins=255, categorical_features='from_dtype', monotonic_cst=None, interaction_cst=None, warm_start=False, early_stopping='auto', scoring='loss', validation_fraction=0.1, n_iter_no_change=10, tol=1e-07, verbose=0, random_state=None, class_weight=None)

Histogram-based Gradient Boosting Classification Tree.

This estimator is much faster than
[`GradientBoostingClassifier`](sklearn.ensemble.GradientBoostingClassifier.md#sklearn.ensemble.GradientBoostingClassifier)
for big datasets (n_samples >= 10 000).

This estimator has native support for missing values (NaNs). During
training, the tree grower learns at each split point whether samples
with missing values should go to the left or right child, based on the
potential gain. When predicting, samples with missing values are
assigned to the left or right child consequently. If no missing values
were encountered for a given feature during training, then samples with
missing values are mapped to whichever child has the most samples.

This implementation is inspired by
[LightGBM](https://github.com/Microsoft/LightGBM).

Read more in the [User Guide](../ensemble.md#histogram-based-gradient-boosting).

#### Versionadded
Added in version 0.21.

* **Parameters:**
  **loss**
  : The loss function to use in the boosting process.
    <br/>
    For binary classification problems, ‘log_loss’ is also known as logistic loss,
    binomial deviance or binary crossentropy. Internally, the model fits one tree
    per boosting iteration and uses the logistic sigmoid function (expit) as
    inverse link function to compute the predicted positive class probability.
    <br/>
    For multiclass classification problems, ‘log_loss’ is also known as multinomial
    deviance or categorical crossentropy. Internally, the model fits one tree per
    boosting iteration and per class and uses the softmax function as inverse link
    function to compute the predicted probabilities of the classes.

  **learning_rate**
  : The learning rate, also known as *shrinkage*. This is used as a
    multiplicative factor for the leaves values. Use `1` for no
    shrinkage.

  **max_iter**
  : The maximum number of iterations of the boosting process, i.e. the
    maximum number of trees for binary classification. For multiclass
    classification, `n_classes` trees per iteration are built.

  **max_leaf_nodes**
  : The maximum number of leaves for each tree. Must be strictly greater
    than 1. If None, there is no maximum limit.

  **max_depth**
  : The maximum depth of each tree. The depth of a tree is the number of
    edges to go from the root to the deepest leaf.
    Depth isn’t constrained by default.

  **min_samples_leaf**
  : The minimum number of samples per leaf. For small datasets with less
    than a few hundred samples, it is recommended to lower this value
    since only very shallow trees would be built.

  **l2_regularization**
  : The L2 regularization parameter penalizing leaves with small hessians.
    Use `0` for no regularization (default).

  **max_features**
  : Proportion of randomly chosen features in each and every node split.
    This is a form of regularization, smaller values make the trees weaker
    learners and might prevent overfitting.
    If interaction constraints from `interaction_cst` are present, only allowed
    features are taken into account for the subsampling.
    <br/>
    #### Versionadded
    Added in version 1.4.

  **max_bins**
  : The maximum number of bins to use for non-missing values. Before
    training, each feature of the input array `X` is binned into
    integer-valued bins, which allows for a much faster training stage.
    Features with a small number of unique values may use less than
    `max_bins` bins. In addition to the `max_bins` bins, one more bin
    is always reserved for missing values. Must be no larger than 255.

  **categorical_features**
  : Indicates the categorical features.
    - None : no feature will be considered categorical.
    - boolean array-like : boolean mask indicating categorical features.
    - integer array-like : integer indices indicating categorical
      features.
    - str array-like: names of categorical features (assuming the training
      data has feature names).
    - `"from_dtype"`: dataframe columns with dtype “category” are
      considered to be categorical features. The input must be an object
      exposing a `__dataframe__` method such as pandas or polars
      DataFrames to use this feature.
    <br/>
    For each categorical feature, there must be at most `max_bins` unique
    categories. Negative values for categorical features encoded as numeric
    dtypes are treated as missing values. All categorical values are
    converted to floating point numbers. This means that categorical values
    of 1.0 and 1 are treated as the same category.
    <br/>
    Read more in the [User Guide](../ensemble.md#categorical-support-gbdt).
    <br/>
    #### Versionadded
    Added in version 0.24.
    <br/>
    #### Versionchanged
    Changed in version 1.2: Added support for feature names.
    <br/>
    #### Versionchanged
    Changed in version 1.4: Added `"from_dtype"` option.
    <br/>
    <!-- versionchanged::1.6
    The default will changed from `None` to `"from_dtype"`. -->

  **monotonic_cst**
  : Monotonic constraint to enforce on each feature are specified using the
    following integer values:
    - 1: monotonic increase
    - 0: no constraint
    - -1: monotonic decrease
    <br/>
    If a dict with str keys, map feature to monotonic constraints by name.
    If an array, the features are mapped to constraints by position. See
    [Using feature names to specify monotonic constraints](../../auto_examples/ensemble/plot_monotonic_constraints.md#monotonic-cst-features-names) for a usage example.
    <br/>
    The constraints are only valid for binary classifications and hold
    over the probability of the positive class.
    Read more in the [User Guide](../ensemble.md#monotonic-cst-gbdt).
    <br/>
    #### Versionadded
    Added in version 0.23.
    <br/>
    #### Versionchanged
    Changed in version 1.2: Accept dict of constraints with feature names as keys.

  **interaction_cst**
  : Specify interaction constraints, the sets of features which can
    interact with each other in child node splits.
    <br/>
    Each item specifies the set of feature indices that are allowed
    to interact with each other. If there are more features than
    specified in these constraints, they are treated as if they were
    specified as an additional set.
    <br/>
    The strings “pairwise” and “no_interactions” are shorthands for
    allowing only pairwise or no interactions, respectively.
    <br/>
    For instance, with 5 features in total, `interaction_cst=[{0, 1}]`
    is equivalent to `interaction_cst=[{0, 1}, {2, 3, 4}]`,
    and specifies that each branch of a tree will either only split
    on features 0 and 1 or only split on features 2, 3 and 4.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **warm_start**
  : When set to `True`, reuse the solution of the previous call to fit
    and add more estimators to the ensemble. For results to be valid, the
    estimator should be re-trained on the same data only.
    See [the Glossary](../../glossary.md#term-warm_start).

  **early_stopping**
  : If ‘auto’, early stopping is enabled if the sample size is larger than
    10000. If True, early stopping is enabled, otherwise early stopping is
    disabled.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **scoring**
  : Scoring parameter to use for early stopping. It can be a single
    string (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter)) or a callable (see
    [Callable scorers](../model_evaluation.md#scoring-callable)). If None, the estimator’s default scorer
    is used. If `scoring='loss'`, early stopping is checked
    w.r.t the loss value. Only used if early stopping is performed.

  **validation_fraction**
  : Proportion (or absolute size) of training data to set aside as
    validation data for early stopping. If None, early stopping is done on
    the training data. Only used if early stopping is performed.

  **n_iter_no_change**
  : Used to determine when to “early stop”. The fitting process is
    stopped when none of the last `n_iter_no_change` scores are better
    than the `n_iter_no_change - 1` -th-to-last one, up to some
    tolerance. Only used if early stopping is performed.

  **tol**
  : The absolute tolerance to use when comparing scores. The higher the
    tolerance, the more likely we are to early stop: higher tolerance
    means that it will be harder for subsequent iterations to be
    considered an improvement upon the reference score.

  **verbose**
  : The verbosity level. If not zero, print some information about the
    fitting process. `1` prints only summary info, `2` prints info per
    iteration.

  **random_state**
  : Pseudo-random number generator to control the subsampling in the
    binning process, and the train/validation data split if early stopping
    is enabled.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **class_weight**
  : Weights associated with classes in the form `{class_label: weight}`.
    If not given, all classes are supposed to have weight one.
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`.
    Note that these weights will be multiplied with sample_weight (passed
    through the fit method) if `sample_weight` is specified.
    <br/>
    #### Versionadded
    Added in version 1.2.
* **Attributes:**
  **classes_**
  : Class labels.

  **do_early_stopping_**
  : Indicates whether early stopping is used during training.

  [`n_iter_`](#sklearn.ensemble.HistGradientBoostingClassifier.n_iter_)
  : Number of iterations of the boosting process.

  **n_trees_per_iteration_**
  : The number of tree that are built at each iteration. This is equal to 1
    for binary classification, and to `n_classes` for multiclass
    classification.

  **train_score_**
  : The scores at each iteration on the training data. The first entry
    is the score of the ensemble before the first iteration. Scores are
    computed according to the `scoring` parameter. If `scoring` is
    not ‘loss’, scores are computed on a subset of at most 10 000
    samples. Empty if no early stopping.

  **validation_score_**
  : The scores at each iteration on the held-out validation data. The
    first entry is the score of the ensemble before the first iteration.
    Scores are computed according to the `scoring` parameter. Empty if
    no early stopping or if `validation_fraction` is None.

  **is_categorical_**
  : Boolean mask for the categorical features. `None` if there are no
    categorical features.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`GradientBoostingClassifier`](sklearn.ensemble.GradientBoostingClassifier.md#sklearn.ensemble.GradientBoostingClassifier)
: Exact gradient boosting method that does not scale as good on datasets with a large number of samples.

[`sklearn.tree.DecisionTreeClassifier`](sklearn.tree.DecisionTreeClassifier.md#sklearn.tree.DecisionTreeClassifier)
: A decision tree classifier.

[`RandomForestClassifier`](sklearn.ensemble.RandomForestClassifier.md#sklearn.ensemble.RandomForestClassifier)
: A meta-estimator that fits a number of decision tree classifiers on various sub-samples of the dataset and uses averaging to improve the predictive accuracy and control over-fitting.

[`AdaBoostClassifier`](sklearn.ensemble.AdaBoostClassifier.md#sklearn.ensemble.AdaBoostClassifier)
: A meta-estimator that begins by fitting a classifier on the original dataset and then fits additional copies of the classifier on the same dataset where the weights of incorrectly classified instances are adjusted such that subsequent classifiers focus more on difficult cases.

### Examples

```pycon
>>> from sklearn.ensemble import HistGradientBoostingClassifier
>>> from sklearn.datasets import load_iris
>>> X, y = load_iris(return_X_y=True)
>>> clf = HistGradientBoostingClassifier().fit(X, y)
>>> clf.score(X, y)
1.0
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Compute the decision function of `X`.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **decision**
  : The raw predicted values (i.e. the sum of the trees leaves) for
    each sample. n_trees_per_iteration is equal to the number of
    classes in multiclass classification.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit the gradient boosting model.

* **Parameters:**
  **X**
  : The input samples.

  **y**
  : Target values.

  **sample_weight**
  : Weights of training data.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_iter_

Number of iterations of the boosting process.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict classes for X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **y**
  : The predicted classes.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict class probabilities for X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **p**
  : The class probabilities of the input samples.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [HistGradientBoostingClassifier](#sklearn.ensemble.HistGradientBoostingClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [HistGradientBoostingClassifier](#sklearn.ensemble.HistGradientBoostingClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### staged_decision_function(X)

Compute decision function of `X` for each iteration.

This method allows monitoring (i.e. determine error on testing set)
after each stage.

* **Parameters:**
  **X**
  : The input samples.
* **Yields:**
  **decision**
  : The decision function of the input samples, which corresponds to
    the raw values predicted from the trees of the ensemble . The
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### staged_predict(X)

Predict classes at each iteration.

This method allows monitoring (i.e. determine error on testing set)
after each stage.

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **X**
  : The input samples.
* **Yields:**
  **y**
  : The predicted classes of the input samples, for each iteration.

<!-- !! processed by numpydoc !! -->

#### staged_predict_proba(X)

Predict class probabilities at each iteration.

This method allows monitoring (i.e. determine error on testing set)
after each stage.

* **Parameters:**
  **X**
  : The input samples.
* **Yields:**
  **y**
  : The predicted class probabilities of the input samples,
    for each iteration.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the performance of Random Forest (RF) and Histogram Gradient Boosting (HGBT) models in terms of score and computation time for a regression dataset, though all the concepts here presented apply to classification as well.">  <div class="sphx-glr-thumbnail-title">Comparing Random Forests and Histogram Gradient Boosting models</div>
</div>
* [Comparing Random Forests and Histogram Gradient Boosting models](../../auto_examples/ensemble/plot_forest_hist_grad_boosting_comparison.md#sphx-glr-auto-examples-ensemble-plot-forest-hist-grad-boosting-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Transform your features into a higher dimensional, sparse space. Then train a linear model on these features.">  <div class="sphx-glr-thumbnail-title">Feature transformations with ensembles of trees</div>
</div>
* [Feature transformations with ensembles of trees](../../auto_examples/ensemble/plot_feature_transformation.md#sphx-glr-auto-examples-ensemble-plot-feature-transformation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
