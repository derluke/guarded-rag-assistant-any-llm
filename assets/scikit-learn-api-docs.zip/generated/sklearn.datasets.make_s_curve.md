# make_s_curve

### sklearn.datasets.make_s_curve(n_samples=100, \*, noise=0.0, random_state=None)

Generate an S curve dataset.

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **n_samples**
  : The number of sample points on the S curve.

  **noise**
  : The standard deviation of the gaussian noise.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : The points.

  **t**
  : The univariate position of the sample according
    to the main dimension of the points in the manifold.

### Examples

```pycon
>>> from sklearn.datasets import make_s_curve
>>> X, t = make_s_curve(noise=0.05, random_state=0)
>>> X.shape
(100, 3)
>>> t.shape
(100,)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An illustration of dimensionality reduction on the S-curve dataset with various manifold learning methods.">  <div class="sphx-glr-thumbnail-title">Comparison of Manifold Learning methods</div>
</div>
* [Comparison of Manifold Learning methods](../../auto_examples/manifold/plot_compare_methods.md#sphx-glr-auto-examples-manifold-plot-compare-methods-py)

<div class="sphx-glr-thumbcontainer" tooltip="An illustration of t-SNE on the two concentric circles and the S-curve datasets for different perplexity values.">  <div class="sphx-glr-thumbnail-title">t-SNE: The effect of various perplexity values on the shape</div>
</div>
* [t-SNE: The effect of various perplexity values on the shape](../../auto_examples/manifold/plot_t_sne_perplexity.md#sphx-glr-auto-examples-manifold-plot-t-sne-perplexity-py)

<!-- thumbnail-parent-div-close --></div>
