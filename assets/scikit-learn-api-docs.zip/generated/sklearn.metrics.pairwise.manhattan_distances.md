# manhattan_distances

### sklearn.metrics.pairwise.manhattan_distances(X, Y=None)

Compute the L1 distances between the vectors in X and Y.

Read more in the [User Guide](../metrics.md#metrics).

* **Parameters:**
  **X**
  : An array where each row is a sample and each column is a feature.

  **Y**
  : An array where each row is a sample and each column is a feature.
    If `None`, method uses `Y=X`.
* **Returns:**
  **distances**
  : Pairwise L1 distances.

### Notes

When X and/or Y are CSR sparse matrices and they are not already
in canonical format, this function modifies them in-place to
make them canonical.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import manhattan_distances
>>> manhattan_distances([[3]], [[3]])
array([[0.]])
>>> manhattan_distances([[3]], [[2]])
array([[1.]])
>>> manhattan_distances([[2]], [[3]])
array([[1.]])
>>> manhattan_distances([[1, 2], [3, 4]],         [[1, 2], [0, 3]])
array([[0., 2.],
       [4., 4.]])
```

<!-- !! processed by numpydoc !! -->
