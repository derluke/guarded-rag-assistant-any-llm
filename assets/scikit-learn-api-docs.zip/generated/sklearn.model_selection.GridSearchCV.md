# GridSearchCV

### *class* sklearn.model_selection.GridSearchCV(estimator, param_grid, \*, scoring=None, n_jobs=None, refit=True, cv=None, verbose=0, pre_dispatch='2\*n_jobs', error_score=nan, return_train_score=False)

Exhaustive search over specified parameter values for an estimator.

Important members are fit, predict.

GridSearchCV implements a “fit” and a “score” method.
It also implements “score_samples”, “predict”, “predict_proba”,
“decision_function”, “transform” and “inverse_transform” if they are
implemented in the estimator used.

The parameters of the estimator used to apply these methods are optimized
by cross-validated grid-search over a parameter grid.

Read more in the [User Guide](../grid_search.md#grid-search).

* **Parameters:**
  **estimator**
  : This is assumed to implement the scikit-learn estimator interface.
    Either estimator needs to provide a `score` function,
    or `scoring` must be passed.

  **param_grid**
  : Dictionary with parameters names (`str`) as keys and lists of
    parameter settings to try as values, or a list of such
    dictionaries, in which case the grids spanned by each dictionary
    in the list are explored. This enables searching over any sequence
    of parameter settings.

  **scoring**
  : Strategy to evaluate the performance of the cross-validated model on
    the test set.
    <br/>
    If `scoring` represents a single score, one can use:
    - a single string (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter));
    - a callable (see [Callable scorers](../model_evaluation.md#scoring-callable)) that returns a single value.
    <br/>
    If `scoring` represents multiple scores, one can use:
    - a list or tuple of unique strings;
    - a callable returning a dictionary where the keys are the metric
      names and the values are the metric scores;
    - a dictionary with metric names as keys and callables as values.
    <br/>
    See [Specifying multiple metrics for evaluation](../grid_search.md#multimetric-grid-search) for an example.

  **n_jobs**
  : Number of jobs to run in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionchanged
    Changed in version v0.20: `n_jobs` default changed from 1 to None

  **refit**
  : Refit an estimator using the best found parameters on the whole
    dataset.
    <br/>
    For multiple metric evaluation, this needs to be a `str` denoting the
    scorer that would be used to find the best parameters for refitting
    the estimator at the end.
    <br/>
    Where there are considerations other than maximum score in
    choosing a best estimator, `refit` can be set to a function which
    returns the selected `best_index_` given `cv_results_`. In that
    case, the `best_estimator_` and `best_params_` will be set
    according to the returned `best_index_` while the `best_score_`
    attribute will not be available.
    <br/>
    The refitted estimator is made available at the `best_estimator_`
    attribute and permits using `predict` directly on this
    `GridSearchCV` instance.
    <br/>
    Also for multiple metric evaluation, the attributes `best_index_`,
    `best_score_` and `best_params_` will only be available if
    `refit` is set and all of them will be determined w.r.t this specific
    scorer.
    <br/>
    See `scoring` parameter to know more about multiple metric
    evaluation.
    <br/>
    See [Custom refit strategy of a grid search with cross-validation](../../auto_examples/model_selection/plot_grid_search_digits.md#sphx-glr-auto-examples-model-selection-plot-grid-search-digits-py)
    to see how to design a custom selection strategy using a callable
    via `refit`.
    <br/>
    #### Versionchanged
    Changed in version 0.20: Support for callable added.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross validation,
    - integer, to specify the number of folds in a `(Stratified)KFold`,
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs, if the estimator is a classifier and `y` is
    either binary or multiclass, [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. In all
    other cases, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used. These splitters are instantiated
    with `shuffle=False` so the splits will be the same across calls.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value if None changed from 3-fold to 5-fold.

  **verbose**
  : Controls the verbosity: the higher, the more messages.
    - >1 : the computation time for each fold and parameter candidate is
      displayed;
    - >2 : the score is also displayed;
    - >3 : the fold and candidate parameter indexes are also displayed
      together with the starting time of the computation.

  **pre_dispatch**
  : Controls the number of jobs that get dispatched during parallel
    execution. Reducing this number can be useful to avoid an
    explosion of memory consumption when more jobs get dispatched
    than CPUs can process. This parameter can be:
    - None, in which case all the jobs are immediately created and spawned. Use
      this for lightweight and fast-running jobs, to avoid delays due to on-demand
      spawning of the jobs
    - An int, giving the exact number of total jobs that are spawned
    - A str, giving an expression as a function of n_jobs, as in ‘2\*n_jobs’

  **error_score**
  : Value to assign to the score if an error occurs in estimator fitting.
    If set to ‘raise’, the error is raised. If a numeric value is given,
    FitFailedWarning is raised. This parameter does not affect the refit
    step, which will always raise the error.

  **return_train_score**
  : If `False`, the `cv_results_` attribute will not include training
    scores.
    Computing training scores is used to get insights on how different
    parameter settings impact the overfitting/underfitting trade-off.
    However computing the scores on the training set can be computationally
    expensive and is not strictly required to select the parameters that
    yield the best generalization performance.
    <br/>
    #### Versionadded
    Added in version 0.19.
    <br/>
    #### Versionchanged
    Changed in version 0.21: Default value was changed from `True` to `False`
* **Attributes:**
  **cv_results_**
  : A dict with keys as column headers and values as columns, that can be
    imported into a pandas `DataFrame`.
    <br/>
    For instance the below given table
    <br/>
    | param_kernel   | param_gamma   | param_degree   |   split0_test_score | …   |   rank_t… |
    |----------------|---------------|----------------|---------------------|-----|-----------|
    | ‘poly’         | –             | 2              |                0.8  | …   |         2 |
    | ‘poly’         | –             | 3              |                0.7  | …   |         4 |
    | ‘rbf’          | 0.1           | –              |                0.8  | …   |         3 |
    | ‘rbf’          | 0.2           | –              |                0.93 | …   |         1 |
    <br/>
    will be represented by a `cv_results_` dict of:
    ```default
    {
    'param_kernel': masked_array(data = ['poly', 'poly', 'rbf', 'rbf'],
                                 mask = [False False False False]...)
    'param_gamma': masked_array(data = [-- -- 0.1 0.2],
                                mask = [ True  True False False]...),
    'param_degree': masked_array(data = [2.0 3.0 -- --],
                                 mask = [False False  True  True]...),
    'split0_test_score'  : [0.80, 0.70, 0.80, 0.93],
    'split1_test_score'  : [0.82, 0.50, 0.70, 0.78],
    'mean_test_score'    : [0.81, 0.60, 0.75, 0.85],
    'std_test_score'     : [0.01, 0.10, 0.05, 0.08],
    'rank_test_score'    : [2, 4, 3, 1],
    'split0_train_score' : [0.80, 0.92, 0.70, 0.93],
    'split1_train_score' : [0.82, 0.55, 0.70, 0.87],
    'mean_train_score'   : [0.81, 0.74, 0.70, 0.90],
    'std_train_score'    : [0.01, 0.19, 0.00, 0.03],
    'mean_fit_time'      : [0.73, 0.63, 0.43, 0.49],
    'std_fit_time'       : [0.01, 0.02, 0.01, 0.01],
    'mean_score_time'    : [0.01, 0.06, 0.04, 0.04],
    'std_score_time'     : [0.00, 0.00, 0.00, 0.01],
    'params'             : [{'kernel': 'poly', 'degree': 2}, ...],
    }
    ```
    <br/>
    NOTE
    <br/>
    The key `'params'` is used to store a list of parameter
    settings dicts for all the parameter candidates.
    <br/>
    The `mean_fit_time`, `std_fit_time`, `mean_score_time` and
    `std_score_time` are all in seconds.
    <br/>
    For multi-metric evaluation, the scores for all the scorers are
    available in the `cv_results_` dict at the keys ending with that
    scorer’s name (`'_<scorer_name>'`) instead of `'_score'` shown
    above. (‘split0_test_precision’, ‘mean_train_precision’ etc.)

  **best_estimator_**
  : Estimator that was chosen by the search, i.e. estimator
    which gave highest score (or smallest loss if specified)
    on the left out data. Not available if `refit=False`.
    <br/>
    See `refit` parameter for more information on allowed values.

  **best_score_**
  : Mean cross-validated score of the best_estimator
    <br/>
    For multi-metric evaluation, this is present only if `refit` is
    specified.
    <br/>
    This attribute is not available if `refit` is a function.

  **best_params_**
  : Parameter setting that gave the best results on the hold out data.
    <br/>
    For multi-metric evaluation, this is present only if `refit` is
    specified.

  **best_index_**
  : The index (of the `cv_results_` arrays) which corresponds to the best
    candidate parameter setting.
    <br/>
    The dict at `search.cv_results_['params'][search.best_index_]` gives
    the parameter setting for the best model, that gives the highest
    mean score (`search.best_score_`).
    <br/>
    For multi-metric evaluation, this is present only if `refit` is
    specified.

  **scorer_**
  : Scorer function used on the held out data to choose the best
    parameters for the model.
    <br/>
    For multi-metric evaluation, this attribute holds the validated
    `scoring` dict which maps the scorer key to the scorer callable.

  **n_splits_**
  : The number of cross-validation splits (folds/iterations).

  **refit_time_**
  : Seconds used for refitting the best model on the whole dataset.
    <br/>
    This is present only if `refit` is not False.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **multimetric_**
  : Whether or not the scorers compute several metrics.

  [`classes_`](#sklearn.model_selection.GridSearchCV.classes_)
  : Class labels.

  [`n_features_in_`](#sklearn.model_selection.GridSearchCV.n_features_in_)
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if
    `best_estimator_` is defined (see the documentation for the `refit`
    parameter for more details) and that `best_estimator_` exposes
    `feature_names_in_` when fit.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`ParameterGrid`](sklearn.model_selection.ParameterGrid.md#sklearn.model_selection.ParameterGrid)
: Generates all the combinations of a hyperparameter grid.

[`train_test_split`](sklearn.model_selection.train_test_split.md#sklearn.model_selection.train_test_split)
: Utility function to split the data into a development set usable for fitting a GridSearchCV instance and an evaluation set for its final evaluation.

[`sklearn.metrics.make_scorer`](sklearn.metrics.make_scorer.md#sklearn.metrics.make_scorer)
: Make a scorer from a performance metric or loss function.

### Notes

The parameters selected are those that maximize the score of the left out
data, unless an explicit score is passed in which case it is used instead.

If `n_jobs` was set to a value higher than one, the data is copied for each
point in the grid (and not `n_jobs` times). This is done for efficiency
reasons if individual jobs take very little time, but may raise errors if
the dataset is large and not enough memory is available.  A workaround in
this case is to set `pre_dispatch`. Then, the memory is copied only
`pre_dispatch` many times. A reasonable value for `pre_dispatch` is `2 *
n_jobs`.

### Examples

```pycon
>>> from sklearn import svm, datasets
>>> from sklearn.model_selection import GridSearchCV
>>> iris = datasets.load_iris()
>>> parameters = {'kernel':('linear', 'rbf'), 'C':[1, 10]}
>>> svc = svm.SVC()
>>> clf = GridSearchCV(svc, parameters)
>>> clf.fit(iris.data, iris.target)
GridSearchCV(estimator=SVC(),
             param_grid={'C': [1, 10], 'kernel': ('linear', 'rbf')})
>>> sorted(clf.cv_results_.keys())
['mean_fit_time', 'mean_score_time', 'mean_test_score',...
 'param_C', 'param_kernel', 'params',...
 'rank_test_score', 'split0_test_score',...
 'split2_test_score', ...
 'std_fit_time', 'std_score_time', 'std_test_score']
```

<!-- !! processed by numpydoc !! -->

#### *property* classes_

Class labels.

Only available when `refit=True` and the estimator is a classifier.

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Call decision_function on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`decision_function`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_score**
  : Result of the decision function for `X` based on the estimator with
    the best found parameters.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, \*\*params)

Run fit with all sets of parameters.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features. For precomputed kernel or
    distance matrix, the expected shape of X is (n_samples, n_samples).

  **y**
  : Target relative to X for classification or regression;
    None for unsupervised learning.

  **\*\*params**
  : Parameters passed to the `fit` method of the estimator, the scorer,
    and the CV splitter.
    <br/>
    If a fit parameter is an array-like whose length is equal to
    `num_samples` then it will be split by cross-validation along with
    `X` and `y`. For example, the [sample_weight](../../glossary.md#term-sample_weight) parameter is
    split because `len(sample_weights) = len(X)`. However, this behavior
    does not apply to `groups` which is passed to the splitter configured
    via the `cv` parameter of the constructor. Thus, `groups` is used
    *to perform the split* and determines which samples are
    assigned to the each side of the a split.
* **Returns:**
  **self**
  : Instance of fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.4.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X=None, Xt=None)

Call inverse_transform on the estimator with the best found params.

Only available if the underlying estimator implements
`inverse_transform` and `refit=True`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.

  **Xt**
  : Must fulfill the input assumptions of the
    underlying estimator.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Xt` was deprecated in 1.5 and will be removed in 1.7. Use `X` instead.
* **Returns:**
  **X**
  : Result of the `inverse_transform` function for `Xt` based on the
    estimator with the best found parameters.

<!-- !! processed by numpydoc !! -->

#### *property* n_features_in_

Number of features seen during [fit](../../glossary.md#term-fit).

Only available when `refit=True`.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Call predict on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`predict`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_pred**
  : The predicted labels or values for `X` based on the estimator with
    the best found parameters.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Call predict_log_proba on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`predict_log_proba`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_pred**
  : Predicted class log-probabilities for `X` based on the estimator
    with the best found parameters. The order of the classes
    corresponds to that in the fitted attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Call predict_proba on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`predict_proba`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_pred**
  : Predicted class probabilities for `X` based on the estimator with
    the best found parameters. The order of the classes corresponds
    to that in the fitted attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y=None, \*\*params)

Return the score on the given data, if the estimator has been refit.

This uses the score defined by `scoring` where provided, and the
`best_estimator_.score` method otherwise.

* **Parameters:**
  **X**
  : Input data, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target relative to X for classification or regression;
    None for unsupervised learning.

  **\*\*params**
  : Parameters to be passed to the underlying scorer(s).
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **score**
  : The score defined by `scoring` if provided, and the
    `best_estimator_.score` method otherwise.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Call score_samples on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`score_samples`.

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **X**
  : Data to predict on. Must fulfill input requirements
    of the underlying estimator.
* **Returns:**
  **y_score**
  : The `best_estimator_.score_samples` method.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Call transform on the estimator with the best found parameters.

Only available if the underlying estimator supports `transform` and
`refit=True`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **Xt**
  : `X` transformed in the new space based on the estimator with
    the best found parameters.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares 2 dimensionality reduction strategies:">  <div class="sphx-glr-thumbnail-title">Feature agglomeration vs. univariate selection</div>
</div>
* [Feature agglomeration vs. univariate selection](../../auto_examples/cluster/plot_feature_agglomeration_vs_univariate_selection.md#sphx-glr-auto-examples-cluster-plot-feature-agglomeration-vs-univariate-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to apply different preprocessing and feature extraction pipelines to different subsets of features, using ColumnTransformer. This is particularly handy for the case of datasets that contain heterogeneous data types, since we may want to scale the numeric features and one-hot encode the categorical ones.">  <div class="sphx-glr-thumbnail-title">Column Transformer with Mixed Types</div>
</div>
* [Column Transformer with Mixed Types](../../auto_examples/compose/plot_column_transformer_mixed_types.md#sphx-glr-auto-examples-compose-plot-column-transformer-mixed-types-py)

<div class="sphx-glr-thumbcontainer" tooltip="In many real-world examples, there are many ways to extract features from a dataset. Often it is beneficial to combine several methods to obtain good performance. This example shows how to use FeatureUnion to combine features obtained by PCA and univariate selection.">  <div class="sphx-glr-thumbnail-title">Concatenating multiple feature extraction methods</div>
</div>
* [Concatenating multiple feature extraction methods](../../auto_examples/compose/plot_feature_union.md#sphx-glr-auto-examples-compose-plot-feature-union-py)

<div class="sphx-glr-thumbcontainer" tooltip="The PCA does an unsupervised dimensionality reduction, while the logistic regression does the prediction.">  <div class="sphx-glr-thumbnail-title">Pipelining: chaining a PCA and a logistic regression</div>
</div>
* [Pipelining: chaining a PCA and a logistic regression](../../auto_examples/compose/plot_digits_pipe.md#sphx-glr-auto-examples-compose-plot-digits-pipe-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example constructs a pipeline that does dimensionality reduction followed by prediction with a support vector classifier. It demonstrates the use of GridSearchCV and Pipeline to optimize over different classes of estimators in a single CV run -- unsupervised PCA and NMF dimensionality reductions are compared to univariate feature selection during the grid search.">  <div class="sphx-glr-thumbnail-title">Selecting dimensionality reduction with Pipeline and GridSearchCV</div>
</div>
* [Selecting dimensionality reduction with Pipeline and GridSearchCV](../../auto_examples/compose/plot_compare_reduction.md#sphx-glr-auto-examples-compose-plot-compare-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="When working with covariance estimation, the usual approach is to use a maximum likelihood estimator, such as the EmpiricalCovariance. It is unbiased, i.e. it converges to the true (population) covariance when given many observations. However, it can also be beneficial to regularize it, in order to reduce its variance; this, in turn, introduces some bias. This example illustrates the simple regularization used in shrunk_covariance estimators. In particular, it focuses on how to set the amount of regularization, i.e. how to choose the bias-variance trade-off.">  <div class="sphx-glr-thumbnail-title">Shrinkage covariance estimation: LedoitWolf vs OAS and max-likelihood</div>
</div>
* [Shrinkage covariance estimation: LedoitWolf vs OAS and max-likelihood](../../auto_examples/covariance/plot_covariance_estimation.md#sphx-glr-auto-examples-covariance-plot-covariance-estimation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Probabilistic PCA and Factor Analysis are probabilistic models. The consequence is that the likelihood of new data can be used for model selection and covariance estimation. Here we compare PCA and FA with cross-validation on low rank data corrupted with homoscedastic noise (noise variance is the same for each feature) or heteroscedastic noise (noise variance is the different for each feature). In a second step we compare the model likelihood to the likelihoods obtained from shrinkage covariance estimators.">  <div class="sphx-glr-thumbnail-title">Model selection with Probabilistic PCA and Factor Analysis (FA)</div>
</div>
* [Model selection with Probabilistic PCA and Factor Analysis (FA)](../../auto_examples/decomposition/plot_pca_vs_fa_model_selection.md#sphx-glr-auto-examples-decomposition-plot-pca-vs-fa-model-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example we compare the performance of Random Forest (RF) and Histogram Gradient Boosting (HGBT) models in terms of score and computation time for a regression dataset, though all the concepts here presented apply to classification as well.">  <div class="sphx-glr-thumbnail-title">Comparing Random Forests and Histogram Gradient Boosting models</div>
</div>
* [Comparing Random Forests and Histogram Gradient Boosting models](../../auto_examples/ensemble/plot_forest_hist_grad_boosting_comparison.md#sphx-glr-auto-examples-ensemble-plot-forest-hist-grad-boosting-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Both kernel ridge regression (KRR) and SVR learn a non-linear function by employing the kernel trick, i.e., they learn a linear function in the space induced by the respective kernel which corresponds to a non-linear function in the original space. They differ in the loss functions (ridge versus epsilon-insensitive loss). In contrast to SVR, fitting a KRR can be done in closed-form and is typically faster for medium-sized datasets. On the other hand, the learned model is non-sparse and thus slower than SVR at prediction-time.">  <div class="sphx-glr-thumbnail-title">Comparison of kernel ridge regression and SVR</div>
</div>
* [Comparison of kernel ridge regression and SVR](../../auto_examples/miscellaneous/plot_kernel_ridge_regression.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-ridge-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="The default configuration for displaying a pipeline in a Jupyter Notebook is &#x27;diagram&#x27; where set_config(display=&#x27;diagram&#x27;). To deactivate HTML representation, use set_config(display=&#x27;text&#x27;).">  <div class="sphx-glr-thumbnail-title">Displaying Pipelines</div>
</div>
* [Displaying Pipelines](../../auto_examples/miscellaneous/plot_pipeline_display.md#sphx-glr-auto-examples-miscellaneous-plot-pipeline-display-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows that model selection can be performed with Gaussian Mixture Models (GMM) using information-theory criteria &lt;aic_bic&gt;. Model selection concerns both the covariance type and the number of components in the model.">  <div class="sphx-glr-thumbnail-title">Gaussian Mixture Model Selection</div>
</div>
* [Gaussian Mixture Model Selection](../../auto_examples/mixture/plot_gmm_selection.md#sphx-glr-auto-examples-mixture-plot-gmm-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example balances model complexity and cross-validated score by finding a decent accuracy within 1 standard deviation of the best accuracy score while minimising the number of PCA components [1].">  <div class="sphx-glr-thumbnail-title">Balance model complexity and cross-validated score</div>
</div>
* [Balance model complexity and cross-validated score](../../auto_examples/model_selection/plot_grid_search_refit_callable.md#sphx-glr-auto-examples-model-selection-plot-grid-search-refit-callable-py)

<div class="sphx-glr-thumbcontainer" tooltip="Compare randomized search and grid search for optimizing hyperparameters of a linear SVM with SGD training. All parameters that influence the learning are searched simultaneously (except for the number of estimators, which poses a time / quality tradeoff).">  <div class="sphx-glr-thumbnail-title">Comparing randomized search and grid search for hyperparameter estimation</div>
</div>
* [Comparing randomized search and grid search for hyperparameter estimation](../../auto_examples/model_selection/plot_randomized_search.md#sphx-glr-auto-examples-model-selection-plot-randomized-search-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares the parameter search performed by HalvingGridSearchCV and GridSearchCV.">  <div class="sphx-glr-thumbnail-title">Comparison between grid search and successive halving</div>
</div>
* [Comparison between grid search and successive halving](../../auto_examples/model_selection/plot_successive_halving_heatmap.md#sphx-glr-auto-examples-model-selection-plot-successive-halving-heatmap-py)

<div class="sphx-glr-thumbcontainer" tooltip="This examples shows how a classifier is optimized by cross-validation, which is done using the GridSearchCV object on a development set that comprises only half of the available labeled data.">  <div class="sphx-glr-thumbnail-title">Custom refit strategy of a grid search with cross-validation</div>
</div>
* [Custom refit strategy of a grid search with cross-validation](../../auto_examples/model_selection/plot_grid_search_digits.md#sphx-glr-auto-examples-model-selection-plot-grid-search-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="Multiple metric parameter search can be done by setting the scoring parameter to a list of metric scorer names or a dict mapping the scorer names to the scorer callables.">  <div class="sphx-glr-thumbnail-title">Demonstration of multi-metric evaluation on cross_val_score and GridSearchCV</div>
</div>
* [Demonstration of multi-metric evaluation on cross_val_score and GridSearchCV](../../auto_examples/model_selection/plot_multi_metric_evaluation.md#sphx-glr-auto-examples-model-selection-plot-multi-metric-evaluation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares non-nested and nested cross-validation strategies on a classifier of the iris data set. Nested cross-validation (CV) is often used to train a model in which hyperparameters also need to be optimized. Nested CV estimates the generalization error of the underlying model and its (hyper)parameter search. Choosing the parameters that maximize non-nested CV biases the model to the dataset, yielding an overly-optimistic score.">  <div class="sphx-glr-thumbnail-title">Nested versus non-nested cross-validation</div>
</div>
* [Nested versus non-nested cross-validation](../../auto_examples/model_selection/plot_nested_cross_validation_iris.md#sphx-glr-auto-examples-model-selection-plot-nested-cross-validation-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is 20newsgroups_dataset which will be automatically downloaded, cached and reused for the document classification example.">  <div class="sphx-glr-thumbnail-title">Sample pipeline for text feature extraction and evaluation</div>
</div>
* [Sample pipeline for text feature extraction and evaluation](../../auto_examples/model_selection/plot_grid_search_text_feature_extraction.md#sphx-glr-auto-examples-model-selection-plot-grid-search-text-feature-extraction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to statistically compare the performance of models trained and evaluated using GridSearchCV.">  <div class="sphx-glr-thumbnail-title">Statistical comparison of models using grid search</div>
</div>
* [Statistical comparison of models using grid search](../../auto_examples/model_selection/plot_grid_search_stats.md#sphx-glr-auto-examples-model-selection-plot-grid-search-stats-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we discuss the problem of classification when the target variable is composed of more than two classes. This is called multiclass classification.">  <div class="sphx-glr-thumbnail-title">Overview of multiclass training meta-estimators</div>
</div>
* [Overview of multiclass training meta-estimators](../../auto_examples/multiclass/plot_multiclass_overview.md#sphx-glr-auto-examples-multiclass-plot-multiclass-overview-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to precompute the k nearest neighbors before using them in KNeighborsClassifier. KNeighborsClassifier can compute the nearest neighbors internally, but precomputing them can have several benefits, such as finer parameter control, caching for multiple use, or custom implementations.">  <div class="sphx-glr-thumbnail-title">Caching nearest neighbors</div>
</div>
* [Caching nearest neighbors](../../auto_examples/neighbors/plot_caching_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-plot-caching-nearest-neighbors-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how kernel density estimation (KDE), a powerful non-parametric density estimation technique, can be used to learn a generative model for a dataset.  With this generative model in place, new samples can be drawn.  These new samples reflect the underlying model of the data.">  <div class="sphx-glr-thumbnail-title">Kernel Density Estimation</div>
</div>
* [Kernel Density Estimation](../../auto_examples/neighbors/plot_digits_kde_sampling.md#sphx-glr-auto-examples-neighbors-plot-digits-kde-sampling-py)

<div class="sphx-glr-thumbcontainer" tooltip="A demonstration of feature discretization on synthetic classification datasets. Feature discretization decomposes each feature into a set of bins, here equally distributed in width. The discrete values are then one-hot encoded, and given to a linear classifier. This preprocessing enables a non-linear behavior even though the classifier is linear.">  <div class="sphx-glr-thumbnail-title">Feature discretization</div>
</div>
* [Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="SVCs aim to find a hyperplane that effectively separates the classes in their training data by maximizing the margin between the outermost data points of each class. This is achieved by finding the best weight vector w that defines the decision boundary hyperplane and minimizes the sum of hinge losses for misclassified samples, as measured by the hinge_loss function. By default, regularization is applied with the parameter C=1, which allows for a certain degree of misclassification tolerance.">  <div class="sphx-glr-thumbnail-title">Plot classification boundaries with different SVM Kernels</div>
</div>
* [Plot classification boundaries with different SVM Kernels](../../auto_examples/svm/plot_svm_kernels.md#sphx-glr-auto-examples-svm-plot-svm-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of the parameters gamma and C of the Radial Basis Function (RBF) kernel SVM.">  <div class="sphx-glr-thumbnail-title">RBF SVM parameters</div>
</div>
* [RBF SVM parameters](../../auto_examples/svm/plot_rbf_parameters.md#sphx-glr-auto-examples-svm-plot-rbf-parameters-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
