# OneVsOneClassifier

### *class* sklearn.multiclass.OneVsOneClassifier(estimator, \*, n_jobs=None)

One-vs-one multiclass strategy.

This strategy consists in fitting one classifier per class pair.
At prediction time, the class which received the most votes is selected.
Since it requires to fit `n_classes * (n_classes - 1) / 2` classifiers,
this method is usually slower than one-vs-the-rest, due to its
O(n_classes^2) complexity. However, this method may be advantageous for
algorithms such as kernel algorithms which don’t scale well with
`n_samples`. This is because each individual learning problem only involves
a small subset of the data whereas, with one-vs-the-rest, the complete
dataset is used `n_classes` times.

Read more in the [User Guide](../multiclass.md#ovo-classification).

* **Parameters:**
  **estimator**
  : A regressor or a classifier that implements [fit](../../glossary.md#term-fit).
    When a classifier is passed, [decision_function](../../glossary.md#term-decision_function) will be used
    in priority and it will fallback to [predict_proba](../../glossary.md#term-predict_proba) if it is not
    available.
    When a regressor is passed, [predict](../../glossary.md#term-predict) is used.

  **n_jobs**
  : The number of jobs to use for the computation: the `n_classes * (
    n_classes - 1) / 2` OVO problems are computed in parallel.
    <br/>
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **estimators_**
  : Estimators used for predictions.

  **classes_**
  : Array containing labels.

  [`n_classes_`](#sklearn.multiclass.OneVsOneClassifier.n_classes_)
  : Number of classes.

  **pairwise_indices_**
  : Indices of samples used when training the estimators.
    `None` when `estimator`’s `pairwise` tag is False.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`OneVsRestClassifier`](sklearn.multiclass.OneVsRestClassifier.md#sklearn.multiclass.OneVsRestClassifier)
: One-vs-all multiclass strategy.

[`OutputCodeClassifier`](sklearn.multiclass.OutputCodeClassifier.md#sklearn.multiclass.OutputCodeClassifier)
: (Error-Correcting) Output-Code multiclass strategy.

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.multiclass import OneVsOneClassifier
>>> from sklearn.svm import LinearSVC
>>> X, y = load_iris(return_X_y=True)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, test_size=0.33, shuffle=True, random_state=0)
>>> clf = OneVsOneClassifier(
...     LinearSVC(random_state=0)).fit(X_train, y_train)
>>> clf.predict(X_test[:10])
array([2, 1, 0, 2, 0, 2, 0, 1, 1, 1])
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Decision function for the OneVsOneClassifier.

The decision values for the samples are computed by adding the
normalized sum of pair-wise classification confidence levels to the
votes in order to disambiguate between the decision values when the
votes for all the classes are equal leading to a tie.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  **Y**
  : Result of calling `decision_function` on the final estimator.
    <br/>
    #### Versionchanged
    Changed in version 0.19: output shape changed to `(n_samples,)` to conform to
    scikit-learn conventions for binary classification.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*\*fit_params)

Fit underlying estimators.

* **Parameters:**
  **X**
  : Data.

  **y**
  : Multi-class targets.

  **\*\*fit_params**
  : Parameters passed to the `estimator.fit` method of each
    sub-estimator.
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **self**
  : The fitted underlying estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.4.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_classes_

Number of classes.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y, classes=None, \*\*partial_fit_params)

Partially fit underlying estimators.

Should be used when memory is inefficient to train all data. Chunks
of data can be passed in several iteration, where the first call
should have an array of all target variables.

* **Parameters:**
  **X**
  : Data.

  **y**
  : Multi-class targets.

  **classes**
  : Classes across all calls to partial_fit.
    Can be obtained via `np.unique(y_all)`, where y_all is the
    target vector of the entire dataset.
    This argument is only required in the first call of partial_fit
    and can be omitted in the subsequent calls.

  **\*\*partial_fit_params**
  : Parameters passed to the `estimator.partial_fit` method of each
    sub-estimator.
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **self**
  : The partially fitted underlying estimator.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Estimate the best class label for each sample in X.

This is implemented as `argmax(decision_function(X), axis=1)` which
will return the label of the class with most votes by estimators
predicting the outcome of a decision for each possible class pair.

* **Parameters:**
  **X**
  : Data.
* **Returns:**
  **y**
  : Predicted multi-class targets.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, classes: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [OneVsOneClassifier](#sklearn.multiclass.OneVsOneClassifier)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **classes**
  : Metadata routing for `classes` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [OneVsOneClassifier](#sklearn.multiclass.OneVsOneClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we discuss the problem of classification when the target variable is composed of more than two classes. This is called multiclass classification.">  <div class="sphx-glr-thumbnail-title">Overview of multiclass training meta-estimators</div>
</div>
* [Overview of multiclass training meta-estimators](../../auto_examples/multiclass/plot_multiclass_overview.md#sphx-glr-auto-examples-multiclass-plot-multiclass-overview-py)

<!-- thumbnail-parent-div-close --></div>
