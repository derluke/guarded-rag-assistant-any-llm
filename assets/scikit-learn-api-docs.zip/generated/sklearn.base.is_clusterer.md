# is_clusterer

### sklearn.base.is_clusterer(estimator)

Return True if the given estimator is (probably) a clusterer.

#### Versionadded
Added in version 1.6.

* **Parameters:**
  **estimator**
  : Estimator object to test.
* **Returns:**
  **out**
  : True if estimator is a clusterer and False otherwise.

### Examples

```pycon
>>> from sklearn.base import is_clusterer
>>> from sklearn.cluster import KMeans
>>> from sklearn.svm import SVC, SVR
>>> classifier = SVC()
>>> regressor = SVR()
>>> kmeans = KMeans()
>>> is_clusterer(classifier)
False
>>> is_clusterer(regressor)
False
>>> is_clusterer(kmeans)
True
```

<!-- !! processed by numpydoc !! -->
