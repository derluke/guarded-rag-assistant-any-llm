# Lars

### *class* sklearn.linear_model.Lars(\*, fit_intercept=True, verbose=False, precompute='auto', n_nonzero_coefs=500, eps=2.220446049250313e-16, copy_X=True, fit_path=True, jitter=None, random_state=None)

Least Angle Regression model a.k.a. LAR.

Read more in the [User Guide](../linear_model.md#least-angle-regression).

* **Parameters:**
  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to false, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **verbose**
  : Sets the verbosity amount.

  **precompute**
  : Whether to use a precomputed Gram matrix to speed up
    calculations. If set to `'auto'` let us decide. The Gram
    matrix can also be passed as argument.

  **n_nonzero_coefs**
  : Target number of non-zero coefficients. Use `np.inf` for no limit.

  **eps**
  : The machine-precision regularization in the computation of the
    Cholesky diagonal factors. Increase this for very ill-conditioned
    systems. Unlike the `tol` parameter in some iterative
    optimization-based algorithms, this parameter does not control
    the tolerance of the optimization.

  **copy_X**
  : If `True`, X will be copied; else, it may be overwritten.

  **fit_path**
  : If True the full path is stored in the `coef_path_` attribute.
    If you compute the solution for a large problem or many targets,
    setting `fit_path` to `False` will lead to a speedup, especially
    with a small alpha.

  **jitter**
  : Upper bound on a uniform noise parameter to be added to the
    `y` values, to satisfy the model’s assumption of
    one-at-a-time computations. Might help with stability.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **random_state**
  : Determines random number generation for jittering. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state). Ignored if `jitter` is None.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Attributes:**
  **alphas_**
  : Maximum of covariances (in absolute value) at each iteration.
    `n_alphas` is either `max_iter`, `n_features` or the
    number of nodes in the path with `alpha >= alpha_min`, whichever
    is smaller. If this is a list of array-like, the length of the outer
    list is `n_targets`.

  **active_**
  : Indices of active variables at the end of the path.
    If this is a list of list, the length of the outer list is `n_targets`.

  **coef_path_**
  : The varying values of the coefficients along the path. It is not
    present if the `fit_path` parameter is `False`. If this is a list
    of array-like, the length of the outer list is `n_targets`.

  **coef_**
  : Parameter vector (w in the formulation formula).

  **intercept_**
  : Independent term in decision function.

  **n_iter_**
  : The number of iterations taken by lars_path to find the
    grid of alphas for each target.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`lars_path`](sklearn.linear_model.lars_path.md#sklearn.linear_model.lars_path)
: Compute Least Angle Regression or Lasso path using LARS algorithm.

[`LarsCV`](sklearn.linear_model.LarsCV.md#sklearn.linear_model.LarsCV)
: Cross-validated Least Angle Regression model.

[`sklearn.decomposition.sparse_encode`](sklearn.decomposition.sparse_encode.md#sklearn.decomposition.sparse_encode)
: Sparse coding.

### Examples

```pycon
>>> from sklearn import linear_model
>>> reg = linear_model.Lars(n_nonzero_coefs=1)
>>> reg.fit([[-1, 1], [0, 0], [1, 1]], [-1.1111, 0, -1.1111])
Lars(n_nonzero_coefs=1)
>>> print(reg.coef_)
[ 0. -1.11...]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, Xy=None)

Fit the model using X, y as training data.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **Xy**
  : Xy = np.dot(X.T, y) that can be precomputed. It is useful
    only when the Gram matrix is precomputed.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, Xy: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [Lars](#sklearn.linear_model.Lars)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **Xy**
  : Metadata routing for `Xy` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [Lars](#sklearn.linear_model.Lars)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->
