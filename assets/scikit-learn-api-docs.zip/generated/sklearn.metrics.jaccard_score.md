# jaccard_score

### sklearn.metrics.jaccard_score(y_true, y_pred, \*, labels=None, pos_label=1, average='binary', sample_weight=None, zero_division='warn')

Jaccard similarity coefficient score.

The Jaccard index [1], or Jaccard similarity coefficient, defined as
the size of the intersection divided by the size of the union of two label
sets, is used to compare set of predicted labels for a sample to the
corresponding set of labels in `y_true`.

Support beyond term:`binary` targets is achieved by treating [multiclass](../../glossary.md#term-multiclass)
and [multilabel](../../glossary.md#term-multilabel) data as a collection of binary problems, one for each
label. For the [binary](../../glossary.md#term-binary) case, setting `average='binary'` will return the
Jaccard similarity coefficient for `pos_label`. If `average` is not `'binary'`,
`pos_label` is ignored and scores for both classes are computed, then averaged or
both returned (when `average=None`). Similarly, for [multiclass](../../glossary.md#term-multiclass) and
[multilabel](../../glossary.md#term-multilabel) targets, scores for all `labels` are either returned or
averaged depending on the `average` parameter. Use `labels` specify the set of
labels to calculate the score for.

Read more in the [User Guide](../model_evaluation.md#jaccard-similarity-score).

* **Parameters:**
  **y_true**
  : Ground truth (correct) labels.

  **y_pred**
  : Predicted labels, as returned by a classifier.

  **labels**
  : The set of labels to include when `average != 'binary'`, and their
    order if `average is None`. Labels present in the data can be
    excluded, for example in multiclass classification to exclude a “negative
    class”. Labels not present in the data can be included and will be
    “assigned” 0 samples. For multilabel targets, labels are column indices.
    By default, all labels in `y_true` and `y_pred` are used in sorted order.

  **pos_label**
  : The class to report if `average='binary'` and the data is binary,
    otherwise this parameter is ignored.
    For multiclass or multilabel targets, set `labels=[pos_label]` and
    `average != 'binary'` to report metrics for one label only.

  **average**
  : If `None`, the scores for each class are returned. Otherwise, this
    determines the type of averaging performed on the data:
    <br/>
    `'binary'`:
    : Only report results for the class specified by `pos_label`.
      This is applicable only if targets (`y_{true,pred}`) are binary.
    <br/>
    `'micro'`:
    : Calculate metrics globally by counting the total true positives,
      false negatives and false positives.
    <br/>
    `'macro'`:
    : Calculate metrics for each label, and find their unweighted
      mean.  This does not take label imbalance into account.
    <br/>
    `'weighted'`:
    : Calculate metrics for each label, and find their average, weighted
      by support (the number of true instances for each label). This
      alters ‘macro’ to account for label imbalance.
    <br/>
    `'samples'`:
    : Calculate metrics for each instance, and find their average (only
      meaningful for multilabel classification).

  **sample_weight**
  : Sample weights.

  **zero_division**
  : Sets the value to return when there is a zero division, i.e. when there
    there are no negative values in predictions and labels. If set to
    “warn”, this acts like 0, but a warning is also raised.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Returns:**
  **score**
  : The Jaccard score. When `average` is not `None`, a single scalar is
    returned.

#### SEE ALSO
[`accuracy_score`](sklearn.metrics.accuracy_score.md#sklearn.metrics.accuracy_score)
: Function for calculating the accuracy score.

[`f1_score`](sklearn.metrics.f1_score.md#sklearn.metrics.f1_score)
: Function for calculating the F1 score.

[`multilabel_confusion_matrix`](sklearn.metrics.multilabel_confusion_matrix.md#sklearn.metrics.multilabel_confusion_matrix)
: Function for computing a confusion matrix                                  for each class or sample.

### Notes

[`jaccard_score`](#sklearn.metrics.jaccard_score) may be a poor metric if there are no
positives for some samples or classes. Jaccard is undefined if there are
no true or predicted labels, and our implementation will return a score
of 0 with a warning.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.metrics import jaccard_score
>>> y_true = np.array([[0, 1, 1],
...                    [1, 1, 0]])
>>> y_pred = np.array([[1, 1, 1],
...                    [1, 0, 0]])
```

In the binary case:

```pycon
>>> jaccard_score(y_true[0], y_pred[0])
np.float64(0.6666...)
```

In the 2D comparison case (e.g. image similarity):

```pycon
>>> jaccard_score(y_true, y_pred, average="micro")
np.float64(0.6)
```

In the multilabel case:

```pycon
>>> jaccard_score(y_true, y_pred, average='samples')
np.float64(0.5833...)
>>> jaccard_score(y_true, y_pred, average='macro')
np.float64(0.6666...)
>>> jaccard_score(y_true, y_pred, average=None)
array([0.5, 0.5, 1. ])
```

In the multiclass case:

```pycon
>>> y_pred = [0, 2, 1, 2]
>>> y_true = [0, 1, 2, 2]
>>> jaccard_score(y_true, y_pred, average=None)
array([1. , 0. , 0.33...])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="The most naive strategy to solve such a task is to independently train a binary classifier on each label (i.e. each column of the target variable). At prediction time, the ensemble of binary classifiers is used to assemble multitask prediction.">  <div class="sphx-glr-thumbnail-title">Multilabel classification using a classifier chain</div>
</div>
* [Multilabel classification using a classifier chain](../../auto_examples/multioutput/plot_classifier_chain_yeast.md#sphx-glr-auto-examples-multioutput-plot-classifier-chain-yeast-py)

<!-- thumbnail-parent-div-close --></div>
