# empirical_covariance

### sklearn.covariance.empirical_covariance(X, \*, assume_centered=False)

Compute the Maximum likelihood covariance estimator.

* **Parameters:**
  **X**
  : Data from which to compute the covariance estimate.

  **assume_centered**
  : If `True`, data will not be centered before computation.
    Useful when working with data whose mean is almost, but not exactly
    zero.
    If `False`, data will be centered before computation.
* **Returns:**
  **covariance**
  : Empirical covariance (Maximum Likelihood Estimator).

### Examples

```pycon
>>> from sklearn.covariance import empirical_covariance
>>> X = [[1,1,1],[1,1,1],[1,1,1],
...      [0,0,0],[0,0,0],[0,0,0]]
>>> empirical_covariance(X)
array([[0.25, 0.25, 0.25],
       [0.25, 0.25, 0.25],
       [0.25, 0.25, 0.25]])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="When working with covariance estimation, the usual approach is to use a maximum likelihood estimator, such as the EmpiricalCovariance. It is unbiased, i.e. it converges to the true (population) covariance when given many observations. However, it can also be beneficial to regularize it, in order to reduce its variance; this, in turn, introduces some bias. This example illustrates the simple regularization used in shrunk_covariance estimators. In particular, it focuses on how to set the amount of regularization, i.e. how to choose the bias-variance trade-off.">  <div class="sphx-glr-thumbnail-title">Shrinkage covariance estimation: LedoitWolf vs OAS and max-likelihood</div>
</div>
* [Shrinkage covariance estimation: LedoitWolf vs OAS and max-likelihood](../../auto_examples/covariance/plot_covariance_estimation.md#sphx-glr-auto-examples-covariance-plot-covariance-estimation-py)

<!-- thumbnail-parent-div-close --></div>
