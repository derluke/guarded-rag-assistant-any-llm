# delayed

### sklearn.utils.parallel.delayed(function)

Decorator used to capture the arguments of a function.

This alternative to `joblib.delayed` is meant to be used in conjunction
with `sklearn.utils.parallel.Parallel`. The latter captures the scikit-
learn configuration by calling `sklearn.get_config()` in the current
thread, prior to dispatching the first task. The captured configuration is
then propagated and enabled for the duration of the execution of the
delayed function in the joblib workers.

#### Versionchanged
Changed in version 1.3: `delayed` was moved from `sklearn.utils.fixes` to `sklearn.utils.parallel`
in scikit-learn 1.3.

* **Parameters:**
  **function**
  : The function to be delayed.
* **Returns:**
  output: tuple
  : Tuple containing the delayed function, the positional arguments, and the
    keyword arguments.

<!-- !! processed by numpydoc !! -->
