# Birch

### *class* sklearn.cluster.Birch(\*, threshold=0.5, branching_factor=50, n_clusters=3, compute_labels=True, copy='deprecated')

Implements the BIRCH clustering algorithm.

It is a memory-efficient, online-learning algorithm provided as an
alternative to [`MiniBatchKMeans`](sklearn.cluster.MiniBatchKMeans.md#sklearn.cluster.MiniBatchKMeans). It constructs a tree
data structure with the cluster centroids being read off the leaf.
These can be either the final cluster centroids or can be provided as input
to another clustering algorithm such as [`AgglomerativeClustering`](sklearn.cluster.AgglomerativeClustering.md#sklearn.cluster.AgglomerativeClustering).

Read more in the [User Guide](../clustering.md#birch).

#### Versionadded
Added in version 0.16.

* **Parameters:**
  **threshold**
  : The radius of the subcluster obtained by merging a new sample and the
    closest subcluster should be lesser than the threshold. Otherwise a new
    subcluster is started. Setting this value to be very low promotes
    splitting and vice-versa.

  **branching_factor**
  : Maximum number of CF subclusters in each node. If a new samples enters
    such that the number of subclusters exceed the branching_factor then
    that node is split into two nodes with the subclusters redistributed
    in each. The parent subcluster of that node is removed and two new
    subclusters are added as parents of the 2 split nodes.

  **n_clusters**
  : Number of clusters after the final clustering step, which treats the
    subclusters from the leaves as new samples.
    - `None` : the final clustering step is not performed and the
      subclusters are returned as they are.
    - [`sklearn.cluster`](../../api/sklearn.cluster.md#module-sklearn.cluster) Estimator : If a model is provided, the model
      is fit treating the subclusters as new samples and the initial data
      is mapped to the label of the closest subcluster.
    - `int` : the model fit is [`AgglomerativeClustering`](sklearn.cluster.AgglomerativeClustering.md#sklearn.cluster.AgglomerativeClustering) with
      `n_clusters` set to be equal to the int.

  **compute_labels**
  : Whether or not to compute labels for each fit.

  **copy**
  : Whether or not to make a copy of the given data. If set to False,
    the initial data will be overwritten.
    <br/>
    #### Deprecated
    Deprecated since version 1.6: `copy` was deprecated in 1.6 and will be removed in 1.8. It has no effect
    as the estimator does not perform in-place operations on the input data.
* **Attributes:**
  **root_**
  : Root of the CFTree.

  **dummy_leaf_**
  : Start pointer to all the leaves.

  **subcluster_centers_**
  : Centroids of all subclusters read directly from the leaves.

  **subcluster_labels_**
  : Labels assigned to the centroids of the subclusters after
    they are clustered globally.

  **labels_**
  : Array of labels assigned to the input data.
    if partial_fit is used instead of fit, they are assigned to the
    last batch of data.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`MiniBatchKMeans`](sklearn.cluster.MiniBatchKMeans.md#sklearn.cluster.MiniBatchKMeans)
: Alternative implementation that does incremental updates of the centers’ positions using mini-batches.

### Notes

The tree data structure consists of nodes with each node consisting of
a number of subclusters. The maximum number of subclusters in a node
is determined by the branching factor. Each subcluster maintains a
linear sum, squared sum and the number of samples in that subcluster.
In addition, each subcluster can also have a node as its child, if the
subcluster is not a member of a leaf node.

For a new point entering the root, it is merged with the subcluster closest
to it and the linear sum, squared sum and the number of samples of that
subcluster are updated. This is done recursively till the properties of
the leaf node are updated.

See [Compare BIRCH and MiniBatchKMeans](../../auto_examples/cluster/plot_birch_vs_minibatchkmeans.md#sphx-glr-auto-examples-cluster-plot-birch-vs-minibatchkmeans-py) for a
comparison with [`MiniBatchKMeans`](sklearn.cluster.MiniBatchKMeans.md#sklearn.cluster.MiniBatchKMeans).

### References

* Tian Zhang, Raghu Ramakrishnan, Maron Livny
  BIRCH: An efficient data clustering method for large databases.
  [https://www.cs.sfu.ca/CourseCentral/459/han/papers/zhang96.pdf](https://www.cs.sfu.ca/CourseCentral/459/han/papers/zhang96.pdf)
* Roberto Perdisci
  JBirch - Java implementation of BIRCH clustering algorithm
  [https://code.google.com/archive/p/jbirch](https://code.google.com/archive/p/jbirch)

### Examples

```pycon
>>> from sklearn.cluster import Birch
>>> X = [[0, 1], [0.3, 1], [-0.3, 1], [0, -1], [0.3, -1], [-0.3, -1]]
>>> brc = Birch(n_clusters=None)
>>> brc.fit(X)
Birch(n_clusters=None)
>>> brc.predict(X)
array([0, 0, 0, 1, 1, 1])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Build a CF Tree for the input data.

* **Parameters:**
  **X**
  : Input data.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None, \*\*kwargs)

Perform clustering on `X` and returns cluster labels.

* **Parameters:**
  **X**
  : Input data.

  **y**
  : Not used, present for API consistency by convention.

  **\*\*kwargs**
  : Arguments to be passed to `fit`.
    <br/>
    #### Versionadded
    Added in version 1.4.
* **Returns:**
  **labels**
  : Cluster labels.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X=None, y=None)

Online learning. Prevents rebuilding of CFTree from scratch.

* **Parameters:**
  **X**
  : Input data. If X is not provided, only the global clustering
    step is done.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict data using the `centroids_` of subclusters.

Avoid computation of the row norms of X.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  **labels**
  : Labelled data.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform X into subcluster centroids dimension.

Each dimension represents the distance from the sample point to each
cluster centroid.

* **Parameters:**
  **X**
  : Input data.
* **Returns:**
  **X_trans**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares the timing of BIRCH (with and without the global clustering step) and MiniBatchKMeans on a synthetic dataset having 25,000 samples and 2 features generated using make_blobs.">  <div class="sphx-glr-thumbnail-title">Compare BIRCH and MiniBatchKMeans</div>
</div>
* [Compare BIRCH and MiniBatchKMeans](../../auto_examples/cluster/plot_birch_vs_minibatchkmeans.md#sphx-glr-auto-examples-cluster-plot-birch-vs-minibatchkmeans-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<!-- thumbnail-parent-div-close --></div>
