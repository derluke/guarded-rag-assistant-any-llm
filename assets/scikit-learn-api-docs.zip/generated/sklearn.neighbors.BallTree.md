# BallTree

### *class* sklearn.neighbors.BallTree

BallTree for fast generalized N-point problems

Read more in the [User Guide](../neighbors.md#unsupervised-neighbors).

* **Parameters:**
  **X**
  : n_samples is the number of points in the data set, and
    n_features is the dimension of the parameter space.
    Note: if X is a C-contiguous array of doubles then data will
    not be copied. Otherwise, an internal copy will be made.

  **leaf_size**
  : Number of points at which to switch to brute-force. Changing
    leaf_size will not affect the results of a query, but can
    significantly impact the speed of a query and the memory required
    to store the constructed tree.  The amount of memory needed to
    store the tree scales as approximately n_samples / leaf_size.
    For a specified `leaf_size`, a leaf node is guaranteed to
    satisfy `leaf_size <= n_points <= 2 * leaf_size`, except in
    the case that `n_samples < leaf_size`.

  **metric**
  : Metric to use for distance computation. Default is “minkowski”, which
    results in the standard Euclidean distance when p = 2.
    A list of valid metrics for BallTree is given by the attribute
    `valid_metrics`.
    See the documentation of [scipy.spatial.distance](https://docs.scipy.org/doc/scipy/reference/spatial.distance.html) and
    the metrics listed in [`distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics) for
    more information on any distance metric.

  **Additional keywords are passed to the distance metric class.**

  **Note: Callable functions in the metric parameter are NOT supported for KDTree**

  **and Ball Tree. Function call overhead will result in very poor performance.**
* **Attributes:**
  **data**
  : The training data

  **valid_metrics: list of str**
  : List of valid distance metrics.

### Examples

Query for k-nearest neighbors

```pycon
>>> import numpy as np
>>> from sklearn.neighbors import BallTree
>>> rng = np.random.RandomState(0)
>>> X = rng.random_sample((10, 3))  # 10 points in 3 dimensions
>>> tree = BallTree(X, leaf_size=2)              
>>> dist, ind = tree.query(X[:1], k=3)                
>>> print(ind)  # indices of 3 closest neighbors
[0 3 1]
>>> print(dist)  # distances to 3 closest neighbors
[ 0.          0.19662693  0.29473397]
```

Pickle and Unpickle a tree.  Note that the state of the tree is saved in the
pickle operation: the tree needs not be rebuilt upon unpickling.

```pycon
>>> import numpy as np
>>> import pickle
>>> rng = np.random.RandomState(0)
>>> X = rng.random_sample((10, 3))  # 10 points in 3 dimensions
>>> tree = BallTree(X, leaf_size=2)        
>>> s = pickle.dumps(tree)                     
>>> tree_copy = pickle.loads(s)                
>>> dist, ind = tree_copy.query(X[:1], k=3)     
>>> print(ind)  # indices of 3 closest neighbors
[0 3 1]
>>> print(dist)  # distances to 3 closest neighbors
[ 0.          0.19662693  0.29473397]
```

Query for neighbors within a given radius

```pycon
>>> import numpy as np
>>> rng = np.random.RandomState(0)
>>> X = rng.random_sample((10, 3))  # 10 points in 3 dimensions
>>> tree = BallTree(X, leaf_size=2)     
>>> print(tree.query_radius(X[:1], r=0.3, count_only=True))
3
>>> ind = tree.query_radius(X[:1], r=0.3)  
>>> print(ind)  # indices of neighbors within distance 0.3
[3 0 1]
```

Compute a gaussian kernel density estimate:

```pycon
>>> import numpy as np
>>> rng = np.random.RandomState(42)
>>> X = rng.random_sample((100, 3))
>>> tree = BallTree(X)                
>>> tree.kernel_density(X[:3], h=0.1, kernel='gaussian')
array([ 6.94114649,  7.83281226,  7.2071716 ])
```

Compute a two-point auto-correlation function

```pycon
>>> import numpy as np
>>> rng = np.random.RandomState(0)
>>> X = rng.random_sample((30, 3))
>>> r = np.linspace(0, 1, 5)
>>> tree = BallTree(X)                
>>> tree.two_point_correlation(X, r)
array([ 30,  62, 278, 580, 820])
```

<!-- !! processed by numpydoc !! -->

#### get_arrays()

Get data and node arrays.

* **Returns:**
  arrays: tuple of array
  : Arrays for storing tree data, index, node data and node bounds.

<!-- !! processed by numpydoc !! -->

#### get_n_calls()

Get number of calls.

* **Returns:**
  n_calls: int
  : number of distance computation calls

<!-- !! processed by numpydoc !! -->

#### get_tree_stats()

Get tree status.

* **Returns:**
  tree_stats: tuple of int
  : (number of trims, number of leaves, number of splits)

<!-- !! processed by numpydoc !! -->

#### kernel_density(X, h, kernel='gaussian', atol=0, rtol=1E-8, breadth_first=True, return_log=False)

Compute the kernel density estimate at points X with the given kernel,
using the distance metric specified at tree creation.

* **Parameters:**
  **X**
  : An array of points to query.  Last dimension should match dimension
    of training data.

  **h**
  : the bandwidth of the kernel

  **kernel**
  : specify the kernel to use.  Options are
    - ‘gaussian’
    - ‘tophat’
    - ‘epanechnikov’
    - ‘exponential’
    - ‘linear’
    - ‘cosine’
    Default is kernel = ‘gaussian’

  **atol**
  : Specify the desired absolute tolerance of the result.
    If the true result is `K_true`, then the returned result `K_ret`
    satisfies `abs(K_true - K_ret) < atol + rtol * K_ret`
    The default is zero (i.e. machine precision).

  **rtol**
  : Specify the desired relative tolerance of the result.
    If the true result is `K_true`, then the returned result `K_ret`
    satisfies `abs(K_true - K_ret) < atol + rtol * K_ret`
    The default is `1e-8` (i.e. machine precision).

  **breadth_first**
  : If True, use a breadth-first search.  If False (default) use a
    depth-first search.  Breadth-first is generally faster for
    compact kernels and/or high tolerances.

  **return_log**
  : Return the logarithm of the result.  This can be more accurate
    than returning the result itself for narrow kernels.
* **Returns:**
  **density**
  : The array of (log)-density evaluations

<!-- !! processed by numpydoc !! -->

#### query(X, k=1, return_distance=True, dualtree=False, breadth_first=False)

query the tree for the k nearest neighbors

* **Parameters:**
  **X**
  : An array of points to query

  **k**
  : The number of nearest neighbors to return

  **return_distance**
  : if True, return a tuple (d, i) of distances and indices
    if False, return array i

  **dualtree**
  : if True, use the dual tree formalism for the query: a tree is
    built for the query points, and the pair of trees is used to
    efficiently search this space.  This can lead to better
    performance as the number of points grows large.

  **breadth_first**
  : if True, then query the nodes in a breadth-first manner.
    Otherwise, query the nodes in a depth-first manner.

  **sort_results**
  : if True, then distances and indices of each point are sorted
    on return, so that the first column contains the closest points.
    Otherwise, neighbors are returned in an arbitrary order.
* **Returns:**
  **i**

  **(d,i)**

  **d**
  : Each entry gives the list of distances to the neighbors of the
    corresponding point.

  **i**
  : Each entry gives the list of indices of neighbors of the
    corresponding point.

<!-- !! processed by numpydoc !! -->

#### query_radius(X, r, return_distance=False, count_only=False, sort_results=False)

query the tree for neighbors within a radius r

* **Parameters:**
  **X**
  : An array of points to query

  **r**
  : r can be a single value, or an array of values of shape
    x.shape[:-1] if different radii are desired for each point.

  **return_distance**
  : if True,  return distances to neighbors of each point
    if False, return only neighbors
    Note that unlike the query() method, setting return_distance=True
    here adds to the computation time.  Not all distances need to be
    calculated explicitly for return_distance=False.  Results are
    not sorted by default: see `sort_results` keyword.

  **count_only**
  : if True,  return only the count of points within distance r
    if False, return the indices of all points within distance r
    If return_distance==True, setting count_only=True will
    result in an error.

  **sort_results**
  : if True, the distances and indices will be sorted before being
    returned.  If False, the results will not be sorted.  If
    return_distance == False, setting sort_results = True will
    result in an error.
* **Returns:**
  **count**

  **ind**

  **(ind, dist)**

  **count**
  : Each entry gives the number of neighbors within a distance r of the
    corresponding point.

  **ind**
  : Each element is a numpy integer array listing the indices of
    neighbors of the corresponding point.  Note that unlike
    the results of a k-neighbors query, the returned neighbors
    are not sorted by distance by default.

  **dist**
  : Each element is a numpy double array listing the distances
    corresponding to indices in i.

<!-- !! processed by numpydoc !! -->

#### reset_n_calls()

Reset number of calls to 0.

<!-- !! processed by numpydoc !! -->

#### two_point_correlation(X, r, dualtree=False)

Compute the two-point correlation function

* **Parameters:**
  **X**
  : An array of points to query.  Last dimension should match dimension
    of training data.

  **r**
  : A one-dimensional array of distances

  **dualtree**
  : If True, use a dualtree algorithm.  Otherwise, use a single-tree
    algorithm.  Dual tree algorithms can have better scaling for
    large N.
* **Returns:**
  **counts**
  : counts[i] contains the number of pairs of points with distance
    less than or equal to r[i]

<!-- !! processed by numpydoc !! -->
