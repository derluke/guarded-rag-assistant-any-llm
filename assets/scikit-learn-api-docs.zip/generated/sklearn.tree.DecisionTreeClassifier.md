# DecisionTreeClassifier

### *class* sklearn.tree.DecisionTreeClassifier(\*, criterion='gini', splitter='best', max_depth=None, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features=None, random_state=None, max_leaf_nodes=None, min_impurity_decrease=0.0, class_weight=None, ccp_alpha=0.0, monotonic_cst=None)

A decision tree classifier.

Read more in the [User Guide](../tree.md#tree).

* **Parameters:**
  **criterion**
  : The function to measure the quality of a split. Supported criteria are
    “gini” for the Gini impurity and “log_loss” and “entropy” both for the
    Shannon information gain, see [Mathematical formulation](../tree.md#tree-mathematical-formulation).

  **splitter**
  : The strategy used to choose the split at each node. Supported
    strategies are “best” to choose the best split and “random” to choose
    the best random split.

  **max_depth**
  : The maximum depth of the tree. If None, then nodes are expanded until
    all leaves are pure or until all leaves contain less than
    min_samples_split samples.

  **min_samples_split**
  : The minimum number of samples required to split an internal node:
    - If int, then consider `min_samples_split` as the minimum number.
    - If float, then `min_samples_split` is a fraction and
      `ceil(min_samples_split * n_samples)` are the minimum
      number of samples for each split.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_samples_leaf**
  : The minimum number of samples required to be at a leaf node.
    A split point at any depth will only be considered if it leaves at
    least `min_samples_leaf` training samples in each of the left and
    right branches.  This may have the effect of smoothing the model,
    especially in regression.
    - If int, then consider `min_samples_leaf` as the minimum number.
    - If float, then `min_samples_leaf` is a fraction and
      `ceil(min_samples_leaf * n_samples)` are the minimum
      number of samples for each node.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_weight_fraction_leaf**
  : The minimum weighted fraction of the sum total of weights (of all
    the input samples) required to be at a leaf node. Samples have
    equal weight when sample_weight is not provided.

  **max_features**
  : The number of features to consider when looking for the best split:
    - If int, then consider `max_features` features at each split.
    - If float, then `max_features` is a fraction and
      `max(1, int(max_features * n_features_in_))` features are considered at
      each split.
    - If “sqrt”, then `max_features=sqrt(n_features)`.
    - If “log2”, then `max_features=log2(n_features)`.
    - If None, then `max_features=n_features`.
    <br/>
    #### NOTE
    The search for a split does not stop until at least one
    valid partition of the node samples is found, even if it requires to
    effectively inspect more than `max_features` features.

  **random_state**
  : Controls the randomness of the estimator. The features are always
    randomly permuted at each split, even if `splitter` is set to
    `"best"`. When `max_features < n_features`, the algorithm will
    select `max_features` at random at each split before finding the best
    split among them. But the best found split may vary across different
    runs, even if `max_features=n_features`. That is the case, if the
    improvement of the criterion is identical for several splits and one
    split has to be selected at random. To obtain a deterministic behaviour
    during fitting, `random_state` has to be fixed to an integer.
    See [Glossary](../../glossary.md#term-random_state) for details.

  **max_leaf_nodes**
  : Grow a tree with `max_leaf_nodes` in best-first fashion.
    Best nodes are defined as relative reduction in impurity.
    If None then unlimited number of leaf nodes.

  **min_impurity_decrease**
  : A node will be split if this split induces a decrease of the impurity
    greater than or equal to this value.
    <br/>
    The weighted impurity decrease equation is the following:
    ```default
    N_t / N * (impurity - N_t_R / N_t * right_impurity
                        - N_t_L / N_t * left_impurity)
    ```
    <br/>
    where `N` is the total number of samples, `N_t` is the number of
    samples at the current node, `N_t_L` is the number of samples in the
    left child, and `N_t_R` is the number of samples in the right child.
    <br/>
    `N`, `N_t`, `N_t_R` and `N_t_L` all refer to the weighted sum,
    if `sample_weight` is passed.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **class_weight**
  : Weights associated with classes in the form `{class_label: weight}`.
    If None, all classes are supposed to have weight one. For
    multi-output problems, a list of dicts can be provided in the same
    order as the columns of y.
    <br/>
    Note that for multioutput (including multilabel) weights should be
    defined for each class of every column in its own dict. For example,
    for four-class multilabel classification weights should be
    [{0: 1, 1: 1}, {0: 1, 1: 5}, {0: 1, 1: 1}, {0: 1, 1: 1}] instead of
    [{1:1}, {2:5}, {3:1}, {4:1}].
    <br/>
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`
    <br/>
    For multi-output, the weights of each column of y will be multiplied.
    <br/>
    Note that these weights will be multiplied with sample_weight (passed
    through the fit method) if sample_weight is specified.

  **ccp_alpha**
  : Complexity parameter used for Minimal Cost-Complexity Pruning. The
    subtree with the largest cost complexity that is smaller than
    `ccp_alpha` will be chosen. By default, no pruning is performed. See
    [Minimal Cost-Complexity Pruning](../tree.md#minimal-cost-complexity-pruning) for details. See
    [Post pruning decision trees with cost complexity pruning](../../auto_examples/tree/plot_cost_complexity_pruning.md#sphx-glr-auto-examples-tree-plot-cost-complexity-pruning-py)
    for an example of such pruning.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **monotonic_cst**
  : Indicates the monotonicity constraint to enforce on each feature.
    : - 1: monotonic increase
      - 0: no constraint
      - -1: monotonic decrease
    <br/>
    If monotonic_cst is None, no constraints are applied.
    <br/>
    Monotonicity constraints are not supported for:
    : - multiclass classifications (i.e. when `n_classes > 2`),
      - multioutput classifications (i.e. when `n_outputs_ > 1`),
      - classifications trained on data with missing values.
    <br/>
    The constraints hold over the probability of the positive class.
    <br/>
    Read more in the [User Guide](../ensemble.md#monotonic-cst-gbdt).
    <br/>
    #### Versionadded
    Added in version 1.4.
* **Attributes:**
  **classes_**
  : The classes labels (single output problem),
    or a list of arrays of class labels (multi-output problem).

  [`feature_importances_`](#sklearn.tree.DecisionTreeClassifier.feature_importances_)
  : Return the feature importances.

  **max_features_**
  : The inferred value of max_features.

  **n_classes_**
  : The number of classes (for single output problems),
    or a list containing the number of classes for each
    output (for multi-output problems).

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_outputs_**
  : The number of outputs when `fit` is performed.

  **tree_**
  : The underlying Tree object. Please refer to
    `help(sklearn.tree._tree.Tree)` for attributes of Tree object and
    [Understanding the decision tree structure](../../auto_examples/tree/plot_unveil_tree_structure.md#sphx-glr-auto-examples-tree-plot-unveil-tree-structure-py)
    for basic usage of these attributes.

#### SEE ALSO
[`DecisionTreeRegressor`](sklearn.tree.DecisionTreeRegressor.md#sklearn.tree.DecisionTreeRegressor)
: A decision tree regressor.

### Notes

The default values for the parameters controlling the size of the trees
(e.g. `max_depth`, `min_samples_leaf`, etc.) lead to fully grown and
unpruned trees which can potentially be very large on some data sets. To
reduce memory consumption, the complexity and size of the trees should be
controlled by setting those parameter values.

The [`predict`](#sklearn.tree.DecisionTreeClassifier.predict) method operates using the [`numpy.argmax`](https://numpy.org/doc/stable/reference/generated/numpy.argmax.html#numpy.argmax)
function on the outputs of [`predict_proba`](#sklearn.tree.DecisionTreeClassifier.predict_proba). This means that in
case the highest predicted probabilities are tied, the classifier will
predict the tied class with the lowest index in [classes_](../../glossary.md#term-classes_).

### References

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn.model_selection import cross_val_score
>>> from sklearn.tree import DecisionTreeClassifier
>>> clf = DecisionTreeClassifier(random_state=0)
>>> iris = load_iris()
>>> cross_val_score(clf, iris.data, iris.target, cv=10)
...                             
...
array([ 1.     ,  0.93...,  0.86...,  0.93...,  0.93...,
        0.93...,  0.93...,  1.     ,  0.93...,  1.      ])
```

<!-- !! processed by numpydoc !! -->

#### apply(X, check_input=True)

Return the index of the leaf that each sample is predicted as.

#### Versionadded
Added in version 0.17.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you’re doing.
* **Returns:**
  **X_leaves**
  : For each datapoint x in X, return the index of the leaf x
    ends up in. Leaves are numbered within
    `[0; self.tree_.node_count)`, possibly with gaps in the
    numbering.

<!-- !! processed by numpydoc !! -->

#### cost_complexity_pruning_path(X, y, sample_weight=None)

Compute the pruning path during Minimal Cost-Complexity Pruning.

See [Minimal Cost-Complexity Pruning](../tree.md#minimal-cost-complexity-pruning) for details on the pruning
process.

* **Parameters:**
  **X**
  : The training input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csc_matrix`.

  **y**
  : The target values (class labels) as integers or strings.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted. Splits
    that would create child nodes with net zero or negative weight are
    ignored while searching for a split in each node. Splits are also
    ignored if they would result in any single class carrying a
    negative weight in either child node.
* **Returns:**
  **ccp_path**
  : Dictionary-like object, with the following attributes.
    <br/>
    ccp_alphas
    : Effective alphas of subtree during pruning.
    <br/>
    impurities
    : Sum of the impurities of the subtree leaves for the
      corresponding alpha value in `ccp_alphas`.

<!-- !! processed by numpydoc !! -->

#### decision_path(X, check_input=True)

Return the decision path in the tree.

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you’re doing.
* **Returns:**
  **indicator**
  : Return a node indicator CSR matrix where non zero elements
    indicates that the samples goes through the nodes.

<!-- !! processed by numpydoc !! -->

#### *property* feature_importances_

Return the feature importances.

The importance of a feature is computed as the (normalized) total
reduction of the criterion brought by that feature.
It is also known as the Gini importance.

Warning: impurity-based feature importances can be misleading for
high cardinality features (many unique values). See
[`sklearn.inspection.permutation_importance`](sklearn.inspection.permutation_importance.md#sklearn.inspection.permutation_importance) as an alternative.

* **Returns:**
  **feature_importances_**
  : Normalized total reduction of criteria by feature
    (Gini importance).

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, check_input=True)

Build a decision tree classifier from the training set (X, y).

* **Parameters:**
  **X**
  : The training input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csc_matrix`.

  **y**
  : The target values (class labels) as integers or strings.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted. Splits
    that would create child nodes with net zero or negative weight are
    ignored while searching for a split in each node. Splits are also
    ignored if they would result in any single class carrying a
    negative weight in either child node.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you’re doing.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_depth()

Return the depth of the decision tree.

The depth of a tree is the maximum distance between the root
and any leaf.

* **Returns:**
  **self.tree_.max_depth**
  : The maximum depth of the tree.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_leaves()

Return the number of leaves of the decision tree.

* **Returns:**
  **self.tree_.n_leaves**
  : Number of leaves.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X, check_input=True)

Predict class or regression value for X.

For a classification model, the predicted class for each sample in X is
returned. For a regression model, the predicted value based on X is
returned.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you’re doing.
* **Returns:**
  **y**
  : The predicted classes, or the predict values.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Predict class log-probabilities of the input samples X.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **proba**
  : The class log-probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_proba(X, check_input=True)

Predict class probabilities of the input samples X.

The predicted class probability is the fraction of samples of the same
class in a leaf.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.

  **check_input**
  : Allow to bypass several input checking.
    Don’t use this parameter unless you know what you’re doing.
* **Returns:**
  **proba**
  : The class probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [DecisionTreeClassifier](#sklearn.tree.DecisionTreeClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [DecisionTreeClassifier](#sklearn.tree.DecisionTreeClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how boosting can improve the prediction accuracy on a multi-label classification problem. It reproduces a similar experiment as depicted by Figure 1 in Zhu et al [1]_.">  <div class="sphx-glr-thumbnail-title">Multi-class AdaBoosted Decision Trees</div>
</div>
* [Multi-class AdaBoosted Decision Trees](../../auto_examples/ensemble/plot_adaboost_multiclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-multiclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision boundaries of a VotingClassifier for two features of the Iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision boundaries of a VotingClassifier</div>
</div>
* [Plot the decision boundaries of a VotingClassifier](../../auto_examples/ensemble/plot_voting_decision_regions.md#sphx-glr-auto-examples-ensemble-plot-voting-decision-regions-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision surfaces of forests of randomized trees trained on pairs of features of the iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision surfaces of ensembles of trees on the iris dataset</div>
</div>
* [Plot the decision surfaces of ensembles of trees on the iris dataset](../../auto_examples/ensemble/plot_forest_iris.md#sphx-glr-auto-examples-ensemble-plot-forest-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example fits an AdaBoosted decision stump on a non-linearly separable classification dataset composed of two &quot;Gaussian quantiles&quot; clusters (see sklearn.datasets.make_gaussian_quantiles) and plots the decision boundary and decision scores. The distributions of decision scores are shown separately for samples of class A and B. The predicted class label for each sample is determined by the sign of the decision score. Samples with decision scores greater than zero are classified as B, and are otherwise classified as A. The magnitude of a decision score determines the degree of likeness with the predicted class label. Additionally, a new dataset could be constructed containing a desired purity of class B, for example, by only selecting samples with a decision score above some value.">  <div class="sphx-glr-thumbnail-title">Two-class AdaBoost</div>
</div>
* [Two-class AdaBoost](../../auto_examples/ensemble/plot_adaboost_twoclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-twoclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="Multiple metric parameter search can be done by setting the scoring parameter to a list of metric scorer names or a dict mapping the scorer names to the scorer callables.">  <div class="sphx-glr-thumbnail-title">Demonstration of multi-metric evaluation on cross_val_score and GridSearchCV</div>
</div>
* [Demonstration of multi-metric evaluation on cross_val_score and GridSearchCV](../../auto_examples/model_selection/plot_multi_metric_evaluation.md#sphx-glr-auto-examples-model-selection-plot-multi-metric-evaluation-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we discuss the problem of classification when the target variable is composed of more than two classes. This is called multiclass classification.">  <div class="sphx-glr-thumbnail-title">Overview of multiclass training meta-estimators</div>
</div>
* [Overview of multiclass training meta-estimators](../../auto_examples/multiclass/plot_multiclass_overview.md#sphx-glr-auto-examples-multiclass-plot-multiclass-overview-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision surface of a decision tree trained on pairs of features of the iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision surface of decision trees trained on the iris dataset</div>
</div>
* [Plot the decision surface of decision trees trained on the iris dataset](../../auto_examples/tree/plot_iris_dtc.md#sphx-glr-auto-examples-tree-plot-iris-dtc-py)

<div class="sphx-glr-thumbcontainer" tooltip="The DecisionTreeClassifier provides parameters such as min_samples_leaf and max_depth to prevent a tree from overfiting. Cost complexity pruning provides another option to control the size of a tree. In DecisionTreeClassifier, this pruning technique is parameterized by the cost complexity parameter, ccp_alpha. Greater values of ccp_alpha increase the number of nodes pruned. Here we only show the effect of ccp_alpha on regularizing the trees and how to choose a ccp_alpha based on validation scores.">  <div class="sphx-glr-thumbnail-title">Post pruning decision trees with cost complexity pruning</div>
</div>
* [Post pruning decision trees with cost complexity pruning](../../auto_examples/tree/plot_cost_complexity_pruning.md#sphx-glr-auto-examples-tree-plot-cost-complexity-pruning-py)

<div class="sphx-glr-thumbcontainer" tooltip="The decision tree structure can be analysed to gain further insight on the relation between the features and the target to predict. In this example, we show how to retrieve:">  <div class="sphx-glr-thumbnail-title">Understanding the decision tree structure</div>
</div>
* [Understanding the decision tree structure](../../auto_examples/tree/plot_unveil_tree_structure.md#sphx-glr-auto-examples-tree-plot-unveil-tree-structure-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.3! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_3&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.3</div>
</div>
* [Release Highlights for scikit-learn 1.3](../../auto_examples/release_highlights/plot_release_highlights_1_3_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-3-0-py)

<!-- thumbnail-parent-div-close --></div>
