# fetch_20newsgroups_vectorized

### sklearn.datasets.fetch_20newsgroups_vectorized(\*, subset='train', remove=(), data_home=None, download_if_missing=True, return_X_y=False, normalize=True, as_frame=False, n_retries=3, delay=1.0)

Load and vectorize the 20 newsgroups dataset (classification).

Download it if necessary.

This is a convenience function; the transformation is done using the
default settings for
[`CountVectorizer`](sklearn.feature_extraction.text.CountVectorizer.md#sklearn.feature_extraction.text.CountVectorizer). For more
advanced usage (stopword filtering, n-gram extraction, etc.), combine
fetch_20newsgroups with a custom
[`CountVectorizer`](sklearn.feature_extraction.text.CountVectorizer.md#sklearn.feature_extraction.text.CountVectorizer),
[`HashingVectorizer`](sklearn.feature_extraction.text.HashingVectorizer.md#sklearn.feature_extraction.text.HashingVectorizer),
[`TfidfTransformer`](sklearn.feature_extraction.text.TfidfTransformer.md#sklearn.feature_extraction.text.TfidfTransformer) or
[`TfidfVectorizer`](sklearn.feature_extraction.text.TfidfVectorizer.md#sklearn.feature_extraction.text.TfidfVectorizer).

The resulting counts are normalized using
[`sklearn.preprocessing.normalize`](sklearn.preprocessing.normalize.md#sklearn.preprocessing.normalize) unless normalize is set to False.

| Classes        | 20     |
|----------------|--------|
| Samples total  | 18846  |
| Dimensionality | 130107 |
| Features       | real   |

Read more in the [User Guide](../../datasets/real_world.md#newsgroups-dataset).

* **Parameters:**
  **subset**
  : Select the dataset to load: ‘train’ for the training set, ‘test’
    for the test set, ‘all’ for both, with shuffled ordering.

  **remove**
  : May contain any subset of (‘headers’, ‘footers’, ‘quotes’). Each of
    these are kinds of text that will be detected and removed from the
    newsgroup posts, preventing classifiers from overfitting on
    metadata.
    <br/>
    ‘headers’ removes newsgroup headers, ‘footers’ removes blocks at the
    ends of posts that look like signatures, and ‘quotes’ removes lines
    that appear to be quoting another post.

  **data_home**
  : Specify an download and cache folder for the datasets. If None,
    all scikit-learn data is stored in ‘~/scikit_learn_data’ subfolders.

  **download_if_missing**
  : If False, raise an OSError if the data is not locally available
    instead of trying to download the data from the source site.

  **return_X_y**
  : If True, returns `(data.data, data.target)` instead of a Bunch
    object.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **normalize**
  : If True, normalizes each document’s feature vector to unit norm using
    [`sklearn.preprocessing.normalize`](sklearn.preprocessing.normalize.md#sklearn.preprocessing.normalize).
    <br/>
    #### Versionadded
    Added in version 0.22.

  **as_frame**
  : If True, the data is a pandas DataFrame including columns with
    appropriate dtypes (numeric, string, or categorical). The target is
    a pandas DataFrame or Series depending on the number of
    `target_columns`.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **n_retries**
  : Number of retries when HTTP errors are encountered.
    <br/>
    #### Versionadded
    Added in version 1.5.

  **delay**
  : Number of seconds between retries.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **bunch**
  : Dictionary-like object, with the following attributes.
    <br/>
    data: {sparse matrix, dataframe} of shape (n_samples, n_features)
    : The input data matrix. If `as_frame` is `True`, `data` is
      a pandas DataFrame with sparse columns.
    <br/>
    target: {ndarray, series} of shape (n_samples,)
    : The target labels. If `as_frame` is `True`, `target` is a
      pandas Series.
    <br/>
    target_names: list of shape (n_classes,)
    : The names of target classes.
    <br/>
    DESCR: str
    : The full description of the dataset.
    <br/>
    frame: dataframe of shape (n_samples, n_features + 1)
    : Only present when `as_frame=True`. Pandas DataFrame with `data`
      and `target`.
      <br/>
      #### Versionadded
      Added in version 0.24.

  **(data, target)**
  : `data` and `target` would be of the format defined in the `Bunch`
    description above.
    <br/>
    #### Versionadded
    Added in version 0.20.

### Examples

```pycon
>>> from sklearn.datasets import fetch_20newsgroups_vectorized
>>> newsgroups_vectorized = fetch_20newsgroups_vectorized(subset='test')
>>> newsgroups_vectorized.data.shape
(7532, 130107)
>>> newsgroups_vectorized.target.shape
(7532,)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Demonstrate how model complexity influences both prediction accuracy and computational performance.">  <div class="sphx-glr-thumbnail-title">Model Complexity Influence</div>
</div>
* [Model Complexity Influence](../../auto_examples/applications/plot_model_complexity_influence.md#sphx-glr-auto-examples-applications-plot-model-complexity-influence-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparison of multinomial logistic L1 vs one-versus-rest L1 logistic regression to classify documents from the newgroups20 dataset. Multinomial logistic regression yields more accurate results and is faster to train on the larger scale dataset.">  <div class="sphx-glr-thumbnail-title">Multiclass sparse logistic regression on 20newgroups</div>
</div>
* [Multiclass sparse logistic regression on 20newgroups](../../auto_examples/linear_model/plot_sparse_logistic_regression_20newsgroups.md#sphx-glr-auto-examples-linear-model-plot-sparse-logistic-regression-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip=" The \`Johnson-Lindenstrauss lemma\`_ states that any high dimensional dataset can be randomly projected into a lower dimensional Euclidean space while controlling the distortion in the pairwise distances.">  <div class="sphx-glr-thumbnail-title">The Johnson-Lindenstrauss bound for embedding with random projections</div>
</div>
* [The Johnson-Lindenstrauss bound for embedding with random projections](../../auto_examples/miscellaneous/plot_johnson_lindenstrauss_bound.md#sphx-glr-auto-examples-miscellaneous-plot-johnson-lindenstrauss-bound-py)

<!-- thumbnail-parent-div-close --></div>
