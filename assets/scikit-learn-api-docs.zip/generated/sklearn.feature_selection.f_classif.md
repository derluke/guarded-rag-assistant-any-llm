# f_classif

### sklearn.feature_selection.f_classif(X, y)

Compute the ANOVA F-value for the provided sample.

Read more in the [User Guide](../feature_selection.md#univariate-feature-selection).

* **Parameters:**
  **X**
  : The set of regressors that will be tested sequentially.

  **y**
  : The target vector.
* **Returns:**
  **f_statistic**
  : F-statistic for each feature.

  **p_values**
  : P-values associated with the F-statistic.

#### SEE ALSO
[`chi2`](sklearn.feature_selection.chi2.md#sklearn.feature_selection.chi2)
: Chi-squared stats of non-negative features for classification tasks.

[`f_regression`](sklearn.feature_selection.f_regression.md#sklearn.feature_selection.f_regression)
: F-value between label/feature for regression tasks.

### Examples

```pycon
>>> from sklearn.datasets import make_classification
>>> from sklearn.feature_selection import f_classif
>>> X, y = make_classification(
...     n_samples=100, n_features=10, n_informative=2, n_clusters_per_class=1,
...     shuffle=False, random_state=42
... )
>>> f_statistic, p_values = f_classif(X, y)
>>> f_statistic
array([2.2...e+02, 7.0...e-01, 1.6...e+00, 9.3...e-01,
       5.4...e+00, 3.2...e-01, 4.7...e-02, 5.7...e-01,
       7.5...e-01, 8.9...e-02])
>>> p_values
array([7.1...e-27, 4.0...e-01, 1.9...e-01, 3.3...e-01,
       2.2...e-02, 5.7...e-01, 8.2...e-01, 4.5...e-01,
       3.8...e-01, 7.6...e-01])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows how a feature selection can be easily integrated within a machine learning pipeline.">  <div class="sphx-glr-thumbnail-title">Pipeline ANOVA SVM</div>
</div>
* [Pipeline ANOVA SVM](../../auto_examples/feature_selection/plot_feature_selection_pipeline.md#sphx-glr-auto-examples-feature-selection-plot-feature-selection-pipeline-py)

<div class="sphx-glr-thumbcontainer" tooltip="This notebook is an example of using univariate feature selection to improve classification accuracy on a noisy dataset.">  <div class="sphx-glr-thumbnail-title">Univariate Feature Selection</div>
</div>
* [Univariate Feature Selection](../../auto_examples/feature_selection/plot_feature_selection.md#sphx-glr-auto-examples-feature-selection-plot-feature-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to perform univariate feature selection before running a SVC (support vector classifier) to improve the classification scores. We use the iris dataset (4 features) and add 36 non-informative features. We can find that our model achieves best performance when we select around 10% of features.">  <div class="sphx-glr-thumbnail-title">SVM-Anova: SVM with univariate feature selection</div>
</div>
* [SVM-Anova: SVM with univariate feature selection](../../auto_examples/svm/plot_svm_anova.md#sphx-glr-auto-examples-svm-plot-svm-anova-py)

<!-- thumbnail-parent-div-close --></div>
