# contingency_matrix

### sklearn.metrics.cluster.contingency_matrix(labels_true, labels_pred, \*, eps=None, sparse=False, dtype=<class 'numpy.int64'>)

Build a contingency matrix describing the relationship between labels.

* **Parameters:**
  **labels_true**
  : Ground truth class labels to be used as a reference.

  **labels_pred**
  : Cluster labels to evaluate.

  **eps**
  : If a float, that value is added to all values in the contingency
    matrix. This helps to stop NaN propagation.
    If `None`, nothing is adjusted.

  **sparse**
  : If `True`, return a sparse CSR continency matrix. If `eps` is not
    `None` and `sparse` is `True` will raise ValueError.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **dtype**
  : Output dtype. Ignored if `eps` is not `None`.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Returns:**
  **contingency**
  : Matrix $C$ such that $C_{i, j}$ is the number of samples in
    true class $i$ and in predicted class $j$. If
    `eps is None`, the dtype of this array will be integer unless set
    otherwise with the `dtype` argument. If `eps` is given, the dtype
    will be float.
    Will be a `sklearn.sparse.csr_matrix` if `sparse=True`.

### Examples

```pycon
>>> from sklearn.metrics.cluster import contingency_matrix
>>> labels_true = [0, 0, 1, 1, 2, 2]
>>> labels_pred = [1, 0, 2, 1, 0, 2]
>>> contingency_matrix(labels_true, labels_pred)
array([[1, 1, 0],
       [0, 1, 1],
       [1, 0, 1]])
```

<!-- !! processed by numpydoc !! -->
