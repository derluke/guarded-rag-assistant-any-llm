# MiniBatchSparsePCA

### *class* sklearn.decomposition.MiniBatchSparsePCA(n_components=None, \*, alpha=1, ridge_alpha=0.01, max_iter=1000, callback=None, batch_size=3, verbose=False, shuffle=True, n_jobs=None, method='lars', random_state=None, tol=0.001, max_no_improvement=10)

Mini-batch Sparse Principal Components Analysis.

Finds the set of sparse components that can optimally reconstruct
the data.  The amount of sparseness is controllable by the coefficient
of the L1 penalty, given by the parameter alpha.

For an example comparing sparse PCA to PCA, see
[Faces dataset decompositions](../../auto_examples/decomposition/plot_faces_decomposition.md#sphx-glr-auto-examples-decomposition-plot-faces-decomposition-py)

Read more in the [User Guide](../decomposition.md#sparsepca).

* **Parameters:**
  **n_components**
  : Number of sparse atoms to extract. If None, then `n_components`
    is set to `n_features`.

  **alpha**
  : Sparsity controlling parameter. Higher values lead to sparser
    components.

  **ridge_alpha**
  : Amount of ridge shrinkage to apply in order to improve
    conditioning when calling the transform method.

  **max_iter**
  : Maximum number of iterations over the complete dataset before
    stopping independently of any early stopping criterion heuristics.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **callback**
  : Callable that gets invoked every five iterations.

  **batch_size**
  : The number of features to take in each mini batch.

  **verbose**
  : Controls the verbosity; the higher, the more messages. Defaults to 0.

  **shuffle**
  : Whether to shuffle the data before splitting it in batches.

  **n_jobs**
  : Number of parallel jobs to run.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **method**
  : Method to be used for optimization.
    lars: uses the least angle regression method to solve the lasso problem
    (linear_model.lars_path)
    cd: uses the coordinate descent method to compute the
    Lasso solution (linear_model.Lasso). Lars will be faster if
    the estimated components are sparse.

  **random_state**
  : Used for random shuffling when `shuffle` is set to `True`,
    during online dictionary learning. Pass an int for reproducible results
    across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **tol**
  : Control early stopping based on the norm of the differences in the
    dictionary between 2 steps.
    <br/>
    To disable early stopping based on changes in the dictionary, set
    `tol` to 0.0.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **max_no_improvement**
  : Control early stopping based on the consecutive number of mini batches
    that does not yield an improvement on the smoothed cost function.
    <br/>
    To disable convergence detection based on cost function, set
    `max_no_improvement` to `None`.
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Attributes:**
  **components_**
  : Sparse components extracted from the data.

  **n_components_**
  : Estimated number of components.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **n_iter_**
  : Number of iterations run.

  **mean_**
  : Per-feature empirical mean, estimated from the training set.
    Equal to `X.mean(axis=0)`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`DictionaryLearning`](sklearn.decomposition.DictionaryLearning.md#sklearn.decomposition.DictionaryLearning)
: Find a dictionary that sparsely encodes data.

[`IncrementalPCA`](sklearn.decomposition.IncrementalPCA.md#sklearn.decomposition.IncrementalPCA)
: Incremental principal components analysis.

[`PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA)
: Principal component analysis.

[`SparsePCA`](sklearn.decomposition.SparsePCA.md#sklearn.decomposition.SparsePCA)
: Sparse Principal Components Analysis.

[`TruncatedSVD`](sklearn.decomposition.TruncatedSVD.md#sklearn.decomposition.TruncatedSVD)
: Dimensionality reduction using truncated SVD.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.datasets import make_friedman1
>>> from sklearn.decomposition import MiniBatchSparsePCA
>>> X, _ = make_friedman1(n_samples=200, n_features=30, random_state=0)
>>> transformer = MiniBatchSparsePCA(n_components=5, batch_size=50,
...                                  max_iter=10, random_state=0)
>>> transformer.fit(X)
MiniBatchSparsePCA(...)
>>> X_transformed = transformer.transform(X)
>>> X_transformed.shape
(200, 5)
>>> # most values in the components_ are zero (sparsity)
>>> np.mean(transformer.components_ == 0)
np.float64(0.9...)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the model from data in X.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present here for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Transform data from the latent space to the original space.

This inversion is an approximation due to the loss of information
induced by the forward decomposition.

#### Versionadded
Added in version 1.2.

* **Parameters:**
  **X**
  : Data in the latent space.
* **Returns:**
  **X_original**
  : Reconstructed data in the original space.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Least Squares projection of the data onto the sparse components.

To avoid instability issues in case the system is under-determined,
regularization can be applied (Ridge regression) via the
`ridge_alpha` parameter.

Note that Sparse PCA components orthogonality is not enforced as in PCA
hence one cannot use a simple linear projection.

* **Parameters:**
  **X**
  : Test data to be transformed, must have the same number of
    features as the data used to train the model.
* **Returns:**
  **X_new**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example applies to olivetti_faces_dataset different unsupervised matrix decomposition (dimension reduction) methods from the module sklearn.decomposition (see the documentation chapter decompositions).">  <div class="sphx-glr-thumbnail-title">Faces dataset decompositions</div>
</div>
* [Faces dataset decompositions](../../auto_examples/decomposition/plot_faces_decomposition.md#sphx-glr-auto-examples-decomposition-plot-faces-decomposition-py)

<!-- thumbnail-parent-div-close --></div>
