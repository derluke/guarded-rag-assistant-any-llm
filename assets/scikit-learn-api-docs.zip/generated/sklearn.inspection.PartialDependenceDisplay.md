# PartialDependenceDisplay

### *class* sklearn.inspection.PartialDependenceDisplay(pd_results, \*, features, feature_names, target_idx, deciles, kind='average', subsample=1000, random_state=None, is_categorical=None)

Partial Dependence Plot (PDP).

This can also display individual partial dependencies which are often
referred to as: Individual Condition Expectation (ICE).

It is recommended to use
[`from_estimator`](#sklearn.inspection.PartialDependenceDisplay.from_estimator) to create a
[`PartialDependenceDisplay`](#sklearn.inspection.PartialDependenceDisplay). All parameters are
stored as attributes.

Read more in
[Advanced Plotting With Partial Dependence](../../auto_examples/miscellaneous/plot_partial_dependence_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-partial-dependence-visualization-api-py)
and the [User Guide](../partial_dependence.md#partial-dependence).

#### Versionadded
Added in version 0.22.

* **Parameters:**
  **pd_results**
  : Results of [`partial_dependence`](sklearn.inspection.partial_dependence.md#sklearn.inspection.partial_dependence) for
    `features`.

  **features**
  : Indices of features for a given plot. A tuple of one integer will plot
    a partial dependence curve of one feature. A tuple of two integers will
    plot a two-way partial dependence curve as a contour plot.

  **feature_names**
  : Feature names corresponding to the indices in `features`.

  **target_idx**
  : - In a multiclass setting, specifies the class for which the PDPs
      should be computed. Note that for binary classification, the
      positive class (index 1) is always used.
    - In a multioutput setting, specifies the task for which the PDPs
      should be computed.
    <br/>
    Ignored in binary classification or classical regression settings.

  **deciles**
  : Deciles for feature indices in `features`.

  **kind**
  : Whether to plot the partial dependence averaged across all the samples
    in the dataset or one line per sample or both.
    - `kind='average'` results in the traditional PD plot;
    - `kind='individual'` results in the ICE plot;
    - `kind='both'` results in plotting both the ICE and PD on the same
      plot.
    <br/>
    A list of such strings can be provided to specify `kind` on a per-plot
    basis. The length of the list should be the same as the number of
    interaction requested in `features`.
    <br/>
    #### NOTE
    ICE (‘individual’ or ‘both’) is not a valid option for 2-ways
    interactions plot. As a result, an error will be raised.
    2-ways interaction plots should always be configured to
    use the ‘average’ kind instead.
    <br/>
    #### NOTE
    The fast `method='recursion'` option is only available for
    `kind='average'` and `sample_weights=None`. Computing individual
    dependencies and doing weighted averages requires using the slower
    `method='brute'`.
    <br/>
    #### Versionadded
    Added in version 0.24: Add `kind` parameter with `'average'`, `'individual'`, and `'both'`
    options.
    <br/>
    #### Versionadded
    Added in version 1.1: Add the possibility to pass a list of string specifying `kind`
    for each plot.

  **subsample**
  : Sampling for ICE curves when `kind` is ‘individual’ or ‘both’.
    If float, should be between 0.0 and 1.0 and represent the proportion
    of the dataset to be used to plot ICE curves. If int, represents the
    maximum absolute number of samples to use.
    <br/>
    Note that the full dataset is still used to calculate partial
    dependence when `kind='both'`.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **random_state**
  : Controls the randomness of the selected samples when subsamples is not
    `None`. See [Glossary](../../glossary.md#term-random_state) for details.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **is_categorical**
  : Whether each target feature in `features` is categorical or not.
    The list should be same size as `features`. If `None`, all features
    are assumed to be continuous.
    <br/>
    #### Versionadded
    Added in version 1.2.
* **Attributes:**
  **bounding_ax_**
  : If `ax` is an axes or None, the `bounding_ax_` is the axes where the
    grid of partial dependence plots are drawn. If `ax` is a list of axes
    or a numpy array of axes, `bounding_ax_` is None.

  **axes_**
  : If `ax` is an axes or None, `axes_[i, j]` is the axes on the i-th row
    and j-th column. If `ax` is a list of axes, `axes_[i]` is the i-th item
    in `ax`. Elements that are None correspond to a nonexisting axes in
    that position.

  **lines_**
  : If `ax` is an axes or None, `lines_[i, j]` is the partial dependence
    curve on the i-th row and j-th column. If `ax` is a list of axes,
    `lines_[i]` is the partial dependence curve corresponding to the i-th
    item in `ax`. Elements that are None correspond to a nonexisting axes
    or an axes that does not include a line plot.

  **deciles_vlines_**
  : If `ax` is an axes or None, `vlines_[i, j]` is the line collection
    representing the x axis deciles of the i-th row and j-th column. If
    `ax` is a list of axes, `vlines_[i]` corresponds to the i-th item in
    `ax`. Elements that are None correspond to a nonexisting axes or an
    axes that does not include a PDP plot.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **deciles_hlines_**
  : If `ax` is an axes or None, `vlines_[i, j]` is the line collection
    representing the y axis deciles of the i-th row and j-th column. If
    `ax` is a list of axes, `vlines_[i]` corresponds to the i-th item in
    `ax`. Elements that are None correspond to a nonexisting axes or an
    axes that does not include a 2-way plot.
    <br/>
    #### Versionadded
    Added in version 0.23.

  **contours_**
  : If `ax` is an axes or None, `contours_[i, j]` is the partial dependence
    plot on the i-th row and j-th column. If `ax` is a list of axes,
    `contours_[i]` is the partial dependence plot corresponding to the i-th
    item in `ax`. Elements that are None correspond to a nonexisting axes
    or an axes that does not include a contour plot.

  **bars_**
  : If `ax` is an axes or None, `bars_[i, j]` is the partial dependence bar
    plot on the i-th row and j-th column (for a categorical feature).
    If `ax` is a list of axes, `bars_[i]` is the partial dependence bar
    plot corresponding to the i-th item in `ax`. Elements that are None
    correspond to a nonexisting axes or an axes that does not include a
    bar plot.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **heatmaps_**
  : If `ax` is an axes or None, `heatmaps_[i, j]` is the partial dependence
    heatmap on the i-th row and j-th column (for a pair of categorical
    features) . If `ax` is a list of axes, `heatmaps_[i]` is the partial
    dependence heatmap corresponding to the i-th item in `ax`. Elements
    that are None correspond to a nonexisting axes or an axes that does not
    include a heatmap.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **figure_**
  : Figure containing partial dependence plots.

#### SEE ALSO
[`partial_dependence`](sklearn.inspection.partial_dependence.md#sklearn.inspection.partial_dependence)
: Compute Partial Dependence values.

[`PartialDependenceDisplay.from_estimator`](#sklearn.inspection.PartialDependenceDisplay.from_estimator)
: Plot Partial Dependence.

### Examples

```pycon
>>> import numpy as np
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_friedman1
>>> from sklearn.ensemble import GradientBoostingRegressor
>>> from sklearn.inspection import PartialDependenceDisplay
>>> from sklearn.inspection import partial_dependence
>>> X, y = make_friedman1()
>>> clf = GradientBoostingRegressor(n_estimators=10).fit(X, y)
>>> features, feature_names = [(0,)], [f"Features #{i}" for i in range(X.shape[1])]
>>> deciles = {0: np.linspace(0, 1, num=5)}
>>> pd_results = partial_dependence(
...     clf, X, features=0, kind="average", grid_resolution=5)
>>> display = PartialDependenceDisplay(
...     [pd_results], features=features, feature_names=feature_names,
...     target_idx=0, deciles=deciles
... )
>>> display.plot(pdp_lim={1: (-1.38, 0.66)})
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-inspection-PartialDependenceDisplay-1.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_estimator(estimator, X, features, \*, sample_weight=None, categorical_features=None, feature_names=None, target=None, response_method='auto', n_cols=3, grid_resolution=100, percentiles=(0.05, 0.95), method='auto', n_jobs=None, verbose=0, line_kw=None, ice_lines_kw=None, pd_line_kw=None, contour_kw=None, ax=None, kind='average', centered=False, subsample=1000, random_state=None)

Partial dependence (PD) and individual conditional expectation (ICE) plots.

Partial dependence plots, individual conditional expectation plots or an
overlay of both of them can be plotted by setting the `kind`
parameter. The `len(features)` plots are arranged in a grid with
`n_cols` columns. Two-way partial dependence plots are plotted as
contour plots. The deciles of the feature values will be shown with tick
marks on the x-axes for one-way plots, and on both axes for two-way
plots.

Read more in the [User Guide](../partial_dependence.md#partial-dependence).

#### NOTE
[`PartialDependenceDisplay.from_estimator`](#sklearn.inspection.PartialDependenceDisplay.from_estimator) does not support using the
same axes with multiple calls. To plot the partial dependence for
multiple estimators, please pass the axes created by the first call to the
second call:

```default
>>> from sklearn.inspection import PartialDependenceDisplay
>>> from sklearn.datasets import make_friedman1
>>> from sklearn.linear_model import LinearRegression
>>> from sklearn.ensemble import RandomForestRegressor
>>> X, y = make_friedman1()
>>> est1 = LinearRegression().fit(X, y)
>>> est2 = RandomForestRegressor().fit(X, y)
>>> disp1 = PartialDependenceDisplay.from_estimator(est1, X,
...                                                 [1, 2])
>>> disp2 = PartialDependenceDisplay.from_estimator(est2, X, [1, 2],
...                                                 ax=disp1.axes_)
```

#### WARNING
For [`GradientBoostingClassifier`](sklearn.ensemble.GradientBoostingClassifier.md#sklearn.ensemble.GradientBoostingClassifier) and
[`GradientBoostingRegressor`](sklearn.ensemble.GradientBoostingRegressor.md#sklearn.ensemble.GradientBoostingRegressor), the
`'recursion'` method (used by default) will not account for the `init`
predictor of the boosting process. In practice, this will produce
the same values as `'brute'` up to a constant offset in the target
response, provided that `init` is a constant estimator (which is the
default). However, if `init` is not a constant estimator, the
partial dependence values are incorrect for `'recursion'` because the
offset will be sample-dependent. It is preferable to use the `'brute'`
method. Note that this only applies to
[`GradientBoostingClassifier`](sklearn.ensemble.GradientBoostingClassifier.md#sklearn.ensemble.GradientBoostingClassifier) and
[`GradientBoostingRegressor`](sklearn.ensemble.GradientBoostingRegressor.md#sklearn.ensemble.GradientBoostingRegressor), not to
[`HistGradientBoostingClassifier`](sklearn.ensemble.HistGradientBoostingClassifier.md#sklearn.ensemble.HistGradientBoostingClassifier) and
[`HistGradientBoostingRegressor`](sklearn.ensemble.HistGradientBoostingRegressor.md#sklearn.ensemble.HistGradientBoostingRegressor).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **estimator**
  : A fitted estimator object implementing [predict](../../glossary.md#term-predict),
    [predict_proba](../../glossary.md#term-predict_proba), or [decision_function](../../glossary.md#term-decision_function).
    Multioutput-multiclass classifiers are not supported.

  **X**
  : `X` is used to generate a grid of values for the target
    `features` (where the partial dependence will be evaluated), and
    also to generate values for the complement features when the
    `method` is `'brute'`.

  **features**
  : The target features for which to create the PDPs.
    If `features[i]` is an integer or a string, a one-way PDP is created;
    if `features[i]` is a tuple, a two-way PDP is created (only supported
    with `kind='average'`). Each tuple must be of size 2.
    If any entry is a string, then it must be in `feature_names`.

  **sample_weight**
  : Sample weights are used to calculate weighted means when averaging the
    model output. If `None`, then samples are equally weighted. If
    `sample_weight` is not `None`, then `method` will be set to `'brute'`.
    Note that `sample_weight` is ignored for `kind='individual'`.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **categorical_features**
  : Indicates the categorical features.
    - `None`: no feature will be considered categorical;
    - boolean array-like: boolean mask of shape `(n_features,)`
      indicating which features are categorical. Thus, this array has
      the same shape has `X.shape[1]`;
    - integer or string array-like: integer indices or strings
      indicating categorical features.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **feature_names**
  : Name of each feature; `feature_names[i]` holds the name of the feature
    with index `i`.
    By default, the name of the feature corresponds to their numerical
    index for NumPy array and their column name for pandas dataframe.

  **target**
  : - In a multiclass setting, specifies the class for which the PDPs
      should be computed. Note that for binary classification, the
      positive class (index 1) is always used.
    - In a multioutput setting, specifies the task for which the PDPs
      should be computed.
    <br/>
    Ignored in binary classification or classical regression settings.

  **response_method**
  : Specifies whether to use [predict_proba](../../glossary.md#term-predict_proba) or
    [decision_function](../../glossary.md#term-decision_function) as the target response. For regressors
    this parameter is ignored and the response is always the output of
    [predict](../../glossary.md#term-predict). By default, [predict_proba](../../glossary.md#term-predict_proba) is tried first
    and we revert to [decision_function](../../glossary.md#term-decision_function) if it doesn’t exist. If
    `method` is `'recursion'`, the response is always the output of
    [decision_function](../../glossary.md#term-decision_function).

  **n_cols**
  : The maximum number of columns in the grid plot. Only active when `ax`
    is a single axis or `None`.

  **grid_resolution**
  : The number of equally spaced points on the axes of the plots, for each
    target feature.

  **percentiles**
  : The lower and upper percentile used to create the extreme values
    for the PDP axes. Must be in [0, 1].

  **method**
  : The method used to calculate the averaged predictions:
    - `'recursion'` is only supported for some tree-based estimators
      (namely
      [`GradientBoostingClassifier`](sklearn.ensemble.GradientBoostingClassifier.md#sklearn.ensemble.GradientBoostingClassifier),
      [`GradientBoostingRegressor`](sklearn.ensemble.GradientBoostingRegressor.md#sklearn.ensemble.GradientBoostingRegressor),
      [`HistGradientBoostingClassifier`](sklearn.ensemble.HistGradientBoostingClassifier.md#sklearn.ensemble.HistGradientBoostingClassifier),
      [`HistGradientBoostingRegressor`](sklearn.ensemble.HistGradientBoostingRegressor.md#sklearn.ensemble.HistGradientBoostingRegressor),
      [`DecisionTreeRegressor`](sklearn.tree.DecisionTreeRegressor.md#sklearn.tree.DecisionTreeRegressor),
      [`RandomForestRegressor`](sklearn.ensemble.RandomForestRegressor.md#sklearn.ensemble.RandomForestRegressor)
      but is more efficient in terms of speed.
      With this method, the target response of a
      classifier is always the decision function, not the predicted
      probabilities. Since the `'recursion'` method implicitly computes
      the average of the ICEs by design, it is not compatible with ICE and
      thus `kind` must be `'average'`.
    - `'brute'` is supported for any estimator, but is more
      computationally intensive.
    - `'auto'`: the `'recursion'` is used for estimators that support it,
      and `'brute'` is used otherwise. If `sample_weight` is not `None`,
      then `'brute'` is used regardless of the estimator.
    <br/>
    Please see [this note](../partial_dependence.md#pdp-method-differences) for
    differences between the `'brute'` and `'recursion'` method.

  **n_jobs**
  : The number of CPUs to use to compute the partial dependences.
    Computation is parallelized over features specified by the `features`
    parameter.
    <br/>
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **verbose**
  : Verbose output during PD computations.

  **line_kw**
  : Dict with keywords passed to the `matplotlib.pyplot.plot` call.
    For one-way partial dependence plots. It can be used to define common
    properties for both `ice_lines_kw` and `pdp_line_kw`.

  **ice_lines_kw**
  : Dictionary with keywords passed to the `matplotlib.pyplot.plot` call.
    For ICE lines in the one-way partial dependence plots.
    The key value pairs defined in `ice_lines_kw` takes priority over
    `line_kw`.

  **pd_line_kw**
  : Dictionary with keywords passed to the `matplotlib.pyplot.plot` call.
    For partial dependence in one-way partial dependence plots.
    The key value pairs defined in `pd_line_kw` takes priority over
    `line_kw`.

  **contour_kw**
  : Dict with keywords passed to the `matplotlib.pyplot.contourf` call.
    For two-way partial dependence plots.

  **ax**
  : - If a single axis is passed in, it is treated as a bounding axes
      and a grid of partial dependence plots will be drawn within
      these bounds. The `n_cols` parameter controls the number of
      columns in the grid.
    - If an array-like of axes are passed in, the partial dependence
      plots will be drawn directly into these axes.
    - If `None`, a figure and a bounding axes is created and treated
      as the single axes case.

  **kind**
  : Whether to plot the partial dependence averaged across all the samples
    in the dataset or one line per sample or both.
    - `kind='average'` results in the traditional PD plot;
    - `kind='individual'` results in the ICE plot.
    <br/>
    Note that the fast `method='recursion'` option is only available for
    `kind='average'` and `sample_weights=None`. Computing individual
    dependencies and doing weighted averages requires using the slower
    `method='brute'`.

  **centered**
  : If `True`, the ICE and PD lines will start at the origin of the
    y-axis. By default, no centering is done.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **subsample**
  : Sampling for ICE curves when `kind` is ‘individual’ or ‘both’.
    If `float`, should be between 0.0 and 1.0 and represent the proportion
    of the dataset to be used to plot ICE curves. If `int`, represents the
    absolute number samples to use.
    <br/>
    Note that the full dataset is still used to calculate averaged partial
    dependence when `kind='both'`.

  **random_state**
  : Controls the randomness of the selected samples when subsamples is not
    `None` and `kind` is either `'both'` or `'individual'`.
    See [Glossary](../../glossary.md#term-random_state) for details.
* **Returns:**
  **display**

#### SEE ALSO
[`partial_dependence`](sklearn.inspection.partial_dependence.md#sklearn.inspection.partial_dependence)
: Compute Partial Dependence values.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_friedman1
>>> from sklearn.ensemble import GradientBoostingRegressor
>>> from sklearn.inspection import PartialDependenceDisplay
>>> X, y = make_friedman1()
>>> clf = GradientBoostingRegressor(n_estimators=10).fit(X, y)
>>> PartialDependenceDisplay.from_estimator(clf, X, [0, (0, 1)])
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-inspection-PartialDependenceDisplay-2.*)
<!-- !! processed by numpydoc !! -->

#### plot(\*, ax=None, n_cols=3, line_kw=None, ice_lines_kw=None, pd_line_kw=None, contour_kw=None, bar_kw=None, heatmap_kw=None, pdp_lim=None, centered=False)

Plot partial dependence plots.

* **Parameters:**
  **ax**
  : - If a single axis is passed in, it is treated as a bounding axes
      : and a grid of partial dependence plots will be drawn within
        these bounds. The `n_cols` parameter controls the number of
        columns in the grid.
    - If an array-like of axes are passed in, the partial dependence
      : plots will be drawn directly into these axes.
    - If `None`, a figure and a bounding axes is created and treated
      : as the single axes case.

  **n_cols**
  : The maximum number of columns in the grid plot. Only active when
    `ax` is a single axes or `None`.

  **line_kw**
  : Dict with keywords passed to the `matplotlib.pyplot.plot` call.
    For one-way partial dependence plots.

  **ice_lines_kw**
  : Dictionary with keywords passed to the `matplotlib.pyplot.plot` call.
    For ICE lines in the one-way partial dependence plots.
    The key value pairs defined in `ice_lines_kw` takes priority over
    `line_kw`.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **pd_line_kw**
  : Dictionary with keywords passed to the `matplotlib.pyplot.plot` call.
    For partial dependence in one-way partial dependence plots.
    The key value pairs defined in `pd_line_kw` takes priority over
    `line_kw`.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **contour_kw**
  : Dict with keywords passed to the `matplotlib.pyplot.contourf`
    call for two-way partial dependence plots.

  **bar_kw**
  : Dict with keywords passed to the `matplotlib.pyplot.bar`
    call for one-way categorical partial dependence plots.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **heatmap_kw**
  : Dict with keywords passed to the `matplotlib.pyplot.imshow`
    call for two-way categorical partial dependence plots.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **pdp_lim**
  : Global min and max average predictions, such that all plots will have the
    same scale and y limits. `pdp_lim[1]` is the global min and max for single
    partial dependence curves. `pdp_lim[2]` is the global min and max for
    two-way partial dependence curves. If `None` (default), the limit will be
    inferred from the global minimum and maximum of all predictions.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **centered**
  : If `True`, the ICE and PD lines will start at the origin of the
    y-axis. By default, no centering is done.
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Returns:**
  **display**
  : Returns a [`PartialDependenceDisplay`](#sklearn.inspection.PartialDependenceDisplay)
    object that contains the partial dependence plots.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="    See also sphx_glr_auto_examples_miscellaneous_plot_roc_curve_visualization_api.py">  <div class="sphx-glr-thumbnail-title">Advanced Plotting With Partial Dependence</div>
</div>
* [Advanced Plotting With Partial Dependence](../../auto_examples/miscellaneous/plot_partial_dependence_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-partial-dependence-visualization-api-py)

<div class="sphx-glr-thumbcontainer" tooltip="histogram_based_gradient_boosting (HGBT) models may be one of the most useful supervised learning models in scikit-learn. They are based on a modern gradient boosting implementation comparable to LightGBM and XGBoost. As such, HGBT models are more feature rich than and often outperform alternative models like random forests, especially when the number of samples is larger than some ten thousands (see sphx_glr_auto_examples_ensemble_plot_forest_hist_grad_boosting_comparison.py).">  <div class="sphx-glr-thumbnail-title">Features in Histogram Gradient Boosting Trees</div>
</div>
* [Features in Histogram Gradient Boosting Trees](../../auto_examples/ensemble/plot_hgbt_regression.md#sphx-glr-auto-examples-ensemble-plot-hgbt-regression-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of monotonic constraints on a gradient boosting estimator.">  <div class="sphx-glr-thumbnail-title">Monotonic Constraints</div>
</div>
* [Monotonic Constraints](../../auto_examples/ensemble/plot_monotonic_constraints.md#sphx-glr-auto-examples-ensemble-plot-monotonic-constraints-py)

<div class="sphx-glr-thumbcontainer" tooltip="Partial dependence plots show the dependence between the target function [2]_ and a set of features of interest, marginalizing over the values of all other features (the complement features). Due to the limits of human perception, the size of the set of features of interest must be small (usually, one or two) thus they are usually chosen among the most important features.">  <div class="sphx-glr-thumbnail-title">Partial Dependence and Individual Conditional Expectation Plots</div>
</div>
* [Partial Dependence and Individual Conditional Expectation Plots](../../auto_examples/inspection/plot_partial_dependence.md#sphx-glr-auto-examples-inspection-plot-partial-dependence-py)

<div class="sphx-glr-thumbcontainer" tooltip="    See also sphx_glr_auto_examples_miscellaneous_plot_roc_curve_visualization_api.py">  <div class="sphx-glr-thumbnail-title">Advanced Plotting With Partial Dependence</div>
</div>
* [Advanced Plotting With Partial Dependence](../../auto_examples/miscellaneous/plot_partial_dependence_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-partial-dependence-visualization-api-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.2! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_2&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.2</div>
</div>
* [Release Highlights for scikit-learn 1.2](../../auto_examples/release_highlights/plot_release_highlights_1_2_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-2-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="    See also sphx_glr_auto_examples_miscellaneous_plot_roc_curve_visualization_api.py">  <div class="sphx-glr-thumbnail-title">Advanced Plotting With Partial Dependence</div>
</div>
* [Advanced Plotting With Partial Dependence](../../auto_examples/miscellaneous/plot_partial_dependence_visualization_api.md#sphx-glr-auto-examples-miscellaneous-plot-partial-dependence-visualization-api-py)

<!-- thumbnail-parent-div-close --></div>
