# KNeighborsTransformer

### *class* sklearn.neighbors.KNeighborsTransformer(\*, mode='distance', n_neighbors=5, algorithm='auto', leaf_size=30, metric='minkowski', p=2, metric_params=None, n_jobs=None)

Transform X into a (weighted) graph of k nearest neighbors.

The transformed data is a sparse graph as returned by kneighbors_graph.

Read more in the [User Guide](../neighbors.md#neighbors-transformer).

#### Versionadded
Added in version 0.22.

* **Parameters:**
  **mode**
  : Type of returned matrix: ‘connectivity’ will return the connectivity
    matrix with ones and zeros, and ‘distance’ will return the distances
    between neighbors according to the given metric.

  **n_neighbors**
  : Number of neighbors for each sample in the transformed sparse graph.
    For compatibility reasons, as each sample is considered as its own
    neighbor, one extra neighbor will be computed when mode == ‘distance’.
    In this case, the sparse graph contains (n_neighbors + 1) neighbors.

  **algorithm**
  : Algorithm used to compute the nearest neighbors:
    - ‘ball_tree’ will use [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree)
    - ‘kd_tree’ will use [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree)
    - ‘brute’ will use a brute-force search.
    - ‘auto’ will attempt to decide the most appropriate algorithm
      based on the values passed to [`fit`](#sklearn.neighbors.KNeighborsTransformer.fit) method.
    <br/>
    Note: fitting on sparse input will override the setting of
    this parameter, using brute force.

  **leaf_size**
  : Leaf size passed to BallTree or KDTree.  This can affect the
    speed of the construction and query, as well as the memory
    required to store the tree.  The optimal value depends on the
    nature of the problem.

  **metric**
  : Metric to use for distance computation. Default is “minkowski”, which
    results in the standard Euclidean distance when p = 2. See the
    documentation of [scipy.spatial.distance](https://docs.scipy.org/doc/scipy/reference/spatial.distance.html) and
    the metrics listed in
    [`distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics) for valid metric
    values.
    <br/>
    If metric is a callable function, it takes two arrays representing 1D
    vectors as inputs and must return one value indicating the distance
    between those vectors. This works for Scipy’s metrics, but is less
    efficient than passing the metric name as a string.
    <br/>
    Distance matrices are not supported.

  **p**
  : Parameter for the Minkowski metric from
    sklearn.metrics.pairwise.pairwise_distances. When p = 1, this is
    equivalent to using manhattan_distance (l1), and euclidean_distance
    (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.
    This parameter is expected to be positive.

  **metric_params**
  : Additional keyword arguments for the metric function.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    If `-1`, then the number of jobs is set to the number of CPU cores.
* **Attributes:**
  **effective_metric_**
  : The distance metric used. It will be same as the `metric` parameter
    or a synonym of it, e.g. ‘euclidean’ if the `metric` parameter set to
    ‘minkowski’ and `p` parameter set to 2.

  **effective_metric_params_**
  : Additional keyword arguments for the metric function. For most metrics
    will be same with `metric_params` parameter, but may also contain the
    `p` parameter value if the `effective_metric_` attribute is set to
    ‘minkowski’.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_samples_fit_**
  : Number of samples in the fitted data.

#### SEE ALSO
[`kneighbors_graph`](sklearn.neighbors.kneighbors_graph.md#sklearn.neighbors.kneighbors_graph)
: Compute the weighted graph of k-neighbors for points in X.

[`RadiusNeighborsTransformer`](sklearn.neighbors.RadiusNeighborsTransformer.md#sklearn.neighbors.RadiusNeighborsTransformer)
: Transform X into a weighted graph of neighbors nearer than a radius.

### Notes

For an example of using [`KNeighborsTransformer`](#sklearn.neighbors.KNeighborsTransformer)
in combination with [`TSNE`](sklearn.manifold.TSNE.md#sklearn.manifold.TSNE) see
[Approximate nearest neighbors in TSNE](../../auto_examples/neighbors/approximate_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-approximate-nearest-neighbors-py).

### Examples

```pycon
>>> from sklearn.datasets import load_wine
>>> from sklearn.neighbors import KNeighborsTransformer
>>> X, _ = load_wine(return_X_y=True)
>>> X.shape
(178, 13)
>>> transformer = KNeighborsTransformer(n_neighbors=5, mode='distance')
>>> X_dist_graph = transformer.fit_transform(X)
>>> X_dist_graph.shape
(178, 178)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the k-nearest neighbors transformer from the training dataset.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : The fitted k-nearest neighbors transformer.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Fit to data, then transform it.

Fits transformer to X and y with optional parameters fit_params
and returns a transformed version of X.

* **Parameters:**
  **X**
  : Training set.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **Xt**
  : Xt[i, j] is assigned the weight of edge that connects i to j.
    Only the neighbors have an explicit value.
    The diagonal is always explicit.
    The matrix is of CSR format.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### kneighbors(X=None, n_neighbors=None, return_distance=True)

Find the K-neighbors of a point.

Returns indices of and distances to the neighbors of each point.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.

  **n_neighbors**
  : Number of neighbors required for each sample. The default is the
    value passed to the constructor.

  **return_distance**
  : Whether or not to return the distances.
* **Returns:**
  **neigh_dist**
  : Array representing the lengths to points, only present if
    return_distance=True.

  **neigh_ind**
  : Indices of the nearest points in the population matrix.

### Examples

In the following example, we construct a NearestNeighbors
class from an array representing our data set and ask who’s
the closest point to [1,1,1]

```pycon
>>> samples = [[0., 0., 0.], [0., .5, 0.], [1., 1., .5]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(n_neighbors=1)
>>> neigh.fit(samples)
NearestNeighbors(n_neighbors=1)
>>> print(neigh.kneighbors([[1., 1., 1.]]))
(array([[0.5]]), array([[2]]))
```

As you can see, it returns [[0.5]], and [[2]], which means that the
element is at distance 0.5 and is the third element of samples
(indexes start at 0). You can also query for multiple points:

```pycon
>>> X = [[0., 1., 0.], [1., 0., 1.]]
>>> neigh.kneighbors(X, return_distance=False)
array([[1],
       [2]]...)
```

<!-- !! processed by numpydoc !! -->

#### kneighbors_graph(X=None, n_neighbors=None, mode='connectivity')

Compute the (weighted) graph of k-Neighbors for points in X.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.
    For `metric='precomputed'` the shape should be
    (n_queries, n_indexed). Otherwise the shape should be
    (n_queries, n_features).

  **n_neighbors**
  : Number of neighbors for each sample. The default is the value
    passed to the constructor.

  **mode**
  : Type of returned matrix: ‘connectivity’ will return the
    connectivity matrix with ones and zeros, in ‘distance’ the
    edges are distances between points, type of distance
    depends on the selected metric parameter in
    NearestNeighbors class.
* **Returns:**
  **A**
  : `n_samples_fit` is the number of samples in the fitted data.
    `A[i, j]` gives the weight of the edge connecting `i` to `j`.
    The matrix is of CSR format.

#### SEE ALSO
[`NearestNeighbors.radius_neighbors_graph`](sklearn.neighbors.NearestNeighbors.md#sklearn.neighbors.NearestNeighbors.radius_neighbors_graph)
: Compute the (weighted) graph of Neighbors for points in X.

### Examples

```pycon
>>> X = [[0], [3], [1]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(n_neighbors=2)
>>> neigh.fit(X)
NearestNeighbors(n_neighbors=2)
>>> A = neigh.kneighbors_graph(X)
>>> A.toarray()
array([[1., 0., 1.],
       [0., 1., 1.],
       [1., 0., 1.]])
```

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Compute the (weighted) graph of Neighbors for points in X.

* **Parameters:**
  **X**
  : Sample data.
* **Returns:**
  **Xt**
  : Xt[i, j] is assigned the weight of edge that connects i to j.
    Only the neighbors have an explicit value.
    The diagonal is always explicit.
    The matrix is of CSR format.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example presents how to chain KNeighborsTransformer and TSNE in a pipeline. It also shows how to wrap the packages nmslib and pynndescent to replace KNeighborsTransformer and perform approximate nearest neighbors. These packages can be installed with pip install nmslib pynndescent.">  <div class="sphx-glr-thumbnail-title">Approximate nearest neighbors in TSNE</div>
</div>
* [Approximate nearest neighbors in TSNE](../../auto_examples/neighbors/approximate_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-approximate-nearest-neighbors-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how to precompute the k nearest neighbors before using them in KNeighborsClassifier. KNeighborsClassifier can compute the nearest neighbors internally, but precomputing them can have several benefits, such as finer parameter control, caching for multiple use, or custom implementations.">  <div class="sphx-glr-thumbnail-title">Caching nearest neighbors</div>
</div>
* [Caching nearest neighbors](../../auto_examples/neighbors/plot_caching_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-plot-caching-nearest-neighbors-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
