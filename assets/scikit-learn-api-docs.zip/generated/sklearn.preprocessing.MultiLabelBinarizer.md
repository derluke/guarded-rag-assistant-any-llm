# MultiLabelBinarizer

### *class* sklearn.preprocessing.MultiLabelBinarizer(\*, classes=None, sparse_output=False)

Transform between iterable of iterables and a multilabel format.

Although a list of sets or tuples is a very intuitive format for multilabel
data, it is unwieldy to process. This transformer converts between this
intuitive format and the supported multilabel format: a (samples x classes)
binary matrix indicating the presence of a class label.

* **Parameters:**
  **classes**
  : Indicates an ordering for the class labels.
    All entries should be unique (cannot contain duplicate classes).

  **sparse_output**
  : Set to True if output binary array is desired in CSR sparse format.
* **Attributes:**
  **classes_**
  : A copy of the `classes` parameter when provided.
    Otherwise it corresponds to the sorted set of classes found
    when fitting.

#### SEE ALSO
[`OneHotEncoder`](sklearn.preprocessing.OneHotEncoder.md#sklearn.preprocessing.OneHotEncoder)
: Encode categorical features using a one-hot aka one-of-K scheme.

### Examples

```pycon
>>> from sklearn.preprocessing import MultiLabelBinarizer
>>> mlb = MultiLabelBinarizer()
>>> mlb.fit_transform([(1, 2), (3,)])
array([[1, 1, 0],
       [0, 0, 1]])
>>> mlb.classes_
array([1, 2, 3])
```

```pycon
>>> mlb.fit_transform([{'sci-fi', 'thriller'}, {'comedy'}])
array([[0, 1, 1],
       [1, 0, 0]])
>>> list(mlb.classes_)
['comedy', 'sci-fi', 'thriller']
```

A common mistake is to pass in a list, which leads to the following issue:

```pycon
>>> mlb = MultiLabelBinarizer()
>>> mlb.fit(['sci-fi', 'thriller', 'comedy'])
MultiLabelBinarizer()
>>> mlb.classes_
array(['-', 'c', 'd', 'e', 'f', 'h', 'i', 'l', 'm', 'o', 'r', 's', 't',
    'y'], dtype=object)
```

To correct this, the list of labels should be passed in as:

```pycon
>>> mlb = MultiLabelBinarizer()
>>> mlb.fit([['sci-fi', 'thriller', 'comedy']])
MultiLabelBinarizer()
>>> mlb.classes_
array(['comedy', 'sci-fi', 'thriller'], dtype=object)
```

<!-- !! processed by numpydoc !! -->

#### fit(y)

Fit the label sets binarizer, storing [classes_](../../glossary.md#term-classes_).

* **Parameters:**
  **y**
  : A set of labels (any orderable and hashable object) for each
    sample. If the `classes` parameter is set, `y` will not be
    iterated.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(y)

Fit the label sets binarizer and transform the given label sets.

* **Parameters:**
  **y**
  : A set of labels (any orderable and hashable object) for each
    sample. If the `classes` parameter is set, `y` will not be
    iterated.
* **Returns:**
  **y_indicator**
  : A matrix such that `y_indicator[i, j] = 1` iff `classes_[j]`
    is in `y[i]`, and 0 otherwise. Sparse matrix will be of CSR
    format.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(yt)

Transform the given indicator matrix into label sets.

* **Parameters:**
  **yt**
  : A matrix containing only 1s ands 0s.
* **Returns:**
  **y**
  : The set of labels for each sample such that `y[i]` consists of
    `classes_[j]` for each `yt[i, j] == 1`.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(y)

Transform the given label sets.

* **Parameters:**
  **y**
  : A set of labels (any orderable and hashable object) for each
    sample. If the `classes` parameter is set, `y` will not be
    iterated.
* **Returns:**
  **y_indicator**
  : A matrix such that `y_indicator[i, j] = 1` iff `classes_[j]` is in
    `y[i]`, and 0 otherwise.

<!-- !! processed by numpydoc !! -->
