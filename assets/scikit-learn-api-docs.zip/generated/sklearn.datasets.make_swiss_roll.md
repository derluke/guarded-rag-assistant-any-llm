# make_swiss_roll

### sklearn.datasets.make_swiss_roll(n_samples=100, \*, noise=0.0, random_state=None, hole=False)

Generate a swiss roll dataset.

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **n_samples**
  : The number of sample points on the Swiss Roll.

  **noise**
  : The standard deviation of the gaussian noise.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **hole**
  : If True generates the swiss roll with hole dataset.
* **Returns:**
  **X**
  : The points.

  **t**
  : The univariate position of the sample according to the main dimension
    of the points in the manifold.

### Notes

The algorithm is from Marsland [1].

### References

### Examples

```pycon
>>> from sklearn.datasets import make_swiss_roll
>>> X, t = make_swiss_roll(noise=0.05, random_state=0)
>>> X.shape
(100, 3)
>>> t.shape
(100,)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Example builds a swiss roll dataset and runs hierarchical clustering on their position.">  <div class="sphx-glr-thumbnail-title">Hierarchical clustering: structured vs unstructured ward</div>
</div>
* [Hierarchical clustering: structured vs unstructured ward](../../auto_examples/cluster/plot_ward_structured_vs_unstructured.md#sphx-glr-auto-examples-cluster-plot-ward-structured-vs-unstructured-py)

<div class="sphx-glr-thumbcontainer" tooltip="Swiss Roll And Swiss-Hole Reduction">  <div class="sphx-glr-thumbnail-title">Swiss Roll And Swiss-Hole Reduction</div>
</div>
* [Swiss Roll And Swiss-Hole Reduction](../../auto_examples/manifold/plot_swissroll.md#sphx-glr-auto-examples-manifold-plot-swissroll-py)

<!-- thumbnail-parent-div-close --></div>
