# davies_bouldin_score

### sklearn.metrics.davies_bouldin_score(X, labels)

Compute the Davies-Bouldin score.

The score is defined as the average similarity measure of each cluster with
its most similar cluster, where similarity is the ratio of within-cluster
distances to between-cluster distances. Thus, clusters which are farther
apart and less dispersed will result in a better score.

The minimum score is zero, with lower values indicating better clustering.

Read more in the [User Guide](../clustering.md#davies-bouldin-index).

#### Versionadded
Added in version 0.20.

* **Parameters:**
  **X**
  : A list of `n_features`-dimensional data points. Each row corresponds
    to a single data point.

  **labels**
  : Predicted labels for each sample.
* **Returns:**
  score: float
  : The resulting Davies-Bouldin score.

### References

### Examples

```pycon
>>> from sklearn.metrics import davies_bouldin_score
>>> X = [[0, 1], [1, 1], [3, 4]]
>>> labels = [0, 0, 1]
>>> davies_bouldin_score(X, labels)
np.float64(0.12...)
```

<!-- !! processed by numpydoc !! -->
