# NMF

### *class* sklearn.decomposition.NMF(n_components='auto', \*, init=None, solver='cd', beta_loss='frobenius', tol=0.0001, max_iter=200, random_state=None, alpha_W=0.0, alpha_H='same', l1_ratio=0.0, verbose=0, shuffle=False)

Non-Negative Matrix Factorization (NMF).

Find two non-negative matrices, i.e. matrices with all non-negative elements, (W, H)
whose product approximates the non-negative matrix X. This factorization can be used
for example for dimensionality reduction, source separation or topic extraction.

The objective function is:

$$
L(W, H) &= 0.5 * ||X - WH||_{loss}^2

        &+ alpha\_W * l1\_ratio * n\_features * ||vec(W)||_1

        &+ alpha\_H * l1\_ratio * n\_samples * ||vec(H)||_1

        &+ 0.5 * alpha\_W * (1 - l1\_ratio) * n\_features * ||W||_{Fro}^2

        &+ 0.5 * alpha\_H * (1 - l1\_ratio) * n\_samples * ||H||_{Fro}^2,
$$

where $||A||_{Fro}^2 = \sum_{i,j} A_{ij}^2$ (Frobenius norm) and
$||vec(A)||_1 = \sum_{i,j} abs(A_{ij})$ (Elementwise L1 norm).

The generic norm $||X - WH||_{loss}$ may represent
the Frobenius norm or another supported beta-divergence loss.
The choice between options is controlled by the `beta_loss` parameter.

The regularization terms are scaled by `n_features` for `W` and by `n_samples` for
`H` to keep their impact balanced with respect to one another and to the data fit
term as independent as possible of the size `n_samples` of the training set.

The objective function is minimized with an alternating minimization of W
and H.

Note that the transformed data is named W and the components matrix is named H. In
the NMF literature, the naming convention is usually the opposite since the data
matrix X is transposed.

Read more in the [User Guide](../decomposition.md#nmf).

* **Parameters:**
  **n_components**
  : Number of components. If `None`, all features are kept.
    If `n_components='auto'`, the number of components is automatically inferred
    from W or H shapes.
    <br/>
    #### Versionchanged
    Changed in version 1.4: Added `'auto'` value.
    <br/>
    #### Versionchanged
    Changed in version 1.6: Default value changed from `None` to `'auto'`.

  **init**
  : Method used to initialize the procedure.
    Valid options:
    - `None`: ‘nndsvda’ if n_components <= min(n_samples, n_features),
      otherwise random.
    - `'random'`: non-negative random matrices, scaled with:
      `sqrt(X.mean() / n_components)`
    - `'nndsvd'`: Nonnegative Double Singular Value Decomposition (NNDSVD)
      initialization (better for sparseness)
    - `'nndsvda'`: NNDSVD with zeros filled with the average of X
      (better when sparsity is not desired)
    - `'nndsvdar'` NNDSVD with zeros filled with small random values
      (generally faster, less accurate alternative to NNDSVDa
      for when sparsity is not desired)
    - `'custom'`: Use custom matrices `W` and `H` which must both be provided.
    <br/>
    #### Versionchanged
    Changed in version 1.1: When `init=None` and n_components is less than n_samples and n_features
    defaults to `nndsvda` instead of `nndsvd`.

  **solver**
  : Numerical solver to use:
    - ‘cd’ is a Coordinate Descent solver.
    - ‘mu’ is a Multiplicative Update solver.
    <br/>
    #### Versionadded
    Added in version 0.17: Coordinate Descent solver.
    <br/>
    #### Versionadded
    Added in version 0.19: Multiplicative Update solver.

  **beta_loss**
  : Beta divergence to be minimized, measuring the distance between X
    and the dot product WH. Note that values different from ‘frobenius’
    (or 2) and ‘kullback-leibler’ (or 1) lead to significantly slower
    fits. Note that for beta_loss <= 0 (or ‘itakura-saito’), the input
    matrix X cannot contain zeros. Used only in ‘mu’ solver.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **tol**
  : Tolerance of the stopping condition.

  **max_iter**
  : Maximum number of iterations before timing out.

  **random_state**
  : Used for initialisation (when `init` == ‘nndsvdar’ or
    ‘random’), and in Coordinate Descent. Pass an int for reproducible
    results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **alpha_W**
  : Constant that multiplies the regularization terms of `W`. Set it to zero
    (default) to have no regularization on `W`.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **alpha_H**
  : Constant that multiplies the regularization terms of `H`. Set it to zero to
    have no regularization on `H`. If “same” (default), it takes the same value as
    `alpha_W`.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **l1_ratio**
  : The regularization mixing parameter, with 0 <= l1_ratio <= 1.
    For l1_ratio = 0 the penalty is an elementwise L2 penalty
    (aka Frobenius Norm).
    For l1_ratio = 1 it is an elementwise L1 penalty.
    For 0 < l1_ratio < 1, the penalty is a combination of L1 and L2.
    <br/>
    #### Versionadded
    Added in version 0.17: Regularization parameter *l1_ratio* used in the Coordinate Descent
    solver.

  **verbose**
  : Whether to be verbose.

  **shuffle**
  : If true, randomize the order of coordinates in the CD solver.
    <br/>
    #### Versionadded
    Added in version 0.17: *shuffle* parameter used in the Coordinate Descent solver.
* **Attributes:**
  **components_**
  : Factorization matrix, sometimes called ‘dictionary’.

  **n_components_**
  : The number of components. It is same as the `n_components` parameter
    if it was given. Otherwise, it will be same as the number of
    features.

  **reconstruction_err_**
  : Frobenius norm of the matrix difference, or beta-divergence, between
    the training data `X` and the reconstructed data `WH` from
    the fitted model.

  **n_iter_**
  : Actual number of iterations.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`DictionaryLearning`](sklearn.decomposition.DictionaryLearning.md#sklearn.decomposition.DictionaryLearning)
: Find a dictionary that sparsely encodes data.

[`MiniBatchSparsePCA`](sklearn.decomposition.MiniBatchSparsePCA.md#sklearn.decomposition.MiniBatchSparsePCA)
: Mini-batch Sparse Principal Components Analysis.

[`PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA)
: Principal component analysis.

[`SparseCoder`](sklearn.decomposition.SparseCoder.md#sklearn.decomposition.SparseCoder)
: Find a sparse representation of data from a fixed, precomputed dictionary.

[`SparsePCA`](sklearn.decomposition.SparsePCA.md#sklearn.decomposition.SparsePCA)
: Sparse Principal Components Analysis.

[`TruncatedSVD`](sklearn.decomposition.TruncatedSVD.md#sklearn.decomposition.TruncatedSVD)
: Dimensionality reduction using truncated SVD.

### References

### Examples

```pycon
>>> import numpy as np
>>> X = np.array([[1, 1], [2, 1], [3, 1.2], [4, 1], [5, 0.8], [6, 1]])
>>> from sklearn.decomposition import NMF
>>> model = NMF(n_components=2, init='random', random_state=0)
>>> W = model.fit_transform(X)
>>> H = model.components_
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, \*\*params)

Learn a NMF model for the data X.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.

  **\*\*params**
  : Parameters (keyword arguments) and values passed to
    the fit_transform instance.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, W=None, H=None)

Learn a NMF model for the data X and returns the transformed data.

This is more efficient than calling fit followed by transform.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.

  **W**
  : If `init='custom'`, it is used as initial guess for the solution.
    If `None`, uses the initialisation method specified in `init`.

  **H**
  : If `init='custom'`, it is used as initial guess for the solution.
    If `None`, uses the initialisation method specified in `init`.
* **Returns:**
  **W**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X=None, \*, Xt=None)

Transform data back to its original space.

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **X**
  : Transformed data matrix.

  **Xt**
  : Transformed data matrix.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Xt` was deprecated in 1.5 and will be removed in 1.7. Use `X` instead.
* **Returns:**
  **X**
  : Returns a data matrix of the original shape.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform the data X according to the fitted NMF model.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples
    and `n_features` is the number of features.
* **Returns:**
  **W**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This is an example of applying NMF and LatentDirichletAllocation on a corpus of documents and extract additive models of the topic structure of the corpus.  The output is a plot of topics, each represented as bar plot using top few words based on weights.">  <div class="sphx-glr-thumbnail-title">Topic extraction with Non-negative Matrix Factorization and Latent Dirichlet Allocation</div>
</div>
* [Topic extraction with Non-negative Matrix Factorization and Latent Dirichlet Allocation](../../auto_examples/applications/plot_topics_extraction_with_nmf_lda.md#sphx-glr-auto-examples-applications-plot-topics-extraction-with-nmf-lda-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example constructs a pipeline that does dimensionality reduction followed by prediction with a support vector classifier. It demonstrates the use of GridSearchCV and Pipeline to optimize over different classes of estimators in a single CV run -- unsupervised PCA and NMF dimensionality reductions are compared to univariate feature selection during the grid search.">  <div class="sphx-glr-thumbnail-title">Selecting dimensionality reduction with Pipeline and GridSearchCV</div>
</div>
* [Selecting dimensionality reduction with Pipeline and GridSearchCV](../../auto_examples/compose/plot_compare_reduction.md#sphx-glr-auto-examples-compose-plot-compare-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example applies to olivetti_faces_dataset different unsupervised matrix decomposition (dimension reduction) methods from the module sklearn.decomposition (see the documentation chapter decompositions).">  <div class="sphx-glr-thumbnail-title">Faces dataset decompositions</div>
</div>
* [Faces dataset decompositions](../../auto_examples/decomposition/plot_faces_decomposition.md#sphx-glr-auto-examples-decomposition-plot-faces-decomposition-py)

<!-- thumbnail-parent-div-close --></div>
