# check_estimator

### sklearn.utils.estimator_checks.check_estimator(estimator=None, generate_only=False, \*, legacy: [bool](https://docs.python.org/3/library/functions.html#bool) = True, expected_failed_checks: [dict](https://docs.python.org/3/library/stdtypes.html#dict)[[str](https://docs.python.org/3/library/stdtypes.html#str), [str](https://docs.python.org/3/library/stdtypes.html#str)] | [None](https://docs.python.org/3/library/constants.html#None) = None, on_skip: Literal['warn'] | [None](https://docs.python.org/3/library/constants.html#None) = 'warn', on_fail: Literal['raise', 'warn'] | [None](https://docs.python.org/3/library/constants.html#None) = 'raise', callback: Callable | [None](https://docs.python.org/3/library/constants.html#None) = None)

Check if estimator adheres to scikit-learn conventions.

This function will run an extensive test-suite for input validation,
shapes, etc, making sure that the estimator complies with `scikit-learn`
conventions as detailed in [Rolling your own estimator](../../developers/develop.md#rolling-your-own-estimator).
Additional tests for classifiers, regressors, clustering or transformers
will be run if the Estimator class inherits from the corresponding mixin
from sklearn.base.

scikit-learn also provides a pytest specific decorator,
[`parametrize_with_checks`](sklearn.utils.estimator_checks.parametrize_with_checks.md#sklearn.utils.estimator_checks.parametrize_with_checks), making it
easier to test multiple estimators.

Checks are categorised into the following groups:

- API checks: a set of checks to ensure API compatibility with scikit-learn.
  Refer to [https://scikit-learn.org/dev/developers/develop.html](https://scikit-learn.org/dev/developers/develop.html) a requirement of
  scikit-learn estimators.
- legacy: a set of checks which gradually will be grouped into other categories.

* **Parameters:**
  **estimator**
  : Estimator instance to check.

  **generate_only**
  : When `False`, checks are evaluated when `check_estimator` is called.
    When `True`, `check_estimator` returns a generator that yields
    (estimator, check) tuples. The check is run by calling
    `check(estimator)`.
    <br/>
    #### Versionadded
    Added in version 0.22.
    <br/>
    #### Deprecated
    Deprecated since version 1.6: `generate_only` will be removed in 1.8. Use
    [`estimator_checks_generator`](sklearn.utils.estimator_checks.estimator_checks_generator.md#sklearn.utils.estimator_checks.estimator_checks_generator) instead.

  **legacy**
  : Whether to include legacy checks. Over time we remove checks from this category
    and move them into their specific category.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **expected_failed_checks**
  : A dictionary of the form:
    ```default
    {
        "check_name": "this check is expected to fail because ...",
    }
    ```
    <br/>
    Where `"check_name"` is the name of the check, and `"my reason"` is why
    the check fails.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **on_skip**
  : This parameter controls what happens when a check is skipped.
    - “warn”: A `SkipTestWarning` is logged
      and running tests continue.
    - None: No warning is logged and running tests continue.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **on_fail**
  : This parameter controls what happens when a check fails.
    - “raise”: The exception raised by the first failing check is raised and
      running tests are aborted. This does not included tests that are expected
      to fail.
    - “warn”: A [`EstimatorCheckFailedWarning`](sklearn.exceptions.EstimatorCheckFailedWarning.md#sklearn.exceptions.EstimatorCheckFailedWarning) is logged
      and running tests continue.
    - None: No exception is raised and no warning is logged.
    <br/>
    Note that if `on_fail != "raise"`, no exception is raised, even if the checks
    fail. You’d need to inspect the return result of `check_estimator` to check
    if any checks failed.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **callback**
  : This callback will be called with the estimator and the check name,
    the exception (if any), the status of the check (xfail, failed, skipped,
    passed), and the reason for the expected failure if the check is
    expected to fail. The callable’s signature needs to be:
    ```default
    def callback(
        estimator,
        check_name: str,
        exception: Exception,
        status: Literal["xfail", "failed", "skipped", "passed"],
        expected_to_fail: bool,
        expected_to_fail_reason: str,
    )
    ```
    <br/>
    `callback` cannot be provided together with `on_fail="raise"`.
    <br/>
    #### Versionadded
    Added in version 1.6.
* **Returns:**
  **test_results**
  : List of dictionaries with the results of the failing tests, of the form:
    ```default
    {
        "estimator": estimator,
        "check_name": check_name,
        "exception": exception,
        "status": status (one of "xfail", "failed", "skipped", "passed"),
        "expected_to_fail": expected_to_fail,
        "expected_to_fail_reason": expected_to_fail_reason,
    }
    ```

  **estimator_checks_generator**
  : Generator that yields (estimator, check) tuples. Returned when
    `generate_only=True`.
    <!-- TODO(1.8): remove return value -->
    <br/>
    #### Deprecated
    Deprecated since version 1.6: `generate_only` will be removed in 1.8. Use
    [`estimator_checks_generator`](sklearn.utils.estimator_checks.estimator_checks_generator.md#sklearn.utils.estimator_checks.estimator_checks_generator) instead.
* **Raises:**
  Exception
  : If `on_fail="raise"`, the exception raised by the first failing check is
    raised and running tests are aborted.
    <br/>
    Note that if `on_fail != "raise"`, no exception is raised, even if the checks
    fail. You’d need to inspect the return result of `check_estimator` to check
    if any checks failed.

#### SEE ALSO
[`parametrize_with_checks`](sklearn.utils.estimator_checks.parametrize_with_checks.md#sklearn.utils.estimator_checks.parametrize_with_checks)
: Pytest specific decorator for parametrizing estimator checks.

[`estimator_checks_generator`](sklearn.utils.estimator_checks.estimator_checks_generator.md#sklearn.utils.estimator_checks.estimator_checks_generator)
: Generator that yields (estimator, check) tuples.

### Examples

```pycon
>>> from sklearn.utils.estimator_checks import check_estimator
>>> from sklearn.linear_model import LogisticRegression
>>> check_estimator(LogisticRegression())
[...]
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.6! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_6&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.6</div>
</div>
* [Release Highlights for scikit-learn 1.6](../../auto_examples/release_highlights/plot_release_highlights_1_6_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-6-0-py)

<!-- thumbnail-parent-div-close --></div>
