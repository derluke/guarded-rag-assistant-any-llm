# SGDClassifier

### *class* sklearn.linear_model.SGDClassifier(loss='hinge', \*, penalty='l2', alpha=0.0001, l1_ratio=0.15, fit_intercept=True, max_iter=1000, tol=0.001, shuffle=True, verbose=0, epsilon=0.1, n_jobs=None, random_state=None, learning_rate='optimal', eta0=0.0, power_t=0.5, early_stopping=False, validation_fraction=0.1, n_iter_no_change=5, class_weight=None, warm_start=False, average=False)

Linear classifiers (SVM, logistic regression, etc.) with SGD training.

This estimator implements regularized linear models with stochastic
gradient descent (SGD) learning: the gradient of the loss is estimated
each sample at a time and the model is updated along the way with a
decreasing strength schedule (aka learning rate). SGD allows minibatch
(online/out-of-core) learning via the `partial_fit` method.
For best results using the default learning rate schedule, the data should
have zero mean and unit variance.

This implementation works with data represented as dense or sparse arrays
of floating point values for the features. The model it fits can be
controlled with the loss parameter; by default, it fits a linear support
vector machine (SVM).

The regularizer is a penalty added to the loss function that shrinks model
parameters towards the zero vector using either the squared euclidean norm
L2 or the absolute norm L1 or a combination of both (Elastic Net). If the
parameter update crosses the 0.0 value because of the regularizer, the
update is truncated to 0.0 to allow for learning sparse models and achieve
online feature selection.

Read more in the [User Guide](../sgd.md#sgd).

* **Parameters:**
  **loss**
  : The loss function to be used.
    - ‘hinge’ gives a linear SVM.
    - ‘log_loss’ gives logistic regression, a probabilistic classifier.
    - ‘modified_huber’ is another smooth loss that brings tolerance to
      outliers as well as probability estimates.
    - ‘squared_hinge’ is like hinge but is quadratically penalized.
    - ‘perceptron’ is the linear loss used by the perceptron algorithm.
    - The other losses, ‘squared_error’, ‘huber’, ‘epsilon_insensitive’ and
      ‘squared_epsilon_insensitive’ are designed for regression but can be useful
      in classification as well; see
      [`SGDRegressor`](sklearn.linear_model.SGDRegressor.md#sklearn.linear_model.SGDRegressor) for a description.
    <br/>
    More details about the losses formulas can be found in the [User Guide](../sgd.md#sgd-mathematical-formulation) and you can find a visualisation of the loss
    functions in
    [SGD: convex loss functions](../../auto_examples/linear_model/plot_sgd_loss_functions.md#sphx-glr-auto-examples-linear-model-plot-sgd-loss-functions-py).

  **penalty**
  : The penalty (aka regularization term) to be used. Defaults to ‘l2’
    which is the standard regularizer for linear SVM models. ‘l1’ and
    ‘elasticnet’ might bring sparsity to the model (feature selection)
    not achievable with ‘l2’. No penalty is added when set to `None`.
    <br/>
    You can see a visualisation of the penalties in
    [SGD: Penalties](../../auto_examples/linear_model/plot_sgd_penalties.md#sphx-glr-auto-examples-linear-model-plot-sgd-penalties-py).

  **alpha**
  : Constant that multiplies the regularization term. The higher the
    value, the stronger the regularization. Also used to compute the
    learning rate when `learning_rate` is set to ‘optimal’.
    Values must be in the range `[0.0, inf)`.

  **l1_ratio**
  : The Elastic Net mixing parameter, with 0 <= l1_ratio <= 1.
    l1_ratio=0 corresponds to L2 penalty, l1_ratio=1 to L1.
    Only used if `penalty` is ‘elasticnet’.
    Values must be in the range `[0.0, 1.0]`.

  **fit_intercept**
  : Whether the intercept should be estimated or not. If False, the
    data is assumed to be already centered.

  **max_iter**
  : The maximum number of passes over the training data (aka epochs).
    It only impacts the behavior in the `fit` method, and not the
    [`partial_fit`](#sklearn.linear_model.SGDClassifier.partial_fit) method.
    Values must be in the range `[1, inf)`.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **tol**
  : The stopping criterion. If it is not None, training will stop
    when (loss > best_loss - tol) for `n_iter_no_change` consecutive
    epochs.
    Convergence is checked against the training loss or the
    validation loss depending on the `early_stopping` parameter.
    Values must be in the range `[0.0, inf)`.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **shuffle**
  : Whether or not the training data should be shuffled after each epoch.

  **verbose**
  : The verbosity level.
    Values must be in the range `[0, inf)`.

  **epsilon**
  : Epsilon in the epsilon-insensitive loss functions; only if `loss` is
    ‘huber’, ‘epsilon_insensitive’, or ‘squared_epsilon_insensitive’.
    For ‘huber’, determines the threshold at which it becomes less
    important to get the prediction exactly right.
    For epsilon-insensitive, any differences between the current prediction
    and the correct label are ignored if they are less than this threshold.
    Values must be in the range `[0.0, inf)`.

  **n_jobs**
  : The number of CPUs to use to do the OVA (One Versus All, for
    multi-class problems) computation.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **random_state**
  : Used for shuffling the data, when `shuffle` is set to `True`.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
    Integer values must be in the range `[0, 2**32 - 1]`.

  **learning_rate**
  : The learning rate schedule:
    - ‘constant’: `eta = eta0`
    - ‘optimal’: `eta = 1.0 / (alpha * (t + t0))`
      where `t0` is chosen by a heuristic proposed by Leon Bottou.
    - ‘invscaling’: `eta = eta0 / pow(t, power_t)`
    - ‘adaptive’: `eta = eta0`, as long as the training keeps decreasing.
      Each time n_iter_no_change consecutive epochs fail to decrease the
      training loss by tol or fail to increase validation score by tol if
      `early_stopping` is `True`, the current learning rate is divided by 5.
    <br/>
    #### Versionadded
    Added in version 0.20: Added ‘adaptive’ option.

  **eta0**
  : The initial learning rate for the ‘constant’, ‘invscaling’ or
    ‘adaptive’ schedules. The default value is 0.0 as eta0 is not used by
    the default schedule ‘optimal’.
    Values must be in the range `[0.0, inf)`.

  **power_t**
  : The exponent for inverse scaling learning rate.
    Values must be in the range `(-inf, inf)`.

  **early_stopping**
  : Whether to use early stopping to terminate training when validation
    score is not improving. If set to `True`, it will automatically set aside
    a stratified fraction of training data as validation and terminate
    training when validation score returned by the `score` method is not
    improving by at least tol for n_iter_no_change consecutive epochs.
    <br/>
    See [Early stopping of Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgd_early_stopping.md#sphx-glr-auto-examples-linear-model-plot-sgd-early-stopping-py) for an
    example of the effects of early stopping.
    <br/>
    #### Versionadded
    Added in version 0.20: Added ‘early_stopping’ option

  **validation_fraction**
  : The proportion of training data to set aside as validation set for
    early stopping. Must be between 0 and 1.
    Only used if `early_stopping` is True.
    Values must be in the range `(0.0, 1.0)`.
    <br/>
    #### Versionadded
    Added in version 0.20: Added ‘validation_fraction’ option

  **n_iter_no_change**
  : Number of iterations with no improvement to wait before stopping
    fitting.
    Convergence is checked against the training loss or the
    validation loss depending on the `early_stopping` parameter.
    Integer values must be in the range `[1, max_iter)`.
    <br/>
    #### Versionadded
    Added in version 0.20: Added ‘n_iter_no_change’ option

  **class_weight**
  : Preset for the class_weight fit parameter.
    <br/>
    Weights associated with classes. If not given, all classes
    are supposed to have weight one.
    <br/>
    The “balanced” mode uses the values of y to automatically adjust
    weights inversely proportional to class frequencies in the input data
    as `n_samples / (n_classes * np.bincount(y))`.

  **warm_start**
  : When set to True, reuse the solution of the previous call to fit as
    initialization, otherwise, just erase the previous solution.
    See [the Glossary](../../glossary.md#term-warm_start).
    <br/>
    Repeatedly calling fit or partial_fit when warm_start is True can
    result in a different solution than when calling fit a single time
    because of the way the data is shuffled.
    If a dynamic learning rate is used, the learning rate is adapted
    depending on the number of samples already seen. Calling `fit` resets
    this counter, while `partial_fit` will result in increasing the
    existing counter.

  **average**
  : When set to `True`, computes the averaged SGD weights across all
    updates and stores the result in the `coef_` attribute. If set to
    an int greater than 1, averaging will begin once the total number of
    samples seen reaches `average`. So `average=10` will begin
    averaging after seeing 10 samples.
    Integer values must be in the range `[1, n_samples]`.
* **Attributes:**
  **coef_**
  : Weights assigned to the features.

  **intercept_**
  : Constants in decision function.

  **n_iter_**
  : The actual number of iterations before reaching the stopping criterion.
    For multiclass fits, it is the maximum over every binary fit.

  **classes_**

  **t_**
  : Number of weight updates performed during training.
    Same as `(n_iter_ * n_samples + 1)`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`sklearn.svm.LinearSVC`](sklearn.svm.LinearSVC.md#sklearn.svm.LinearSVC)
: Linear support vector classification.

[`LogisticRegression`](sklearn.linear_model.LogisticRegression.md#sklearn.linear_model.LogisticRegression)
: Logistic regression.

[`Perceptron`](sklearn.linear_model.Perceptron.md#sklearn.linear_model.Perceptron)
: Inherits from SGDClassifier. `Perceptron()` is equivalent to `SGDClassifier(loss="perceptron", eta0=1, learning_rate="constant", penalty=None)`.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.linear_model import SGDClassifier
>>> from sklearn.preprocessing import StandardScaler
>>> from sklearn.pipeline import make_pipeline
>>> X = np.array([[-1, -1], [-2, -1], [1, 1], [2, 1]])
>>> Y = np.array([1, 1, 2, 2])
>>> # Always scale the input. The most convenient way is to use a pipeline.
>>> clf = make_pipeline(StandardScaler(),
...                     SGDClassifier(max_iter=1000, tol=1e-3))
>>> clf.fit(X, Y)
Pipeline(steps=[('standardscaler', StandardScaler()),
                ('sgdclassifier', SGDClassifier())])
>>> print(clf.predict([[-0.8, -1]]))
[1]
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Predict confidence scores for samples.

The confidence score for a sample is proportional to the signed
distance of that sample to the hyperplane.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the confidence scores.
* **Returns:**
  **scores**
  : Confidence scores per `(n_samples, n_classes)` combination. In the
    binary case, confidence score for `self.classes_[1]` where >0 means
    this class would be predicted.

<!-- !! processed by numpydoc !! -->

#### densify()

Convert coefficient matrix to dense array format.

Converts the `coef_` member (back) to a numpy.ndarray. This is the
default format of `coef_` and is required for fitting, so calling
this method is only required on models that have previously been
sparsified; otherwise, it is a no-op.

* **Returns:**
  self
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, coef_init=None, intercept_init=None, sample_weight=None)

Fit linear model with Stochastic Gradient Descent.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **coef_init**
  : The initial coefficients to warm-start the optimization.

  **intercept_init**
  : The initial intercept to warm-start the optimization.

  **sample_weight**
  : Weights applied to individual samples.
    If not provided, uniform weights are assumed. These weights will
    be multiplied with class_weight (passed through the
    constructor) if class_weight is specified.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y, classes=None, sample_weight=None)

Perform one epoch of stochastic gradient descent on given samples.

Internally, this method uses `max_iter = 1`. Therefore, it is not
guaranteed that a minimum of the cost function is reached after calling
it once. Matters such as objective convergence, early stopping, and
learning rate adjustments should be handled by the user.

* **Parameters:**
  **X**
  : Subset of the training data.

  **y**
  : Subset of the target values.

  **classes**
  : Classes across all calls to partial_fit.
    Can be obtained by via `np.unique(y_all)`, where y_all is the
    target vector of the entire dataset.
    This argument is required for the first call to partial_fit
    and can be omitted in the subsequent calls.
    Note that y doesn’t need to contain all labels in `classes`.

  **sample_weight**
  : Weights applied to individual samples.
    If not provided, uniform weights are assumed.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict class labels for samples in X.

* **Parameters:**
  **X**
  : The data matrix for which we want to get the predictions.
* **Returns:**
  **y_pred**
  : Vector containing the class labels for each sample.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Log of probability estimates.

This method is only available for log loss and modified Huber loss.

When loss=”modified_huber”, probability estimates may be hard zeros
and ones, so taking the logarithm is not possible.

See `predict_proba` for details.

* **Parameters:**
  **X**
  : Input data for prediction.
* **Returns:**
  **T**
  : Returns the log-probability of the sample for each class in the
    model, where classes are ordered as they are in
    `self.classes_`.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Probability estimates.

This method is only available for log loss and modified Huber loss.

Multiclass probability estimates are derived from binary (one-vs.-rest)
estimates by simple normalization, as recommended by Zadrozny and
Elkan.

Binary probability estimates for loss=”modified_huber” are given by
(clip(decision_function(X), -1, 1) + 1) / 2. For other loss functions
it is necessary to perform proper probability calibration by wrapping
the classifier with
[`CalibratedClassifierCV`](sklearn.calibration.CalibratedClassifierCV.md#sklearn.calibration.CalibratedClassifierCV) instead.

* **Parameters:**
  **X**
  : Input data for prediction.
* **Returns:**
  ndarray of shape (n_samples, n_classes)
  : Returns the probability of the sample for each class in the model,
    where classes are ordered as they are in `self.classes_`.

### References

Zadrozny and Elkan, “Transforming classifier scores into multiclass
probability estimates”, SIGKDD’02,
[https://dl.acm.org/doi/pdf/10.1145/775047.775151](https://dl.acm.org/doi/pdf/10.1145/775047.775151)

The justification for the formula in the loss=”modified_huber”
case is in the appendix B in:
[http://jmlr.csail.mit.edu/papers/volume2/zhang02c/zhang02c.pdf](http://jmlr.csail.mit.edu/papers/volume2/zhang02c/zhang02c.pdf)

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, coef_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', intercept_init: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SGDClassifier](#sklearn.linear_model.SGDClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **coef_init**
  : Metadata routing for `coef_init` parameter in `fit`.

  **intercept_init**
  : Metadata routing for `intercept_init` parameter in `fit`.

  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, classes: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SGDClassifier](#sklearn.linear_model.SGDClassifier)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **classes**
  : Metadata routing for `classes` parameter in `partial_fit`.

  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [SGDClassifier](#sklearn.linear_model.SGDClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### sparsify()

Convert coefficient matrix to sparse format.

Converts the `coef_` member to a scipy.sparse matrix, which for
L1-regularized models can be much more memory- and storage-efficient
than the usual numpy.ndarray representation.

The `intercept_` member is not converted.

* **Returns:**
  self
  : Fitted estimator.

### Notes

For non-sparse models, i.e. when there are not many zeros in `coef_`,
this may actually *increase* memory usage, so use this method with
care. A rule of thumb is that the number of zero elements, which can
be computed with `(coef_ == 0).sum()`, must be more than 50% for this
to provide significant benefits.

After calling this method, further fitting with the partial_fit
method (if any) will not work until you call densify.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Demonstrate how model complexity influences both prediction accuracy and computational performance.">  <div class="sphx-glr-thumbnail-title">Model Complexity Influence</div>
</div>
* [Model Complexity Influence](../../auto_examples/applications/plot_model_complexity_influence.md#sphx-glr-auto-examples-applications-plot-model-complexity-influence-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used for classification using an out-of-core approach: learning from data that doesn&#x27;t fit into main memory. We make use of an online classifier, i.e., one that supports the partial_fit method, that will be fed with batches of examples. To guarantee that the features space remains the same over time we leverage a HashingVectorizer that will project each example into the same feature space. This is especially useful in the case of text classification where new features (words) may appear in each batch.">  <div class="sphx-glr-thumbnail-title">Out-of-core classification of text documents</div>
</div>
* [Out-of-core classification of text documents](../../auto_examples/applications/plot_out_of_core_classification.md#sphx-glr-auto-examples-applications-plot-out-of-core-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparing various online solvers">  <div class="sphx-glr-thumbnail-title">Comparing various online solvers</div>
</div>
* [Comparing various online solvers](../../auto_examples/linear_model/plot_sgd_comparison.md#sphx-glr-auto-examples-linear-model-plot-sgd-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stochastic Gradient Descent is an optimization technique which minimizes a loss function in a stochastic fashion, performing a gradient descent step sample by sample. In particular, it is a very efficient method to fit linear models.">  <div class="sphx-glr-thumbnail-title">Early stopping of Stochastic Gradient Descent</div>
</div>
* [Early stopping of Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgd_early_stopping.md#sphx-glr-auto-examples-linear-model-plot-sgd-early-stopping-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot decision surface of multi-class SGD on iris dataset. The hyperplanes corresponding to the three one-versus-all (OVA) classifiers are represented by the dashed lines.">  <div class="sphx-glr-thumbnail-title">Plot multi-class SGD on the iris dataset</div>
</div>
* [Plot multi-class SGD on the iris dataset](../../auto_examples/linear_model/plot_sgd_iris.md#sphx-glr-auto-examples-linear-model-plot-sgd-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the maximum margin separating hyperplane within a two-class separable dataset using a linear Support Vector Machines classifier trained using SGD.">  <div class="sphx-glr-thumbnail-title">SGD: Maximum margin separating hyperplane</div>
</div>
* [SGD: Maximum margin separating hyperplane](../../auto_examples/linear_model/plot_sgd_separating_hyperplane.md#sphx-glr-auto-examples-linear-model-plot-sgd-separating-hyperplane-py)

<div class="sphx-glr-thumbcontainer" tooltip="Contours of where the penalty is equal to 1 for the three penalties L1, L2 and elastic-net.">  <div class="sphx-glr-thumbnail-title">SGD: Penalties</div>
</div>
* [SGD: Penalties](../../auto_examples/linear_model/plot_sgd_penalties.md#sphx-glr-auto-examples-linear-model-plot-sgd-penalties-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot decision function of a weighted dataset, where the size of points is proportional to its weight.">  <div class="sphx-glr-thumbnail-title">SGD: Weighted samples</div>
</div>
* [SGD: Weighted samples](../../auto_examples/linear_model/plot_sgd_weighted_samples.md#sphx-glr-auto-examples-linear-model-plot-sgd-weighted-samples-py)

<div class="sphx-glr-thumbcontainer" tooltip="A plot that compares the various convex loss functions supported by SGDClassifier .">  <div class="sphx-glr-thumbnail-title">SGD: convex loss functions</div>
</div>
* [SGD: convex loss functions](../../auto_examples/linear_model/plot_sgd_loss_functions.md#sphx-glr-auto-examples-linear-model-plot-sgd-loss-functions-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example illustrating the approximation of the feature map of an RBF kernel.">  <div class="sphx-glr-thumbnail-title">Explicit feature map approximation for RBF kernels</div>
</div>
* [Explicit feature map approximation for RBF kernels](../../auto_examples/miscellaneous/plot_kernel_approximation.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-approximation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Compare randomized search and grid search for optimizing hyperparameters of a linear SVM with SGD training. All parameters that influence the learning are searched simultaneously (except for the number of estimators, which poses a time / quality tradeoff).">  <div class="sphx-glr-thumbnail-title">Comparing randomized search and grid search for hyperparameter estimation</div>
</div>
* [Comparing randomized search and grid search for hyperparameter estimation](../../auto_examples/model_selection/plot_randomized_search.md#sphx-glr-auto-examples-model-selection-plot-randomized-search-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, semi-supervised classifiers are trained on the 20 newsgroups dataset (which will be automatically downloaded).">  <div class="sphx-glr-thumbnail-title">Semi-supervised Classification on a Text Dataset</div>
</div>
* [Semi-supervised Classification on a Text Dataset](../../auto_examples/semi_supervised/plot_semi_supervised_newsgroups.md#sphx-glr-auto-examples-semi-supervised-plot-semi-supervised-newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.6! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_6&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.6</div>
</div>
* [Release Highlights for scikit-learn 1.6](../../auto_examples/release_highlights/plot_release_highlights_1_6_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-6-0-py)

<!-- thumbnail-parent-div-close --></div>
