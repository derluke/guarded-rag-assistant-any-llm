# PairwiseKernel

### *class* sklearn.gaussian_process.kernels.PairwiseKernel(gamma=1.0, gamma_bounds=(1e-05, 100000.0), metric='linear', pairwise_kernels_kwargs=None)

Wrapper for kernels in sklearn.metrics.pairwise.

A thin wrapper around the functionality of the kernels in
sklearn.metrics.pairwise.

Note: Evaluation of eval_gradient is not analytic but numeric and all
: kernels support only isotropic distances. The parameter gamma is
  considered to be a hyperparameter and may be optimized. The other
  kernel parameters are set directly at initialization and are kept
  fixed.

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **gamma**
  : Parameter gamma of the pairwise kernel specified by metric. It should
    be positive.

  **gamma_bounds**
  : The lower and upper bound on ‘gamma’.
    If set to “fixed”, ‘gamma’ cannot be changed during
    hyperparameter tuning.

  **metric**
  : The metric to use when calculating kernel between instances in a
    feature array. If metric is a string, it must be one of the metrics
    in pairwise.PAIRWISE_KERNEL_FUNCTIONS.
    If metric is “precomputed”, X is assumed to be a kernel matrix.
    Alternatively, if metric is a callable function, it is called on each
    pair of instances (rows) and the resulting value recorded. The callable
    should take two arrays from X as input and return a value indicating
    the distance between them.

  **pairwise_kernels_kwargs**
  : All entries of this dict (if any) are passed as keyword arguments to
    the pairwise kernel function.

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn.gaussian_process import GaussianProcessClassifier
>>> from sklearn.gaussian_process.kernels import PairwiseKernel
>>> X, y = load_iris(return_X_y=True)
>>> kernel = PairwiseKernel(metric='rbf')
>>> gpc = GaussianProcessClassifier(kernel=kernel,
...         random_state=0).fit(X, y)
>>> gpc.score(X, y)
0.9733...
>>> gpc.predict_proba(X[:2,:])
array([[0.8880..., 0.05663..., 0.05532...],
       [0.8676..., 0.07073..., 0.06165...]])
```

<!-- !! processed by numpydoc !! -->

#### \_\_call_\_(X, Y=None, eval_gradient=False)

Return the kernel k(X, Y) and optionally its gradient.

* **Parameters:**
  **X**
  : Left argument of the returned kernel k(X, Y)

  **Y**
  : Right argument of the returned kernel k(X, Y). If None, k(X, X)
    if evaluated instead.

  **eval_gradient**
  : Determines whether the gradient with respect to the log of
    the kernel hyperparameter is computed.
    Only supported when Y is None.
* **Returns:**
  **K**
  : Kernel k(X, Y)

  **K_gradient**
  : The gradient of the kernel k(X, X) with respect to the log of the
    hyperparameter of the kernel. Only returned when `eval_gradient`
    is True.

<!-- !! processed by numpydoc !! -->

#### *property* bounds

Returns the log-transformed bounds on the theta.

* **Returns:**
  **bounds**
  : The log-transformed bounds on the kernel’s hyperparameters theta

<!-- !! processed by numpydoc !! -->

#### clone_with_theta(theta)

Returns a clone of self with given hyperparameters theta.

* **Parameters:**
  **theta**
  : The hyperparameters

<!-- !! processed by numpydoc !! -->

#### diag(X)

Returns the diagonal of the kernel k(X, X).

The result of this method is identical to np.diag(self(X)); however,
it can be evaluated more efficiently since only the diagonal is
evaluated.

* **Parameters:**
  **X**
  : Left argument of the returned kernel k(X, Y)
* **Returns:**
  **K_diag**
  : Diagonal of kernel k(X, X)

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters of this kernel.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* hyperparameters

Returns a list of all hyperparameter specifications.

<!-- !! processed by numpydoc !! -->

#### is_stationary()

Returns whether the kernel is stationary.

<!-- !! processed by numpydoc !! -->

#### *property* n_dims

Returns the number of non-fixed hyperparameters of the kernel.

<!-- !! processed by numpydoc !! -->

#### *property* requires_vector_input

Returns whether the kernel is defined on fixed-length feature
vectors or generic objects. Defaults to True for backward
compatibility.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this kernel.

The method works on simple kernels as well as on nested kernels.
The latter have parameters of the form `<component>__<parameter>`
so that it’s possible to update each component of a nested object.

* **Returns:**
  self

<!-- !! processed by numpydoc !! -->

#### *property* theta

Returns the (flattened, log-transformed) non-fixed hyperparameters.

Note that theta are typically the log-transformed values of the
kernel’s hyperparameters as this representation of the search space
is more amenable for hyperparameter search, as hyperparameters like
length-scales naturally live on a log-scale.

* **Returns:**
  **theta**
  : The non-fixed, log-transformed hyperparameters of the kernel

<!-- !! processed by numpydoc !! -->
