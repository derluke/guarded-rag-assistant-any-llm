# TransformerTags

### *class* sklearn.utils.TransformerTags(preserves_dtype: list[str] = <factory>)

Tags for the transformer.

* **Parameters:**
  **preserves_dtype**
  : Applies only on transformers. It corresponds to the data types
    which will be preserved such that `X_trans.dtype` is the same
    as `X.dtype` after calling `transformer.transform(X)`. If this
    list is empty, then the transformer is not expected to
    preserve the data type. The first value in the list is
    considered as the default data type, corresponding to the data
    type of the output when the input data type is not going to be
    preserved.

<!-- !! processed by numpydoc !! -->
