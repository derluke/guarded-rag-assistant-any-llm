# HDBSCAN

### *class* sklearn.cluster.HDBSCAN(min_cluster_size=5, min_samples=None, cluster_selection_epsilon=0.0, max_cluster_size=None, metric='euclidean', metric_params=None, alpha=1.0, algorithm='auto', leaf_size=40, n_jobs=None, cluster_selection_method='eom', allow_single_cluster=False, store_centers=None, copy=False)

Cluster data using hierarchical density-based clustering.

HDBSCAN - Hierarchical Density-Based Spatial Clustering of Applications
with Noise. Performs [`DBSCAN`](sklearn.cluster.DBSCAN.md#sklearn.cluster.DBSCAN) over varying epsilon
values and integrates the result to find a clustering that gives the best
stability over epsilon.
This allows HDBSCAN to find clusters of varying densities (unlike
[`DBSCAN`](sklearn.cluster.DBSCAN.md#sklearn.cluster.DBSCAN)), and be more robust to parameter selection.
Read more in the [User Guide](../clustering.md#hdbscan).

For an example of how to use HDBSCAN, as well as a comparison to
[`DBSCAN`](sklearn.cluster.DBSCAN.md#sklearn.cluster.DBSCAN), please see the [plotting demo](../../auto_examples/cluster/plot_hdbscan.md#sphx-glr-auto-examples-cluster-plot-hdbscan-py).

#### Versionadded
Added in version 1.3.

* **Parameters:**
  **min_cluster_size**
  : The minimum number of samples in a group for that group to be
    considered a cluster; groupings smaller than this size will be left
    as noise.

  **min_samples**
  : The parameter `k` used to calculate the distance between a point
    `x_p` and its k-th nearest neighbor.
    When `None`, defaults to `min_cluster_size`.

  **cluster_selection_epsilon**
  : A distance threshold. Clusters below this value will be merged.
    See [[5]](#r6f313792b2b7-5) for more information.

  **max_cluster_size**
  : A limit to the size of clusters returned by the `"eom"` cluster
    selection algorithm. There is no limit when `max_cluster_size=None`.
    Has no effect if `cluster_selection_method="leaf"`.

  **metric**
  : The metric to use when calculating distance between instances in a
    feature array.
    - If metric is a string or callable, it must be one of
      the options allowed by [`pairwise_distances`](sklearn.metrics.pairwise_distances.md#sklearn.metrics.pairwise_distances)
      for its metric parameter.
    - If metric is “precomputed”, X is assumed to be a distance matrix and
      must be square.

  **metric_params**
  : Arguments passed to the distance metric.

  **alpha**
  : A distance scaling parameter as used in robust single linkage.
    See [[3]](#r6f313792b2b7-3) for more information.

  **algorithm**
  : Exactly which algorithm to use for computing core distances; By default
    this is set to `"auto"` which attempts to use a
    [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree) tree if possible, otherwise it uses
    a [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree) tree. Both `"kd_tree"` and
    `"ball_tree"` algorithms use the
    [`NearestNeighbors`](sklearn.neighbors.NearestNeighbors.md#sklearn.neighbors.NearestNeighbors) estimator.
    <br/>
    If the `X` passed during `fit` is sparse or `metric` is invalid for
    both [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree) and
    [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree), then it resolves to use the
    `"brute"` algorithm.

  **leaf_size**
  : Leaf size for trees responsible for fast nearest neighbour queries when
    a KDTree or a BallTree are used as core-distance algorithms. A large
    dataset size and small `leaf_size` may induce excessive memory usage.
    If you are running out of memory consider increasing the `leaf_size`
    parameter. Ignored for `algorithm="brute"`.

  **n_jobs**
  : Number of jobs to run in parallel to calculate distances.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **cluster_selection_method**
  : The method used to select clusters from the condensed tree. The
    standard approach for HDBSCAN\* is to use an Excess of Mass (`"eom"`)
    algorithm to find the most persistent clusters. Alternatively you can
    instead select the clusters at the leaves of the tree – this provides
    the most fine grained and homogeneous clusters.

  **allow_single_cluster**
  : By default HDBSCAN\* will not produce a single cluster, setting this
    to True will override this and allow single cluster results in
    the case that you feel this is a valid result for your dataset.

  **store_centers**
  : Which, if any, cluster centers to compute and store. The options are:
    - `None` which does not compute nor store any centers.
    - `"centroid"` which calculates the center by taking the weighted
      average of their positions. Note that the algorithm uses the
      euclidean metric and does not guarantee that the output will be
      an observed data point.
    - `"medoid"` which calculates the center by taking the point in the
      fitted data which minimizes the distance to all other points in
      the cluster. This is slower than “centroid” since it requires
      computing additional pairwise distances between points of the
      same cluster but guarantees the output is an observed data point.
      The medoid is also well-defined for arbitrary metrics, and does not
      depend on a euclidean metric.
    - `"both"` which computes and stores both forms of centers.

  **copy**
  : If `copy=True` then any time an in-place modifications would be made
    that would overwrite data passed to [fit](../../glossary.md#term-fit), a copy will first be
    made, guaranteeing that the original data will be unchanged.
    Currently, it only applies when `metric="precomputed"`, when passing
    a dense array or a CSR sparse matrix and when `algorithm="brute"`.
* **Attributes:**
  **labels_**
  : Cluster labels for each point in the dataset given to [fit](../../glossary.md#term-fit).
    Outliers are labeled as follows:
    - Noisy samples are given the label -1.
    - Samples with infinite elements (+/- np.inf) are given the label -2.
    - Samples with missing data are given the label -3, even if they
      also have infinite elements.

  **probabilities_**
  : The strength with which each sample is a member of its assigned
    cluster.
    - Clustered samples have probabilities proportional to the degree that
      they persist as part of the cluster.
    - Noisy samples have probability zero.
    - Samples with infinite elements (+/- np.inf) have probability 0.
    - Samples with missing data have probability `np.nan`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.

  **centroids_**
  : A collection containing the centroid of each cluster calculated under
    the standard euclidean metric. The centroids may fall “outside” their
    respective clusters if the clusters themselves are non-convex.
    <br/>
    Note that `n_clusters` only counts non-outlier clusters. That is to
    say, the `-1, -2, -3` labels for the outlier clusters are excluded.

  **medoids_**
  : A collection containing the medoid of each cluster calculated under
    the whichever metric was passed to the `metric` parameter. The
    medoids are points in the original cluster which minimize the average
    distance to all other points in that cluster under the chosen metric.
    These can be thought of as the result of projecting the `metric`-based
    centroid back onto the cluster.
    <br/>
    Note that `n_clusters` only counts non-outlier clusters. That is to
    say, the `-1, -2, -3` labels for the outlier clusters are excluded.

#### SEE ALSO
[`DBSCAN`](sklearn.cluster.DBSCAN.md#sklearn.cluster.DBSCAN)
: Density-Based Spatial Clustering of Applications with Noise.

[`OPTICS`](sklearn.cluster.OPTICS.md#sklearn.cluster.OPTICS)
: Ordering Points To Identify the Clustering Structure.

[`Birch`](sklearn.cluster.Birch.md#sklearn.cluster.Birch)
: Memory-efficient, online-learning algorithm.

### Notes

The `min_samples` parameter includes the point itself, whereas the implementation in
[scikit-learn-contrib/hdbscan](https://github.com/scikit-learn-contrib/hdbscan)
does not. To get the same results in both versions, the value of `min_samples` here
must be 1 greater than the value used in [scikit-learn-contrib/hdbscan](https://github.com/scikit-learn-contrib/hdbscan).

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.cluster import HDBSCAN
>>> from sklearn.datasets import load_digits
>>> X, _ = load_digits(return_X_y=True)
>>> hdb = HDBSCAN(min_cluster_size=20)
>>> hdb.fit(X)
HDBSCAN(min_cluster_size=20)
>>> hdb.labels_.shape == (X.shape[0],)
True
>>> np.unique(hdb.labels_).tolist()
[-1, 0, 1, 2, 3, 4, 5, 6, 7]
```

<!-- !! processed by numpydoc !! -->

#### dbscan_clustering(cut_distance, min_cluster_size=5)

Return clustering given by DBSCAN without border points.

Return clustering that would be equivalent to running DBSCAN\* for a
particular cut_distance (or epsilon) DBSCAN\* can be thought of as
DBSCAN without the border points.  As such these results may differ
slightly from `cluster.DBSCAN` due to the difference in implementation
over the non-core points.

This can also be thought of as a flat clustering derived from constant
height cut through the single linkage tree.

This represents the result of selecting a cut value for robust single linkage
clustering. The `min_cluster_size` allows the flat clustering to declare noise
points (and cluster smaller than `min_cluster_size`).

* **Parameters:**
  **cut_distance**
  : The mutual reachability distance cut value to use to generate a
    flat clustering.

  **min_cluster_size**
  : Clusters smaller than this value with be called ‘noise’ and remain
    unclustered in the resulting flat clustering.
* **Returns:**
  **labels**
  : An array of cluster labels, one per datapoint.
    Outliers are labeled as follows:
    - Noisy samples are given the label -1.
    - Samples with infinite elements (+/- np.inf) are given the label -2.
    - Samples with missing data are given the label -3, even if they
      also have infinite elements.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Find clusters based on hierarchical density-based clustering.

* **Parameters:**
  **X**
  : A feature array, or array of distances between samples if
    `metric='precomputed'`.

  **y**
  : Ignored.
* **Returns:**
  **self**
  : Returns self.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None)

Cluster X and return the associated cluster labels.

* **Parameters:**
  **X**
  : A feature array, or array of distances between samples if
    `metric='precomputed'`.

  **y**
  : Ignored.
* **Returns:**
  **y**
  : Cluster labels.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this demo we will take a look at cluster.HDBSCAN from the perspective of generalizing the cluster.DBSCAN algorithm. We&#x27;ll compare both algorithms on specific datasets. Finally we&#x27;ll evaluate HDBSCAN&#x27;s sensitivity to certain hyperparameters.">  <div class="sphx-glr-thumbnail-title">Demo of HDBSCAN clustering algorithm</div>
</div>
* [Demo of HDBSCAN clustering algorithm](../../auto_examples/cluster/plot_hdbscan.md#sphx-glr-auto-examples-cluster-plot-hdbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.3! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_3&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.3</div>
</div>
* [Release Highlights for scikit-learn 1.3](../../auto_examples/release_highlights/plot_release_highlights_1_3_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-3-0-py)

<!-- thumbnail-parent-div-close --></div>
