# affinity_propagation

### sklearn.cluster.affinity_propagation(S, \*, preference=None, convergence_iter=15, max_iter=200, damping=0.5, copy=True, verbose=False, return_n_iter=False, random_state=None)

Perform Affinity Propagation Clustering of data.

Read more in the [User Guide](../clustering.md#affinity-propagation).

* **Parameters:**
  **S**
  : Matrix of similarities between points.

  **preference**
  : Preferences for each point - points with larger values of
    preferences are more likely to be chosen as exemplars. The number of
    exemplars, i.e. of clusters, is influenced by the input preferences
    value. If the preferences are not passed as arguments, they will be
    set to the median of the input similarities (resulting in a moderate
    number of clusters). For a smaller amount of clusters, this can be set
    to the minimum value of the similarities.

  **convergence_iter**
  : Number of iterations with no change in the number
    of estimated clusters that stops the convergence.

  **max_iter**
  : Maximum number of iterations.

  **damping**
  : Damping factor between 0.5 and 1.

  **copy**
  : If copy is False, the affinity matrix is modified inplace by the
    algorithm, for memory efficiency.

  **verbose**
  : The verbosity level.

  **return_n_iter**
  : Whether or not to return the number of iterations.

  **random_state**
  : Pseudo-random number generator to control the starting state.
    Use an int for reproducible results across function calls.
    See the [Glossary](../../glossary.md#term-random_state).
    <br/>
    #### Versionadded
    Added in version 0.23: this parameter was previously hardcoded as 0.
* **Returns:**
  **cluster_centers_indices**
  : Index of clusters centers.

  **labels**
  : Cluster labels for each point.

  **n_iter**
  : Number of iterations run. Returned only if `return_n_iter` is
    set to True.

### Notes

For an example usage,
see [Demo of affinity propagation clustering algorithm](../../auto_examples/cluster/plot_affinity_propagation.md#sphx-glr-auto-examples-cluster-plot-affinity-propagation-py).
You may also check out,
[Visualizing the stock market structure](../../auto_examples/applications/plot_stock_market.md#sphx-glr-auto-examples-applications-plot-stock-market-py)

When the algorithm does not converge, it will still return a arrays of
`cluster_center_indices` and labels if there are any exemplars/clusters,
however they may be degenerate and should be used with caution.

When all training samples have equal similarities and equal preferences,
the assignment of cluster centers and labels depends on the preference.
If the preference is smaller than the similarities, a single cluster center
and label `0` for every sample will be returned. Otherwise, every
training sample becomes its own cluster center and is assigned a unique
label.

### References

Brendan J. Frey and Delbert Dueck, “Clustering by Passing Messages
Between Data Points”, Science Feb. 2007

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.cluster import affinity_propagation
>>> from sklearn.metrics.pairwise import euclidean_distances
>>> X = np.array([[1, 2], [1, 4], [1, 0],
...               [4, 2], [4, 4], [4, 0]])
>>> S = -euclidean_distances(X, squared=True)
>>> cluster_centers_indices, labels = affinity_propagation(S, random_state=0)
>>> cluster_centers_indices
array([0, 3])
>>> labels
array([0, 0, 0, 1, 1, 1])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example employs several unsupervised learning techniques to extract the stock market structure from variations in historical quotes.">  <div class="sphx-glr-thumbnail-title">Visualizing the stock market structure</div>
</div>
* [Visualizing the stock market structure](../../auto_examples/applications/plot_stock_market.md#sphx-glr-auto-examples-applications-plot-stock-market-py)

<!-- thumbnail-parent-div-close --></div>
