# paired_manhattan_distances

### sklearn.metrics.pairwise.paired_manhattan_distances(X, Y)

Compute the paired L1 distances between X and Y.

Distances are calculated between (X[0], Y[0]), (X[1], Y[1]), …,
(X[n_samples], Y[n_samples]).

Read more in the [User Guide](../metrics.md#metrics).

* **Parameters:**
  **X**
  : An array-like where each row is a sample and each column is a feature.

  **Y**
  : An array-like where each row is a sample and each column is a feature.
* **Returns:**
  **distances**
  : L1 paired distances between the row vectors of `X`
    and the row vectors of `Y`.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import paired_manhattan_distances
>>> import numpy as np
>>> X = np.array([[1, 1, 0], [0, 1, 0], [0, 0, 1]])
>>> Y = np.array([[0, 1, 0], [0, 0, 1], [0, 0, 0]])
>>> paired_manhattan_distances(X, Y)
array([1., 2., 1.])
```

<!-- !! processed by numpydoc !! -->
