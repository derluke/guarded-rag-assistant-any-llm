# BaggingRegressor

### *class* sklearn.ensemble.BaggingRegressor(estimator=None, n_estimators=10, \*, max_samples=1.0, max_features=1.0, bootstrap=True, bootstrap_features=False, oob_score=False, warm_start=False, n_jobs=None, random_state=None, verbose=0)

A Bagging regressor.

A Bagging regressor is an ensemble meta-estimator that fits base
regressors each on random subsets of the original dataset and then
aggregate their individual predictions (either by voting or by averaging)
to form a final prediction. Such a meta-estimator can typically be used as
a way to reduce the variance of a black-box estimator (e.g., a decision
tree), by introducing randomization into its construction procedure and
then making an ensemble out of it.

This algorithm encompasses several works from the literature. When random
subsets of the dataset are drawn as random subsets of the samples, then
this algorithm is known as Pasting [[1]](#r4d113ba76fc0-1). If samples are drawn with
replacement, then the method is known as Bagging [[2]](#r4d113ba76fc0-2). When random subsets
of the dataset are drawn as random subsets of the features, then the method
is known as Random Subspaces [[3]](#r4d113ba76fc0-3). Finally, when base estimators are built
on subsets of both samples and features, then the method is known as
Random Patches [[4]](#r4d113ba76fc0-4).

Read more in the [User Guide](../ensemble.md#bagging).

#### Versionadded
Added in version 0.15.

* **Parameters:**
  **estimator**
  : The base estimator to fit on random subsets of the dataset.
    If None, then the base estimator is a
    [`DecisionTreeRegressor`](sklearn.tree.DecisionTreeRegressor.md#sklearn.tree.DecisionTreeRegressor).
    <br/>
    #### Versionadded
    Added in version 1.2: `base_estimator` was renamed to `estimator`.

  **n_estimators**
  : The number of base estimators in the ensemble.

  **max_samples**
  : The number of samples to draw from X to train each base estimator (with
    replacement by default, see `bootstrap` for more details).
    - If int, then draw `max_samples` samples.
    - If float, then draw `max_samples * X.shape[0]` samples.

  **max_features**
  : The number of features to draw from X to train each base estimator (
    without replacement by default, see `bootstrap_features` for more
    details).
    - If int, then draw `max_features` features.
    - If float, then draw `max(1, int(max_features * n_features_in_))` features.

  **bootstrap**
  : Whether samples are drawn with replacement. If False, sampling
    without replacement is performed.

  **bootstrap_features**
  : Whether features are drawn with replacement.

  **oob_score**
  : Whether to use out-of-bag samples to estimate
    the generalization error. Only available if bootstrap=True.

  **warm_start**
  : When set to True, reuse the solution of the previous call to fit
    and add more estimators to the ensemble, otherwise, just fit
    a whole new ensemble. See [the Glossary](../../glossary.md#term-warm_start).

  **n_jobs**
  : The number of jobs to run in parallel for both [`fit`](#sklearn.ensemble.BaggingRegressor.fit) and
    [`predict`](#sklearn.ensemble.BaggingRegressor.predict). `None` means 1 unless in a
    [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context. `-1` means using all
    processors. See [Glossary](../../glossary.md#term-n_jobs) for more details.

  **random_state**
  : Controls the random resampling of the original dataset
    (sample wise and feature wise).
    If the base estimator accepts a `random_state` attribute, a different
    seed is generated for each instance in the ensemble.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **verbose**
  : Controls the verbosity when fitting and predicting.
* **Attributes:**
  **estimator_**
  : The base estimator from which the ensemble is grown.
    <br/>
    #### Versionadded
    Added in version 1.2: `base_estimator_` was renamed to `estimator_`.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **estimators_**
  : The collection of fitted sub-estimators.

  [`estimators_samples_`](#sklearn.ensemble.BaggingRegressor.estimators_samples_)
  : The subset of drawn samples for each base estimator.

  **estimators_features_**
  : The subset of drawn features for each base estimator.

  **oob_score_**
  : Score of the training dataset obtained using an out-of-bag estimate.
    This attribute exists only when `oob_score` is True.

  **oob_prediction_**
  : Prediction computed with out-of-bag estimate on the training
    set. If n_estimators is small it might be possible that a data point
    was never left out during the bootstrap. In this case,
    `oob_prediction_` might contain NaN. This attribute exists only
    when `oob_score` is True.

#### SEE ALSO
[`BaggingClassifier`](sklearn.ensemble.BaggingClassifier.md#sklearn.ensemble.BaggingClassifier)
: A Bagging classifier.

### References

### Examples

```pycon
>>> from sklearn.svm import SVR
>>> from sklearn.ensemble import BaggingRegressor
>>> from sklearn.datasets import make_regression
>>> X, y = make_regression(n_samples=100, n_features=4,
...                        n_informative=2, n_targets=1,
...                        random_state=0, shuffle=False)
>>> regr = BaggingRegressor(estimator=SVR(),
...                         n_estimators=10, random_state=0).fit(X, y)
>>> regr.predict([[0, 0, 0, 0]])
array([-2.8720...])
```

<!-- !! processed by numpydoc !! -->

#### *property* estimators_samples_

The subset of drawn samples for each base estimator.

Returns a dynamically generated list of indices identifying
the samples used for fitting each member of the ensemble, i.e.,
the in-bag samples.

Note: the list is re-created at each call to the property in order
to reduce the object memory footprint by not storing the sampling
data. Thus fetching the property may be slower than expected.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*, sample_weight=None, \*\*fit_params)

Build a Bagging ensemble of estimators from the training set (X, y).

* **Parameters:**
  **X**
  : The training input samples. Sparse matrices are accepted only if
    they are supported by the base estimator.

  **y**
  : The target values (class labels in classification, real numbers in
    regression).

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted.
    Note that this is supported only if the base estimator supports
    sample weighting.

  **\*\*fit_params**
  : Parameters to pass to the underlying estimators.
    <br/>
    #### Versionadded
    Added in version 1.5: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.5.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict regression target for X.

The predicted regression target of an input sample is computed as the
mean predicted regression targets of the estimators in the ensemble.

* **Parameters:**
  **X**
  : The training input samples. Sparse matrices are accepted only if
    they are supported by the base estimator.
* **Returns:**
  **y**
  : The predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BaggingRegressor](#sklearn.ensemble.BaggingRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [BaggingRegressor](#sklearn.ensemble.BaggingRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares the bias-variance decomposition of the expected mean squared error of a single estimator against a bagging ensemble.">  <div class="sphx-glr-thumbnail-title">Single estimator versus bagging: bias-variance decomposition</div>
</div>
* [Single estimator versus bagging: bias-variance decomposition](../../auto_examples/ensemble/plot_bias_variance.md#sphx-glr-auto-examples-ensemble-plot-bias-variance-py)

<!-- thumbnail-parent-div-close --></div>
