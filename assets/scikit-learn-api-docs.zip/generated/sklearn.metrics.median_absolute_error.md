# median_absolute_error

### sklearn.metrics.median_absolute_error(y_true, y_pred, \*, multioutput='uniform_average', sample_weight=None)

Median absolute error regression loss.

Median absolute error output is non-negative floating point. The best value
is 0.0. Read more in the [User Guide](../model_evaluation.md#median-absolute-error).

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated target values.

  **multioutput**
  : Defines aggregating of multiple output values. Array-like value defines
    weights used to average errors.
    <br/>
    ‘raw_values’ :
    : Returns a full set of errors in case of multioutput input.
    <br/>
    ‘uniform_average’ :
    : Errors of all outputs are averaged with uniform weight.

  **sample_weight**
  : Sample weights.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Returns:**
  **loss**
  : If multioutput is ‘raw_values’, then mean absolute error is returned
    for each output separately.
    If multioutput is ‘uniform_average’ or an ndarray of weights, then the
    weighted average of all output errors is returned.

### Examples

```pycon
>>> from sklearn.metrics import median_absolute_error
>>> y_true = [3, -0.5, 2, 7]
>>> y_pred = [2.5, 0.0, 2, 8]
>>> median_absolute_error(y_true, y_pred)
np.float64(0.5)
>>> y_true = [[0.5, 1], [-1, 1], [7, -6]]
>>> y_pred = [[0, 2], [-1, 2], [8, -5]]
>>> median_absolute_error(y_true, y_pred)
np.float64(0.75)
>>> median_absolute_error(y_true, y_pred, multioutput='raw_values')
array([0.5, 1. ])
>>> median_absolute_error(y_true, y_pred, multioutput=[0.3, 0.7])
np.float64(0.85)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we give an overview of TransformedTargetRegressor. We use two examples to illustrate the benefit of transforming the targets before learning a linear regression model. The first example uses synthetic data while the second example is based on the Ames housing data set.">  <div class="sphx-glr-thumbnail-title">Effect of transforming the targets in regression model</div>
</div>
* [Effect of transforming the targets in regression model](../../auto_examples/compose/plot_transformed_target.md#sphx-glr-auto-examples-compose-plot-transformed-target-py)

<div class="sphx-glr-thumbcontainer" tooltip="In linear models, the target value is modeled as a linear combination of the features (see the linear_model User Guide section for a description of a set of linear models available in scikit-learn). Coefficients in multiple linear models represent the relationship between the given feature, X_i and the target, y, assuming that all the other features remain constant (conditional dependence). This is different from plotting X_i versus y and fitting a linear relationship: in that case all possible values of the other features are taken into account in the estimation (marginal dependence).">  <div class="sphx-glr-thumbnail-title">Common pitfalls in the interpretation of coefficients of linear models</div>
</div>
* [Common pitfalls in the interpretation of coefficients of linear models](../../auto_examples/inspection/plot_linear_model_coefficient_interpretation.md#sphx-glr-auto-examples-inspection-plot-linear-model-coefficient-interpretation-py)

<!-- thumbnail-parent-div-close --></div>
