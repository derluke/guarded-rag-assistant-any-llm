# \_safe_indexing

### sklearn.utils.\_safe_indexing(X, indices, \*, axis=0)

Return rows, items or columns of X using indices.

#### WARNING
This utility is documented, but **private**. This means that
backward compatibility might be broken without any deprecation
cycle.

* **Parameters:**
  **X**
  : Data from which to sample rows, items or columns. `list` are only
    supported when `axis=0`.

  **indices**
  : - If `axis=0`, boolean and integer array-like, integer slice,
      and scalar integer are supported.
    - If `axis=1`:
      : - to select a single column, `indices` can be of `int` type for
          all `X` types and `str` only for dataframe. The selected subset
          will be 1D, unless `X` is a sparse matrix in which case it will
          be 2D.
        - to select multiples columns, `indices` can be one of the
          following: `list`, `array`, `slice`. The type used in
          these containers can be one of the following: `int`, ‘bool’ and
          `str`. However, `str` is only supported when `X` is a dataframe.
          The selected subset will be 2D.

  **axis**
  : The axis along which `X` will be subsampled. `axis=0` will select
    rows while `axis=1` will select columns.
* **Returns:**
  subset
  : Subset of X on axis 0 or 1.

### Notes

CSR, CSC, and LIL sparse matrices are supported. COO sparse matrices are
not supported.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.utils import _safe_indexing
>>> data = np.array([[1, 2], [3, 4], [5, 6]])
>>> _safe_indexing(data, 0, axis=0)  # select the first row
array([1, 2])
>>> _safe_indexing(data, 0, axis=1)  # select the first column
array([1, 3, 5])
```

<!-- !! processed by numpydoc !! -->
