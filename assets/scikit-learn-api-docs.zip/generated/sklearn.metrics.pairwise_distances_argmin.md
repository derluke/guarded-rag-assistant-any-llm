# pairwise_distances_argmin

### sklearn.metrics.pairwise_distances_argmin(X, Y, \*, axis=1, metric='euclidean', metric_kwargs=None)

Compute minimum distances between one point and a set of points.

This function computes for each row in X, the index of the row of Y which
is closest (according to the specified distance).

This is mostly equivalent to calling:

```default
pairwise_distances(X, Y=Y, metric=metric).argmin(axis=axis)
```

but uses much less memory, and is faster for large arrays.

This function works with dense 2D arrays only.

* **Parameters:**
  **X**
  : Array containing points.

  **Y**
  : Arrays containing points.

  **axis**
  : Axis along which the argmin and distances are to be computed.

  **metric**
  : Metric to use for distance computation. Any metric from scikit-learn
    or scipy.spatial.distance can be used.
    <br/>
    If metric is a callable function, it is called on each
    pair of instances (rows) and the resulting value recorded. The callable
    should take two arrays as input and return one value indicating the
    distance between them. This works for Scipy’s metrics, but is less
    efficient than passing the metric name as a string.
    <br/>
    Distance matrices are not supported.
    <br/>
    Valid values for metric are:
    - from scikit-learn: [‘cityblock’, ‘cosine’, ‘euclidean’, ‘l1’, ‘l2’,
      ‘manhattan’, ‘nan_euclidean’]
    - from scipy.spatial.distance: [‘braycurtis’, ‘canberra’, ‘chebyshev’,
      ‘correlation’, ‘dice’, ‘hamming’, ‘jaccard’, ‘kulsinski’,
      ‘mahalanobis’, ‘minkowski’, ‘rogerstanimoto’, ‘russellrao’,
      ‘seuclidean’, ‘sokalmichener’, ‘sokalsneath’, ‘sqeuclidean’,
      ‘yule’]
    <br/>
    See the documentation for scipy.spatial.distance for details on these
    metrics.
    <br/>
    #### NOTE
    `'kulsinski'` is deprecated from SciPy 1.9 and will be removed in SciPy 1.11.
    <br/>
    #### NOTE
    `'matching'` has been removed in SciPy 1.9 (use `'hamming'` instead).

  **metric_kwargs**
  : Keyword arguments to pass to specified metric function.
* **Returns:**
  **argmin**
  : Y[argmin[i], :] is the row in Y that is closest to X[i, :].

#### SEE ALSO
[`pairwise_distances`](sklearn.metrics.pairwise_distances.md#sklearn.metrics.pairwise_distances)
: Distances between every pair of samples of X and Y.

[`pairwise_distances_argmin_min`](sklearn.metrics.pairwise_distances_argmin_min.md#sklearn.metrics.pairwise_distances_argmin_min)
: Same as `pairwise_distances_argmin` but also returns the distances.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import pairwise_distances_argmin
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> pairwise_distances_argmin(X, Y)
array([0, 1])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="We want to compare the performance of the MiniBatchKMeans and KMeans: the MiniBatchKMeans is faster, but gives slightly different results (see mini_batch_kmeans).">  <div class="sphx-glr-thumbnail-title">Comparison of the K-Means and MiniBatchKMeans clustering algorithms</div>
</div>
* [Comparison of the K-Means and MiniBatchKMeans clustering algorithms](../../auto_examples/cluster/plot_mini_batch_kmeans.md#sphx-glr-auto-examples-cluster-plot-mini-batch-kmeans-py)

<!-- thumbnail-parent-div-close --></div>
