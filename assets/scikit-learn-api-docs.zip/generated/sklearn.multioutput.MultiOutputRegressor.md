# MultiOutputRegressor

### *class* sklearn.multioutput.MultiOutputRegressor(estimator, \*, n_jobs=None)

Multi target regression.

This strategy consists of fitting one regressor per target. This is a
simple strategy for extending regressors that do not natively support
multi-target regression.

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **estimator**
  : An estimator object implementing [fit](../../glossary.md#term-fit) and [predict](../../glossary.md#term-predict).

  **n_jobs**
  : The number of jobs to run in parallel.
    [`fit`](#sklearn.multioutput.MultiOutputRegressor.fit), [`predict`](#sklearn.multioutput.MultiOutputRegressor.predict) and [`partial_fit`](#sklearn.multioutput.MultiOutputRegressor.partial_fit) (if supported
    by the passed estimator) will be parallelized for each target.
    <br/>
    When individual estimators are fast to train or predict,
    using `n_jobs > 1` can result in slower performance due
    to the parallelism overhead.
    <br/>
    `None` means `1` unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all available processes / threads.
    See [Glossary](../../glossary.md#term-n_jobs) for more details.
    <br/>
    #### Versionchanged
    Changed in version 0.20: `n_jobs` default changed from `1` to `None`.
* **Attributes:**
  **estimators_**
  : Estimators used for predictions.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying `estimator` exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimators expose such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`RegressorChain`](sklearn.multioutput.RegressorChain.md#sklearn.multioutput.RegressorChain)
: A multi-label model that arranges regressions into a chain.

[`MultiOutputClassifier`](sklearn.multioutput.MultiOutputClassifier.md#sklearn.multioutput.MultiOutputClassifier)
: Classifies each output independently rather than chaining.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.datasets import load_linnerud
>>> from sklearn.multioutput import MultiOutputRegressor
>>> from sklearn.linear_model import Ridge
>>> X, y = load_linnerud(return_X_y=True)
>>> regr = MultiOutputRegressor(Ridge(random_state=123)).fit(X, y)
>>> regr.predict(X[[0]])
array([[176..., 35..., 57...]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, \*\*fit_params)

Fit the model to data, separately for each output variable.

* **Parameters:**
  **X**
  : The input data.

  **y**
  : Multi-output targets. An indicator matrix turns on multilabel
    estimation.

  **sample_weight**
  : Sample weights. If `None`, then samples are equally weighted.
    Only supported if the underlying regressor supports sample
    weights.

  **\*\*fit_params**
  : Parameters passed to the `estimator.fit` method of each step.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **self**
  : Returns a fitted instance.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.3.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y, sample_weight=None, \*\*partial_fit_params)

Incrementally fit the model to data, for each output variable.

* **Parameters:**
  **X**
  : The input data.

  **y**
  : Multi-output targets.

  **sample_weight**
  : Sample weights. If `None`, then samples are equally weighted.
    Only supported if the underlying regressor supports sample
    weights.

  **\*\*partial_fit_params**
  : Parameters passed to the `estimator.partial_fit` method of each
    sub-estimator.
    <br/>
    Only available if `enable_metadata_routing=True`. See the
    [User Guide](../../metadata_routing.md#metadata-routing).
    <br/>
    #### Versionadded
    Added in version 1.3.
* **Returns:**
  **self**
  : Returns a fitted instance.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict multi-output variable using model for each target variable.

* **Parameters:**
  **X**
  : The input data.
* **Returns:**
  **y**
  : Multi-output targets predicted across multiple predictors.
    Note: Separate models are generated for each predictor.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [MultiOutputRegressor](#sklearn.multioutput.MultiOutputRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [MultiOutputRegressor](#sklearn.multioutput.MultiOutputRegressor)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [MultiOutputRegressor](#sklearn.multioutput.MultiOutputRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An example to compare multi-output regression with random forest and the multiclass meta-estimator.">  <div class="sphx-glr-thumbnail-title">Comparing random forests and the multi-output meta estimator</div>
</div>
* [Comparing random forests and the multi-output meta estimator](../../auto_examples/ensemble/plot_random_forest_regression_multioutput.md#sphx-glr-auto-examples-ensemble-plot-random-forest-regression-multioutput-py)

<!-- thumbnail-parent-div-close --></div>
