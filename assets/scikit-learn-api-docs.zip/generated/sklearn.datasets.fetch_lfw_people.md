# fetch_lfw_people

### sklearn.datasets.fetch_lfw_people(\*, data_home=None, funneled=True, resize=0.5, min_faces_per_person=0, color=False, slice_=(slice(70, 195, None), slice(78, 172, None)), download_if_missing=True, return_X_y=False, n_retries=3, delay=1.0)

Load the Labeled Faces in the Wild (LFW) people dataset (classification).

Download it if necessary.

| Classes        | 5749                    |
|----------------|-------------------------|
| Samples total  | 13233                   |
| Dimensionality | 5828                    |
| Features       | real, between 0 and 255 |

For a usage example of this dataset, see
[Faces recognition example using eigenfaces and SVMs](../../auto_examples/applications/plot_face_recognition.md#sphx-glr-auto-examples-applications-plot-face-recognition-py).

Read more in the [User Guide](../../datasets/real_world.md#labeled-faces-in-the-wild-dataset).

* **Parameters:**
  **data_home**
  : Specify another download and cache folder for the datasets. By default
    all scikit-learn data is stored in ‘~/scikit_learn_data’ subfolders.

  **funneled**
  : Download and use the funneled variant of the dataset.

  **resize**
  : Ratio used to resize the each face picture. If `None`, no resizing is
    performed.

  **min_faces_per_person**
  : The extracted dataset will only retain pictures of people that have at
    least `min_faces_per_person` different pictures.

  **color**
  : Keep the 3 RGB channels instead of averaging them to a single
    gray level channel. If color is True the shape of the data has
    one more dimension than the shape with color = False.

  **slice_**
  : Provide a custom 2D slice (height, width) to extract the
    ‘interesting’ part of the jpeg files and avoid use statistical
    correlation from the background.

  **download_if_missing**
  : If False, raise an OSError if the data is not locally available
    instead of trying to download the data from the source site.

  **return_X_y**
  : If True, returns `(dataset.data, dataset.target)` instead of a Bunch
    object. See below for more information about the `dataset.data` and
    `dataset.target` object.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **n_retries**
  : Number of retries when HTTP errors are encountered.
    <br/>
    #### Versionadded
    Added in version 1.5.

  **delay**
  : Number of seconds between retries.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **dataset**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : Each row corresponds to a ravelled face image
      of original size 62 x 47 pixels.
      Changing the `slice_` or resize parameters will change the
      shape of the output.
    <br/>
    images
    : Each row is a face image corresponding to one of the 5749 people in
      the dataset. Changing the `slice_`
      or resize parameters will change the shape of the output.
    <br/>
    target
    : Labels associated to each face image.
      Those labels range from 0-5748 and correspond to the person IDs.
    <br/>
    target_names
    : Names of all persons in the dataset.
      Position in array corresponds to the person ID in the target array.
    <br/>
    DESCR
    : Description of the Labeled Faces in the Wild (LFW) dataset.

  **(data, target)**
  : A tuple of two ndarray. The first containing a 2D array of
    shape (n_samples, n_features) with each row representing one
    sample and each column representing the features. The second
    ndarray of shape (n_samples,) containing the target samples.
    <br/>
    #### Versionadded
    Added in version 0.20.

### Examples

```pycon
>>> from sklearn.datasets import fetch_lfw_people
>>> lfw_people = fetch_lfw_people()
>>> lfw_people.data.shape
(13233, 2914)
>>> lfw_people.target.shape
(13233,)
>>> for name in lfw_people.target_names[:5]:
...    print(name)
AJ Cook
AJ Lamas
Aaron Eckhart
Aaron Guiel
Aaron Patterson
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is a preprocessed excerpt of the &quot;Labeled Faces in the Wild&quot;, aka LFW_: http://vis-www.cs.umass.edu/lfw/lfw-funneled.tgz (233MB)">  <div class="sphx-glr-thumbnail-title">Faces recognition example using eigenfaces and SVMs</div>
</div>
* [Faces recognition example using eigenfaces and SVMs](../../auto_examples/applications/plot_face_recognition.md#sphx-glr-auto-examples-applications-plot-face-recognition-py)

<!-- thumbnail-parent-div-close --></div>
