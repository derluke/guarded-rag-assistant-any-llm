# det_curve

### sklearn.metrics.det_curve(y_true, y_score, pos_label=None, sample_weight=None)

Compute error rates for different probability thresholds.

#### NOTE
This metric is used for evaluation of ranking and error tradeoffs of
a binary classification task.

Read more in the [User Guide](../model_evaluation.md#det-curve).

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **y_true**
  : True binary labels. If labels are not either {-1, 1} or {0, 1}, then
    pos_label should be explicitly given.

  **y_score**
  : Target scores, can either be probability estimates of the positive
    class, confidence values, or non-thresholded measure of decisions
    (as returned by “decision_function” on some classifiers).
    For [decision_function](../../glossary.md#term-decision_function) scores, values greater than or equal to
    zero should indicate the positive class.

  **pos_label**
  : The label of the positive class.
    When `pos_label=None`, if `y_true` is in {-1, 1} or {0, 1},
    `pos_label` is set to 1, otherwise an error will be raised.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **fpr**
  : False positive rate (FPR) such that element i is the false positive
    rate of predictions with score >= thresholds[i]. This is occasionally
    referred to as false acceptance probability or fall-out.

  **fnr**
  : False negative rate (FNR) such that element i is the false negative
    rate of predictions with score >= thresholds[i]. This is occasionally
    referred to as false rejection or miss rate.

  **thresholds**
  : Decreasing score values.

#### SEE ALSO
[`DetCurveDisplay.from_estimator`](sklearn.metrics.DetCurveDisplay.md#sklearn.metrics.DetCurveDisplay.from_estimator)
: Plot DET curve given an estimator and some data.

[`DetCurveDisplay.from_predictions`](sklearn.metrics.DetCurveDisplay.md#sklearn.metrics.DetCurveDisplay.from_predictions)
: Plot DET curve given the true and predicted labels.

[`DetCurveDisplay`](sklearn.metrics.DetCurveDisplay.md#sklearn.metrics.DetCurveDisplay)
: DET curve visualization.

[`roc_curve`](sklearn.metrics.roc_curve.md#sklearn.metrics.roc_curve)
: Compute Receiver operating characteristic (ROC) curve.

[`precision_recall_curve`](sklearn.metrics.precision_recall_curve.md#sklearn.metrics.precision_recall_curve)
: Compute precision-recall curve.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.metrics import det_curve
>>> y_true = np.array([0, 0, 1, 1])
>>> y_scores = np.array([0.1, 0.4, 0.35, 0.8])
>>> fpr, fnr, thresholds = det_curve(y_true, y_scores)
>>> fpr
array([0.5, 0.5, 0. ])
>>> fnr
array([0. , 0.5, 0.5])
>>> thresholds
array([0.35, 0.4 , 0.8 ])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we compare two binary classification multi-threshold metrics: the Receiver Operating Characteristic (ROC) and the Detection Error Tradeoff (DET). For such purpose, we evaluate two different classifiers for the same classification task.">  <div class="sphx-glr-thumbnail-title">Detection error tradeoff (DET) curve</div>
</div>
* [Detection error tradeoff (DET) curve](../../auto_examples/model_selection/plot_det.md#sphx-glr-auto-examples-model-selection-plot-det-py)

<!-- thumbnail-parent-div-close --></div>
