# KBinsDiscretizer

### *class* sklearn.preprocessing.KBinsDiscretizer(n_bins=5, \*, encode='onehot', strategy='quantile', dtype=None, subsample=200000, random_state=None)

Bin continuous data into intervals.

Read more in the [User Guide](../preprocessing.md#preprocessing-discretization).

#### Versionadded
Added in version 0.20.

* **Parameters:**
  **n_bins**
  : The number of bins to produce. Raises ValueError if `n_bins < 2`.

  **encode**
  : Method used to encode the transformed result.
    - ‘onehot’: Encode the transformed result with one-hot encoding
      and return a sparse matrix. Ignored features are always
      stacked to the right.
    - ‘onehot-dense’: Encode the transformed result with one-hot encoding
      and return a dense array. Ignored features are always
      stacked to the right.
    - ‘ordinal’: Return the bin identifier encoded as an integer value.

  **strategy**
  : Strategy used to define the widths of the bins.
    - ‘uniform’: All bins in each feature have identical widths.
    - ‘quantile’: All bins in each feature have the same number of points.
    - ‘kmeans’: Values in each bin have the same nearest center of a 1D
      k-means cluster.
    <br/>
    For an example of the different strategies see:
    [Demonstrating the different strategies of KBinsDiscretizer](../../auto_examples/preprocessing/plot_discretization_strategies.md#sphx-glr-auto-examples-preprocessing-plot-discretization-strategies-py).

  **dtype**
  : The desired data-type for the output. If None, output dtype is
    consistent with input dtype. Only np.float32 and np.float64 are
    supported.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **subsample**
  : Maximum number of samples, used to fit the model, for computational
    efficiency.
    `subsample=None` means that all the training samples are used when
    computing the quantiles that determine the binning thresholds.
    Since quantile computation relies on sorting each column of `X` and
    that sorting has an `n log(n)` time complexity,
    it is recommended to use subsampling on datasets with a
    very large number of samples.
    <br/>
    #### Versionchanged
    Changed in version 1.3: The default value of `subsample` changed from `None` to `200_000` when
    `strategy="quantile"`.
    <br/>
    #### Versionchanged
    Changed in version 1.5: The default value of `subsample` changed from `None` to `200_000` when
    `strategy="uniform"` or `strategy="kmeans"`.

  **random_state**
  : Determines random number generation for subsampling.
    Pass an int for reproducible results across multiple function calls.
    See the `subsample` parameter for more details.
    See [Glossary](../../glossary.md#term-random_state).
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Attributes:**
  **bin_edges_**
  : The edges of each bin. Contain arrays of varying shapes `(n_bins_, )`
    Ignored features will have empty arrays.

  **n_bins_**
  : Number of bins per feature. Bins whose width are too small
    (i.e., <= 1e-8) are removed with a warning.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`Binarizer`](sklearn.preprocessing.Binarizer.md#sklearn.preprocessing.Binarizer)
: Class used to bin values as `0` or `1` based on a parameter `threshold`.

### Notes

For a visualization of discretization on different datasets refer to
[Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py).
On the effect of discretization on linear models see:
[Using KBinsDiscretizer to discretize continuous features](../../auto_examples/preprocessing/plot_discretization.md#sphx-glr-auto-examples-preprocessing-plot-discretization-py).

In bin edges for feature `i`, the first and last values are used only for
`inverse_transform`. During transform, bin edges are extended to:

```default
np.concatenate([-np.inf, bin_edges_[i][1:-1], np.inf])
```

You can combine `KBinsDiscretizer` with
[`ColumnTransformer`](sklearn.compose.ColumnTransformer.md#sklearn.compose.ColumnTransformer) if you only want to preprocess
part of the features.

`KBinsDiscretizer` might produce constant features (e.g., when
`encode = 'onehot'` and certain bins do not contain any data).
These features can be removed with feature selection algorithms
(e.g., [`VarianceThreshold`](sklearn.feature_selection.VarianceThreshold.md#sklearn.feature_selection.VarianceThreshold)).

### Examples

```pycon
>>> from sklearn.preprocessing import KBinsDiscretizer
>>> X = [[-2, 1, -4,   -1],
...      [-1, 2, -3, -0.5],
...      [ 0, 3, -2,  0.5],
...      [ 1, 4, -1,    2]]
>>> est = KBinsDiscretizer(
...     n_bins=3, encode='ordinal', strategy='uniform'
... )
>>> est.fit(X)
KBinsDiscretizer(...)
>>> Xt = est.transform(X)
>>> Xt  
array([[ 0., 0., 0., 0.],
       [ 1., 1., 1., 0.],
       [ 2., 2., 2., 1.],
       [ 2., 2., 2., 2.]])
```

Sometimes it may be useful to convert the data back into the original
feature space. The `inverse_transform` function converts the binned
data into the original feature space. Each value will be equal to the mean
of the two bin edges.

```pycon
>>> est.bin_edges_[0]
array([-2., -1.,  0.,  1.])
>>> est.inverse_transform(Xt)
array([[-1.5,  1.5, -3.5, -0.5],
       [-0.5,  2.5, -2.5, -0.5],
       [ 0.5,  3.5, -1.5,  0.5],
       [ 0.5,  3.5, -1.5,  1.5]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Fit the estimator.

* **Parameters:**
  **X**
  : Data to be discretized.

  **y**
  : Ignored. This parameter exists only for compatibility with
    [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline).

  **sample_weight**
  : Contains weight values to be associated with each sample.
    Cannot be used when `strategy` is set to `"uniform"`.
    <br/>
    #### Versionadded
    Added in version 1.3.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X=None, \*, Xt=None)

Transform discretized data back to original feature space.

Note that this function does not regenerate the original data
due to discretization rounding.

* **Parameters:**
  **X**
  : Transformed data in the binned space.

  **Xt**
  : Transformed data in the binned space.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Xt` was deprecated in 1.5 and will be removed in 1.7. Use `X` instead.
* **Returns:**
  **Xinv**
  : Data in the original feature space.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [KBinsDiscretizer](#sklearn.preprocessing.KBinsDiscretizer)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Discretize the data.

* **Parameters:**
  **X**
  : Data to be discretized.
* **Returns:**
  **Xt**
  : Data in the binned space. Will be a sparse matrix if
    `self.encode='onehot'` and ndarray otherwise.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how one can use KBinsDiscretizer to perform vector quantization on a set of toy image, the raccoon face.">  <div class="sphx-glr-thumbnail-title">Vector Quantization Example</div>
</div>
* [Vector Quantization Example](../../auto_examples/cluster/plot_face_compress.md#sphx-glr-auto-examples-cluster-plot-face-compress-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Poisson, Gamma and Tweedie regression on the French Motor Third-Party Liability Claims dataset, and is inspired by an R tutorial [1]_.">  <div class="sphx-glr-thumbnail-title">Tweedie regression on insurance claims</div>
</div>
* [Tweedie regression on insurance claims](../../auto_examples/linear_model/plot_tweedie_regression_insurance_claims.md#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents the different strategies implemented in KBinsDiscretizer:">  <div class="sphx-glr-thumbnail-title">Demonstrating the different strategies of KBinsDiscretizer</div>
</div>
* [Demonstrating the different strategies of KBinsDiscretizer](../../auto_examples/preprocessing/plot_discretization_strategies.md#sphx-glr-auto-examples-preprocessing-plot-discretization-strategies-py)

<div class="sphx-glr-thumbcontainer" tooltip="A demonstration of feature discretization on synthetic classification datasets. Feature discretization decomposes each feature into a set of bins, here equally distributed in width. The discrete values are then one-hot encoded, and given to a linear classifier. This preprocessing enables a non-linear behavior even though the classifier is linear.">  <div class="sphx-glr-thumbnail-title">Feature discretization</div>
</div>
* [Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="The TargetEncoder replaces each category of a categorical feature with the shrunk mean of the target variable for that category. This method is useful in cases where there is a strong relationship between the categorical feature and the target. To prevent overfitting, TargetEncoder.fit_transform uses an internal cross fitting scheme to encode the training data to be used by a downstream model. This scheme involves splitting the data into k folds and encoding each fold using the encodings learnt using the other k-1 folds. In this example, we demonstrate the importance of the cross fitting procedure to prevent overfitting.">  <div class="sphx-glr-thumbnail-title">Target Encoder's Internal Cross fitting</div>
</div>
* [Target Encoder’s Internal Cross fitting](../../auto_examples/preprocessing/plot_target_encoder_cross_val.md#sphx-glr-auto-examples-preprocessing-plot-target-encoder-cross-val-py)

<div class="sphx-glr-thumbcontainer" tooltip="The example compares prediction result of linear regression (linear model) and decision tree (tree based model) with and without discretization of real-valued features.">  <div class="sphx-glr-thumbnail-title">Using KBinsDiscretizer to discretize continuous features</div>
</div>
* [Using KBinsDiscretizer to discretize continuous features](../../auto_examples/preprocessing/plot_discretization.md#sphx-glr-auto-examples-preprocessing-plot-discretization-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.2! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_2&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.2</div>
</div>
* [Release Highlights for scikit-learn 1.2](../../auto_examples/release_highlights/plot_release_highlights_1_2_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-2-0-py)

<!-- thumbnail-parent-div-close --></div>
