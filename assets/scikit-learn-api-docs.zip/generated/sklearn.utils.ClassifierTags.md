# ClassifierTags

### *class* sklearn.utils.ClassifierTags(poor_score: [bool](https://docs.python.org/3/library/functions.html#bool) = False, multi_class: [bool](https://docs.python.org/3/library/functions.html#bool) = True, multi_label: [bool](https://docs.python.org/3/library/functions.html#bool) = False)

Tags for the classifier.

* **Parameters:**
  **poor_score**
  : Whether the estimator fails to provide a “reasonable” test-set
    score, which currently for classification is an accuracy of
    0.83 on `make_blobs(n_samples=300, random_state=0)`. The
    datasets and values are based on current estimators in scikit-learn
    and might be replaced by something more systematic.

  **multi_class**
  : Whether the classifier can handle multi-class
    classification. Note that all classifiers support binary
    classification. Therefore this flag indicates whether the
    classifier is a binary-classifier-only or not.
    <br/>
    See [multi-class](../../glossary.md#term-multi-class) in the glossary.

  **multi_label**
  : Whether the classifier supports multi-label output: a data point can
    be predicted to belong to a variable number of classes.
    <br/>
    See [multi-label](../../glossary.md#term-multi-label) in the glossary.

<!-- !! processed by numpydoc !! -->
