# fetch_olivetti_faces

### sklearn.datasets.fetch_olivetti_faces(\*, data_home=None, shuffle=False, random_state=0, download_if_missing=True, return_X_y=False, n_retries=3, delay=1.0)

Load the Olivetti faces data-set from AT&T (classification).

Download it if necessary.

| Classes        | 40                    |
|----------------|-----------------------|
| Samples total  | 400                   |
| Dimensionality | 4096                  |
| Features       | real, between 0 and 1 |

Read more in the [User Guide](../../datasets/real_world.md#olivetti-faces-dataset).

* **Parameters:**
  **data_home**
  : Specify another download and cache folder for the datasets. By default
    all scikit-learn data is stored in ‘~/scikit_learn_data’ subfolders.

  **shuffle**
  : If True the order of the dataset is shuffled to avoid having
    images of the same person grouped.

  **random_state**
  : Determines random number generation for dataset shuffling. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **download_if_missing**
  : If False, raise an OSError if the data is not locally available
    instead of trying to download the data from the source site.

  **return_X_y**
  : If True, returns `(data, target)` instead of a `Bunch` object. See
    below for more information about the `data` and `target` object.
    <br/>
    #### Versionadded
    Added in version 0.22.

  **n_retries**
  : Number of retries when HTTP errors are encountered.
    <br/>
    #### Versionadded
    Added in version 1.5.

  **delay**
  : Number of seconds between retries.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    data: ndarray, shape (400, 4096)
    : Each row corresponds to a ravelled
      face image of original size 64 x 64 pixels.
    <br/>
    images
    : Each row is a face image
      corresponding to one of the 40 subjects of the dataset.
    <br/>
    target
    : Labels associated to each face image.
      Those labels are ranging from 0-39 and correspond to the
      Subject IDs.
    <br/>
    DESCR
    : Description of the modified Olivetti Faces Dataset.

  **(data, target)**
  : Tuple with the `data` and `target` objects described above.
    <br/>
    #### Versionadded
    Added in version 0.22.

### Examples

```pycon
>>> from sklearn.datasets import fetch_olivetti_faces
>>> olivetti_faces = fetch_olivetti_faces()
>>> olivetti_faces.data.shape
(400, 4096)
>>> olivetti_faces.target.shape
(400,)
>>> olivetti_faces.images.shape
(400, 64, 64)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example uses a large dataset of faces to learn a set of 20 x 20 images patches that constitute faces.">  <div class="sphx-glr-thumbnail-title">Online learning of a dictionary of parts of faces</div>
</div>
* [Online learning of a dictionary of parts of faces](../../auto_examples/cluster/plot_dict_face_patches.md#sphx-glr-auto-examples-cluster-plot-dict-face-patches-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example applies to olivetti_faces_dataset different unsupervised matrix decomposition (dimension reduction) methods from the module sklearn.decomposition (see the documentation chapter decompositions).">  <div class="sphx-glr-thumbnail-title">Faces dataset decompositions</div>
</div>
* [Faces dataset decompositions](../../auto_examples/decomposition/plot_faces_decomposition.md#sphx-glr-auto-examples-decomposition-plot-faces-decomposition-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows the use of multi-output estimator to complete images. The goal is to predict the lower half of a face given its upper half.">  <div class="sphx-glr-thumbnail-title">Face completion with a multi-output estimators</div>
</div>
* [Face completion with a multi-output estimators](../../auto_examples/miscellaneous/plot_multioutput_face_completion.md#sphx-glr-auto-examples-miscellaneous-plot-multioutput-face-completion-py)

<!-- thumbnail-parent-div-close --></div>
