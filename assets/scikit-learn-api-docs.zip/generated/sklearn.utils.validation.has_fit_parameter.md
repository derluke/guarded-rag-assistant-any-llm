# has_fit_parameter

### sklearn.utils.validation.has_fit_parameter(estimator, parameter)

Check whether the estimator’s fit method supports the given parameter.

* **Parameters:**
  **estimator**
  : An estimator to inspect.

  **parameter**
  : The searched parameter.
* **Returns:**
  **is_parameter**
  : Whether the parameter was found to be a named parameter of the
    estimator’s fit method.

### Examples

```pycon
>>> from sklearn.svm import SVC
>>> from sklearn.utils.validation import has_fit_parameter
>>> has_fit_parameter(SVC(), "sample_weight")
True
```

<!-- !! processed by numpydoc !! -->
