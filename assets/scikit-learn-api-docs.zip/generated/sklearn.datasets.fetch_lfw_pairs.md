# fetch_lfw_pairs

### sklearn.datasets.fetch_lfw_pairs(\*, subset='train', data_home=None, funneled=True, resize=0.5, color=False, slice_=(slice(70, 195, None), slice(78, 172, None)), download_if_missing=True, n_retries=3, delay=1.0)

Load the Labeled Faces in the Wild (LFW) pairs dataset (classification).

Download it if necessary.

| Classes        | 2                       |
|----------------|-------------------------|
| Samples total  | 13233                   |
| Dimensionality | 5828                    |
| Features       | real, between 0 and 255 |

In the official [README.txt](http://vis-www.cs.umass.edu/lfw/README.txt) this task is described as the
“Restricted” task.  As I am not sure as to implement the
“Unrestricted” variant correctly, I left it as unsupported for now.

The original images are 250 x 250 pixels, but the default slice and resize
arguments reduce them to 62 x 47.

Read more in the [User Guide](../../datasets/real_world.md#labeled-faces-in-the-wild-dataset).

* **Parameters:**
  **subset**
  : Select the dataset to load: ‘train’ for the development training
    set, ‘test’ for the development test set, and ‘10_folds’ for the
    official evaluation set that is meant to be used with a 10-folds
    cross validation.

  **data_home**
  : Specify another download and cache folder for the datasets. By
    default all scikit-learn data is stored in ‘~/scikit_learn_data’
    subfolders.

  **funneled**
  : Download and use the funneled variant of the dataset.

  **resize**
  : Ratio used to resize the each face picture.

  **color**
  : Keep the 3 RGB channels instead of averaging them to a single
    gray level channel. If color is True the shape of the data has
    one more dimension than the shape with color = False.

  **slice_**
  : Provide a custom 2D slice (height, width) to extract the
    ‘interesting’ part of the jpeg files and avoid use statistical
    correlation from the background.

  **download_if_missing**
  : If False, raise an OSError if the data is not locally available
    instead of trying to download the data from the source site.

  **n_retries**
  : Number of retries when HTTP errors are encountered.
    <br/>
    #### Versionadded
    Added in version 1.5.

  **delay**
  : Number of seconds between retries.
    <br/>
    #### Versionadded
    Added in version 1.5.
* **Returns:**
  **data**
  : Dictionary-like object, with the following attributes.
    <br/>
    data
    : Each row corresponds to 2 ravel’d face images
      of original size 62 x 47 pixels.
      Changing the `slice_`, `resize` or `subset` parameters
      will change the shape of the output.
    <br/>
    pairs
    : Each row has 2 face images corresponding
      to same or different person from the dataset
      containing 5749 people. Changing the `slice_`,
      `resize` or `subset` parameters will change the shape of the
      output.
    <br/>
    target
    : Labels associated to each pair of images.
      The two label values being different persons or the same person.
    <br/>
    target_names
    : Explains the target values of the target array.
      0 corresponds to “Different person”, 1 corresponds to “same person”.
    <br/>
    DESCR
    : Description of the Labeled Faces in the Wild (LFW) dataset.

### Examples

```pycon
>>> from sklearn.datasets import fetch_lfw_pairs
>>> lfw_pairs_train = fetch_lfw_pairs(subset='train')
>>> list(lfw_pairs_train.target_names)
[np.str_('Different persons'), np.str_('Same person')]
>>> lfw_pairs_train.pairs.shape
(2200, 2, 62, 47)
>>> lfw_pairs_train.data.shape
(2200, 5828)
>>> lfw_pairs_train.target.shape
(2200,)
```

<!-- !! processed by numpydoc !! -->
