# GradientBoostingClassifier

### *class* sklearn.ensemble.GradientBoostingClassifier(\*, loss='log_loss', learning_rate=0.1, n_estimators=100, subsample=1.0, criterion='friedman_mse', min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_depth=3, min_impurity_decrease=0.0, init=None, random_state=None, max_features=None, verbose=0, max_leaf_nodes=None, warm_start=False, validation_fraction=0.1, n_iter_no_change=None, tol=0.0001, ccp_alpha=0.0)

Gradient Boosting for classification.

This algorithm builds an additive model in a forward stage-wise fashion; it
allows for the optimization of arbitrary differentiable loss functions. In
each stage `n_classes_` regression trees are fit on the negative gradient
of the loss function, e.g. binary or multiclass log loss. Binary
classification is a special case where only a single regression tree is
induced.

[`HistGradientBoostingClassifier`](sklearn.ensemble.HistGradientBoostingClassifier.md#sklearn.ensemble.HistGradientBoostingClassifier) is a much faster variant
of this algorithm for intermediate and large datasets (`n_samples >= 10_000`) and
supports monotonic constraints.

Read more in the [User Guide](../ensemble.md#gradient-boosting).

* **Parameters:**
  **loss**
  : The loss function to be optimized. ‘log_loss’ refers to binomial and
    multinomial deviance, the same as used in logistic regression.
    It is a good choice for classification with probabilistic outputs.
    For loss ‘exponential’, gradient boosting recovers the AdaBoost algorithm.

  **learning_rate**
  : Learning rate shrinks the contribution of each tree by `learning_rate`.
    There is a trade-off between learning_rate and n_estimators.
    Values must be in the range `[0.0, inf)`.

  **n_estimators**
  : The number of boosting stages to perform. Gradient boosting
    is fairly robust to over-fitting so a large number usually
    results in better performance.
    Values must be in the range `[1, inf)`.

  **subsample**
  : The fraction of samples to be used for fitting the individual base
    learners. If smaller than 1.0 this results in Stochastic Gradient
    Boosting. `subsample` interacts with the parameter `n_estimators`.
    Choosing `subsample < 1.0` leads to a reduction of variance
    and an increase in bias.
    Values must be in the range `(0.0, 1.0]`.

  **criterion**
  : The function to measure the quality of a split. Supported criteria are
    ‘friedman_mse’ for the mean squared error with improvement score by
    Friedman, ‘squared_error’ for mean squared error. The default value of
    ‘friedman_mse’ is generally the best as it can provide a better
    approximation in some cases.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **min_samples_split**
  : The minimum number of samples required to split an internal node:
    - If int, values must be in the range `[2, inf)`.
    - If float, values must be in the range `(0.0, 1.0]` and `min_samples_split`
      will be `ceil(min_samples_split * n_samples)`.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_samples_leaf**
  : The minimum number of samples required to be at a leaf node.
    A split point at any depth will only be considered if it leaves at
    least `min_samples_leaf` training samples in each of the left and
    right branches.  This may have the effect of smoothing the model,
    especially in regression.
    - If int, values must be in the range `[1, inf)`.
    - If float, values must be in the range `(0.0, 1.0)` and `min_samples_leaf`
      will be `ceil(min_samples_leaf * n_samples)`.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_weight_fraction_leaf**
  : The minimum weighted fraction of the sum total of weights (of all
    the input samples) required to be at a leaf node. Samples have
    equal weight when sample_weight is not provided.
    Values must be in the range `[0.0, 0.5]`.

  **max_depth**
  : Maximum depth of the individual regression estimators. The maximum
    depth limits the number of nodes in the tree. Tune this parameter
    for best performance; the best value depends on the interaction
    of the input variables. If None, then nodes are expanded until
    all leaves are pure or until all leaves contain less than
    min_samples_split samples.
    If int, values must be in the range `[1, inf)`.

  **min_impurity_decrease**
  : A node will be split if this split induces a decrease of the impurity
    greater than or equal to this value.
    Values must be in the range `[0.0, inf)`.
    <br/>
    The weighted impurity decrease equation is the following:
    ```default
    N_t / N * (impurity - N_t_R / N_t * right_impurity
                        - N_t_L / N_t * left_impurity)
    ```
    <br/>
    where `N` is the total number of samples, `N_t` is the number of
    samples at the current node, `N_t_L` is the number of samples in the
    left child, and `N_t_R` is the number of samples in the right child.
    <br/>
    `N`, `N_t`, `N_t_R` and `N_t_L` all refer to the weighted sum,
    if `sample_weight` is passed.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **init**
  : An estimator object that is used to compute the initial predictions.
    `init` has to provide [fit](../../glossary.md#term-fit) and [predict_proba](../../glossary.md#term-predict_proba). If
    ‘zero’, the initial raw predictions are set to zero. By default, a
    `DummyEstimator` predicting the classes priors is used.

  **random_state**
  : Controls the random seed given to each Tree estimator at each
    boosting iteration.
    In addition, it controls the random permutation of the features at
    each split (see Notes for more details).
    It also controls the random splitting of the training data to obtain a
    validation set if `n_iter_no_change` is not None.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **max_features**
  : The number of features to consider when looking for the best split:
    - If int, values must be in the range `[1, inf)`.
    - If float, values must be in the range `(0.0, 1.0]` and the features
      considered at each split will be `max(1, int(max_features * n_features_in_))`.
    - If ‘sqrt’, then `max_features=sqrt(n_features)`.
    - If ‘log2’, then `max_features=log2(n_features)`.
    - If None, then `max_features=n_features`.
    <br/>
    Choosing `max_features < n_features` leads to a reduction of variance
    and an increase in bias.
    <br/>
    Note: the search for a split does not stop until at least one
    valid partition of the node samples is found, even if it requires to
    effectively inspect more than `max_features` features.

  **verbose**
  : Enable verbose output. If 1 then it prints progress and performance
    once in a while (the more trees the lower the frequency). If greater
    than 1 then it prints progress and performance for every tree.
    Values must be in the range `[0, inf)`.

  **max_leaf_nodes**
  : Grow trees with `max_leaf_nodes` in best-first fashion.
    Best nodes are defined as relative reduction in impurity.
    Values must be in the range `[2, inf)`.
    If `None`, then unlimited number of leaf nodes.

  **warm_start**
  : When set to `True`, reuse the solution of the previous call to fit
    and add more estimators to the ensemble, otherwise, just erase the
    previous solution. See [the Glossary](../../glossary.md#term-warm_start).

  **validation_fraction**
  : The proportion of training data to set aside as validation set for
    early stopping. Values must be in the range `(0.0, 1.0)`.
    Only used if `n_iter_no_change` is set to an integer.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **n_iter_no_change**
  : `n_iter_no_change` is used to decide if early stopping will be used
    to terminate training when validation score is not improving. By
    default it is set to None to disable early stopping. If set to a
    number, it will set aside `validation_fraction` size of the training
    data as validation and terminate training when validation score is not
    improving in all of the previous `n_iter_no_change` numbers of
    iterations. The split is stratified.
    Values must be in the range `[1, inf)`.
    See
    [Early stopping in Gradient Boosting](../../auto_examples/ensemble/plot_gradient_boosting_early_stopping.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-early-stopping-py).
    <br/>
    #### Versionadded
    Added in version 0.20.

  **tol**
  : Tolerance for the early stopping. When the loss is not improving
    by at least tol for `n_iter_no_change` iterations (if set to a
    number), the training stops.
    Values must be in the range `[0.0, inf)`.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **ccp_alpha**
  : Complexity parameter used for Minimal Cost-Complexity Pruning. The
    subtree with the largest cost complexity that is smaller than
    `ccp_alpha` will be chosen. By default, no pruning is performed.
    Values must be in the range `[0.0, inf)`.
    See [Minimal Cost-Complexity Pruning](../tree.md#minimal-cost-complexity-pruning) for details. See
    [Post pruning decision trees with cost complexity pruning](../../auto_examples/tree/plot_cost_complexity_pruning.md#sphx-glr-auto-examples-tree-plot-cost-complexity-pruning-py)
    for an example of such pruning.
    <br/>
    #### Versionadded
    Added in version 0.22.
* **Attributes:**
  **n_estimators_**
  : The number of estimators as selected by early stopping (if
    `n_iter_no_change` is specified). Otherwise it is set to
    `n_estimators`.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **n_trees_per_iteration_**
  : The number of trees that are built at each iteration. For binary classifiers,
    this is always 1.
    <br/>
    #### Versionadded
    Added in version 1.4.0.

  [`feature_importances_`](#sklearn.ensemble.GradientBoostingClassifier.feature_importances_)
  : The impurity-based feature importances.

  **oob_improvement_**
  : The improvement in loss on the out-of-bag samples
    relative to the previous iteration.
    `oob_improvement_[0]` is the improvement in
    loss of the first stage over the `init` estimator.
    Only available if `subsample < 1.0`.

  **oob_scores_**
  : The full history of the loss values on the out-of-bag
    samples. Only available if `subsample < 1.0`.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **oob_score_**
  : The last value of the loss on the out-of-bag samples. It is
    the same as `oob_scores_[-1]`. Only available if `subsample < 1.0`.
    <br/>
    #### Versionadded
    Added in version 1.3.

  **train_score_**
  : The i-th score `train_score_[i]` is the loss of the
    model at iteration `i` on the in-bag sample.
    If `subsample == 1` this is the loss on the training data.

  **init_**
  : The estimator that provides the initial predictions. Set via the `init`
    argument.

  **estimators_**
  : The collection of fitted sub-estimators. `n_trees_per_iteration_` is 1 for
    binary classification, otherwise `n_classes`.

  **classes_**
  : The classes labels.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_classes_**
  : The number of classes.

  **max_features_**
  : The inferred value of max_features.

#### SEE ALSO
[`HistGradientBoostingClassifier`](sklearn.ensemble.HistGradientBoostingClassifier.md#sklearn.ensemble.HistGradientBoostingClassifier)
: Histogram-based Gradient Boosting Classification Tree.

[`sklearn.tree.DecisionTreeClassifier`](sklearn.tree.DecisionTreeClassifier.md#sklearn.tree.DecisionTreeClassifier)
: A decision tree classifier.

[`RandomForestClassifier`](sklearn.ensemble.RandomForestClassifier.md#sklearn.ensemble.RandomForestClassifier)
: A meta-estimator that fits a number of decision tree classifiers on various sub-samples of the dataset and uses averaging to improve the predictive accuracy and control over-fitting.

[`AdaBoostClassifier`](sklearn.ensemble.AdaBoostClassifier.md#sklearn.ensemble.AdaBoostClassifier)
: A meta-estimator that begins by fitting a classifier on the original dataset and then fits additional copies of the classifier on the same dataset where the weights of incorrectly classified instances are adjusted such that subsequent classifiers focus more on difficult cases.

### Notes

The features are always randomly permuted at each split. Therefore,
the best found split may vary, even with the same training data and
`max_features=n_features`, if the improvement of the criterion is
identical for several splits enumerated during the search of the best
split. To obtain a deterministic behaviour during fitting,
`random_state` has to be fixed.

### References

J. Friedman, Greedy Function Approximation: A Gradient Boosting
Machine, The Annals of Statistics, Vol. 29, No. 5, 2001.

1. Friedman, Stochastic Gradient Boosting, 1999

T. Hastie, R. Tibshirani and J. Friedman.
Elements of Statistical Learning Ed. 2, Springer, 2009.

### Examples

The following example shows how to fit a gradient boosting classifier with
100 decision stumps as weak learners.

```pycon
>>> from sklearn.datasets import make_hastie_10_2
>>> from sklearn.ensemble import GradientBoostingClassifier
```

```pycon
>>> X, y = make_hastie_10_2(random_state=0)
>>> X_train, X_test = X[:2000], X[2000:]
>>> y_train, y_test = y[:2000], y[2000:]
```

```pycon
>>> clf = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0,
...     max_depth=1, random_state=0).fit(X_train, y_train)
>>> clf.score(X_test, y_test)
0.913...
```

<!-- !! processed by numpydoc !! -->

#### apply(X)

Apply trees in the ensemble to X, return leaf indices.

#### Versionadded
Added in version 0.17.

* **Parameters:**
  **X**
  : The input samples. Internally, its dtype will be converted to
    `dtype=np.float32`. If a sparse matrix is provided, it will
    be converted to a sparse `csr_matrix`.
* **Returns:**
  **X_leaves**
  : For each datapoint x in X and for each tree in the ensemble,
    return the index of the leaf x ends up in each estimator.
    In the case of binary classification n_classes is 1.

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Compute the decision function of `X`.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **score**
  : The decision function of the input samples, which corresponds to
    the raw values predicted from the trees of the ensemble . The
    order of the classes corresponds to that in the attribute
    [classes_](../../glossary.md#term-classes_). Regression and binary classification produce an
    array of shape (n_samples,).

<!-- !! processed by numpydoc !! -->

#### *property* feature_importances_

The impurity-based feature importances.

The higher, the more important the feature.
The importance of a feature is computed as the (normalized)
total reduction of the criterion brought by that feature.  It is also
known as the Gini importance.

Warning: impurity-based feature importances can be misleading for
high cardinality features (many unique values). See
[`sklearn.inspection.permutation_importance`](sklearn.inspection.permutation_importance.md#sklearn.inspection.permutation_importance) as an alternative.

* **Returns:**
  **feature_importances_**
  : The values of this array sum to 1, unless all trees are single node
    trees consisting of only the root node, in which case it will be an
    array of zeros.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, monitor=None)

Fit the gradient boosting model.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.

  **y**
  : Target values (strings or integers in classification, real numbers
    in regression)
    For classification, labels must correspond to classes.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted. Splits
    that would create child nodes with net zero or negative weight are
    ignored while searching for a split in each node. In the case of
    classification, splits are also ignored if they would result in any
    single class carrying a negative weight in either child node.

  **monitor**
  : The monitor is called after each iteration with the current
    iteration, a reference to the estimator and the local variables of
    `_fit_stages` as keyword arguments `callable(i, self,
    locals())`. If the callable returns `True` the fitting procedure
    is stopped. The monitor can be used for various things such as
    computing held-out estimates, early stopping, model introspect, and
    snapshotting.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict class for X.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **y**
  : The predicted values.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Predict class log-probabilities for X.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **p**
  : The class log-probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).
* **Raises:**
  AttributeError
  : If the `loss` does not support probabilities.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict class probabilities for X.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **p**
  : The class probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).
* **Raises:**
  AttributeError
  : If the `loss` does not support probabilities.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, monitor: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [GradientBoostingClassifier](#sklearn.ensemble.GradientBoostingClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **monitor**
  : Metadata routing for `monitor` parameter in `fit`.

  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [GradientBoostingClassifier](#sklearn.ensemble.GradientBoostingClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### staged_decision_function(X)

Compute decision function of `X` for each iteration.

This method allows monitoring (i.e. determine error on testing set)
after each stage.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Yields:**
  **score**
  : The decision function of the input samples, which corresponds to
    the raw values predicted from the trees of the ensemble . The
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).
    Regression and binary classification are special cases with
    `k == 1`, otherwise `k==n_classes`.

<!-- !! processed by numpydoc !! -->

#### staged_predict(X)

Predict class at each stage for X.

This method allows monitoring (i.e. determine error on testing set)
after each stage.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Yields:**
  **y**
  : The predicted value of the input samples.

<!-- !! processed by numpydoc !! -->

#### staged_predict_proba(X)

Predict class probabilities at each stage for X.

This method allows monitoring (i.e. determine error on testing set)
after each stage.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Yields:**
  **y**
  : The predicted value of the input samples.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Transform your features into a higher dimensional, sparse space. Then train a linear model on these features.">  <div class="sphx-glr-thumbnail-title">Feature transformations with ensembles of trees</div>
</div>
* [Feature transformations with ensembles of trees](../../auto_examples/ensemble/plot_feature_transformation.md#sphx-glr-auto-examples-ensemble-plot-feature-transformation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Gradient Boosting Out-of-Bag estimates">  <div class="sphx-glr-thumbnail-title">Gradient Boosting Out-of-Bag estimates</div>
</div>
* [Gradient Boosting Out-of-Bag estimates](../../auto_examples/ensemble/plot_gradient_boosting_oob.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-oob-py)

<div class="sphx-glr-thumbcontainer" tooltip="Illustration of the effect of different regularization strategies for Gradient Boosting. The example is taken from Hastie et al 2009 [1]_.">  <div class="sphx-glr-thumbnail-title">Gradient Boosting regularization</div>
</div>
* [Gradient Boosting regularization](../../auto_examples/ensemble/plot_gradient_boosting_regularization.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-regularization-py)

<div class="sphx-glr-thumbcontainer" tooltip="A demonstration of feature discretization on synthetic classification datasets. Feature discretization decomposes each feature into a set of bins, here equally distributed in width. The discrete values are then one-hot encoded, and given to a linear classifier. This preprocessing enables a non-linear behavior even though the classifier is linear.">  <div class="sphx-glr-thumbnail-title">Feature discretization</div>
</div>
* [Feature discretization](../../auto_examples/preprocessing/plot_discretization_classification.md#sphx-glr-auto-examples-preprocessing-plot-discretization-classification-py)

<!-- thumbnail-parent-div-close --></div>
