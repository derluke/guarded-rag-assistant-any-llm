# column_or_1d

### sklearn.utils.validation.column_or_1d(y, \*, dtype=None, warn=False, device=None)

Ravel column or 1d numpy array, else raises an error.

* **Parameters:**
  **y**
  : Input data.

  **dtype**
  : Data type for `y`.
    <br/>
    #### Versionadded
    Added in version 1.2.

  **warn**
  : To control display of warnings.

  **device**
  : `device` object.
    See the [Array API User Guide](../array_api.md#array-api) for more details.
    <br/>
    #### Versionadded
    Added in version 1.6.
* **Returns:**
  **y**
  : Output data.
* **Raises:**
  ValueError
  : If `y` is not a 1D array or a 2D array with a single row or column.

### Examples

```pycon
>>> from sklearn.utils.validation import column_or_1d
>>> column_or_1d([1, 1])
array([1, 1])
```

<!-- !! processed by numpydoc !! -->
