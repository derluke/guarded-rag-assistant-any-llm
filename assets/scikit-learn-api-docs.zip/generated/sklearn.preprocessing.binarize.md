# binarize

### sklearn.preprocessing.binarize(X, \*, threshold=0.0, copy=True)

Boolean thresholding of array-like or scipy.sparse matrix.

Read more in the [User Guide](../preprocessing.md#preprocessing-binarization).

* **Parameters:**
  **X**
  : The data to binarize, element by element.
    scipy.sparse matrices should be in CSR or CSC format to avoid an
    un-necessary copy.

  **threshold**
  : Feature values below or equal to this are replaced by 0, above it by 1.
    Threshold may not be less than 0 for operations on sparse matrices.

  **copy**
  : If False, try to avoid a copy and binarize in place.
    This is not guaranteed to always work in place; e.g. if the data is
    a numpy array with an object dtype, a copy will be returned even with
    copy=False.
* **Returns:**
  **X_tr**
  : The transformed data.

#### SEE ALSO
[`Binarizer`](sklearn.preprocessing.Binarizer.md#sklearn.preprocessing.Binarizer)
: Performs binarization using the Transformer API (e.g. as part of a preprocessing [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)).

### Examples

```pycon
>>> from sklearn.preprocessing import binarize
>>> X = [[0.4, 0.6, 0.5], [0.6, 0.1, 0.2]]
>>> binarize(X, threshold=0.5)
array([[0., 1., 0.],
       [1., 0., 0.]])
```

<!-- !! processed by numpydoc !! -->
