# GaussianProcessClassifier

### *class* sklearn.gaussian_process.GaussianProcessClassifier(kernel=None, \*, optimizer='fmin_l_bfgs_b', n_restarts_optimizer=0, max_iter_predict=100, warm_start=False, copy_X_train=True, random_state=None, multi_class='one_vs_rest', n_jobs=None)

Gaussian process classification (GPC) based on Laplace approximation.

The implementation is based on Algorithm 3.1, 3.2, and 5.1 from [[RW2006]](#r2da648a61a73-rw2006).

Internally, the Laplace approximation is used for approximating the
non-Gaussian posterior by a Gaussian.

Currently, the implementation is restricted to using the logistic link
function. For multi-class classification, several binary one-versus rest
classifiers are fitted. Note that this class thus does not implement
a true multi-class Laplace approximation.

Read more in the [User Guide](../gaussian_process.md#gaussian-process).

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **kernel**
  : The kernel specifying the covariance function of the GP. If None is
    passed, the kernel “1.0 \* RBF(1.0)” is used as default. Note that
    the kernel’s hyperparameters are optimized during fitting. Also kernel
    cannot be a `CompoundKernel`.

  **optimizer**
  : Can either be one of the internally supported optimizers for optimizing
    the kernel’s parameters, specified by a string, or an externally
    defined optimizer passed as a callable. If a callable is passed, it
    must have the  signature:
    ```default
    def optimizer(obj_func, initial_theta, bounds):
        # * 'obj_func' is the objective function to be maximized, which
        #   takes the hyperparameters theta as parameter and an
        #   optional flag eval_gradient, which determines if the
        #   gradient is returned additionally to the function value
        # * 'initial_theta': the initial value for theta, which can be
        #   used by local optimizers
        # * 'bounds': the bounds on the values of theta
        ....
        # Returned are the best found hyperparameters theta and
        # the corresponding value of the target function.
        return theta_opt, func_min
    ```
    <br/>
    Per default, the ‘L-BFGS-B’ algorithm from scipy.optimize.minimize
    is used. If None is passed, the kernel’s parameters are kept fixed.
    Available internal optimizers are:
    ```default
    'fmin_l_bfgs_b'
    ```

  **n_restarts_optimizer**
  : The number of restarts of the optimizer for finding the kernel’s
    parameters which maximize the log-marginal likelihood. The first run
    of the optimizer is performed from the kernel’s initial parameters,
    the remaining ones (if any) from thetas sampled log-uniform randomly
    from the space of allowed theta-values. If greater than 0, all bounds
    must be finite. Note that n_restarts_optimizer=0 implies that one
    run is performed.

  **max_iter_predict**
  : The maximum number of iterations in Newton’s method for approximating
    the posterior during predict. Smaller values will reduce computation
    time at the cost of worse results.

  **warm_start**
  : If warm-starts are enabled, the solution of the last Newton iteration
    on the Laplace approximation of the posterior mode is used as
    initialization for the next call of \_posterior_mode(). This can speed
    up convergence when \_posterior_mode is called several times on similar
    problems as in hyperparameter optimization. See [the Glossary](../../glossary.md#term-warm_start).

  **copy_X_train**
  : If True, a persistent copy of the training data is stored in the
    object. Otherwise, just a reference to the training data is stored,
    which might cause predictions to change if the data is modified
    externally.

  **random_state**
  : Determines random number generation used to initialize the centers.
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **multi_class**
  : Specifies how multi-class classification problems are handled.
    Supported are ‘one_vs_rest’ and ‘one_vs_one’. In ‘one_vs_rest’,
    one binary Gaussian process classifier is fitted for each class, which
    is trained to separate this class from the rest. In ‘one_vs_one’, one
    binary Gaussian process classifier is fitted for each pair of classes,
    which is trained to separate these two classes. The predictions of
    these binary predictors are combined into multi-class predictions.
    Note that ‘one_vs_one’ does not support predicting probability
    estimates.

  **n_jobs**
  : The number of jobs to use for the computation: the specified
    multiclass problems are computed in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **base_estimator_**
  : The estimator instance that defines the likelihood function
    using the observed data.

  [`kernel_`](#sklearn.gaussian_process.GaussianProcessClassifier.kernel_)
  : Return the kernel of the base estimator.

  **log_marginal_likelihood_value_**
  : The log-marginal-likelihood of `self.kernel_.theta`

  **classes_**
  : Unique class labels.

  **n_classes_**
  : The number of classes in the training data

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`GaussianProcessRegressor`](sklearn.gaussian_process.GaussianProcessRegressor.md#sklearn.gaussian_process.GaussianProcessRegressor)
: Gaussian process regression (GPR).

### References

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn.gaussian_process import GaussianProcessClassifier
>>> from sklearn.gaussian_process.kernels import RBF
>>> X, y = load_iris(return_X_y=True)
>>> kernel = 1.0 * RBF(1.0)
>>> gpc = GaussianProcessClassifier(kernel=kernel,
...         random_state=0).fit(X, y)
>>> gpc.score(X, y)
0.9866...
>>> gpc.predict_proba(X[:2,:])
array([[0.83548752, 0.03228706, 0.13222543],
       [0.79064206, 0.06525643, 0.14410151]])
```

For a comaprison of the GaussianProcessClassifier with other classifiers see:
[Plot classification probability](../../auto_examples/classification/plot_classification_probability.md#sphx-glr-auto-examples-classification-plot-classification-probability-py).

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit Gaussian process classification model.

* **Parameters:**
  **X**
  : Feature vectors or other representations of training data.

  **y**
  : Target values, must be binary.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* kernel_

Return the kernel of the base estimator.

<!-- !! processed by numpydoc !! -->

#### log_marginal_likelihood(theta=None, eval_gradient=False, clone_kernel=True)

Return log-marginal likelihood of theta for training data.

In the case of multi-class classification, the mean log-marginal
likelihood of the one-versus-rest classifiers are returned.

* **Parameters:**
  **theta**
  : Kernel hyperparameters for which the log-marginal likelihood is
    evaluated. In the case of multi-class classification, theta may
    be the  hyperparameters of the compound kernel or of an individual
    kernel. In the latter case, all individual kernel get assigned the
    same theta values. If None, the precomputed log_marginal_likelihood
    of `self.kernel_.theta` is returned.

  **eval_gradient**
  : If True, the gradient of the log-marginal likelihood with respect
    to the kernel hyperparameters at position theta is returned
    additionally. Note that gradient computation is not supported
    for non-binary classification. If True, theta must not be None.

  **clone_kernel**
  : If True, the kernel attribute is copied. If False, the kernel
    attribute is modified, but may result in a performance improvement.
* **Returns:**
  **log_likelihood**
  : Log-marginal likelihood of theta for training data.

  **log_likelihood_gradient**
  : Gradient of the log-marginal likelihood with respect to the kernel
    hyperparameters at position theta.
    Only returned when `eval_gradient` is True.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Perform classification on an array of test vectors X.

* **Parameters:**
  **X**
  : Query points where the GP is evaluated for classification.
* **Returns:**
  **C**
  : Predicted target values for X, values are from `classes_`.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Return probability estimates for the test vector X.

* **Parameters:**
  **X**
  : Query points where the GP is evaluated for classification.
* **Returns:**
  **C**
  : Returns the probability of the samples for each class in
    the model. The columns correspond to the classes in sorted
    order, as they appear in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [GaussianProcessClassifier](#sklearn.gaussian_process.GaussianProcessClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the classification probability for different classifiers. We use a 3 class dataset, and we classify it with a Support Vector classifier, L1 and L2 penalized logistic regression (multinomial multiclass), a One-Vs-Rest version with logistic regression, and Gaussian process classification.">  <div class="sphx-glr-thumbnail-title">Plot classification probability</div>
</div>
* [Plot classification probability](../../auto_examples/classification/plot_classification_probability.md#sphx-glr-auto-examples-classification-plot-classification-probability-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the predicted probability of GPC for an isotropic and anisotropic RBF kernel on a two-dimensional version for the iris-dataset. The anisotropic RBF kernel obtains slightly higher log-marginal-likelihood by assigning different length-scales to the two feature dimensions.">  <div class="sphx-glr-thumbnail-title">Gaussian process classification (GPC) on iris dataset</div>
</div>
* [Gaussian process classification (GPC) on iris dataset](../../auto_examples/gaussian_process/plot_gpc_iris.md#sphx-glr-auto-examples-gaussian-process-plot-gpc-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Gaussian processes for regression and classification tasks on data that are not in fixed-length feature vector form. This is achieved through the use of kernel functions that operates directly on discrete structures such as variable-length sequences, trees, and graphs.">  <div class="sphx-glr-thumbnail-title">Gaussian processes on discrete data structures</div>
</div>
* [Gaussian processes on discrete data structures](../../auto_examples/gaussian_process/plot_gpr_on_structured_data.md#sphx-glr-auto-examples-gaussian-process-plot-gpr-on-structured-data-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates GPC on XOR data. Compared are a stationary, isotropic kernel (RBF) and a non-stationary kernel (DotProduct). On this particular dataset, the DotProduct kernel obtains considerably better results because the class-boundaries are linear and coincide with the coordinate axes. In general, stationary kernels often obtain better results.">  <div class="sphx-glr-thumbnail-title">Illustration of Gaussian process classification (GPC) on the XOR dataset</div>
</div>
* [Illustration of Gaussian process classification (GPC) on the XOR dataset](../../auto_examples/gaussian_process/plot_gpc_xor.md#sphx-glr-auto-examples-gaussian-process-plot-gpc-xor-py)

<div class="sphx-glr-thumbcontainer" tooltip="A two-dimensional classification example showing iso-probability lines for the predicted probabilities.">  <div class="sphx-glr-thumbnail-title">Iso-probability lines for Gaussian Processes classification (GPC)</div>
</div>
* [Iso-probability lines for Gaussian Processes classification (GPC)](../../auto_examples/gaussian_process/plot_gpc_isoprobability.md#sphx-glr-auto-examples-gaussian-process-plot-gpc-isoprobability-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the predicted probability of GPC for an RBF kernel with different choices of the hyperparameters. The first figure shows the predicted probability of GPC with arbitrarily chosen hyperparameters and with the hyperparameters corresponding to the maximum log-marginal-likelihood (LML).">  <div class="sphx-glr-thumbnail-title">Probabilistic predictions with Gaussian process classification (GPC)</div>
</div>
* [Probabilistic predictions with Gaussian process classification (GPC)](../../auto_examples/gaussian_process/plot_gpc.md#sphx-glr-auto-examples-gaussian-process-plot-gpc-py)

<!-- thumbnail-parent-div-close --></div>
