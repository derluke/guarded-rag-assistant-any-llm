# LeaveOneGroupOut

### *class* sklearn.model_selection.LeaveOneGroupOut

Leave One Group Out cross-validator.

Provides train/test indices to split data such that each training set is
comprised of all samples except ones belonging to one specific group.
Arbitrary domain specific group information is provided as an array of integers
that encodes the group of each sample.

For instance the groups could be the year of collection of the samples
and thus allow for cross-validation against time-based splits.

Read more in the [User Guide](../cross_validation.md#leave-one-group-out).

#### SEE ALSO
[`GroupKFold`](sklearn.model_selection.GroupKFold.md#sklearn.model_selection.GroupKFold)
: K-fold iterator variant with non-overlapping groups.

### Notes

Splits are ordered according to the index of the group left out. The first
split has testing set consisting of the group whose index in `groups` is
lowest, and so on.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import LeaveOneGroupOut
>>> X = np.array([[1, 2], [3, 4], [5, 6], [7, 8]])
>>> y = np.array([1, 2, 1, 2])
>>> groups = np.array([1, 1, 2, 2])
>>> logo = LeaveOneGroupOut()
>>> logo.get_n_splits(X, y, groups)
2
>>> logo.get_n_splits(groups=groups)  # 'groups' is always required
2
>>> print(logo)
LeaveOneGroupOut()
>>> for i, (train_index, test_index) in enumerate(logo.split(X, y, groups)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}, group={groups[train_index]}")
...     print(f"  Test:  index={test_index}, group={groups[test_index]}")
Fold 0:
  Train: index=[2 3], group=[2 2]
  Test:  index=[0 1], group=[1 1]
Fold 1:
  Train: index=[0 1], group=[1 1]
  Test:  index=[2 3], group=[2 2]
```

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X=None, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Group labels for the samples used while splitting the dataset into
    train/test set. This ‘groups’ parameter must always be specified to
    calculate the number of splits, though the other parameters can be
    omitted.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### set_split_request(\*, groups: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [LeaveOneGroupOut](#sklearn.model_selection.LeaveOneGroupOut)

Request metadata passed to the `split` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `split` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `split`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **groups**
  : Metadata routing for `groups` parameter in `split`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### split(X, y=None, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : The target variable for supervised learning problems.

  **groups**
  : Group labels for the samples used while splitting the dataset into
    train/test set.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

<!-- !! processed by numpydoc !! -->
