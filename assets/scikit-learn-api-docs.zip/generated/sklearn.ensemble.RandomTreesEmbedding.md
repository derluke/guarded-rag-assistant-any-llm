# RandomTreesEmbedding

### *class* sklearn.ensemble.RandomTreesEmbedding(n_estimators=100, \*, max_depth=5, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_leaf_nodes=None, min_impurity_decrease=0.0, sparse_output=True, n_jobs=None, random_state=None, verbose=0, warm_start=False)

An ensemble of totally random trees.

An unsupervised transformation of a dataset to a high-dimensional
sparse representation. A datapoint is coded according to which leaf of
each tree it is sorted into. Using a one-hot encoding of the leaves,
this leads to a binary coding with as many ones as there are trees in
the forest.

The dimensionality of the resulting representation is
`n_out <= n_estimators * max_leaf_nodes`. If `max_leaf_nodes == None`,
the number of leaf nodes is at most `n_estimators * 2 ** max_depth`.

For an example of applying Random Trees Embedding to non-linear
classification, see
[Hashing feature transformation using Totally Random Trees](../../auto_examples/ensemble/plot_random_forest_embedding.md#sphx-glr-auto-examples-ensemble-plot-random-forest-embedding-py).

Read more in the [User Guide](../ensemble.md#random-trees-embedding).

* **Parameters:**
  **n_estimators**
  : Number of trees in the forest.
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default value of `n_estimators` changed from 10 to 100
    in 0.22.

  **max_depth**
  : The maximum depth of each tree. If None, then nodes are expanded until
    all leaves are pure or until all leaves contain less than
    min_samples_split samples.

  **min_samples_split**
  : The minimum number of samples required to split an internal node:
    - If int, then consider `min_samples_split` as the minimum number.
    - If float, then `min_samples_split` is a fraction and
      `ceil(min_samples_split * n_samples)` is the minimum
      number of samples for each split.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_samples_leaf**
  : The minimum number of samples required to be at a leaf node.
    A split point at any depth will only be considered if it leaves at
    least `min_samples_leaf` training samples in each of the left and
    right branches.  This may have the effect of smoothing the model,
    especially in regression.
    - If int, then consider `min_samples_leaf` as the minimum number.
    - If float, then `min_samples_leaf` is a fraction and
      `ceil(min_samples_leaf * n_samples)` is the minimum
      number of samples for each node.
    <br/>
    #### Versionchanged
    Changed in version 0.18: Added float values for fractions.

  **min_weight_fraction_leaf**
  : The minimum weighted fraction of the sum total of weights (of all
    the input samples) required to be at a leaf node. Samples have
    equal weight when sample_weight is not provided.

  **max_leaf_nodes**
  : Grow trees with `max_leaf_nodes` in best-first fashion.
    Best nodes are defined as relative reduction in impurity.
    If None then unlimited number of leaf nodes.

  **min_impurity_decrease**
  : A node will be split if this split induces a decrease of the impurity
    greater than or equal to this value.
    <br/>
    The weighted impurity decrease equation is the following:
    ```default
    N_t / N * (impurity - N_t_R / N_t * right_impurity
                        - N_t_L / N_t * left_impurity)
    ```
    <br/>
    where `N` is the total number of samples, `N_t` is the number of
    samples at the current node, `N_t_L` is the number of samples in the
    left child, and `N_t_R` is the number of samples in the right child.
    <br/>
    `N`, `N_t`, `N_t_R` and `N_t_L` all refer to the weighted sum,
    if `sample_weight` is passed.
    <br/>
    #### Versionadded
    Added in version 0.19.

  **sparse_output**
  : Whether or not to return a sparse CSR matrix, as default behavior,
    or to return a dense array compatible with dense pipeline operators.

  **n_jobs**
  : The number of jobs to run in parallel. [`fit`](#sklearn.ensemble.RandomTreesEmbedding.fit), [`transform`](#sklearn.ensemble.RandomTreesEmbedding.transform),
    [`decision_path`](#sklearn.ensemble.RandomTreesEmbedding.decision_path) and [`apply`](#sklearn.ensemble.RandomTreesEmbedding.apply) are all parallelized over the
    trees. `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend)
    context. `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs) for more details.

  **random_state**
  : Controls the generation of the random `y` used to fit the trees
    and the draw of the splits for each feature at the trees’ nodes.
    See [Glossary](../../glossary.md#term-random_state) for details.

  **verbose**
  : Controls the verbosity when fitting and predicting.

  **warm_start**
  : When set to `True`, reuse the solution of the previous call to fit
    and add more estimators to the ensemble, otherwise, just fit a whole
    new forest. See [Glossary](../../glossary.md#term-warm_start) and
    [Fitting additional trees](../ensemble.md#tree-ensemble-warm-start) for details.
* **Attributes:**
  **estimator_**
  : The child estimator template used to create the collection of fitted
    sub-estimators.
    <br/>
    #### Versionadded
    Added in version 1.2: `base_estimator_` was renamed to `estimator_`.

  **estimators_**
  : The collection of fitted sub-estimators.

  [`feature_importances_`](#sklearn.ensemble.RandomTreesEmbedding.feature_importances_)
  : The impurity-based feature importances.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_outputs_**
  : The number of outputs when `fit` is performed.

  **one_hot_encoder_**
  : One-hot encoder used to create the sparse embedding.

  [`estimators_samples_`](#sklearn.ensemble.RandomTreesEmbedding.estimators_samples_)
  : The subset of drawn samples for each base estimator.

#### SEE ALSO
[`ExtraTreesClassifier`](sklearn.ensemble.ExtraTreesClassifier.md#sklearn.ensemble.ExtraTreesClassifier)
: An extra-trees classifier.

[`ExtraTreesRegressor`](sklearn.ensemble.ExtraTreesRegressor.md#sklearn.ensemble.ExtraTreesRegressor)
: An extra-trees regressor.

[`RandomForestClassifier`](sklearn.ensemble.RandomForestClassifier.md#sklearn.ensemble.RandomForestClassifier)
: A random forest classifier.

[`RandomForestRegressor`](sklearn.ensemble.RandomForestRegressor.md#sklearn.ensemble.RandomForestRegressor)
: A random forest regressor.

[`sklearn.tree.ExtraTreeClassifier`](sklearn.tree.ExtraTreeClassifier.md#sklearn.tree.ExtraTreeClassifier)
: An extremely randomized tree classifier.

[`sklearn.tree.ExtraTreeRegressor`](sklearn.tree.ExtraTreeRegressor.md#sklearn.tree.ExtraTreeRegressor)
: An extremely randomized tree regressor.

### References

### Examples

```pycon
>>> from sklearn.ensemble import RandomTreesEmbedding
>>> X = [[0,0], [1,0], [0,1], [-1,0], [0,-1]]
>>> random_trees = RandomTreesEmbedding(
...    n_estimators=5, random_state=0, max_depth=1).fit(X)
>>> X_sparse_embedding = random_trees.transform(X)
>>> X_sparse_embedding.toarray()
array([[0., 1., 1., 0., 1., 0., 0., 1., 1., 0.],
       [0., 1., 1., 0., 1., 0., 0., 1., 1., 0.],
       [0., 1., 0., 1., 0., 1., 0., 1., 0., 1.],
       [1., 0., 1., 0., 1., 0., 1., 0., 1., 0.],
       [0., 1., 1., 0., 1., 0., 0., 1., 1., 0.]])
```

<!-- !! processed by numpydoc !! -->

#### apply(X)

Apply trees in the forest to X, return leaf indices.

* **Parameters:**
  **X**
  : The input samples. Internally, its dtype will be converted to
    `dtype=np.float32`. If a sparse matrix is provided, it will be
    converted into a sparse `csr_matrix`.
* **Returns:**
  **X_leaves**
  : For each datapoint x in X and for each tree in the forest,
    return the index of the leaf x ends up in.

<!-- !! processed by numpydoc !! -->

#### decision_path(X)

Return the decision path in the forest.

#### Versionadded
Added in version 0.18.

* **Parameters:**
  **X**
  : The input samples. Internally, its dtype will be converted to
    `dtype=np.float32`. If a sparse matrix is provided, it will be
    converted into a sparse `csr_matrix`.
* **Returns:**
  **indicator**
  : Return a node indicator matrix where non zero elements indicates
    that the samples goes through the nodes. The matrix is of CSR
    format.

  **n_nodes_ptr**
  : The columns from indicator[n_nodes_ptr[i]:n_nodes_ptr[i+1]]
    gives the indicator value for the i-th estimator.

<!-- !! processed by numpydoc !! -->

#### *property* estimators_samples_

The subset of drawn samples for each base estimator.

Returns a dynamically generated list of indices identifying
the samples used for fitting each member of the ensemble, i.e.,
the in-bag samples.

Note: the list is re-created at each call to the property in order
to reduce the object memory footprint by not storing the sampling
data. Thus fetching the property may be slower than expected.

<!-- !! processed by numpydoc !! -->

#### *property* feature_importances_

The impurity-based feature importances.

The higher, the more important the feature.
The importance of a feature is computed as the (normalized)
total reduction of the criterion brought by that feature.  It is also
known as the Gini importance.

Warning: impurity-based feature importances can be misleading for
high cardinality features (many unique values). See
[`sklearn.inspection.permutation_importance`](sklearn.inspection.permutation_importance.md#sklearn.inspection.permutation_importance) as an alternative.

* **Returns:**
  **feature_importances_**
  : The values of this array sum to 1, unless all trees are single node
    trees consisting of only the root node, in which case it will be an
    array of zeros.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Fit estimator.

* **Parameters:**
  **X**
  : The input samples. Use `dtype=np.float32` for maximum
    efficiency. Sparse matrices are also supported, use sparse
    `csc_matrix` for maximum efficiency.

  **y**
  : Not used, present for API consistency by convention.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted. Splits
    that would create child nodes with net zero or negative weight are
    ignored while searching for a split in each node. In the case of
    classification, splits are also ignored if they would result in any
    single class carrying a negative weight in either child node.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, sample_weight=None)

Fit estimator and transform dataset.

* **Parameters:**
  **X**
  : Input data used to build forests. Use `dtype=np.float32` for
    maximum efficiency.

  **y**
  : Not used, present for API consistency by convention.

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted. Splits
    that would create child nodes with net zero or negative weight are
    ignored while searching for a split in each node. In the case of
    classification, splits are also ignored if they would result in any
    single class carrying a negative weight in either child node.
* **Returns:**
  **X_transformed**
  : Transformed dataset.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in [`fit`](#sklearn.ensemble.RandomTreesEmbedding.fit).
* **Returns:**
  **feature_names_out**
  : Transformed feature names, in the format of
    `randomtreesembedding_{tree}_{leaf}`, where `tree` is the tree used
    to generate the leaf and `leaf` is the index of a leaf node
    in that tree. Note that the node indexing scheme is used to
    index both nodes with children (split nodes) and leaf nodes.
    Only the latter can be present as output features.
    As a consequence, there are missing indices in the output
    feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RandomTreesEmbedding](#sklearn.ensemble.RandomTreesEmbedding)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Transform dataset.

* **Parameters:**
  **X**
  : Input data to be transformed. Use `dtype=np.float32` for maximum
    efficiency. Sparse matrices are also supported, use sparse
    `csr_matrix` for maximum efficiency.
* **Returns:**
  **X_transformed**
  : Transformed dataset.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Transform your features into a higher dimensional, sparse space. Then train a linear model on these features.">  <div class="sphx-glr-thumbnail-title">Feature transformations with ensembles of trees</div>
</div>
* [Feature transformations with ensembles of trees](../../auto_examples/ensemble/plot_feature_transformation.md#sphx-glr-auto-examples-ensemble-plot-feature-transformation-py)

<div class="sphx-glr-thumbcontainer" tooltip="RandomTreesEmbedding provides a way to map data to a very high-dimensional, sparse representation, which might be beneficial for classification. The mapping is completely unsupervised and very efficient.">  <div class="sphx-glr-thumbnail-title">Hashing feature transformation using Totally Random Trees</div>
</div>
* [Hashing feature transformation using Totally Random Trees](../../auto_examples/ensemble/plot_random_forest_embedding.md#sphx-glr-auto-examples-ensemble-plot-random-forest-embedding-py)

<div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<!-- thumbnail-parent-div-close --></div>
