# OrthogonalMatchingPursuit

### *class* sklearn.linear_model.OrthogonalMatchingPursuit(\*, n_nonzero_coefs=None, tol=None, fit_intercept=True, precompute='auto')

Orthogonal Matching Pursuit model (OMP).

Read more in the [User Guide](../linear_model.md#omp).

* **Parameters:**
  **n_nonzero_coefs**
  : Desired number of non-zero entries in the solution. Ignored if `tol` is set.
    When `None` and `tol` is also `None`, this value is either set to 10% of
    `n_features` or 1, whichever is greater.

  **tol**
  : Maximum squared norm of the residual. If not None, overrides n_nonzero_coefs.

  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to false, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **precompute**
  : Whether to use a precomputed Gram and Xy matrix to speed up
    calculations. Improves performance when [n_targets](../../glossary.md#term-n_targets) or
    [n_samples](../../glossary.md#term-n_samples) is very large. Note that if you already have such
    matrices, you can pass them directly to the fit method.
* **Attributes:**
  **coef_**
  : Parameter vector (w in the formula).

  **intercept_**
  : Independent term in decision function.

  **n_iter_**
  : Number of active features across every target.

  **n_nonzero_coefs_**
  : The number of non-zero coefficients in the solution or `None` when `tol` is
    set. If `n_nonzero_coefs` is None and `tol` is None this value is either set
    to 10% of `n_features` or 1, whichever is greater.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`orthogonal_mp`](sklearn.linear_model.orthogonal_mp.md#sklearn.linear_model.orthogonal_mp)
: Solves n_targets Orthogonal Matching Pursuit problems.

[`orthogonal_mp_gram`](sklearn.linear_model.orthogonal_mp_gram.md#sklearn.linear_model.orthogonal_mp_gram)
: Solves n_targets Orthogonal Matching Pursuit problems using only the Gram matrix X.T \* X and the product X.T \* y.

[`lars_path`](sklearn.linear_model.lars_path.md#sklearn.linear_model.lars_path)
: Compute Least Angle Regression or Lasso path using LARS algorithm.

[`Lars`](sklearn.linear_model.Lars.md#sklearn.linear_model.Lars)
: Least Angle Regression model a.k.a. LAR.

[`LassoLars`](sklearn.linear_model.LassoLars.md#sklearn.linear_model.LassoLars)
: Lasso model fit with Least Angle Regression a.k.a. Lars.

[`sklearn.decomposition.sparse_encode`](sklearn.decomposition.sparse_encode.md#sklearn.decomposition.sparse_encode)
: Generic sparse coding. Each column of the result is the solution to a Lasso problem.

[`OrthogonalMatchingPursuitCV`](sklearn.linear_model.OrthogonalMatchingPursuitCV.md#sklearn.linear_model.OrthogonalMatchingPursuitCV)
: Cross-validated Orthogonal Matching Pursuit model (OMP).

### Notes

Orthogonal matching pursuit was introduced in G. Mallat, Z. Zhang,
Matching pursuits with time-frequency dictionaries, IEEE Transactions on
Signal Processing, Vol. 41, No. 12. (December 1993), pp. 3397-3415.
([https://www.di.ens.fr/~mallat/papiers/MallatPursuit93.pdf](https://www.di.ens.fr/~mallat/papiers/MallatPursuit93.pdf))

This implementation is based on Rubinstein, R., Zibulevsky, M. and Elad,
M., Efficient Implementation of the K-SVD Algorithm using Batch Orthogonal
Matching Pursuit Technical Report - CS Technion, April 2008.
[https://www.cs.technion.ac.il/~ronrubin/Publications/KSVD-OMP-v2.pdf](https://www.cs.technion.ac.il/~ronrubin/Publications/KSVD-OMP-v2.pdf)

### Examples

```pycon
>>> from sklearn.linear_model import OrthogonalMatchingPursuit
>>> from sklearn.datasets import make_regression
>>> X, y = make_regression(noise=4, random_state=0)
>>> reg = OrthogonalMatchingPursuit().fit(X, y)
>>> reg.score(X, y)
0.9991...
>>> reg.predict(X[:1,])
array([-78.3854...])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit the model using X, y as training data.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values. Will be cast to X’s dtype if necessary.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [OrthogonalMatchingPursuit](#sklearn.linear_model.OrthogonalMatchingPursuit)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Using orthogonal matching pursuit for recovering a sparse signal from a noisy measurement encoded with a dictionary">  <div class="sphx-glr-thumbnail-title">Orthogonal Matching Pursuit</div>
</div>
* [Orthogonal Matching Pursuit](../../auto_examples/linear_model/plot_omp.md#sphx-glr-auto-examples-linear-model-plot-omp-py)

<!-- thumbnail-parent-div-close --></div>
