# NearestNeighbors

### *class* sklearn.neighbors.NearestNeighbors(\*, n_neighbors=5, radius=1.0, algorithm='auto', leaf_size=30, metric='minkowski', p=2, metric_params=None, n_jobs=None)

Unsupervised learner for implementing neighbor searches.

Read more in the [User Guide](../neighbors.md#unsupervised-neighbors).

#### Versionadded
Added in version 0.9.

* **Parameters:**
  **n_neighbors**
  : Number of neighbors to use by default for [`kneighbors`](#sklearn.neighbors.NearestNeighbors.kneighbors) queries.

  **radius**
  : Range of parameter space to use by default for [`radius_neighbors`](#sklearn.neighbors.NearestNeighbors.radius_neighbors)
    queries.

  **algorithm**
  : Algorithm used to compute the nearest neighbors:
    - ‘ball_tree’ will use [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree)
    - ‘kd_tree’ will use [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree)
    - ‘brute’ will use a brute-force search.
    - ‘auto’ will attempt to decide the most appropriate algorithm
      based on the values passed to [`fit`](#sklearn.neighbors.NearestNeighbors.fit) method.
    <br/>
    Note: fitting on sparse input will override the setting of
    this parameter, using brute force.

  **leaf_size**
  : Leaf size passed to BallTree or KDTree.  This can affect the
    speed of the construction and query, as well as the memory
    required to store the tree.  The optimal value depends on the
    nature of the problem.

  **metric**
  : Metric to use for distance computation. Default is “minkowski”, which
    results in the standard Euclidean distance when p = 2. See the
    documentation of [scipy.spatial.distance](https://docs.scipy.org/doc/scipy/reference/spatial.distance.html) and
    the metrics listed in
    [`distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics) for valid metric
    values.
    <br/>
    If metric is “precomputed”, X is assumed to be a distance matrix and
    must be square during fit. X may be a [sparse graph](../../glossary.md#term-sparse-graph), in which
    case only “nonzero” elements may be considered neighbors.
    <br/>
    If metric is a callable function, it takes two arrays representing 1D
    vectors as inputs and must return one value indicating the distance
    between those vectors. This works for Scipy’s metrics, but is less
    efficient than passing the metric name as a string.

  **p**
  : Parameter for the Minkowski metric from
    sklearn.metrics.pairwise.pairwise_distances. When p = 1, this is
    equivalent to using manhattan_distance (l1), and euclidean_distance
    (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.

  **metric_params**
  : Additional keyword arguments for the metric function.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **effective_metric_**
  : Metric used to compute distances to neighbors.

  **effective_metric_params_**
  : Parameters for the metric used to compute distances to neighbors.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_samples_fit_**
  : Number of samples in the fitted data.

#### SEE ALSO
[`KNeighborsClassifier`](sklearn.neighbors.KNeighborsClassifier.md#sklearn.neighbors.KNeighborsClassifier)
: Classifier implementing the k-nearest neighbors vote.

[`RadiusNeighborsClassifier`](sklearn.neighbors.RadiusNeighborsClassifier.md#sklearn.neighbors.RadiusNeighborsClassifier)
: Classifier implementing a vote among neighbors within a given radius.

[`KNeighborsRegressor`](sklearn.neighbors.KNeighborsRegressor.md#sklearn.neighbors.KNeighborsRegressor)
: Regression based on k-nearest neighbors.

[`RadiusNeighborsRegressor`](sklearn.neighbors.RadiusNeighborsRegressor.md#sklearn.neighbors.RadiusNeighborsRegressor)
: Regression based on neighbors within a fixed radius.

[`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree)
: Space partitioning data structure for organizing points in a multi-dimensional space, used for nearest neighbor search.

### Notes

See [Nearest Neighbors](../neighbors.md#neighbors) in the online documentation
for a discussion of the choice of `algorithm` and `leaf_size`.

[https://en.wikipedia.org/wiki/K-nearest_neighbors_algorithm](https://en.wikipedia.org/wiki/K-nearest_neighbors_algorithm)

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.neighbors import NearestNeighbors
>>> samples = [[0, 0, 2], [1, 0, 0], [0, 0, 1]]
>>> neigh = NearestNeighbors(n_neighbors=2, radius=0.4)
>>> neigh.fit(samples)
NearestNeighbors(...)
>>> neigh.kneighbors([[0, 0, 1.3]], 2, return_distance=False)
array([[2, 0]]...)
>>> nbrs = neigh.radius_neighbors(
...    [[0, 0, 1.3]], 0.4, return_distance=False
... )
>>> np.asarray(nbrs[0][0])
array(2)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the nearest neighbors estimator from the training dataset.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : The fitted nearest neighbors estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### kneighbors(X=None, n_neighbors=None, return_distance=True)

Find the K-neighbors of a point.

Returns indices of and distances to the neighbors of each point.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.

  **n_neighbors**
  : Number of neighbors required for each sample. The default is the
    value passed to the constructor.

  **return_distance**
  : Whether or not to return the distances.
* **Returns:**
  **neigh_dist**
  : Array representing the lengths to points, only present if
    return_distance=True.

  **neigh_ind**
  : Indices of the nearest points in the population matrix.

### Examples

In the following example, we construct a NearestNeighbors
class from an array representing our data set and ask who’s
the closest point to [1,1,1]

```pycon
>>> samples = [[0., 0., 0.], [0., .5, 0.], [1., 1., .5]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(n_neighbors=1)
>>> neigh.fit(samples)
NearestNeighbors(n_neighbors=1)
>>> print(neigh.kneighbors([[1., 1., 1.]]))
(array([[0.5]]), array([[2]]))
```

As you can see, it returns [[0.5]], and [[2]], which means that the
element is at distance 0.5 and is the third element of samples
(indexes start at 0). You can also query for multiple points:

```pycon
>>> X = [[0., 1., 0.], [1., 0., 1.]]
>>> neigh.kneighbors(X, return_distance=False)
array([[1],
       [2]]...)
```

<!-- !! processed by numpydoc !! -->

#### kneighbors_graph(X=None, n_neighbors=None, mode='connectivity')

Compute the (weighted) graph of k-Neighbors for points in X.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.
    For `metric='precomputed'` the shape should be
    (n_queries, n_indexed). Otherwise the shape should be
    (n_queries, n_features).

  **n_neighbors**
  : Number of neighbors for each sample. The default is the value
    passed to the constructor.

  **mode**
  : Type of returned matrix: ‘connectivity’ will return the
    connectivity matrix with ones and zeros, in ‘distance’ the
    edges are distances between points, type of distance
    depends on the selected metric parameter in
    NearestNeighbors class.
* **Returns:**
  **A**
  : `n_samples_fit` is the number of samples in the fitted data.
    `A[i, j]` gives the weight of the edge connecting `i` to `j`.
    The matrix is of CSR format.

#### SEE ALSO
[`NearestNeighbors.radius_neighbors_graph`](#sklearn.neighbors.NearestNeighbors.radius_neighbors_graph)
: Compute the (weighted) graph of Neighbors for points in X.

### Examples

```pycon
>>> X = [[0], [3], [1]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(n_neighbors=2)
>>> neigh.fit(X)
NearestNeighbors(n_neighbors=2)
>>> A = neigh.kneighbors_graph(X)
>>> A.toarray()
array([[1., 0., 1.],
       [0., 1., 1.],
       [1., 0., 1.]])
```

<!-- !! processed by numpydoc !! -->

#### radius_neighbors(X=None, radius=None, return_distance=True, sort_results=False)

Find the neighbors within a given radius of a point or points.

Return the indices and distances of each point from the dataset
lying in a ball with size `radius` around the points of the query
array. Points lying on the boundary are included in the results.

The result points are *not* necessarily sorted by distance to their
query point.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.

  **radius**
  : Limiting distance of neighbors to return. The default is the value
    passed to the constructor.

  **return_distance**
  : Whether or not to return the distances.

  **sort_results**
  : If True, the distances and indices will be sorted by increasing
    distances before being returned. If False, the results may not
    be sorted. If `return_distance=False`, setting `sort_results=True`
    will result in an error.
    <br/>
    #### Versionadded
    Added in version 0.22.
* **Returns:**
  **neigh_dist**
  : Array representing the distances to each point, only present if
    `return_distance=True`. The distance values are computed according
    to the `metric` constructor parameter.

  **neigh_ind**
  : An array of arrays of indices of the approximate nearest points
    from the population matrix that lie within a ball of size
    `radius` around the query points.

### Notes

Because the number of neighbors of each point is not necessarily
equal, the results for multiple query points cannot be fit in a
standard data array.
For efficiency, `radius_neighbors` returns arrays of objects, where
each object is a 1D array of indices or distances.

### Examples

In the following example, we construct a NeighborsClassifier
class from an array representing our data set and ask who’s
the closest point to [1, 1, 1]:

```pycon
>>> import numpy as np
>>> samples = [[0., 0., 0.], [0., .5, 0.], [1., 1., .5]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(radius=1.6)
>>> neigh.fit(samples)
NearestNeighbors(radius=1.6)
>>> rng = neigh.radius_neighbors([[1., 1., 1.]])
>>> print(np.asarray(rng[0][0]))
[1.5 0.5]
>>> print(np.asarray(rng[1][0]))
[1 2]
```

The first array returned contains the distances to all points which
are closer than 1.6, while the second array returned contains their
indices.  In general, multiple points can be queried at the same time.

<!-- !! processed by numpydoc !! -->

#### radius_neighbors_graph(X=None, radius=None, mode='connectivity', sort_results=False)

Compute the (weighted) graph of Neighbors for points in X.

Neighborhoods are restricted the points at a distance lower than
radius.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.

  **radius**
  : Radius of neighborhoods. The default is the value passed to the
    constructor.

  **mode**
  : Type of returned matrix: ‘connectivity’ will return the
    connectivity matrix with ones and zeros, in ‘distance’ the
    edges are distances between points, type of distance
    depends on the selected metric parameter in
    NearestNeighbors class.

  **sort_results**
  : If True, in each row of the result, the non-zero entries will be
    sorted by increasing distances. If False, the non-zero entries may
    not be sorted. Only used with mode=’distance’.
    <br/>
    #### Versionadded
    Added in version 0.22.
* **Returns:**
  **A**
  : `n_samples_fit` is the number of samples in the fitted data.
    `A[i, j]` gives the weight of the edge connecting `i` to `j`.
    The matrix is of CSR format.

#### SEE ALSO
[`kneighbors_graph`](sklearn.neighbors.kneighbors_graph.md#sklearn.neighbors.kneighbors_graph)
: Compute the (weighted) graph of k-Neighbors for points in X.

### Examples

```pycon
>>> X = [[0], [3], [1]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(radius=1.5)
>>> neigh.fit(X)
NearestNeighbors(radius=1.5)
>>> A = neigh.radius_neighbors_graph(X)
>>> A.toarray()
array([[1., 0., 1.],
       [0., 1., 0.],
       [1., 0., 1.]])
```

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example presents how to chain KNeighborsTransformer and TSNE in a pipeline. It also shows how to wrap the packages nmslib and pynndescent to replace KNeighborsTransformer and perform approximate nearest neighbors. These packages can be installed with pip install nmslib pynndescent.">  <div class="sphx-glr-thumbnail-title">Approximate nearest neighbors in TSNE</div>
</div>
* [Approximate nearest neighbors in TSNE](../../auto_examples/neighbors/approximate_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-approximate-nearest-neighbors-py)

<!-- thumbnail-parent-div-close --></div>
