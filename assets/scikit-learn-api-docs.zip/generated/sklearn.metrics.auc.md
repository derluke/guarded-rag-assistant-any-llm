# auc

### sklearn.metrics.auc(x, y)

Compute Area Under the Curve (AUC) using the trapezoidal rule.

This is a general function, given points on a curve.  For computing the
area under the ROC-curve, see [`roc_auc_score`](sklearn.metrics.roc_auc_score.md#sklearn.metrics.roc_auc_score).  For an alternative
way to summarize a precision-recall curve, see
[`average_precision_score`](sklearn.metrics.average_precision_score.md#sklearn.metrics.average_precision_score).

* **Parameters:**
  **x**
  : X coordinates. These must be either monotonic increasing or monotonic
    decreasing.

  **y**
  : Y coordinates.
* **Returns:**
  **auc**
  : Area Under the Curve.

#### SEE ALSO
[`roc_auc_score`](sklearn.metrics.roc_auc_score.md#sklearn.metrics.roc_auc_score)
: Compute the area under the ROC curve.

[`average_precision_score`](sklearn.metrics.average_precision_score.md#sklearn.metrics.average_precision_score)
: Compute average precision from prediction scores.

[`precision_recall_curve`](sklearn.metrics.precision_recall_curve.md#sklearn.metrics.precision_recall_curve)
: Compute precision-recall pairs for different probability thresholds.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn import metrics
>>> y = np.array([1, 1, 2, 2])
>>> pred = np.array([0.1, 0.4, 0.35, 0.8])
>>> fpr, tpr, thresholds = metrics.roc_curve(y, pred, pos_label=2)
>>> metrics.auc(fpr, tpr)
np.float64(0.75)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Modeling species&#x27; geographic distributions is an important problem in conservation biology. In this example, we model the geographic distribution of two South American mammals given past observations and 14 environmental variables. Since we have only positive examples (there are no unsuccessful observations), we cast this problem as a density estimation problem and use the OneClassSVM as our modeling tool. The dataset is provided by Phillips et. al. (2006). If available, the example uses basemap to plot the coast lines and national boundaries of South America.">  <div class="sphx-glr-thumbnail-title">Species distribution modeling</div>
</div>
* [Species distribution modeling](../../auto_examples/applications/plot_species_distribution_modeling.md#sphx-glr-auto-examples-applications-plot-species-distribution-modeling-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Poisson, Gamma and Tweedie regression on the French Motor Third-Party Liability Claims dataset, and is inspired by an R tutorial [1]_.">  <div class="sphx-glr-thumbnail-title">Tweedie regression on insurance claims</div>
</div>
* [Tweedie regression on insurance claims](../../auto_examples/linear_model/plot_tweedie_regression_insurance_claims.md#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example describes the use of the Receiver Operating Characteristic (ROC) metric to evaluate the quality of multiclass classifiers.">  <div class="sphx-glr-thumbnail-title">Multiclass Receiver Operating Characteristic (ROC)</div>
</div>
* [Multiclass Receiver Operating Characteristic (ROC)](../../auto_examples/model_selection/plot_roc.md#sphx-glr-auto-examples-model-selection-plot-roc-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of Precision-Recall metric to evaluate classifier output quality.">  <div class="sphx-glr-thumbnail-title">Precision-Recall</div>
</div>
* [Precision-Recall](../../auto_examples/model_selection/plot_precision_recall.md#sphx-glr-auto-examples-model-selection-plot-precision-recall-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents how to estimate and visualize the variance of the Receiver Operating Characteristic (ROC) metric using cross-validation.">  <div class="sphx-glr-thumbnail-title">Receiver Operating Characteristic (ROC) with cross validation</div>
</div>
* [Receiver Operating Characteristic (ROC) with cross validation](../../auto_examples/model_selection/plot_roc_crossval.md#sphx-glr-auto-examples-model-selection-plot-roc-crossval-py)

<!-- thumbnail-parent-div-close --></div>
