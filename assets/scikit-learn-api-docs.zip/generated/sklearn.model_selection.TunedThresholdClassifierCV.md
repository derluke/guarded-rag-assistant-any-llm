# TunedThresholdClassifierCV

### *class* sklearn.model_selection.TunedThresholdClassifierCV(estimator, \*, scoring='balanced_accuracy', response_method='auto', thresholds=100, cv=None, refit=True, n_jobs=None, random_state=None, store_cv_results=False)

Classifier that post-tunes the decision threshold using cross-validation.

This estimator post-tunes the decision threshold (cut-off point) that is
used for converting posterior probability estimates (i.e. output of
`predict_proba`) or decision scores (i.e. output of `decision_function`)
into a class label. The tuning is done by optimizing a binary metric,
potentially constrained by a another metric.

Read more in the [User Guide](../classification_threshold.md#tunedthresholdclassifiercv).

#### Versionadded
Added in version 1.5.

* **Parameters:**
  **estimator**
  : The classifier, fitted or not, for which we want to optimize
    the decision threshold used during `predict`.

  **scoring**
  : The objective metric to be optimized. Can be one of:
    * a string associated to a scoring function for binary classification
      (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter));
    * a scorer callable object created with [`make_scorer`](sklearn.metrics.make_scorer.md#sklearn.metrics.make_scorer);

  **response_method**
  : Methods by the classifier `estimator` corresponding to the
    decision function for which we want to find a threshold. It can be:
    * if `"auto"`, it will try to invoke, for each classifier,
      `"predict_proba"` or `"decision_function"` in that order.
    * otherwise, one of `"predict_proba"` or `"decision_function"`.
      If the method is not implemented by the classifier, it will raise an
      error.

  **thresholds**
  : The number of decision threshold to use when discretizing the output of the
    classifier `method`. Pass an array-like to manually specify the thresholds
    to use.

  **cv**
  : Determines the cross-validation splitting strategy to train classifier.
    Possible inputs for cv are:
    * `None`, to use the default 5-fold stratified K-fold cross validation;
    * An integer number, to specify the number of folds in a stratified k-fold;
    * A float number, to specify a single shuffle split. The floating number should
      be in (0, 1) and represent the size of the validation set;
    * An object to be used as a cross-validation generator;
    * An iterable yielding train, test splits;
    * `"prefit"`, to bypass the cross-validation.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### WARNING
    Using `cv="prefit"` and passing the same dataset for fitting `estimator`
    and tuning the cut-off point is subject to undesired overfitting. You can
    refer to [Consideration regarding model refitting and cross-validation](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#tunedthresholdclassifiercv-no-cv) for an example.
    <br/>
    This option should only be used when the set used to fit `estimator` is
    different from the one used to tune the cut-off point (by calling
    [`TunedThresholdClassifierCV.fit`](#sklearn.model_selection.TunedThresholdClassifierCV.fit)).

  **refit**
  : Whether or not to refit the classifier on the entire training set once
    the decision threshold has been found.
    Note that forcing `refit=False` on cross-validation having more
    than a single split will raise an error. Similarly, `refit=True` in
    conjunction with `cv="prefit"` will raise an error.

  **n_jobs**
  : The number of jobs to run in parallel. When `cv` represents a
    cross-validation strategy, the fitting and scoring on each data split
    is done in parallel. `None` means 1 unless in a
    [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context. `-1` means using all
    processors. See [Glossary](../../glossary.md#term-n_jobs) for more details.

  **random_state**
  : Controls the randomness of cross-validation when `cv` is a float.
    See [Glossary](../../glossary.md#term-random_state).

  **store_cv_results**
  : Whether to store all scores and thresholds computed during the cross-validation
    process.
* **Attributes:**
  **estimator_**
  : The fitted classifier used when predicting.

  **best_threshold_**
  : The new decision threshold.

  **best_score_**
  : The optimal score of the objective metric, evaluated at `best_threshold_`.

  **cv_results_**
  : A dictionary containing the scores and thresholds computed during the
    cross-validation process. Only exist if `store_cv_results=True`. The
    keys are `"thresholds"` and `"scores"`.

  [`classes_`](#sklearn.model_selection.TunedThresholdClassifierCV.classes_)
  : Classes labels.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.

#### SEE ALSO
[`sklearn.model_selection.FixedThresholdClassifier`](sklearn.model_selection.FixedThresholdClassifier.md#sklearn.model_selection.FixedThresholdClassifier)
: Classifier that uses a constant threshold.

[`sklearn.calibration.CalibratedClassifierCV`](sklearn.calibration.CalibratedClassifierCV.md#sklearn.calibration.CalibratedClassifierCV)
: Estimator that calibrates probabilities.

### Examples

```pycon
>>> from sklearn.datasets import make_classification
>>> from sklearn.ensemble import RandomForestClassifier
>>> from sklearn.metrics import classification_report
>>> from sklearn.model_selection import TunedThresholdClassifierCV, train_test_split
>>> X, y = make_classification(
...     n_samples=1_000, weights=[0.9, 0.1], class_sep=0.8, random_state=42
... )
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, stratify=y, random_state=42
... )
>>> classifier = RandomForestClassifier(random_state=0).fit(X_train, y_train)
>>> print(classification_report(y_test, classifier.predict(X_test)))
              precision    recall  f1-score   support

           0       0.94      0.99      0.96       224
           1       0.80      0.46      0.59        26

    accuracy                           0.93       250
   macro avg       0.87      0.72      0.77       250
weighted avg       0.93      0.93      0.92       250

>>> classifier_tuned = TunedThresholdClassifierCV(
...     classifier, scoring="balanced_accuracy"
... ).fit(X_train, y_train)
>>> print(
...     f"Cut-off point found at {classifier_tuned.best_threshold_:.3f}"
... )
Cut-off point found at 0.342
>>> print(classification_report(y_test, classifier_tuned.predict(X_test)))
              precision    recall  f1-score   support

           0       0.96      0.95      0.96       224
           1       0.61      0.65      0.63        26

    accuracy                           0.92       250
   macro avg       0.78      0.80      0.79       250
weighted avg       0.92      0.92      0.92       250
```

<!-- !! processed by numpydoc !! -->

#### *property* classes_

Classes labels.

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Decision function for samples in `X` using the fitted estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **decisions**
  : The decision function computed the fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*\*params)

Fit the classifier.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **\*\*params**
  : Parameters to pass to the `fit` method of the underlying
    classifier.
* **Returns:**
  **self**
  : Returns an instance of self.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict the target of new samples.

* **Parameters:**
  **X**
  : The samples, as accepted by `estimator.predict`.
* **Returns:**
  **class_labels**
  : The predicted class.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Predict logarithm class probabilities for `X` using the fitted estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **log_probabilities**
  : The logarithm class probabilities of the input samples.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict class probabilities for `X` using the fitted estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **probabilities**
  : The class probabilities of the input samples.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [TunedThresholdClassifierCV](#sklearn.model_selection.TunedThresholdClassifierCV)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Once a binary classifier is trained, the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. The default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0. However, this default strategy may not be optimal for the task at hand.">  <div class="sphx-glr-thumbnail-title">Post-hoc tuning the cut-off point of decision function</div>
</div>
* [Post-hoc tuning the cut-off point of decision function](../../auto_examples/model_selection/plot_tuned_decision_threshold.md#sphx-glr-auto-examples-model-selection-plot-tuned-decision-threshold-py)

<div class="sphx-glr-thumbcontainer" tooltip="Once a classifier is trained, the output of the predict method outputs class label predictions corresponding to a thresholding of either the decision_function or the predict_proba output. For a binary classifier, the default threshold is defined as a posterior probability estimate of 0.5 or a decision score of 0.0.">  <div class="sphx-glr-thumbnail-title">Post-tuning the decision threshold for cost-sensitive learning</div>
</div>
* [Post-tuning the decision threshold for cost-sensitive learning](../../auto_examples/model_selection/plot_cost_sensitive_learning.md#sphx-glr-auto-examples-model-selection-plot-cost-sensitive-learning-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<!-- thumbnail-parent-div-close --></div>
