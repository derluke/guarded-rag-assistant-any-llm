# MinMaxScaler

### *class* sklearn.preprocessing.MinMaxScaler(feature_range=(0, 1), \*, copy=True, clip=False)

Transform features by scaling each feature to a given range.

This estimator scales and translates each feature individually such
that it is in the given range on the training set, e.g. between
zero and one.

The transformation is given by:

```default
X_std = (X - X.min(axis=0)) / (X.max(axis=0) - X.min(axis=0))
X_scaled = X_std * (max - min) + min
```

where min, max = feature_range.

This transformation is often used as an alternative to zero mean,
unit variance scaling.

`MinMaxScaler` doesn’t reduce the effect of outliers, but it linearly
scales them down into a fixed range, where the largest occurring data point
corresponds to the maximum value and the smallest one corresponds to the
minimum value. For an example visualization, refer to [Compare
MinMaxScaler with other scalers](../../auto_examples/preprocessing/plot_all_scaling.md#plot-all-scaling-minmax-scaler-section).

Read more in the [User Guide](../preprocessing.md#preprocessing-scaler).

* **Parameters:**
  **feature_range**
  : Desired range of transformed data.

  **copy**
  : Set to False to perform inplace row normalization and avoid a
    copy (if the input is already a numpy array).

  **clip**
  : Set to True to clip transformed values of held-out data to
    provided `feature range`.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  **min_**
  : Per feature adjustment for minimum. Equivalent to
    `min - X.min(axis=0) * self.scale_`

  **scale_**
  : Per feature relative scaling of the data. Equivalent to
    `(max - min) / (X.max(axis=0) - X.min(axis=0))`
    <br/>
    #### Versionadded
    Added in version 0.17: *scale_* attribute.

  **data_min_**
  : Per feature minimum seen in the data
    <br/>
    #### Versionadded
    Added in version 0.17: *data_min_*

  **data_max_**
  : Per feature maximum seen in the data
    <br/>
    #### Versionadded
    Added in version 0.17: *data_max_*

  **data_range_**
  : Per feature range `(data_max_ - data_min_)` seen in the data
    <br/>
    #### Versionadded
    Added in version 0.17: *data_range_*

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **n_samples_seen_**
  : The number of samples processed by the estimator.
    It will be reset on new calls to fit, but increments across
    `partial_fit` calls.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`minmax_scale`](sklearn.preprocessing.minmax_scale.md#sklearn.preprocessing.minmax_scale)
: Equivalent function without the estimator API.

### Notes

NaNs are treated as missing values: disregarded in fit, and maintained in
transform.

### Examples

```pycon
>>> from sklearn.preprocessing import MinMaxScaler
>>> data = [[-1, 2], [-0.5, 6], [0, 10], [1, 18]]
>>> scaler = MinMaxScaler()
>>> print(scaler.fit(data))
MinMaxScaler()
>>> print(scaler.data_max_)
[ 1. 18.]
>>> print(scaler.transform(data))
[[0.   0.  ]
 [0.25 0.25]
 [0.5  0.5 ]
 [1.   1.  ]]
>>> print(scaler.transform([[2, 2]]))
[[1.5 0. ]]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Compute the minimum and maximum to be used for later scaling.

* **Parameters:**
  **X**
  : The data used to compute the per-feature minimum and maximum
    used for later scaling along the features axis.

  **y**
  : Ignored.
* **Returns:**
  **self**
  : Fitted scaler.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Same as input features.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Undo the scaling of X according to feature_range.

* **Parameters:**
  **X**
  : Input data that will be transformed. It cannot be sparse.
* **Returns:**
  **Xt**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y=None)

Online computation of min and max on X for later scaling.

All of X is processed as a single batch. This is intended for cases
when [`fit`](#sklearn.preprocessing.MinMaxScaler.fit) is not feasible due to very large number of
`n_samples` or because X is read from a continuous stream.

* **Parameters:**
  **X**
  : The data used to compute the mean and standard deviation
    used for later scaling along the features axis.

  **y**
  : Ignored.
* **Returns:**
  **self**
  : Fitted scaler.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Scale features of X according to feature_range.

* **Parameters:**
  **X**
  : Input data that will be transformed.
* **Returns:**
  **Xt**
  : Transformed data.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use KernelPCA to denoise images. In short, we take advantage of the approximation function learned during fit to reconstruct the original image.">  <div class="sphx-glr-thumbnail-title">Image denoising using kernel PCA</div>
</div>
* [Image denoising using kernel PCA](../../auto_examples/applications/plot_digits_denoising.md#sphx-glr-auto-examples-applications-plot-digits-denoising-py)

<div class="sphx-glr-thumbcontainer" tooltip="This notebook introduces different strategies to leverage time-related features for a bike sharing demand regression task that is highly dependent on business cycles (days, weeks, months) and yearly season cycles.">  <div class="sphx-glr-thumbnail-title">Time-related feature engineering</div>
</div>
* [Time-related feature engineering](../../auto_examples/applications/plot_cyclical_feature_engineering.md#sphx-glr-auto-examples-applications-plot-cyclical-feature-engineering-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example constructs a pipeline that does dimensionality reduction followed by prediction with a support vector classifier. It demonstrates the use of GridSearchCV and Pipeline to optimize over different classes of estimators in a single CV run -- unsupervised PCA and NMF dimensionality reductions are compared to univariate feature selection during the grid search.">  <div class="sphx-glr-thumbnail-title">Selecting dimensionality reduction with Pipeline and GridSearchCV</div>
</div>
* [Selecting dimensionality reduction with Pipeline and GridSearchCV](../../auto_examples/compose/plot_compare_reduction.md#sphx-glr-auto-examples-compose-plot-compare-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Recursive Feature Elimination (~sklearn.feature_selection.RFE) can be used to determine the importance of individual pixels for classifying handwritten digits. RFE recursively removes the least significant features, assigning ranks based on their importance, where higher ranking_ values denote lower importance. The ranking is visualized using both shades of blue and pixel annotations for clarity. As expected, pixels positioned at the center of the image tend to be more predictive than those near the edges.">  <div class="sphx-glr-thumbnail-title">Recursive feature elimination</div>
</div>
* [Recursive feature elimination](../../auto_examples/feature_selection/plot_rfe_digits.md#sphx-glr-auto-examples-feature-selection-plot-rfe-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="This notebook is an example of using univariate feature selection to improve classification accuracy on a noisy dataset.">  <div class="sphx-glr-thumbnail-title">Univariate Feature Selection</div>
</div>
* [Univariate Feature Selection](../../auto_examples/feature_selection/plot_feature_selection.md#sphx-glr-auto-examples-feature-selection-plot-feature-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of PolynomialCountSketch to efficiently generate polynomial kernel feature-space approximations. This is used to train linear classifiers that approximate the accuracy of kernelized ones.">  <div class="sphx-glr-thumbnail-title">Scalable learning with polynomial kernel approximation</div>
</div>
* [Scalable learning with polynomial kernel approximation](../../auto_examples/kernel_approximation/plot_scalable_poly_kernels.md#sphx-glr-auto-examples-kernel-approximation-plot-scalable-poly-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example visualizes some training loss curves for different stochastic learning strategies, including SGD and Adam. Because of time-constraints, we use several small datasets, for which L-BFGS might be more suitable. The general trend shown in these examples seems to carry over to larger datasets, however.">  <div class="sphx-glr-thumbnail-title">Compare Stochastic learning strategies for MLPClassifier</div>
</div>
* [Compare Stochastic learning strategies for MLPClassifier](../../auto_examples/neural_networks/plot_mlp_training_curves.md#sphx-glr-auto-examples-neural-networks-plot-mlp-training-curves-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature 0 (median income in a block) and feature 5 (average house occupancy) of the california_housing_dataset have very different scales and contain some very large outliers. These two characteristics lead to difficulties to visualize the data and, more importantly, they can degrade the predictive performance of many machine learning algorithms. Unscaled data can also slow down or even prevent the convergence of many gradient-based estimators.">  <div class="sphx-glr-thumbnail-title">Compare the effect of different scalers on data with outliers</div>
</div>
* [Compare the effect of different scalers on data with outliers](../../auto_examples/preprocessing/plot_all_scaling.md#sphx-glr-auto-examples-preprocessing-plot-all-scaling-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
