# gen_even_slices

### sklearn.utils.gen_even_slices(n, n_packs, \*, n_samples=None)

Generator to create `n_packs` evenly spaced slices going up to `n`.

If `n_packs` does not divide `n`, except for the first `n % n_packs`
slices, remaining slices may contain fewer elements.

* **Parameters:**
  **n**
  : Size of the sequence.

  **n_packs**
  : Number of slices to generate.

  **n_samples**
  : Number of samples. Pass `n_samples` when the slices are to be used for
    sparse matrix indexing; slicing off-the-end raises an exception, while
    it works for NumPy arrays.
* **Yields:**
  `slice` representing a set of indices from 0 to n.

#### SEE ALSO
[`gen_batches`](sklearn.utils.gen_batches.md#sklearn.utils.gen_batches)
: Generator to create slices containing batch_size elements from 0 to n.

### Examples

```pycon
>>> from sklearn.utils import gen_even_slices
>>> list(gen_even_slices(10, 1))
[slice(0, 10, None)]
>>> list(gen_even_slices(10, 10))
[slice(0, 1, None), slice(1, 2, None), ..., slice(9, 10, None)]
>>> list(gen_even_slices(10, 5))
[slice(0, 2, None), slice(2, 4, None), ..., slice(8, 10, None)]
>>> list(gen_even_slices(10, 3))
[slice(0, 4, None), slice(4, 7, None), slice(7, 10, None)]
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<!-- thumbnail-parent-div-close --></div>
