# murmurhash3_32

### sklearn.utils.murmurhash3_32(key, seed=0, positive=False)

Compute the 32bit murmurhash3 of key at seed.

The underlying implementation is MurmurHash3_x86_32 generating low
latency 32bits hash suitable for implementing lookup tables, Bloom
filters, count min sketch or feature hashing.

* **Parameters:**
  **key**
  : The physical object to hash.

  **seed**
  : Integer seed for the hashing algorithm.

  **positive**
  : True: the results is casted to an unsigned int
    : from 0 to 2 \*\* 32 - 1
    <br/>
    False: the results is casted to a signed int
    : from -(2 \*\* 31) to 2 \*\* 31 - 1

### Examples

```pycon
>>> from sklearn.utils import murmurhash3_32
>>> murmurhash3_32(b"Hello World!", seed=42)
3565178
```

<!-- !! processed by numpydoc !! -->
