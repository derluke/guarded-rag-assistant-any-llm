# f_regression

### sklearn.feature_selection.f_regression(X, y, \*, center=True, force_finite=True)

Univariate linear regression tests returning F-statistic and p-values.

Quick linear model for testing the effect of a single regressor,
sequentially for many regressors.

This is done in 2 steps:

1. The cross correlation between each regressor and the target is computed
   using [`r_regression`](sklearn.feature_selection.r_regression.md#sklearn.feature_selection.r_regression) as:
   ```default
   E[(X[:, i] - mean(X[:, i])) * (y - mean(y))] / (std(X[:, i]) * std(y))
   ```
2. It is converted to an F score and then to a p-value.

[`f_regression`](#sklearn.feature_selection.f_regression) is derived from [`r_regression`](sklearn.feature_selection.r_regression.md#sklearn.feature_selection.r_regression) and will rank
features in the same order if all the features are positively correlated
with the target.

Note however that contrary to [`f_regression`](#sklearn.feature_selection.f_regression), [`r_regression`](sklearn.feature_selection.r_regression.md#sklearn.feature_selection.r_regression)
values lie in [-1, 1] and can thus be negative. [`f_regression`](#sklearn.feature_selection.f_regression) is
therefore recommended as a feature selection criterion to identify
potentially predictive feature for a downstream classifier, irrespective of
the sign of the association with the target variable.

Furthermore [`f_regression`](#sklearn.feature_selection.f_regression) returns p-values while
[`r_regression`](sklearn.feature_selection.r_regression.md#sklearn.feature_selection.r_regression) does not.

Read more in the [User Guide](../feature_selection.md#univariate-feature-selection).

* **Parameters:**
  **X**
  : The data matrix.

  **y**
  : The target vector.

  **center**
  : Whether or not to center the data matrix `X` and the target vector `y`.
    By default, `X` and `y` will be centered.

  **force_finite**
  : Whether or not to force the F-statistics and associated p-values to
    be finite. There are two cases where the F-statistic is expected to not
    be finite:
    - when the target `y` or some features in `X` are constant. In this
      case, the Pearson’s R correlation is not defined leading to obtain
      `np.nan` values in the F-statistic and p-value. When
      `force_finite=True`, the F-statistic is set to `0.0` and the
      associated p-value is set to `1.0`.
    - when a feature in `X` is perfectly correlated (or
      anti-correlated) with the target `y`. In this case, the F-statistic
      is expected to be `np.inf`. When `force_finite=True`, the F-statistic
      is set to `np.finfo(dtype).max` and the associated p-value is set to
      `0.0`.
    <br/>
    #### Versionadded
    Added in version 1.1.
* **Returns:**
  **f_statistic**
  : F-statistic for each feature.

  **p_values**
  : P-values associated with the F-statistic.

#### SEE ALSO
[`r_regression`](sklearn.feature_selection.r_regression.md#sklearn.feature_selection.r_regression)
: Pearson’s R between label/feature for regression tasks.

[`f_classif`](sklearn.feature_selection.f_classif.md#sklearn.feature_selection.f_classif)
: ANOVA F-value between label/feature for classification tasks.

[`chi2`](sklearn.feature_selection.chi2.md#sklearn.feature_selection.chi2)
: Chi-squared stats of non-negative features for classification tasks.

[`SelectKBest`](sklearn.feature_selection.SelectKBest.md#sklearn.feature_selection.SelectKBest)
: Select features based on the k highest scores.

[`SelectFpr`](sklearn.feature_selection.SelectFpr.md#sklearn.feature_selection.SelectFpr)
: Select features based on a false positive rate test.

[`SelectFdr`](sklearn.feature_selection.SelectFdr.md#sklearn.feature_selection.SelectFdr)
: Select features based on an estimated false discovery rate.

[`SelectFwe`](sklearn.feature_selection.SelectFwe.md#sklearn.feature_selection.SelectFwe)
: Select features based on family-wise error rate.

[`SelectPercentile`](sklearn.feature_selection.SelectPercentile.md#sklearn.feature_selection.SelectPercentile)
: Select features based on percentile of the highest scores.

### Examples

```pycon
>>> from sklearn.datasets import make_regression
>>> from sklearn.feature_selection import f_regression
>>> X, y = make_regression(
...     n_samples=50, n_features=3, n_informative=1, noise=1e-4, random_state=42
... )
>>> f_statistic, p_values = f_regression(X, y)
>>> f_statistic
array([1.2...+00, 2.6...+13, 2.6...+00])
>>> p_values
array([2.7..., 1.5..., 1.0...])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example compares 2 dimensionality reduction strategies:">  <div class="sphx-glr-thumbnail-title">Feature agglomeration vs. univariate selection</div>
</div>
* [Feature agglomeration vs. univariate selection](../../auto_examples/cluster/plot_feature_agglomeration_vs_univariate_selection.md#sphx-glr-auto-examples-cluster-plot-feature-agglomeration-vs-univariate-selection-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the differences between univariate F-test statistics and mutual information.">  <div class="sphx-glr-thumbnail-title">Comparison of F-test and mutual information</div>
</div>
* [Comparison of F-test and mutual information](../../auto_examples/feature_selection/plot_f_test_vs_mi.md#sphx-glr-auto-examples-feature-selection-plot-f-test-vs-mi-py)

<!-- thumbnail-parent-div-close --></div>
