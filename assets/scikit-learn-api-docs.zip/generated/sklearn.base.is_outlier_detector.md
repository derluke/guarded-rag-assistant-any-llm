# is_outlier_detector

### sklearn.base.is_outlier_detector(estimator)

Return True if the given estimator is (probably) an outlier detector.

* **Parameters:**
  **estimator**
  : Estimator object to test.
* **Returns:**
  **out**
  : True if estimator is an outlier detector and False otherwise.

<!-- !! processed by numpydoc !! -->
