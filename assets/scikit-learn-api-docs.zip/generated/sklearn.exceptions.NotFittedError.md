# NotFittedError

### *exception* sklearn.exceptions.NotFittedError

Exception class to raise if estimator is used before fitting.

This class inherits from both ValueError and AttributeError to help with
exception handling and backward compatibility.

### Examples

```pycon
>>> from sklearn.svm import LinearSVC
>>> from sklearn.exceptions import NotFittedError
>>> try:
...     LinearSVC().predict([[1, 2], [2, 3], [3, 4]])
... except NotFittedError as e:
...     print(repr(e))
NotFittedError("This LinearSVC instance is not fitted yet. Call 'fit' with
appropriate arguments before using this estimator."...)
```

#### Versionchanged
Changed in version 0.18: Moved from sklearn.utils.validation.

<!-- !! processed by numpydoc !! -->
