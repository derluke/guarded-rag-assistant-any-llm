# check_is_fitted

### sklearn.utils.validation.check_is_fitted(estimator, attributes=None, \*, msg=None, all_or_any=<built-in function all>)

Perform is_fitted validation for estimator.

Checks if the estimator is fitted by verifying the presence of
fitted attributes (ending with a trailing underscore) and otherwise
raises a [`NotFittedError`](sklearn.exceptions.NotFittedError.md#sklearn.exceptions.NotFittedError) with the given message.

If an estimator does not set any attributes with a trailing underscore, it
can define a `__sklearn_is_fitted__` method returning a boolean to
specify if the estimator is fitted or not. See
[\_\_sklearn_is_fitted_\_ as Developer API](../../auto_examples/developing_estimators/sklearn_is_fitted.md#sphx-glr-auto-examples-developing-estimators-sklearn-is-fitted-py)
for an example on how to use the API.

If no `attributes` are passed, this fuction will pass if an estimator is stateless.
An estimator can indicate it’s stateless by setting the `requires_fit` tag. See
[Estimator Tags](../../developers/develop.md#estimator-tags) for more information. Note that the `requires_fit` tag
is ignored if `attributes` are passed.

* **Parameters:**
  **estimator**
  : Estimator instance for which the check is performed.

  **attributes**
  : Attribute name(s) given as string or a list/tuple of strings
    Eg.: `["coef_", "estimator_", ...], "coef_"`
    <br/>
    If `None`, `estimator` is considered fitted if there exist an
    attribute that ends with a underscore and does not start with double
    underscore.

  **msg**
  : The default error message is, “This %(name)s instance is not fitted
    yet. Call ‘fit’ with appropriate arguments before using this
    estimator.”
    <br/>
    For custom messages if “%(name)s” is present in the message string,
    it is substituted for the estimator name.
    <br/>
    Eg. : “Estimator, %(name)s, must be fitted before sparsifying”.

  **all_or_any**
  : Specify whether all or any of the given attributes must exist.
* **Raises:**
  TypeError
  : If the estimator is a class or not an estimator instance

  NotFittedError
  : If the attributes are not found.

### Examples

```pycon
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.utils.validation import check_is_fitted
>>> from sklearn.exceptions import NotFittedError
>>> lr = LogisticRegression()
>>> try:
...     check_is_fitted(lr)
... except NotFittedError as exc:
...     print(f"Model is not fitted yet.")
Model is not fitted yet.
>>> lr.fit([[1, 2], [1, 3]], [1, 0])
LogisticRegression()
>>> check_is_fitted(lr)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Clustering can be expensive, especially when our dataset contains millions of datapoints. Many clustering algorithms are not inductive and so cannot be directly applied to new data samples without recomputing the clustering, which may be intractable. Instead, we can use clustering to then learn an inductive model with a classifier, which has several benefits:">  <div class="sphx-glr-thumbnail-title">Inductive Clustering</div>
</div>
* [Inductive Clustering](../../auto_examples/cluster/plot_inductive_clustering.md#sphx-glr-auto-examples-cluster-plot-inductive-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="The \_\_sklearn_is_fitted_\_ method is a convention used in scikit-learn for checking whether an estimator object has been fitted or not. This method is typically implemented in custom estimator classes that are built on top of scikit-learn&#x27;s base classes like BaseEstimator or its subclasses.">  <div class="sphx-glr-thumbnail-title">_\_sklearn_is_fitted_\_ as Developer API</div>
</div>
* [\_\_sklearn_is_fitted_\_ as Developer API](../../auto_examples/developing_estimators/sklearn_is_fitted.md#sphx-glr-auto-examples-developing-estimators-sklearn-is-fitted-py)

<div class="sphx-glr-thumbcontainer" tooltip="This document shows how you can use the metadata routing mechanism &lt;metadata_routing&gt; in scikit-learn to route metadata to the estimators, scorers, and CV splitters consuming them.">  <div class="sphx-glr-thumbnail-title">Metadata Routing</div>
</div>
* [Metadata Routing](../../auto_examples/miscellaneous/plot_metadata_routing.md#sphx-glr-auto-examples-miscellaneous-plot-metadata-routing-py)

<!-- thumbnail-parent-div-close --></div>
