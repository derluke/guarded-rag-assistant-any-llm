# MetaEstimatorMixin

### *class* sklearn.base.MetaEstimatorMixin

Mixin class for all meta estimators in scikit-learn.

This mixin is empty, and only exists to indicate that the estimator is a
meta-estimator.

#### Versionchanged
Changed in version 1.6: The `_required_parameters` is now removed and is unnecessary since tests are
refactored and don’t use this anymore.

### Examples

```pycon
>>> from sklearn.base import MetaEstimatorMixin
>>> from sklearn.datasets import load_iris
>>> from sklearn.linear_model import LogisticRegression
>>> class MyEstimator(MetaEstimatorMixin):
...     def __init__(self, *, estimator=None):
...         self.estimator = estimator
...     def fit(self, X, y=None):
...         if self.estimator is None:
...             self.estimator_ = LogisticRegression()
...         else:
...             self.estimator_ = self.estimator
...         return self
>>> X, y = load_iris(return_X_y=True)
>>> estimator = MyEstimator().fit(X, y)
>>> estimator.estimator_
LogisticRegression()
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This document shows how you can use the metadata routing mechanism &lt;metadata_routing&gt; in scikit-learn to route metadata to the estimators, scorers, and CV splitters consuming them.">  <div class="sphx-glr-thumbnail-title">Metadata Routing</div>
</div>
* [Metadata Routing](../../auto_examples/miscellaneous/plot_metadata_routing.md#sphx-glr-auto-examples-miscellaneous-plot-metadata-routing-py)

<!-- thumbnail-parent-div-close --></div>
