# DetCurveDisplay

### *class* sklearn.metrics.DetCurveDisplay(\*, fpr, fnr, estimator_name=None, pos_label=None)

DET curve visualization.

It is recommend to use [`from_estimator`](#sklearn.metrics.DetCurveDisplay.from_estimator)
or [`from_predictions`](#sklearn.metrics.DetCurveDisplay.from_predictions) to create a
visualizer. All parameters are stored as attributes.

Read more in the [User Guide](../../visualizations.md#visualizations).

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **fpr**
  : False positive rate.

  **fnr**
  : False negative rate.

  **estimator_name**
  : Name of estimator. If None, the estimator name is not shown.

  **pos_label**
  : The label of the positive class.
* **Attributes:**
  **line_**
  : DET Curve.

  **ax_**
  : Axes with DET Curve.

  **figure_**
  : Figure containing the curve.

#### SEE ALSO
[`det_curve`](sklearn.metrics.det_curve.md#sklearn.metrics.det_curve)
: Compute error rates for different probability thresholds.

[`DetCurveDisplay.from_estimator`](#sklearn.metrics.DetCurveDisplay.from_estimator)
: Plot DET curve given an estimator and some data.

[`DetCurveDisplay.from_predictions`](#sklearn.metrics.DetCurveDisplay.from_predictions)
: Plot DET curve given the true and predicted labels.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import det_curve, DetCurveDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.svm import SVC
>>> X, y = make_classification(n_samples=1000, random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, test_size=0.4, random_state=0)
>>> clf = SVC(random_state=0).fit(X_train, y_train)
>>> y_pred = clf.decision_function(X_test)
>>> fpr, fnr, _ = det_curve(y_test, y_pred)
>>> display = DetCurveDisplay(
...     fpr=fpr, fnr=fnr, estimator_name="SVC"
... )
>>> display.plot()
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-DetCurveDisplay-1.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_estimator(estimator, X, y, \*, sample_weight=None, response_method='auto', pos_label=None, name=None, ax=None, \*\*kwargs)

Plot DET curve given an estimator and data.

Read more in the [User Guide](../../visualizations.md#visualizations).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **estimator**
  : Fitted classifier or a fitted [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)
    in which the last estimator is a classifier.

  **X**
  : Input values.

  **y**
  : Target values.

  **sample_weight**
  : Sample weights.

  **response_method**
  : Specifies whether to use [predict_proba](../../glossary.md#term-predict_proba) or
    [decision_function](../../glossary.md#term-decision_function) as the predicted target response. If set
    to ‘auto’, [predict_proba](../../glossary.md#term-predict_proba) is tried first and if it does not
    exist [decision_function](../../glossary.md#term-decision_function) is tried next.

  **pos_label**
  : The label of the positive class. When `pos_label=None`, if `y_true`
    is in {-1, 1} or {0, 1}, `pos_label` is set to 1, otherwise an
    error will be raised.

  **name**
  : Name of DET curve for labeling. If `None`, use the name of the
    estimator.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **\*\*kwargs**
  : Additional keywords arguments passed to matplotlib `plot` function.
* **Returns:**
  **display**
  : Object that stores computed values.

#### SEE ALSO
[`det_curve`](sklearn.metrics.det_curve.md#sklearn.metrics.det_curve)
: Compute error rates for different probability thresholds.

[`DetCurveDisplay.from_predictions`](#sklearn.metrics.DetCurveDisplay.from_predictions)
: Plot DET curve given the true and predicted labels.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import DetCurveDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.svm import SVC
>>> X, y = make_classification(n_samples=1000, random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, test_size=0.4, random_state=0)
>>> clf = SVC(random_state=0).fit(X_train, y_train)
>>> DetCurveDisplay.from_estimator(
...    clf, X_test, y_test)
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-DetCurveDisplay-2.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_predictions(y_true, y_pred, \*, sample_weight=None, pos_label=None, name=None, ax=None, \*\*kwargs)

Plot the DET curve given the true and predicted labels.

Read more in the [User Guide](../../visualizations.md#visualizations).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **y_true**
  : True labels.

  **y_pred**
  : Target scores, can either be probability estimates of the positive
    class, confidence values, or non-thresholded measure of decisions
    (as returned by `decision_function` on some classifiers).

  **sample_weight**
  : Sample weights.

  **pos_label**
  : The label of the positive class. When `pos_label=None`, if `y_true`
    is in {-1, 1} or {0, 1}, `pos_label` is set to 1, otherwise an
    error will be raised.

  **name**
  : Name of DET curve for labeling. If `None`, name will be set to
    `"Classifier"`.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **\*\*kwargs**
  : Additional keywords arguments passed to matplotlib `plot` function.
* **Returns:**
  **display**
  : Object that stores computed values.

#### SEE ALSO
[`det_curve`](sklearn.metrics.det_curve.md#sklearn.metrics.det_curve)
: Compute error rates for different probability thresholds.

[`DetCurveDisplay.from_estimator`](#sklearn.metrics.DetCurveDisplay.from_estimator)
: Plot DET curve given an estimator and some data.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import DetCurveDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.svm import SVC
>>> X, y = make_classification(n_samples=1000, random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, test_size=0.4, random_state=0)
>>> clf = SVC(random_state=0).fit(X_train, y_train)
>>> y_pred = clf.decision_function(X_test)
>>> DetCurveDisplay.from_predictions(
...    y_test, y_pred)
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-DetCurveDisplay-3.*)
<!-- !! processed by numpydoc !! -->

#### plot(ax=None, \*, name=None, \*\*kwargs)

Plot visualization.

* **Parameters:**
  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **name**
  : Name of DET curve for labeling. If `None`, use `estimator_name` if
    it is not `None`, otherwise no labeling is shown.

  **\*\*kwargs**
  : Additional keywords arguments passed to matplotlib `plot` function.
* **Returns:**
  **display**
  : Object that stores computed values.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we compare two binary classification multi-threshold metrics: the Receiver Operating Characteristic (ROC) and the Detection Error Tradeoff (DET). For such purpose, we evaluate two different classifiers for the same classification task.">  <div class="sphx-glr-thumbnail-title">Detection error tradeoff (DET) curve</div>
</div>
* [Detection error tradeoff (DET) curve](../../auto_examples/model_selection/plot_det.md#sphx-glr-auto-examples-model-selection-plot-det-py)

<!-- thumbnail-parent-div-close --></div>
