# rand_score

### sklearn.metrics.rand_score(labels_true, labels_pred)

Rand index.

The Rand Index computes a similarity measure between two clusterings
by considering all pairs of samples and counting pairs that are
assigned in the same or different clusters in the predicted and
true clusterings [[1]](#rbedd61930922-1) [[2]](#rbedd61930922-2).

The raw RI score [[3]](#rbedd61930922-3) is:

```text
RI = (number of agreeing pairs) / (number of pairs)
```

Read more in the [User Guide](../clustering.md#rand-score).

* **Parameters:**
  **labels_true**
  : Ground truth class labels to be used as a reference.

  **labels_pred**
  : Cluster labels to evaluate.
* **Returns:**
  **RI**
  : Similarity score between 0.0 and 1.0, inclusive, 1.0 stands for
    perfect match.

#### SEE ALSO
[`adjusted_rand_score`](sklearn.metrics.adjusted_rand_score.md#sklearn.metrics.adjusted_rand_score)
: Adjusted Rand Score.

[`adjusted_mutual_info_score`](sklearn.metrics.adjusted_mutual_info_score.md#sklearn.metrics.adjusted_mutual_info_score)
: Adjusted Mutual Information.

### References

### Examples

Perfectly matching labelings have a score of 1 even

```pycon
>>> from sklearn.metrics.cluster import rand_score
>>> rand_score([0, 0, 1, 1], [1, 1, 0, 0])
1.0
```

Labelings that assign all classes members to the same clusters
are complete but may not always be pure, hence penalized:

```pycon
>>> rand_score([0, 0, 1, 2], [0, 0, 1, 1])
np.float64(0.83...)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="- a first experiment with fixed &quot;ground truth labels&quot; (and therefore fixed   number of classes) and randomly &quot;predicted labels&quot;; - a second experiment with varying &quot;ground truth labels&quot;, randomly &quot;predicted   labels&quot;. The &quot;predicted labels&quot; have the same number of classes and clusters   as the &quot;ground truth labels&quot;.">  <div class="sphx-glr-thumbnail-title">Adjustment for chance in clustering performance evaluation</div>
</div>
* [Adjustment for chance in clustering performance evaluation](../../auto_examples/cluster/plot_adjusted_for_chance_measures.md#sphx-glr-auto-examples-cluster-plot-adjusted-for-chance-measures-py)

<!-- thumbnail-parent-div-close --></div>
