# make_gaussian_quantiles

### sklearn.datasets.make_gaussian_quantiles(\*, mean=None, cov=1.0, n_samples=100, n_features=2, n_classes=3, shuffle=True, random_state=None)

Generate isotropic Gaussian and label samples by quantile.

This classification dataset is constructed by taking a multi-dimensional
standard normal distribution and defining classes separated by nested
concentric multi-dimensional spheres such that roughly equal numbers of
samples are in each class (quantiles of the $\chi^2$ distribution).

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **mean**
  : The mean of the multi-dimensional normal distribution.
    If None then use the origin (0, 0, …).

  **cov**
  : The covariance matrix will be this value times the unit matrix. This
    dataset only produces symmetric normal distributions.

  **n_samples**
  : The total number of points equally divided among classes.

  **n_features**
  : The number of features for each sample.

  **n_classes**
  : The number of classes.

  **shuffle**
  : Shuffle the samples.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : The generated samples.

  **y**
  : The integer labels for quantile membership of each sample.

### Notes

The dataset is from Zhu et al [1].

### References

### Examples

```pycon
>>> from sklearn.datasets import make_gaussian_quantiles
>>> X, y = make_gaussian_quantiles(random_state=42)
>>> X.shape
(100, 2)
>>> y.shape
(100,)
>>> list(y[:5])
[np.int64(2), np.int64(0), np.int64(1), np.int64(0), np.int64(2)]
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows how boosting can improve the prediction accuracy on a multi-label classification problem. It reproduces a similar experiment as depicted by Figure 1 in Zhu et al [1]_.">  <div class="sphx-glr-thumbnail-title">Multi-class AdaBoosted Decision Trees</div>
</div>
* [Multi-class AdaBoosted Decision Trees](../../auto_examples/ensemble/plot_adaboost_multiclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-multiclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example fits an AdaBoosted decision stump on a non-linearly separable classification dataset composed of two &quot;Gaussian quantiles&quot; clusters (see sklearn.datasets.make_gaussian_quantiles) and plots the decision boundary and decision scores. The distributions of decision scores are shown separately for samples of class A and B. The predicted class label for each sample is determined by the sign of the decision score. Samples with decision scores greater than zero are classified as B, and are otherwise classified as A. The magnitude of a decision score determines the degree of likeness with the predicted class label. Additionally, a new dataset could be constructed containing a desired purity of class B, for example, by only selecting samples with a decision score above some value.">  <div class="sphx-glr-thumbnail-title">Two-class AdaBoost</div>
</div>
* [Two-class AdaBoost](../../auto_examples/ensemble/plot_adaboost_twoclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-twoclass-py)

<!-- thumbnail-parent-div-close --></div>
