# NeighborhoodComponentsAnalysis

### *class* sklearn.neighbors.NeighborhoodComponentsAnalysis(n_components=None, \*, init='auto', warm_start=False, max_iter=50, tol=1e-05, callback=None, verbose=0, random_state=None)

Neighborhood Components Analysis.

Neighborhood Component Analysis (NCA) is a machine learning algorithm for
metric learning. It learns a linear transformation in a supervised fashion
to improve the classification accuracy of a stochastic nearest neighbors
rule in the transformed space.

Read more in the [User Guide](../neighbors.md#nca).

* **Parameters:**
  **n_components**
  : Preferred dimensionality of the projected space.
    If None it will be set to `n_features`.

  **init**
  : Initialization of the linear transformation. Possible options are
    `'auto'`, `'pca'`, `'lda'`, `'identity'`, `'random'`, and a numpy
    array of shape `(n_features_a, n_features_b)`.
    - `'auto'`
      : Depending on `n_components`, the most reasonable initialization
        is chosen. If `n_components <= min(n_features, n_classes - 1)`
        we use `'lda'`, as it uses labels information. If not, but
        `n_components < min(n_features, n_samples)`, we use `'pca'`, as
        it projects data in meaningful directions (those of higher
        variance). Otherwise, we just use `'identity'`.
    - `'pca'`
      : `n_components` principal components of the inputs passed
        to [`fit`](#sklearn.neighbors.NeighborhoodComponentsAnalysis.fit) will be used to initialize the transformation.
        (See [`PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA))
    - `'lda'`
      : `min(n_components, n_classes)` most discriminative
        components of the inputs passed to [`fit`](#sklearn.neighbors.NeighborhoodComponentsAnalysis.fit) will be used to
        initialize the transformation. (If `n_components > n_classes`,
        the rest of the components will be zero.) (See
        [`LinearDiscriminantAnalysis`](sklearn.discriminant_analysis.LinearDiscriminantAnalysis.md#sklearn.discriminant_analysis.LinearDiscriminantAnalysis))
    - `'identity'`
      : If `n_components` is strictly smaller than the
        dimensionality of the inputs passed to [`fit`](#sklearn.neighbors.NeighborhoodComponentsAnalysis.fit), the identity
        matrix will be truncated to the first `n_components` rows.
    - `'random'`
      : The initial transformation will be a random array of shape
        `(n_components, n_features)`. Each value is sampled from the
        standard normal distribution.
    - numpy array
      : `n_features_b` must match the dimensionality of the inputs passed
        to [`fit`](#sklearn.neighbors.NeighborhoodComponentsAnalysis.fit) and n_features_a must be less than or equal to that.
        If `n_components` is not `None`, `n_features_a` must match it.

  **warm_start**
  : If `True` and [`fit`](#sklearn.neighbors.NeighborhoodComponentsAnalysis.fit) has been called before, the solution of the
    previous call to [`fit`](#sklearn.neighbors.NeighborhoodComponentsAnalysis.fit) is used as the initial linear
    transformation (`n_components` and `init` will be ignored).

  **max_iter**
  : Maximum number of iterations in the optimization.

  **tol**
  : Convergence tolerance for the optimization.

  **callback**
  : If not `None`, this function is called after every iteration of the
    optimizer, taking as arguments the current solution (flattened
    transformation matrix) and the number of iterations. This might be
    useful in case one wants to examine or store the transformation
    found after each iteration.

  **verbose**
  : If 0, no progress messages will be printed.
    If 1, progress messages will be printed to stdout.
    If > 1, progress messages will be printed and the `disp`
    parameter of [`scipy.optimize.minimize`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.minimize.html#scipy.optimize.minimize) will be set to
    `verbose - 2`.

  **random_state**
  : A pseudo random number generator object or a seed for it if int. If
    `init='random'`, `random_state` is used to initialize the random
    transformation. If `init='pca'`, `random_state` is passed as an
    argument to PCA when initializing the transformation. Pass an int
    for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **components_**
  : The linear transformation learned during fitting.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **n_iter_**
  : Counts the number of iterations performed by the optimizer.

  **random_state_**
  : Pseudo random number generator object used during initialization.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`sklearn.discriminant_analysis.LinearDiscriminantAnalysis`](sklearn.discriminant_analysis.LinearDiscriminantAnalysis.md#sklearn.discriminant_analysis.LinearDiscriminantAnalysis)
: Linear Discriminant Analysis.

[`sklearn.decomposition.PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA)
: Principal component analysis (PCA).

### References

### Examples

```pycon
>>> from sklearn.neighbors import NeighborhoodComponentsAnalysis
>>> from sklearn.neighbors import KNeighborsClassifier
>>> from sklearn.datasets import load_iris
>>> from sklearn.model_selection import train_test_split
>>> X, y = load_iris(return_X_y=True)
>>> X_train, X_test, y_train, y_test = train_test_split(X, y,
... stratify=y, test_size=0.7, random_state=42)
>>> nca = NeighborhoodComponentsAnalysis(random_state=42)
>>> nca.fit(X_train, y_train)
NeighborhoodComponentsAnalysis(...)
>>> knn = KNeighborsClassifier(n_neighbors=3)
>>> knn.fit(X_train, y_train)
KNeighborsClassifier(...)
>>> print(knn.score(X_test, y_test))
0.933333...
>>> knn.fit(nca.transform(X_train), y_train)
KNeighborsClassifier(...)
>>> print(knn.score(nca.transform(X_test), y_test))
0.961904...
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit the model according to the given training data.

* **Parameters:**
  **X**
  : The training samples.

  **y**
  : The corresponding training labels.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Apply the learned transformation to the given data.

* **Parameters:**
  **X**
  : Data samples.
* **Returns:**
  X_embedded: ndarray of shape (n_samples, n_components)
  : The data samples transformed.
* **Raises:**
  NotFittedError
  : If [`fit`](#sklearn.neighbors.NeighborhoodComponentsAnalysis.fit) has not been called before.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="We illustrate various embedding techniques on the digits dataset.">  <div class="sphx-glr-thumbnail-title">Manifold learning on handwritten digits: Locally Linear Embedding, Isomap...</div>
</div>
* [Manifold learning on handwritten digits: Locally Linear Embedding, Isomap…](../../auto_examples/manifold/plot_lle_digits.md#sphx-glr-auto-examples-manifold-plot-lle-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example comparing nearest neighbors classification with and without Neighborhood Components Analysis.">  <div class="sphx-glr-thumbnail-title">Comparing Nearest Neighbors with and without Neighborhood Components Analysis</div>
</div>
* [Comparing Nearest Neighbors with and without Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_classification.md#sphx-glr-auto-examples-neighbors-plot-nca-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Sample usage of Neighborhood Components Analysis for dimensionality reduction.">  <div class="sphx-glr-thumbnail-title">Dimensionality Reduction with Neighborhood Components Analysis</div>
</div>
* [Dimensionality Reduction with Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_dim_reduction.md#sphx-glr-auto-examples-neighbors-plot-nca-dim-reduction-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates a learned distance metric that maximizes the nearest neighbors classification accuracy. It provides a visual representation of this metric compared to the original point space. Please refer to the User Guide &lt;nca&gt; for more information.">  <div class="sphx-glr-thumbnail-title">Neighborhood Components Analysis Illustration</div>
</div>
* [Neighborhood Components Analysis Illustration](../../auto_examples/neighbors/plot_nca_illustration.md#sphx-glr-auto-examples-neighbors-plot-nca-illustration-py)

<!-- thumbnail-parent-div-close --></div>
