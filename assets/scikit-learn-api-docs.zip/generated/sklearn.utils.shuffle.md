# shuffle

### sklearn.utils.shuffle(\*arrays, random_state=None, n_samples=None)

Shuffle arrays or sparse matrices in a consistent way.

This is a convenience alias to `resample(*arrays, replace=False)` to do
random permutations of the collections.

* **Parameters:**
  **\*arrays**
  : Indexable data-structures can be arrays, lists, dataframes or scipy
    sparse matrices with consistent first dimension.

  **random_state**
  : Determines random number generation for shuffling
    the data.
    Pass an int for reproducible results across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **n_samples**
  : Number of samples to generate. If left to None this is
    automatically set to the first dimension of the arrays.  It should
    not be larger than the length of arrays.
* **Returns:**
  **shuffled_arrays**
  : Sequence of shuffled copies of the collections. The original arrays
    are not impacted.

#### SEE ALSO
[`resample`](sklearn.utils.resample.md#sklearn.utils.resample)
: Resample arrays or sparse matrices in a consistent way.

### Examples

It is possible to mix sparse and dense arrays in the same run:

```default
>>> import numpy as np
>>> X = np.array([[1., 0.], [2., 1.], [0., 0.]])
>>> y = np.array([0, 1, 2])

>>> from scipy.sparse import coo_matrix
>>> X_sparse = coo_matrix(X)

>>> from sklearn.utils import shuffle
>>> X, X_sparse, y = shuffle(X, X_sparse, y, random_state=0)
>>> X
array([[0., 0.],
       [2., 1.],
       [1., 0.]])

>>> X_sparse
<Compressed Sparse Row sparse matrix of dtype 'float64'
    with 3 stored elements and shape (3, 2)>

>>> X_sparse.toarray()
array([[0., 0.],
       [2., 1.],
       [1., 0.]])

>>> y
array([2, 1, 0])

>>> shuffle(y, n_samples=2, random_state=0)
array([0, 1])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This is an example showing the prediction latency of various scikit-learn estimators.">  <div class="sphx-glr-thumbnail-title">Prediction Latency</div>
</div>
* [Prediction Latency](../../auto_examples/applications/plot_prediction_latency.md#sphx-glr-auto-examples-applications-plot-prediction-latency-py)

<div class="sphx-glr-thumbcontainer" tooltip="Evaluate the ability of k-means initializations strategies to make the algorithm convergence robust, as measured by the relative standard deviation of the inertia of the clustering (i.e. the sum of squared distances to the nearest cluster center).">  <div class="sphx-glr-thumbnail-title">Empirical evaluation of the impact of k-means initialization</div>
</div>
* [Empirical evaluation of the impact of k-means initialization](../../auto_examples/cluster/plot_kmeans_stability_low_dim_dense.md#sphx-glr-auto-examples-cluster-plot-kmeans-stability-low-dim-dense-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stacking refers to a method to blend estimators. In this strategy, some estimators are individually fitted on some training data while a final estimator is trained using the stacked predictions of these base estimators.">  <div class="sphx-glr-thumbnail-title">Combine predictors using stacking</div>
</div>
* [Combine predictors using stacking](../../auto_examples/ensemble/plot_stack_predictors.md#sphx-glr-auto-examples-ensemble-plot-stack-predictors-py)

<div class="sphx-glr-thumbcontainer" tooltip="Stochastic Gradient Descent is an optimization technique which minimizes a loss function in a stochastic fashion, performing a gradient descent step sample by sample. In particular, it is a very efficient method to fit linear models.">  <div class="sphx-glr-thumbnail-title">Early stopping of Stochastic Gradient Descent</div>
</div>
* [Early stopping of Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgd_early_stopping.md#sphx-glr-auto-examples-linear-model-plot-sgd-early-stopping-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents how to chain KNeighborsTransformer and TSNE in a pipeline. It also shows how to wrap the packages nmslib and pynndescent to replace KNeighborsTransformer and perform approximate nearest neighbors. These packages can be installed with pip install nmslib pynndescent.">  <div class="sphx-glr-thumbnail-title">Approximate nearest neighbors in TSNE</div>
</div>
* [Approximate nearest neighbors in TSNE](../../auto_examples/neighbors/approximate_nearest_neighbors.md#sphx-glr-auto-examples-neighbors-approximate-nearest-neighbors-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the effect of a varying threshold on self-training. The breast_cancer dataset is loaded, and labels are deleted such that only 50 out of 569 samples have labels. A SelfTrainingClassifier is fitted on this dataset, with varying thresholds.">  <div class="sphx-glr-thumbnail-title">Effect of varying threshold for self-training</div>
</div>
* [Effect of varying threshold for self-training](../../auto_examples/semi_supervised/plot_self_training_varying_threshold.md#sphx-glr-auto-examples-semi-supervised-plot-self-training-varying-threshold-py)

<!-- thumbnail-parent-div-close --></div>
