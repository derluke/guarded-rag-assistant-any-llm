# ConfusionMatrixDisplay

### *class* sklearn.metrics.ConfusionMatrixDisplay(confusion_matrix, \*, display_labels=None)

Confusion Matrix visualization.

It is recommend to use
[`from_estimator`](#sklearn.metrics.ConfusionMatrixDisplay.from_estimator) or
[`from_predictions`](#sklearn.metrics.ConfusionMatrixDisplay.from_predictions) to
create a [`ConfusionMatrixDisplay`](#sklearn.metrics.ConfusionMatrixDisplay). All parameters are stored as
attributes.

Read more in the [User Guide](../../visualizations.md#visualizations).

* **Parameters:**
  **confusion_matrix**
  : Confusion matrix.

  **display_labels**
  : Display labels for plot. If None, display labels are set from 0 to
    `n_classes - 1`.
* **Attributes:**
  **im_**
  : Image representing the confusion matrix.

  **text_**
  : Array of matplotlib axes. `None` if `include_values` is false.

  **ax_**
  : Axes with confusion matrix.

  **figure_**
  : Figure containing the confusion matrix.

#### SEE ALSO
[`confusion_matrix`](sklearn.metrics.confusion_matrix.md#sklearn.metrics.confusion_matrix)
: Compute Confusion Matrix to evaluate the accuracy of a classification.

[`ConfusionMatrixDisplay.from_estimator`](#sklearn.metrics.ConfusionMatrixDisplay.from_estimator)
: Plot the confusion matrix given an estimator, the data, and the label.

[`ConfusionMatrixDisplay.from_predictions`](#sklearn.metrics.ConfusionMatrixDisplay.from_predictions)
: Plot the confusion matrix given the true and predicted labels.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.svm import SVC
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(X, y,
...                                                     random_state=0)
>>> clf = SVC(random_state=0)
>>> clf.fit(X_train, y_train)
SVC(random_state=0)
>>> predictions = clf.predict(X_test)
>>> cm = confusion_matrix(y_test, predictions, labels=clf.classes_)
>>> disp = ConfusionMatrixDisplay(confusion_matrix=cm,
...                               display_labels=clf.classes_)
>>> disp.plot()
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-ConfusionMatrixDisplay-1.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_estimator(estimator, X, y, \*, labels=None, sample_weight=None, normalize=None, display_labels=None, include_values=True, xticks_rotation='horizontal', values_format=None, cmap='viridis', ax=None, colorbar=True, im_kw=None, text_kw=None)

Plot Confusion Matrix given an estimator and some data.

Read more in the [User Guide](../model_evaluation.md#confusion-matrix).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **estimator**
  : Fitted classifier or a fitted [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)
    in which the last estimator is a classifier.

  **X**
  : Input values.

  **y**
  : Target values.

  **labels**
  : List of labels to index the confusion matrix. This may be used to
    reorder or select a subset of labels. If `None` is given, those
    that appear at least once in `y_true` or `y_pred` are used in
    sorted order.

  **sample_weight**
  : Sample weights.

  **normalize**
  : Either to normalize the counts display in the matrix:
    - if `'true'`, the confusion matrix is normalized over the true
      conditions (e.g. rows);
    - if `'pred'`, the confusion matrix is normalized over the
      predicted conditions (e.g. columns);
    - if `'all'`, the confusion matrix is normalized by the total
      number of samples;
    - if `None` (default), the confusion matrix will not be normalized.

  **display_labels**
  : Target names used for plotting. By default, `labels` will be used
    if it is defined, otherwise the unique labels of `y_true` and
    `y_pred` will be used.

  **include_values**
  : Includes values in confusion matrix.

  **xticks_rotation**
  : Rotation of xtick labels.

  **values_format**
  : Format specification for values in confusion matrix. If `None`, the
    format specification is ‘d’ or ‘.2g’ whichever is shorter.

  **cmap**
  : Colormap recognized by matplotlib.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **colorbar**
  : Whether or not to add a colorbar to the plot.

  **im_kw**
  : Dict with keywords passed to `matplotlib.pyplot.imshow` call.

  **text_kw**
  : Dict with keywords passed to `matplotlib.pyplot.text` call.
    <br/>
    #### Versionadded
    Added in version 1.2.
* **Returns:**
  **display**

#### SEE ALSO
[`ConfusionMatrixDisplay.from_predictions`](#sklearn.metrics.ConfusionMatrixDisplay.from_predictions)
: Plot the confusion matrix given the true and predicted labels.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import ConfusionMatrixDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.svm import SVC
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...         X, y, random_state=0)
>>> clf = SVC(random_state=0)
>>> clf.fit(X_train, y_train)
SVC(random_state=0)
>>> ConfusionMatrixDisplay.from_estimator(
...     clf, X_test, y_test)
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-ConfusionMatrixDisplay-2.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_predictions(y_true, y_pred, \*, labels=None, sample_weight=None, normalize=None, display_labels=None, include_values=True, xticks_rotation='horizontal', values_format=None, cmap='viridis', ax=None, colorbar=True, im_kw=None, text_kw=None)

Plot Confusion Matrix given true and predicted labels.

Read more in the [User Guide](../model_evaluation.md#confusion-matrix).

#### Versionadded
Added in version 1.0.

* **Parameters:**
  **y_true**
  : True labels.

  **y_pred**
  : The predicted labels given by the method `predict` of an
    classifier.

  **labels**
  : List of labels to index the confusion matrix. This may be used to
    reorder or select a subset of labels. If `None` is given, those
    that appear at least once in `y_true` or `y_pred` are used in
    sorted order.

  **sample_weight**
  : Sample weights.

  **normalize**
  : Either to normalize the counts display in the matrix:
    - if `'true'`, the confusion matrix is normalized over the true
      conditions (e.g. rows);
    - if `'pred'`, the confusion matrix is normalized over the
      predicted conditions (e.g. columns);
    - if `'all'`, the confusion matrix is normalized by the total
      number of samples;
    - if `None` (default), the confusion matrix will not be normalized.

  **display_labels**
  : Target names used for plotting. By default, `labels` will be used
    if it is defined, otherwise the unique labels of `y_true` and
    `y_pred` will be used.

  **include_values**
  : Includes values in confusion matrix.

  **xticks_rotation**
  : Rotation of xtick labels.

  **values_format**
  : Format specification for values in confusion matrix. If `None`, the
    format specification is ‘d’ or ‘.2g’ whichever is shorter.

  **cmap**
  : Colormap recognized by matplotlib.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **colorbar**
  : Whether or not to add a colorbar to the plot.

  **im_kw**
  : Dict with keywords passed to `matplotlib.pyplot.imshow` call.

  **text_kw**
  : Dict with keywords passed to `matplotlib.pyplot.text` call.
    <br/>
    #### Versionadded
    Added in version 1.2.
* **Returns:**
  **display**

#### SEE ALSO
[`ConfusionMatrixDisplay.from_estimator`](#sklearn.metrics.ConfusionMatrixDisplay.from_estimator)
: Plot the confusion matrix given an estimator, the data, and the label.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import make_classification
>>> from sklearn.metrics import ConfusionMatrixDisplay
>>> from sklearn.model_selection import train_test_split
>>> from sklearn.svm import SVC
>>> X, y = make_classification(random_state=0)
>>> X_train, X_test, y_train, y_test = train_test_split(
...         X, y, random_state=0)
>>> clf = SVC(random_state=0)
>>> clf.fit(X_train, y_train)
SVC(random_state=0)
>>> y_pred = clf.predict(X_test)
>>> ConfusionMatrixDisplay.from_predictions(
...    y_test, y_pred)
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-metrics-ConfusionMatrixDisplay-3.*)
<!-- !! processed by numpydoc !! -->

#### plot(\*, include_values=True, cmap='viridis', xticks_rotation='horizontal', values_format=None, ax=None, colorbar=True, im_kw=None, text_kw=None)

Plot visualization.

* **Parameters:**
  **include_values**
  : Includes values in confusion matrix.

  **cmap**
  : Colormap recognized by matplotlib.

  **xticks_rotation**
  : Rotation of xtick labels.

  **values_format**
  : Format specification for values in confusion matrix. If `None`,
    the format specification is ‘d’ or ‘.2g’ whichever is shorter.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **colorbar**
  : Whether or not to add a colorbar to the plot.

  **im_kw**
  : Dict with keywords passed to `matplotlib.pyplot.imshow` call.

  **text_kw**
  : Dict with keywords passed to `matplotlib.pyplot.text` call.
    <br/>
    #### Versionadded
    Added in version 1.2.
* **Returns:**
  **display**
  : Returns a [`ConfusionMatrixDisplay`](#sklearn.metrics.ConfusionMatrixDisplay) instance
    that contains all the information to plot the confusion matrix.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is a preprocessed excerpt of the &quot;Labeled Faces in the Wild&quot;, aka LFW_: http://vis-www.cs.umass.edu/lfw/lfw-funneled.tgz (233MB)">  <div class="sphx-glr-thumbnail-title">Faces recognition example using eigenfaces and SVMs</div>
</div>
* [Faces recognition example using eigenfaces and SVMs](../../auto_examples/applications/plot_face_recognition.md#sphx-glr-auto-examples-applications-plot-face-recognition-py)

<div class="sphx-glr-thumbcontainer" tooltip="Example of confusion matrix usage to evaluate the quality of the output of a classifier on the iris data set. The diagonal elements represent the number of points for which the predicted label is equal to the true label, while off-diagonal elements are those that are mislabeled by the classifier. The higher the diagonal values of the confusion matrix the better, indicating many correct predictions.">  <div class="sphx-glr-thumbnail-title">Confusion matrix</div>
</div>
* [Confusion matrix](../../auto_examples/model_selection/plot_confusion_matrix.md#sphx-glr-auto-examples-model-selection-plot-confusion-matrix-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how scikit-learn can be used to recognize images of hand-written digits, from 0-9.">  <div class="sphx-glr-thumbnail-title">Recognizing hand-written digits</div>
</div>
* [Recognizing hand-written digits](../../auto_examples/classification/plot_digits_classification.md#sphx-glr-auto-examples-classification-plot-digits-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the power of semisupervised learning by training a Label Spreading model to classify handwritten digits with sets of very few labels.">  <div class="sphx-glr-thumbnail-title">Label Propagation digits: Demonstrating performance</div>
</div>
* [Label Propagation digits: Demonstrating performance](../../auto_examples/semi_supervised/plot_label_propagation_digits.md#sphx-glr-auto-examples-semi-supervised-plot-label-propagation-digits-py)

<div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used to classify documents by topics using a Bag of Words approach. This example uses a Tf-idf-weighted document-term sparse matrix to encode the features and demonstrates various classifiers that can efficiently handle sparse matrices.">  <div class="sphx-glr-thumbnail-title">Classification of text documents using sparse features</div>
</div>
* [Classification of text documents using sparse features](../../auto_examples/text/plot_document_classification_20newsgroups.md#sphx-glr-auto-examples-text-plot-document-classification-20newsgroups-py)

<!-- thumbnail-parent-div-close --></div>
