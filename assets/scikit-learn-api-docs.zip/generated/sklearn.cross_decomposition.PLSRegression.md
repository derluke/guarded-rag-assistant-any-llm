# PLSRegression

### *class* sklearn.cross_decomposition.PLSRegression(n_components=2, \*, scale=True, max_iter=500, tol=1e-06, copy=True)

PLS regression.

PLSRegression is also known as PLS2 or PLS1, depending on the number of
targets.

For a comparison between other cross decomposition algorithms, see
[Compare cross decomposition methods](../../auto_examples/cross_decomposition/plot_compare_cross_decomposition.md#sphx-glr-auto-examples-cross-decomposition-plot-compare-cross-decomposition-py).

Read more in the [User Guide](../cross_decomposition.md#cross-decomposition).

#### Versionadded
Added in version 0.8.

* **Parameters:**
  **n_components**
  : Number of components to keep. Should be in `[1, n_features]`.

  **scale**
  : Whether to scale `X` and `Y`.

  **max_iter**
  : The maximum number of iterations of the power method when
    `algorithm='nipals'`. Ignored otherwise.

  **tol**
  : The tolerance used as convergence criteria in the power method: the
    algorithm stops whenever the squared norm of `u_i - u_{i-1}` is less
    than `tol`, where `u` corresponds to the left singular vector.

  **copy**
  : Whether to copy `X` and `Y` in [fit](../../glossary.md#term-fit) before applying centering,
    and potentially scaling. If `False`, these operations will be done
    inplace, modifying both arrays.
* **Attributes:**
  **x_weights_**
  : The left singular vectors of the cross-covariance matrices of each
    iteration.

  **y_weights_**
  : The right singular vectors of the cross-covariance matrices of each
    iteration.

  **x_loadings_**
  : The loadings of `X`.

  **y_loadings_**
  : The loadings of `Y`.

  **x_scores_**
  : The transformed training samples.

  **y_scores_**
  : The transformed training targets.

  **x_rotations_**
  : The projection matrix used to transform `X`.

  **y_rotations_**
  : The projection matrix used to transform `Y`.

  **coef_**
  : The coefficients of the linear model such that `Y` is approximated as
    `Y = X @ coef_.T + intercept_`.

  **intercept_**
  : The intercepts of the linear model such that `Y` is approximated as
    `Y = X @ coef_.T + intercept_`.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **n_iter_**
  : Number of iterations of the power method, for each
    component.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`PLSCanonical`](sklearn.cross_decomposition.PLSCanonical.md#sklearn.cross_decomposition.PLSCanonical)
: Partial Least Squares transformer and regressor.

### Examples

```pycon
>>> from sklearn.cross_decomposition import PLSRegression
>>> X = [[0., 0., 1.], [1.,0.,0.], [2.,2.,2.], [2.,5.,4.]]
>>> y = [[0.1, -0.2], [0.9, 1.1], [6.2, 5.9], [11.9, 12.3]]
>>> pls2 = PLSRegression(n_components=2)
>>> pls2.fit(X, y)
PLSRegression()
>>> Y_pred = pls2.predict(X)
```

For a comparison between PLS Regression and [`PCA`](sklearn.decomposition.PCA.md#sklearn.decomposition.PCA), see
[Principal Component Regression vs Partial Least Squares Regression](../../auto_examples/cross_decomposition/plot_pcr_vs_pls.md#sphx-glr-auto-examples-cross-decomposition-plot-pcr-vs-pls-py).

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, Y=None)

Fit model to data.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of predictors.

  **y**
  : Target vectors, where `n_samples` is the number of samples and
    `n_targets` is the number of response variables.

  **Y**
  : Target vectors, where `n_samples` is the number of samples and
    `n_targets` is the number of response variables.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Y` is deprecated in 1.5 and will be removed in 1.7. Use `y` instead.
* **Returns:**
  **self**
  : Fitted model.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Learn and apply the dimension reduction on the train data.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of predictors.

  **y**
  : Target vectors, where `n_samples` is the number of samples and
    `n_targets` is the number of response variables.
* **Returns:**
  **self**
  : Return `x_scores` if `Y` is not given, `(x_scores, y_scores)` otherwise.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X, y=None, Y=None)

Transform data back to its original space.

* **Parameters:**
  **X**
  : New data, where `n_samples` is the number of samples
    and `n_components` is the number of pls components.

  **y**
  : New target, where `n_samples` is the number of samples
    and `n_components` is the number of pls components.

  **Y**
  : New target, where `n_samples` is the number of samples
    and `n_components` is the number of pls components.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Y` is deprecated in 1.5 and will be removed in 1.7. Use `y` instead.
* **Returns:**
  **X_reconstructed**
  : Return the reconstructed `X` data.

  **y_reconstructed**
  : Return the reconstructed `X` target. Only returned when `y` is given.

### Notes

This transformation will only be exact if `n_components=n_features`.

<!-- !! processed by numpydoc !! -->

#### predict(X, copy=True)

Predict targets of given samples.

* **Parameters:**
  **X**
  : Samples.

  **copy**
  : Whether to copy `X` and `Y`, or perform in-place normalization.
* **Returns:**
  **y_pred**
  : Returns predicted values.

### Notes

This call requires the estimation of a matrix of shape
`(n_features, n_targets)`, which may be an issue in high dimensional
space.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_predict_request(\*, copy: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PLSRegression](#sklearn.cross_decomposition.PLSRegression)

Request metadata passed to the `predict` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `predict` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `predict`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **copy**
  : Metadata routing for `copy` parameter in `predict`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PLSRegression](#sklearn.cross_decomposition.PLSRegression)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_transform_request(\*, copy: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PLSRegression](#sklearn.cross_decomposition.PLSRegression)

Request metadata passed to the `transform` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `transform` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `transform`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **copy**
  : Metadata routing for `copy` parameter in `transform`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### transform(X, y=None, Y=None, copy=True)

Apply the dimension reduction.

* **Parameters:**
  **X**
  : Samples to transform.

  **y**
  : Target vectors.

  **Y**
  : Target vectors.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Y` is deprecated in 1.5 and will be removed in 1.7. Use `y` instead.

  **copy**
  : Whether to copy `X` and `Y`, or perform in-place normalization.
* **Returns:**
  **x_scores, y_scores**
  : Return `x_scores` if `Y` is not given, `(x_scores, y_scores)` otherwise.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Simple usage of various cross decomposition algorithms:">  <div class="sphx-glr-thumbnail-title">Compare cross decomposition methods</div>
</div>
* [Compare cross decomposition methods](../../auto_examples/cross_decomposition/plot_compare_cross_decomposition.md#sphx-glr-auto-examples-cross-decomposition-plot-compare-cross-decomposition-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares Principal Component Regression (PCR) and Partial Least Squares Regression (PLS) on a toy dataset. Our goal is to illustrate how PLS can outperform PCR when the target is strongly correlated with some directions in the data that have a low variance.">  <div class="sphx-glr-thumbnail-title">Principal Component Regression vs Partial Least Squares Regression</div>
</div>
* [Principal Component Regression vs Partial Least Squares Regression](../../auto_examples/cross_decomposition/plot_pcr_vs_pls.md#sphx-glr-auto-examples-cross-decomposition-plot-pcr-vs-pls-py)

<!-- thumbnail-parent-div-close --></div>
