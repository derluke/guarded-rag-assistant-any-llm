# roc_curve

### sklearn.metrics.roc_curve(y_true, y_score, \*, pos_label=None, sample_weight=None, drop_intermediate=True)

Compute Receiver operating characteristic (ROC).

Note: this implementation is restricted to the binary classification task.

Read more in the [User Guide](../model_evaluation.md#roc-metrics).

* **Parameters:**
  **y_true**
  : True binary labels. If labels are not either {-1, 1} or {0, 1}, then
    pos_label should be explicitly given.

  **y_score**
  : Target scores, can either be probability estimates of the positive
    class, confidence values, or non-thresholded measure of decisions
    (as returned by “decision_function” on some classifiers).
    For [decision_function](../../glossary.md#term-decision_function) scores, values greater than or equal to
    zero should indicate the positive class.

  **pos_label**
  : The label of the positive class.
    When `pos_label=None`, if `y_true` is in {-1, 1} or {0, 1},
    `pos_label` is set to 1, otherwise an error will be raised.

  **sample_weight**
  : Sample weights.

  **drop_intermediate**
  : Whether to drop some suboptimal thresholds which would not appear
    on a plotted ROC curve. This is useful in order to create lighter
    ROC curves.
    <br/>
    #### Versionadded
    Added in version 0.17: parameter *drop_intermediate*.
* **Returns:**
  **fpr**
  : Increasing false positive rates such that element i is the false
    positive rate of predictions with score >= `thresholds[i]`.

  **tpr**
  : Increasing true positive rates such that element `i` is the true
    positive rate of predictions with score >= `thresholds[i]`.

  **thresholds**
  : Decreasing thresholds on the decision function used to compute
    fpr and tpr. `thresholds[0]` represents no instances being predicted
    and is arbitrarily set to `np.inf`.

#### SEE ALSO
[`RocCurveDisplay.from_estimator`](sklearn.metrics.RocCurveDisplay.md#sklearn.metrics.RocCurveDisplay.from_estimator)
: Plot Receiver Operating Characteristic (ROC) curve given an estimator and some data.

[`RocCurveDisplay.from_predictions`](sklearn.metrics.RocCurveDisplay.md#sklearn.metrics.RocCurveDisplay.from_predictions)
: Plot Receiver Operating Characteristic (ROC) curve given the true and predicted values.

[`det_curve`](sklearn.metrics.det_curve.md#sklearn.metrics.det_curve)
: Compute error rates for different probability thresholds.

[`roc_auc_score`](sklearn.metrics.roc_auc_score.md#sklearn.metrics.roc_auc_score)
: Compute the area under the ROC curve.

### Notes

Since the thresholds are sorted from low to high values, they
are reversed upon returning them to ensure they correspond to both `fpr`
and `tpr`, which are sorted in reversed order during their calculation.

An arbitrary threshold is added for the case `tpr=0` and `fpr=0` to
ensure that the curve starts at `(0, 0)`. This threshold corresponds to the
`np.inf`.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn import metrics
>>> y = np.array([1, 1, 2, 2])
>>> scores = np.array([0.1, 0.4, 0.35, 0.8])
>>> fpr, tpr, thresholds = metrics.roc_curve(y, scores, pos_label=2)
>>> fpr
array([0. , 0. , 0.5, 0.5, 1. ])
>>> tpr
array([0. , 0.5, 0.5, 1. , 1. ])
>>> thresholds
array([ inf, 0.8 , 0.4 , 0.35, 0.1 ])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Modeling species&#x27; geographic distributions is an important problem in conservation biology. In this example, we model the geographic distribution of two South American mammals given past observations and 14 environmental variables. Since we have only positive examples (there are no unsuccessful observations), we cast this problem as a density estimation problem and use the OneClassSVM as our modeling tool. The dataset is provided by Phillips et. al. (2006). If available, the example uses basemap to plot the coast lines and national boundaries of South America.">  <div class="sphx-glr-thumbnail-title">Species distribution modeling</div>
</div>
* [Species distribution modeling](../../auto_examples/applications/plot_species_distribution_modeling.md#sphx-glr-auto-examples-applications-plot-species-distribution-modeling-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we will construct display objects, ConfusionMatrixDisplay, RocCurveDisplay, and PrecisionRecallDisplay directly from their respective metrics. This is an alternative to using their corresponding plot functions when a model&#x27;s predictions are already computed or expensive to compute. Note that this is advanced usage, and in general we recommend using their respective plot functions.">  <div class="sphx-glr-thumbnail-title">Visualizations with Display Objects</div>
</div>
* [Visualizations with Display Objects](../../auto_examples/miscellaneous/plot_display_object_visualization.md#sphx-glr-auto-examples-miscellaneous-plot-display-object-visualization-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this example, we compare two binary classification multi-threshold metrics: the Receiver Operating Characteristic (ROC) and the Detection Error Tradeoff (DET). For such purpose, we evaluate two different classifiers for the same classification task.">  <div class="sphx-glr-thumbnail-title">Detection error tradeoff (DET) curve</div>
</div>
* [Detection error tradeoff (DET) curve](../../auto_examples/model_selection/plot_det.md#sphx-glr-auto-examples-model-selection-plot-det-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example describes the use of the Receiver Operating Characteristic (ROC) metric to evaluate the quality of multiclass classifiers.">  <div class="sphx-glr-thumbnail-title">Multiclass Receiver Operating Characteristic (ROC)</div>
</div>
* [Multiclass Receiver Operating Characteristic (ROC)](../../auto_examples/model_selection/plot_roc.md#sphx-glr-auto-examples-model-selection-plot-roc-py)

<!-- thumbnail-parent-div-close --></div>
