# PoissonRegressor

### *class* sklearn.linear_model.PoissonRegressor(\*, alpha=1.0, fit_intercept=True, solver='lbfgs', max_iter=100, tol=0.0001, warm_start=False, verbose=0)

Generalized Linear Model with a Poisson distribution.

This regressor uses the ‘log’ link function.

Read more in the [User Guide](../linear_model.md#generalized-linear-models).

#### Versionadded
Added in version 0.23.

* **Parameters:**
  **alpha**
  : Constant that multiplies the L2 penalty term and determines the
    regularization strength. `alpha = 0` is equivalent to unpenalized
    GLMs. In this case, the design matrix `X` must have full column rank
    (no collinearities).
    Values of `alpha` must be in the range `[0.0, inf)`.

  **fit_intercept**
  : Specifies if a constant (a.k.a. bias or intercept) should be
    added to the linear predictor (`X @ coef + intercept`).

  **solver**
  : Algorithm to use in the optimization problem:
    <br/>
    ‘lbfgs’
    : Calls scipy’s L-BFGS-B optimizer.
    <br/>
    ‘newton-cholesky’
    : Uses Newton-Raphson steps (in arbitrary precision arithmetic equivalent to
      iterated reweighted least squares) with an inner Cholesky based solver.
      This solver is a good choice for `n_samples` >> `n_features`, especially
      with one-hot encoded categorical features with rare categories. Be aware
      that the memory usage of this solver has a quadratic dependency on
      `n_features` because it explicitly computes the Hessian matrix.
      <br/>
      #### Versionadded
      Added in version 1.2.

  **max_iter**
  : The maximal number of iterations for the solver.
    Values must be in the range `[1, inf)`.

  **tol**
  : Stopping criterion. For the lbfgs solver,
    the iteration will stop when `max{|g_j|, j = 1, ..., d} <= tol`
    where `g_j` is the j-th component of the gradient (derivative) of
    the objective function.
    Values must be in the range `(0.0, inf)`.

  **warm_start**
  : If set to `True`, reuse the solution of the previous call to `fit`
    as initialization for `coef_` and `intercept_` .

  **verbose**
  : For the lbfgs solver set verbose to any positive number for verbosity.
    Values must be in the range `[0, inf)`.
* **Attributes:**
  **coef_**
  : Estimated coefficients for the linear predictor (`X @ coef_ +
    intercept_`) in the GLM.

  **intercept_**
  : Intercept (a.k.a. bias) added to linear predictor.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Actual number of iterations used in the solver.

#### SEE ALSO
[`TweedieRegressor`](sklearn.linear_model.TweedieRegressor.md#sklearn.linear_model.TweedieRegressor)
: Generalized Linear Model with a Tweedie distribution.

### Examples

```pycon
>>> from sklearn import linear_model
>>> clf = linear_model.PoissonRegressor()
>>> X = [[1, 2], [2, 3], [3, 4], [4, 3]]
>>> y = [12, 17, 22, 21]
>>> clf.fit(X, y)
PoissonRegressor()
>>> clf.score(X, y)
np.float64(0.990...)
>>> clf.coef_
array([0.121..., 0.158...])
>>> clf.intercept_
np.float64(2.088...)
>>> clf.predict([[1, 1], [3, 4]])
array([10.676..., 21.875...])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None)

Fit a Generalized Linear Model.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **self**
  : Fitted model.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using GLM with feature matrix X.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **y_pred**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Compute D^2, the percentage of deviance explained.

D^2 is a generalization of the coefficient of determination R^2.
R^2 uses squared error and D^2 uses the deviance of this GLM, see the
[User Guide](../model_evaluation.md#regression-metrics).

D^2 is defined as
$D^2 = 1-\frac{D(y_{true},y_{pred})}{D_{null}}$,
$D_{null}$ is the null deviance, i.e. the deviance of a model
with intercept alone, which corresponds to $y_{pred} = \bar{y}$.
The mean $\bar{y}$ is averaged by sample_weight.
Best possible score is 1.0 and it can be negative (because the model
can be arbitrarily worse).

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True values of target.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : D^2 of self.predict(X) w.r.t. y.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PoissonRegressor](#sklearn.linear_model.PoissonRegressor)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [PoissonRegressor](#sklearn.linear_model.PoissonRegressor)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of log-linear Poisson regression on the French Motor Third-Party Liability Claims dataset from [1]_ and compares it with a linear model fitted with the usual least squared error and a non-linear GBRT model fitted with the Poisson loss (and a log-link).">  <div class="sphx-glr-thumbnail-title">Poisson regression and non-normal loss</div>
</div>
* [Poisson regression and non-normal loss](../../auto_examples/linear_model/plot_poisson_regression_non_normal_loss.md#sphx-glr-auto-examples-linear-model-plot-poisson-regression-non-normal-loss-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the use of Poisson, Gamma and Tweedie regression on the French Motor Third-Party Liability Claims dataset, and is inspired by an R tutorial [1]_.">  <div class="sphx-glr-thumbnail-title">Tweedie regression on insurance claims</div>
</div>
* [Tweedie regression on insurance claims](../../auto_examples/linear_model/plot_tweedie_regression_insurance_claims.md#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<!-- thumbnail-parent-div-close --></div>
