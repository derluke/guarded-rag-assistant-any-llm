# make_low_rank_matrix

### sklearn.datasets.make_low_rank_matrix(n_samples=100, n_features=100, \*, effective_rank=10, tail_strength=0.5, random_state=None)

Generate a mostly low rank matrix with bell-shaped singular values.

Most of the variance can be explained by a bell-shaped curve of width
effective_rank: the low rank part of the singular values profile is:

```default
(1 - tail_strength) * exp(-1.0 * (i / effective_rank) ** 2)
```

The remaining singular values’ tail is fat, decreasing as:

```default
tail_strength * exp(-0.1 * i / effective_rank).
```

The low rank part of the profile can be considered the structured
signal part of the data while the tail can be considered the noisy
part of the data that cannot be summarized by a low number of linear
components (singular vectors).

This kind of singular profiles is often seen in practice, for instance:
: - gray level pictures of faces
  - TF-IDF vectors of text documents crawled from the web

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **n_samples**
  : The number of samples.

  **n_features**
  : The number of features.

  **effective_rank**
  : The approximate number of singular vectors required to explain most of
    the data by linear combinations.

  **tail_strength**
  : The relative importance of the fat noisy tail of the singular values
    profile. The value should be between 0 and 1.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : The matrix.

### Examples

```pycon
>>> from numpy.linalg import svd
>>> from sklearn.datasets import make_low_rank_matrix
>>> X = make_low_rank_matrix(
...     n_samples=50,
...     n_features=25,
...     effective_rank=5,
...     tail_strength=0.01,
...     random_state=0,
... )
>>> X.shape
(50, 25)
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.5! Many bug fixes and improvements were added, as well as some key new features. Below we detail the highlights of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_5&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.5</div>
</div>
* [Release Highlights for scikit-learn 1.5](../../auto_examples/release_highlights/plot_release_highlights_1_5_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-5-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.3! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_3&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.3</div>
</div>
* [Release Highlights for scikit-learn 1.3](../../auto_examples/release_highlights/plot_release_highlights_1_3_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-3-0-py)

<!-- thumbnail-parent-div-close --></div>
