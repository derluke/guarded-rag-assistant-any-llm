# RadiusNeighborsClassifier

### *class* sklearn.neighbors.RadiusNeighborsClassifier(radius=1.0, \*, weights='uniform', algorithm='auto', leaf_size=30, p=2, metric='minkowski', outlier_label=None, metric_params=None, n_jobs=None)

Classifier implementing a vote among neighbors within a given radius.

Read more in the [User Guide](../neighbors.md#classification).

* **Parameters:**
  **radius**
  : Range of parameter space to use by default for [`radius_neighbors`](#sklearn.neighbors.RadiusNeighborsClassifier.radius_neighbors)
    queries.

  **weights**
  : Weight function used in prediction.  Possible values:
    - ‘uniform’ : uniform weights.  All points in each neighborhood
      are weighted equally.
    - ‘distance’ : weight points by the inverse of their distance.
      in this case, closer neighbors of a query point will have a
      greater influence than neighbors which are further away.
    - [callable] : a user-defined function which accepts an
      array of distances, and returns an array of the same shape
      containing the weights.
    <br/>
    Uniform weights are used by default.

  **algorithm**
  : Algorithm used to compute the nearest neighbors:
    - ‘ball_tree’ will use [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree)
    - ‘kd_tree’ will use [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree)
    - ‘brute’ will use a brute-force search.
    - ‘auto’ will attempt to decide the most appropriate algorithm
      based on the values passed to [`fit`](#sklearn.neighbors.RadiusNeighborsClassifier.fit) method.
    <br/>
    Note: fitting on sparse input will override the setting of
    this parameter, using brute force.

  **leaf_size**
  : Leaf size passed to BallTree or KDTree.  This can affect the
    speed of the construction and query, as well as the memory
    required to store the tree.  The optimal value depends on the
    nature of the problem.

  **p**
  : Power parameter for the Minkowski metric. When p = 1, this is
    equivalent to using manhattan_distance (l1), and euclidean_distance
    (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.
    This parameter is expected to be positive.

  **metric**
  : Metric to use for distance computation. Default is “minkowski”, which
    results in the standard Euclidean distance when p = 2. See the
    documentation of [scipy.spatial.distance](https://docs.scipy.org/doc/scipy/reference/spatial.distance.html) and
    the metrics listed in
    [`distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics) for valid metric
    values.
    <br/>
    If metric is “precomputed”, X is assumed to be a distance matrix and
    must be square during fit. X may be a [sparse graph](../../glossary.md#term-sparse-graph), in which
    case only “nonzero” elements may be considered neighbors.
    <br/>
    If metric is a callable function, it takes two arrays representing 1D
    vectors as inputs and must return one value indicating the distance
    between those vectors. This works for Scipy’s metrics, but is less
    efficient than passing the metric name as a string.

  **outlier_label**
  : Label for outlier samples (samples with no neighbors in given radius).
    - manual label: str or int label (should be the same type as y)
      or list of manual labels if multi-output is used.
    - ‘most_frequent’ : assign the most frequent label of y to outliers.
    - None : when any outlier is detected, ValueError will be raised.
    <br/>
    The outlier label should be selected from among the unique ‘Y’ labels.
    If it is specified with a different value a warning will be raised and
    all class probabilities of outliers will be assigned to be 0.

  **metric_params**
  : Additional keyword arguments for the metric function.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **classes_**
  : Class labels known to the classifier.

  **effective_metric_**
  : The distance metric used. It will be same as the `metric` parameter
    or a synonym of it, e.g. ‘euclidean’ if the `metric` parameter set to
    ‘minkowski’ and `p` parameter set to 2.

  **effective_metric_params_**
  : Additional keyword arguments for the metric function. For most metrics
    will be same with `metric_params` parameter, but may also contain the
    `p` parameter value if the `effective_metric_` attribute is set to
    ‘minkowski’.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_samples_fit_**
  : Number of samples in the fitted data.

  **outlier_label_**
  : Label which is given for outlier samples (samples with no neighbors
    on given radius).

  **outputs_2d_**
  : False when `y`’s shape is (n_samples, ) or (n_samples, 1) during fit
    otherwise True.

#### SEE ALSO
[`KNeighborsClassifier`](sklearn.neighbors.KNeighborsClassifier.md#sklearn.neighbors.KNeighborsClassifier)
: Classifier implementing the k-nearest neighbors vote.

[`RadiusNeighborsRegressor`](sklearn.neighbors.RadiusNeighborsRegressor.md#sklearn.neighbors.RadiusNeighborsRegressor)
: Regression based on neighbors within a fixed radius.

[`KNeighborsRegressor`](sklearn.neighbors.KNeighborsRegressor.md#sklearn.neighbors.KNeighborsRegressor)
: Regression based on k-nearest neighbors.

[`NearestNeighbors`](sklearn.neighbors.NearestNeighbors.md#sklearn.neighbors.NearestNeighbors)
: Unsupervised learner for implementing neighbor searches.

### Notes

See [Nearest Neighbors](../neighbors.md#neighbors) in the online documentation
for a discussion of the choice of `algorithm` and `leaf_size`.

[https://en.wikipedia.org/wiki/K-nearest_neighbor_algorithm](https://en.wikipedia.org/wiki/K-nearest_neighbor_algorithm)

### Examples

```pycon
>>> X = [[0], [1], [2], [3]]
>>> y = [0, 0, 1, 1]
>>> from sklearn.neighbors import RadiusNeighborsClassifier
>>> neigh = RadiusNeighborsClassifier(radius=1.0)
>>> neigh.fit(X, y)
RadiusNeighborsClassifier(...)
>>> print(neigh.predict([[1.5]]))
[0]
>>> print(neigh.predict_proba([[1.0]]))
[[0.66666667 0.33333333]]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y)

Fit the radius neighbors classifier from the training dataset.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Target values.
* **Returns:**
  **self**
  : The fitted radius neighbors classifier.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict the class labels for the provided data.

* **Parameters:**
  **X**
  : Test samples. If `None`, predictions for all indexed points are
    returned; in this case, points are not considered their own
    neighbors.
* **Returns:**
  **y**
  : Class labels for each data sample.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Return probability estimates for the test data X.

* **Parameters:**
  **X**
  : Test samples. If `None`, predictions for all indexed points are
    returned; in this case, points are not considered their own
    neighbors.
* **Returns:**
  **p**
  : The class probabilities of the input samples. Classes are ordered
    by lexicographic order.

<!-- !! processed by numpydoc !! -->

#### radius_neighbors(X=None, radius=None, return_distance=True, sort_results=False)

Find the neighbors within a given radius of a point or points.

Return the indices and distances of each point from the dataset
lying in a ball with size `radius` around the points of the query
array. Points lying on the boundary are included in the results.

The result points are *not* necessarily sorted by distance to their
query point.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.

  **radius**
  : Limiting distance of neighbors to return. The default is the value
    passed to the constructor.

  **return_distance**
  : Whether or not to return the distances.

  **sort_results**
  : If True, the distances and indices will be sorted by increasing
    distances before being returned. If False, the results may not
    be sorted. If `return_distance=False`, setting `sort_results=True`
    will result in an error.
    <br/>
    #### Versionadded
    Added in version 0.22.
* **Returns:**
  **neigh_dist**
  : Array representing the distances to each point, only present if
    `return_distance=True`. The distance values are computed according
    to the `metric` constructor parameter.

  **neigh_ind**
  : An array of arrays of indices of the approximate nearest points
    from the population matrix that lie within a ball of size
    `radius` around the query points.

### Notes

Because the number of neighbors of each point is not necessarily
equal, the results for multiple query points cannot be fit in a
standard data array.
For efficiency, `radius_neighbors` returns arrays of objects, where
each object is a 1D array of indices or distances.

### Examples

In the following example, we construct a NeighborsClassifier
class from an array representing our data set and ask who’s
the closest point to [1, 1, 1]:

```pycon
>>> import numpy as np
>>> samples = [[0., 0., 0.], [0., .5, 0.], [1., 1., .5]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(radius=1.6)
>>> neigh.fit(samples)
NearestNeighbors(radius=1.6)
>>> rng = neigh.radius_neighbors([[1., 1., 1.]])
>>> print(np.asarray(rng[0][0]))
[1.5 0.5]
>>> print(np.asarray(rng[1][0]))
[1 2]
```

The first array returned contains the distances to all points which
are closer than 1.6, while the second array returned contains their
indices.  In general, multiple points can be queried at the same time.

<!-- !! processed by numpydoc !! -->

#### radius_neighbors_graph(X=None, radius=None, mode='connectivity', sort_results=False)

Compute the (weighted) graph of Neighbors for points in X.

Neighborhoods are restricted the points at a distance lower than
radius.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.

  **radius**
  : Radius of neighborhoods. The default is the value passed to the
    constructor.

  **mode**
  : Type of returned matrix: ‘connectivity’ will return the
    connectivity matrix with ones and zeros, in ‘distance’ the
    edges are distances between points, type of distance
    depends on the selected metric parameter in
    NearestNeighbors class.

  **sort_results**
  : If True, in each row of the result, the non-zero entries will be
    sorted by increasing distances. If False, the non-zero entries may
    not be sorted. Only used with mode=’distance’.
    <br/>
    #### Versionadded
    Added in version 0.22.
* **Returns:**
  **A**
  : `n_samples_fit` is the number of samples in the fitted data.
    `A[i, j]` gives the weight of the edge connecting `i` to `j`.
    The matrix is of CSR format.

#### SEE ALSO
[`kneighbors_graph`](sklearn.neighbors.kneighbors_graph.md#sklearn.neighbors.kneighbors_graph)
: Compute the (weighted) graph of k-Neighbors for points in X.

### Examples

```pycon
>>> X = [[0], [3], [1]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(radius=1.5)
>>> neigh.fit(X)
NearestNeighbors(radius=1.5)
>>> A = neigh.radius_neighbors_graph(X)
>>> A.toarray()
array([[1., 0., 1.],
       [0., 1., 0.],
       [1., 0., 1.]])
```

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples. If `None`, predictions for all indexed points are
    used; in this case, points are not considered their own
    neighbors. This means that `knn.fit(X, y).score(None, y)`
    implicitly performs a leave-one-out cross-validation procedure
    and is equivalent to `cross_val_score(knn, X, y, cv=LeaveOneOut())`
    but typically much faster.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [RadiusNeighborsClassifier](#sklearn.neighbors.RadiusNeighborsClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->
