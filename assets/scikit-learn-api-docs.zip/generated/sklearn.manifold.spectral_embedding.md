# spectral_embedding

### sklearn.manifold.spectral_embedding(adjacency, \*, n_components=8, eigen_solver=None, random_state=None, eigen_tol='auto', norm_laplacian=True, drop_first=True)

Project the sample on the first eigenvectors of the graph Laplacian.

The adjacency matrix is used to compute a normalized graph Laplacian
whose spectrum (especially the eigenvectors associated to the
smallest eigenvalues) has an interpretation in terms of minimal
number of cuts necessary to split the graph into comparably sized
components.

This embedding can also ‘work’ even if the `adjacency` variable is
not strictly the adjacency matrix of a graph but more generally
an affinity or similarity matrix between samples (for instance the
heat kernel of a euclidean distance matrix or a k-NN matrix).

However care must taken to always make the affinity matrix symmetric
so that the eigenvector decomposition works as expected.

Note : Laplacian Eigenmaps is the actual algorithm implemented here.

Read more in the [User Guide](../manifold.md#spectral-embedding).

* **Parameters:**
  **adjacency**
  : The adjacency matrix of the graph to embed.

  **n_components**
  : The dimension of the projection subspace.

  **eigen_solver**
  : The eigenvalue decomposition strategy to use. AMG requires pyamg
    to be installed. It can be faster on very large, sparse problems,
    but may also lead to instabilities. If None, then `'arpack'` is
    used.

  **random_state**
  : A pseudo random number generator used for the initialization
    of the lobpcg eigen vectors decomposition when `eigen_solver ==
    'amg'`, and for the K-Means initialization. Use an int to make
    the results deterministic across calls (See
    [Glossary](../../glossary.md#term-random_state)).
    <br/>
    #### NOTE
    When using `eigen_solver == 'amg'`,
    it is necessary to also fix the global numpy seed with
    `np.random.seed(int)` to get deterministic results. See
    [https://github.com/pyamg/pyamg/issues/139](https://github.com/pyamg/pyamg/issues/139) for further
    information.

  **eigen_tol**
  : Stopping criterion for eigendecomposition of the Laplacian matrix.
    If `eigen_tol="auto"` then the passed tolerance will depend on the
    `eigen_solver`:
    - If `eigen_solver="arpack"`, then `eigen_tol=0.0`;
    - If `eigen_solver="lobpcg"` or `eigen_solver="amg"`, then
      `eigen_tol=None` which configures the underlying `lobpcg` solver to
      automatically resolve the value according to their heuristics. See,
      [`scipy.sparse.linalg.lobpcg`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.lobpcg.html#scipy.sparse.linalg.lobpcg) for details.
    <br/>
    Note that when using `eigen_solver="amg"` values of `tol<1e-5` may lead
    to convergence issues and should be avoided.
    <br/>
    #### Versionadded
    Added in version 1.2: Added ‘auto’ option.

  **norm_laplacian**
  : If True, then compute symmetric normalized Laplacian.

  **drop_first**
  : Whether to drop the first eigenvector. For spectral embedding, this
    should be True as the first eigenvector should be constant vector for
    connected graph, but for spectral clustering, this should be kept as
    False to retain the first eigenvector.
* **Returns:**
  **embedding**
  : The reduced samples.

### Notes

Spectral Embedding (Laplacian Eigenmaps) is most useful when the graph
has one connected component. If there graph has many components, the first
few eigenvectors will simply uncover the connected components of the graph.

### References

* [https://en.wikipedia.org/wiki/LOBPCG](https://en.wikipedia.org/wiki/LOBPCG)
* [“Toward the Optimal Preconditioned Eigensolver: Locally Optimal
  Block Preconditioned Conjugate Gradient Method”,
  Andrew V. Knyazev](https://doi.org/10.1137/S1064827500366124)

### Examples

```pycon
>>> from sklearn.datasets import load_digits
>>> from sklearn.neighbors import kneighbors_graph
>>> from sklearn.manifold import spectral_embedding
>>> X, _ = load_digits(return_X_y=True)
>>> X = X[:100]
>>> affinity_matrix = kneighbors_graph(
...     X, n_neighbors=int(X.shape[0] / 10), include_self=True
... )
>>> # make the matrix symmetric
>>> affinity_matrix = 0.5 * (affinity_matrix + affinity_matrix.T)
>>> embedding = spectral_embedding(affinity_matrix, n_components=2, random_state=42)
>>> embedding.shape
(100, 2)
```

<!-- !! processed by numpydoc !! -->
