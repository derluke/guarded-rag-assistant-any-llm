# DecisionBoundaryDisplay

### *class* sklearn.inspection.DecisionBoundaryDisplay(\*, xx0, xx1, response, xlabel=None, ylabel=None)

Decisions boundary visualization.

It is recommended to use
[`from_estimator`](#sklearn.inspection.DecisionBoundaryDisplay.from_estimator)
to create a [`DecisionBoundaryDisplay`](#sklearn.inspection.DecisionBoundaryDisplay). All parameters are stored as
attributes.

Read more in the [User Guide](../../visualizations.md#visualizations).

#### Versionadded
Added in version 1.1.

* **Parameters:**
  **xx0**
  : First output of [`meshgrid`](https://numpy.org/doc/stable/reference/generated/numpy.meshgrid.html#numpy.meshgrid).

  **xx1**
  : Second output of [`meshgrid`](https://numpy.org/doc/stable/reference/generated/numpy.meshgrid.html#numpy.meshgrid).

  **response**
  : Values of the response function.

  **xlabel**
  : Default label to place on x axis.

  **ylabel**
  : Default label to place on y axis.
* **Attributes:**
  **surface_**
  : If `plot_method` is ‘contour’ or ‘contourf’, `surface_` is a
    [`QuadContourSet`](https://matplotlib.org/stable/api/contour_api.html#matplotlib.contour.QuadContourSet). If
    `plot_method` is ‘pcolormesh’, `surface_` is a
    [`QuadMesh`](https://matplotlib.org/stable/api/collections_api.html#matplotlib.collections.QuadMesh).

  **ax_**
  : Axes with decision boundary.

  **figure_**
  : Figure containing the decision boundary.

#### SEE ALSO
[`DecisionBoundaryDisplay.from_estimator`](#sklearn.inspection.DecisionBoundaryDisplay.from_estimator)
: Plot decision boundary given an estimator.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> import numpy as np
>>> from sklearn.datasets import load_iris
>>> from sklearn.inspection import DecisionBoundaryDisplay
>>> from sklearn.tree import DecisionTreeClassifier
>>> iris = load_iris()
>>> feature_1, feature_2 = np.meshgrid(
...     np.linspace(iris.data[:, 0].min(), iris.data[:, 0].max()),
...     np.linspace(iris.data[:, 1].min(), iris.data[:, 1].max())
... )
>>> grid = np.vstack([feature_1.ravel(), feature_2.ravel()]).T
>>> tree = DecisionTreeClassifier().fit(iris.data[:, :2], iris.target)
>>> y_pred = np.reshape(tree.predict(grid), feature_1.shape)
>>> display = DecisionBoundaryDisplay(
...     xx0=feature_1, xx1=feature_2, response=y_pred
... )
>>> display.plot()
<...>
>>> display.ax_.scatter(
...     iris.data[:, 0], iris.data[:, 1], c=iris.target, edgecolor="black"
... )
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-inspection-DecisionBoundaryDisplay-1.*)
<!-- !! processed by numpydoc !! -->

#### *classmethod* from_estimator(estimator, X, \*, grid_resolution=100, eps=1.0, plot_method='contourf', response_method='auto', class_of_interest=None, xlabel=None, ylabel=None, ax=None, \*\*kwargs)

Plot decision boundary given an estimator.

Read more in the [User Guide](../../visualizations.md#visualizations).

* **Parameters:**
  **estimator**
  : Trained estimator used to plot the decision boundary.

  **X**
  : Input data that should be only 2-dimensional.

  **grid_resolution**
  : Number of grid points to use for plotting decision boundary.
    Higher values will make the plot look nicer but be slower to
    render.

  **eps**
  : Extends the minimum and maximum values of X for evaluating the
    response function.

  **plot_method**
  : Plotting method to call when plotting the response. Please refer
    to the following matplotlib documentation for details:
    [`contourf`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.contourf.html#matplotlib.pyplot.contourf),
    [`contour`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.contour.html#matplotlib.pyplot.contour),
    [`pcolormesh`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.pcolormesh.html#matplotlib.pyplot.pcolormesh).

  **response_method**
  : Specifies whether to use [predict_proba](../../glossary.md#term-predict_proba),
    [decision_function](../../glossary.md#term-decision_function), [predict](../../glossary.md#term-predict) as the target response.
    If set to ‘auto’, the response method is tried in the following order:
    [decision_function](../../glossary.md#term-decision_function), [predict_proba](../../glossary.md#term-predict_proba), [predict](../../glossary.md#term-predict).
    For multiclass problems, [predict](../../glossary.md#term-predict) is selected when
    `response_method="auto"`.

  **class_of_interest**
  : The class considered when plotting the decision. If None,
    `estimator.classes_[1]` is considered as the positive class
    for binary classifiers. Must have an explicit value for
    multiclass classifiers when `response_method` is ‘predict_proba’
    or ‘decision_function’.
    <br/>
    #### Versionadded
    Added in version 1.4.

  **xlabel**
  : The label used for the x-axis. If `None`, an attempt is made to
    extract a label from `X` if it is a dataframe, otherwise an empty
    string is used.

  **ylabel**
  : The label used for the y-axis. If `None`, an attempt is made to
    extract a label from `X` if it is a dataframe, otherwise an empty
    string is used.

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **\*\*kwargs**
  : Additional keyword arguments to be passed to the
    `plot_method`.
* **Returns:**
  **display**
  : Object that stores the result.

#### SEE ALSO
[`DecisionBoundaryDisplay`](#sklearn.inspection.DecisionBoundaryDisplay)
: Decision boundary visualization.

[`sklearn.metrics.ConfusionMatrixDisplay.from_estimator`](sklearn.metrics.ConfusionMatrixDisplay.md#sklearn.metrics.ConfusionMatrixDisplay.from_estimator)
: Plot the confusion matrix given an estimator, the data, and the label.

[`sklearn.metrics.ConfusionMatrixDisplay.from_predictions`](sklearn.metrics.ConfusionMatrixDisplay.md#sklearn.metrics.ConfusionMatrixDisplay.from_predictions)
: Plot the confusion matrix given the true and predicted labels.

### Examples

```pycon
>>> import matplotlib.pyplot as plt
>>> from sklearn.datasets import load_iris
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.inspection import DecisionBoundaryDisplay
>>> iris = load_iris()
>>> X = iris.data[:, :2]
>>> classifier = LogisticRegression().fit(X, iris.target)
>>> disp = DecisionBoundaryDisplay.from_estimator(
...     classifier, X, response_method="predict",
...     xlabel=iris.feature_names[0], ylabel=iris.feature_names[1],
...     alpha=0.5,
... )
>>> disp.ax_.scatter(X[:, 0], X[:, 1], c=iris.target, edgecolor="k")
<...>
>>> plt.show()
```

![image](../md/plot_directive/modules/generated/sklearn-inspection-DecisionBoundaryDisplay-2.*)
<!-- !! processed by numpydoc !! -->

#### plot(plot_method='contourf', ax=None, xlabel=None, ylabel=None, \*\*kwargs)

Plot visualization.

* **Parameters:**
  **plot_method**
  : Plotting method to call when plotting the response. Please refer
    to the following matplotlib documentation for details:
    [`contourf`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.contourf.html#matplotlib.pyplot.contourf),
    [`contour`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.contour.html#matplotlib.pyplot.contour),
    [`pcolormesh`](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.pcolormesh.html#matplotlib.pyplot.pcolormesh).

  **ax**
  : Axes object to plot on. If `None`, a new figure and axes is
    created.

  **xlabel**
  : Overwrite the x-axis label.

  **ylabel**
  : Overwrite the y-axis label.

  **\*\*kwargs**
  : Additional keyword arguments to be passed to the `plot_method`.
* **Returns:**
  display: [`DecisionBoundaryDisplay`](#sklearn.inspection.DecisionBoundaryDisplay)
  : Object that stores computed values.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An example using IsolationForest for anomaly detection.">  <div class="sphx-glr-thumbnail-title">IsolationForest example</div>
</div>
* [IsolationForest example](../../auto_examples/ensemble/plot_isolation_forest.md#sphx-glr-auto-examples-ensemble-plot-isolation-forest-py)

<div class="sphx-glr-thumbcontainer" tooltip="SVCs aim to find a hyperplane that effectively separates the classes in their training data by maximizing the margin between the outermost data points of each class. This is achieved by finding the best weight vector w that defines the decision boundary hyperplane and minimizes the sum of hinge losses for misclassified samples, as measured by the hinge_loss function. By default, regularization is applied with the parameter C=1, which allows for a certain degree of misclassification tolerance.">  <div class="sphx-glr-thumbnail-title">Plot classification boundaries with different SVM Kernels</div>
</div>
* [Plot classification boundaries with different SVM Kernels](../../auto_examples/svm/plot_svm_kernels.md#sphx-glr-auto-examples-svm-plot-svm-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the need for robust covariance estimation on a real data set. It is useful both for outlier detection and for a better understanding of the data structure.">  <div class="sphx-glr-thumbnail-title">Outlier detection on a real data set</div>
</div>
* [Outlier detection on a real data set](../../auto_examples/applications/plot_outlier_detection_wine.md#sphx-glr-auto-examples-applications-plot-outlier-detection-wine-py)

<div class="sphx-glr-thumbcontainer" tooltip="A comparison of several classifiers in scikit-learn on synthetic datasets. The point of this example is to illustrate the nature of decision boundaries of different classifiers. This should be taken with a grain of salt, as the intuition conveyed by these examples does not necessarily carry over to real datasets.">  <div class="sphx-glr-thumbnail-title">Classifier comparison</div>
</div>
* [Classifier comparison](../../auto_examples/classification/plot_classifier_comparison.md#sphx-glr-auto-examples-classification-plot-classifier-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example plots the covariance ellipsoids of each class and the decision boundary learned by LinearDiscriminantAnalysis (LDA) and QuadraticDiscriminantAnalysis (QDA). The ellipsoids display the double standard deviation for each class. With LDA, the standard deviation is the same for all the classes, while each class has its own standard deviation with QDA.">  <div class="sphx-glr-thumbnail-title">Linear and Quadratic Discriminant Analysis with covariance ellipsoid</div>
</div>
* [Linear and Quadratic Discriminant Analysis with covariance ellipsoid](../../auto_examples/classification/plot_lda_qda.md#sphx-glr-auto-examples-classification-plot-lda-qda-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the classification probability for different classifiers. We use a 3 class dataset, and we classify it with a Support Vector classifier, L1 and L2 penalized logistic regression (multinomial multiclass), a One-Vs-Rest version with logistic regression, and Gaussian process classification.">  <div class="sphx-glr-thumbnail-title">Plot classification probability</div>
</div>
* [Plot classification probability](../../auto_examples/classification/plot_classification_probability.md#sphx-glr-auto-examples-classification-plot-classification-probability-py)

<div class="sphx-glr-thumbcontainer" tooltip="Clustering can be expensive, especially when our dataset contains millions of datapoints. Many clustering algorithms are not inductive and so cannot be directly applied to new data samples without recomputing the clustering, which may be intractable. Instead, we can use clustering to then learn an inductive model with a classifier, which has several benefits:">  <div class="sphx-glr-thumbnail-title">Inductive Clustering</div>
</div>
* [Inductive Clustering](../../auto_examples/cluster/plot_inductive_clustering.md#sphx-glr-auto-examples-cluster-plot-inductive-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example using IsolationForest for anomaly detection.">  <div class="sphx-glr-thumbnail-title">IsolationForest example</div>
</div>
* [IsolationForest example](../../auto_examples/ensemble/plot_isolation_forest.md#sphx-glr-auto-examples-ensemble-plot-isolation-forest-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision boundaries of a VotingClassifier for two features of the Iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision boundaries of a VotingClassifier</div>
</div>
* [Plot the decision boundaries of a VotingClassifier](../../auto_examples/ensemble/plot_voting_decision_regions.md#sphx-glr-auto-examples-ensemble-plot-voting-decision-regions-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example fits an AdaBoosted decision stump on a non-linearly separable classification dataset composed of two &quot;Gaussian quantiles&quot; clusters (see sklearn.datasets.make_gaussian_quantiles) and plots the decision boundary and decision scores. The distributions of decision scores are shown separately for samples of class A and B. The predicted class label for each sample is determined by the sign of the decision score. Samples with decision scores greater than zero are classified as B, and are otherwise classified as A. The magnitude of a decision score determines the degree of likeness with the predicted class label. Additionally, a new dataset could be constructed containing a desired purity of class B, for example, by only selecting samples with a decision score above some value.">  <div class="sphx-glr-thumbnail-title">Two-class AdaBoost</div>
</div>
* [Two-class AdaBoost](../../auto_examples/ensemble/plot_adaboost_twoclass.md#sphx-glr-auto-examples-ensemble-plot-adaboost-twoclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares decision boundaries of multinomial and one-vs-rest logistic regression on a 2D dataset with three classes.">  <div class="sphx-glr-thumbnail-title">Decision Boundaries of Multinomial and One-vs-Rest Logistic Regression</div>
</div>
* [Decision Boundaries of Multinomial and One-vs-Rest Logistic Regression](../../auto_examples/linear_model/plot_logistic_multinomial.md#sphx-glr-auto-examples-linear-model-plot-logistic-multinomial-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to approximate the solution of sklearn.svm.OneClassSVM in the case of an RBF kernel with sklearn.linear_model.SGDOneClassSVM, a Stochastic Gradient Descent (SGD) version of the One-Class SVM. A kernel approximation is first used in order to apply sklearn.linear_model.SGDOneClassSVM which implements a linear One-Class SVM using SGD.">  <div class="sphx-glr-thumbnail-title">One-Class SVM versus One-Class SVM using Stochastic Gradient Descent</div>
</div>
* [One-Class SVM versus One-Class SVM using Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgdocsvm_vs_ocsvm.md#sphx-glr-auto-examples-linear-model-plot-sgdocsvm-vs-ocsvm-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot decision surface of multi-class SGD on iris dataset. The hyperplanes corresponding to the three one-versus-all (OVA) classifiers are represented by the dashed lines.">  <div class="sphx-glr-thumbnail-title">Plot multi-class SGD on the iris dataset</div>
</div>
* [Plot multi-class SGD on the iris dataset](../../auto_examples/linear_model/plot_sgd_iris.md#sphx-glr-auto-examples-linear-model-plot-sgd-iris-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates the class_likelihood_ratios function, which computes the positive and negative likelihood ratios (\`LR+\`, LR-) to assess the predictive power of a binary classifier. As we will see, these metrics are independent of the proportion between classes in the test set, which makes them very useful when the available data for a study has a different class proportion than the target application.">  <div class="sphx-glr-thumbnail-title">Class Likelihood Ratios to measure classification performance</div>
</div>
* [Class Likelihood Ratios to measure classification performance](../../auto_examples/model_selection/plot_likelihood_ratios.md#sphx-glr-auto-examples-model-selection-plot-likelihood-ratios-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example comparing nearest neighbors classification with and without Neighborhood Components Analysis.">  <div class="sphx-glr-thumbnail-title">Comparing Nearest Neighbors with and without Neighborhood Components Analysis</div>
</div>
* [Comparing Nearest Neighbors with and without Neighborhood Components Analysis](../../auto_examples/neighbors/plot_nca_classification.md#sphx-glr-auto-examples-neighbors-plot-nca-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Sample usage of Nearest Centroid classification. It will plot the decision boundaries for each class.">  <div class="sphx-glr-thumbnail-title">Nearest Centroid Classification</div>
</div>
* [Nearest Centroid Classification](../../auto_examples/neighbors/plot_nearest_centroid.md#sphx-glr-auto-examples-neighbors-plot-nearest-centroid-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use KNeighborsClassifier. We train such a classifier on the iris dataset and observe the difference of the decision boundary obtained with regards to the parameter weights.">  <div class="sphx-glr-thumbnail-title">Nearest Neighbors Classification</div>
</div>
* [Nearest Neighbors Classification](../../auto_examples/neighbors/plot_classification.md#sphx-glr-auto-examples-neighbors-plot-classification-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature scaling through standardization, also called Z-score normalization, is an important preprocessing step for many machine learning algorithms. It involves rescaling each feature such that it has a standard deviation of 1 and a mean of 0.">  <div class="sphx-glr-thumbnail-title">Importance of Feature Scaling</div>
</div>
* [Importance of Feature Scaling](../../auto_examples/preprocessing/plot_scaling_importance.md#sphx-glr-auto-examples-preprocessing-plot-scaling-importance-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example using a one-class SVM for novelty detection.">  <div class="sphx-glr-thumbnail-title">One-class SVM with non-linear kernel (RBF)</div>
</div>
* [One-class SVM with non-linear kernel (RBF)](../../auto_examples/svm/plot_oneclass.md#sphx-glr-auto-examples-svm-plot-oneclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="SVCs aim to find a hyperplane that effectively separates the classes in their training data by maximizing the margin between the outermost data points of each class. This is achieved by finding the best weight vector w that defines the decision boundary hyperplane and minimizes the sum of hinge losses for misclassified samples, as measured by the hinge_loss function. By default, regularization is applied with the parameter C=1, which allows for a certain degree of misclassification tolerance.">  <div class="sphx-glr-thumbnail-title">Plot classification boundaries with different SVM Kernels</div>
</div>
* [Plot classification boundaries with different SVM Kernels](../../auto_examples/svm/plot_svm_kernels.md#sphx-glr-auto-examples-svm-plot-svm-kernels-py)

<div class="sphx-glr-thumbcontainer" tooltip="Comparison of different linear SVM classifiers on a 2D projection of the iris dataset. We only consider the first 2 features of this dataset:">  <div class="sphx-glr-thumbnail-title">Plot different SVM classifiers in the iris dataset</div>
</div>
* [Plot different SVM classifiers in the iris dataset](../../auto_examples/svm/plot_iris_svc.md#sphx-glr-auto-examples-svm-plot-iris-svc-py)

<div class="sphx-glr-thumbcontainer" tooltip="Unlike SVC (based on LIBSVM), LinearSVC (based on LIBLINEAR) does not provide the support vectors. This example demonstrates how to obtain the support vectors in LinearSVC.">  <div class="sphx-glr-thumbnail-title">Plot the support vectors in LinearSVC</div>
</div>
* [Plot the support vectors in LinearSVC](../../auto_examples/svm/plot_linearsvc_support_vectors.md#sphx-glr-auto-examples-svm-plot-linearsvc-support-vectors-py)

<div class="sphx-glr-thumbcontainer" tooltip="Simple usage of Support Vector Machines to classify a sample. It will plot the decision surface and the support vectors.">  <div class="sphx-glr-thumbnail-title">SVM with custom kernel</div>
</div>
* [SVM with custom kernel](../../auto_examples/svm/plot_custom_kernel.md#sphx-glr-auto-examples-svm-plot-custom-kernel-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the maximum margin separating hyperplane within a two-class separable dataset using a Support Vector Machine classifier with linear kernel.">  <div class="sphx-glr-thumbnail-title">SVM: Maximum margin separating hyperplane</div>
</div>
* [SVM: Maximum margin separating hyperplane](../../auto_examples/svm/plot_separating_hyperplane.md#sphx-glr-auto-examples-svm-plot-separating-hyperplane-py)

<div class="sphx-glr-thumbcontainer" tooltip="Find the optimal separating hyperplane using an SVC for classes that are unbalanced.">  <div class="sphx-glr-thumbnail-title">SVM: Separating hyperplane for unbalanced classes</div>
</div>
* [SVM: Separating hyperplane for unbalanced classes](../../auto_examples/svm/plot_separating_hyperplane_unbalanced.md#sphx-glr-auto-examples-svm-plot-separating-hyperplane-unbalanced-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot decision function of a weighted dataset, where the size of points is proportional to its weight.">  <div class="sphx-glr-thumbnail-title">SVM: Weighted samples</div>
</div>
* [SVM: Weighted samples](../../auto_examples/svm/plot_weighted_samples.md#sphx-glr-auto-examples-svm-plot-weighted-samples-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the decision surface of a decision tree trained on pairs of features of the iris dataset.">  <div class="sphx-glr-thumbnail-title">Plot the decision surface of decision trees trained on the iris dataset</div>
</div>
* [Plot the decision surface of decision trees trained on the iris dataset](../../auto_examples/tree/plot_iris_dtc.md#sphx-glr-auto-examples-tree-plot-iris-dtc-py)

<!-- thumbnail-parent-div-close --></div>
