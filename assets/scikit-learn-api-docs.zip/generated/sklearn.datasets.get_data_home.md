# get_data_home

### sklearn.datasets.get_data_home(data_home=None) → [str](https://docs.python.org/3/library/stdtypes.html#str)

Return the path of the scikit-learn data directory.

This folder is used by some large dataset loaders to avoid downloading the
data several times.

By default the data directory is set to a folder named ‘scikit_learn_data’ in the
user home folder.

Alternatively, it can be set by the ‘SCIKIT_LEARN_DATA’ environment
variable or programmatically by giving an explicit folder path. The ‘~’
symbol is expanded to the user home folder.

If the folder does not already exist, it is automatically created.

* **Parameters:**
  **data_home**
  : The path to scikit-learn data directory. If `None`, the default path
    is `~/scikit_learn_data`.
* **Returns:**
  data_home: str
  : The path to scikit-learn data directory.

### Examples

```pycon
>>> import os
>>> from sklearn.datasets import get_data_home
>>> data_home_path = get_data_home()
>>> os.path.exists(data_home_path)
True
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This is an example showing how scikit-learn can be used for classification using an out-of-core approach: learning from data that doesn&#x27;t fit into main memory. We make use of an online classifier, i.e., one that supports the partial_fit method, that will be fed with batches of examples. To guarantee that the features space remains the same over time we leverage a HashingVectorizer that will project each example into the same feature space. This is especially useful in the case of text classification where new features (words) may appear in each batch.">  <div class="sphx-glr-thumbnail-title">Out-of-core classification of text documents</div>
</div>
* [Out-of-core classification of text documents](../../auto_examples/applications/plot_out_of_core_classification.md#sphx-glr-auto-examples-applications-plot-out-of-core-classification-py)

<!-- thumbnail-parent-div-close --></div>
