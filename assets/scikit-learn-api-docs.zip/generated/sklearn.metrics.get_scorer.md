# get_scorer

### sklearn.metrics.get_scorer(scoring)

Get a scorer from string.

Read more in the [User Guide](../model_evaluation.md#scoring-parameter).
[`get_scorer_names`](sklearn.metrics.get_scorer_names.md#sklearn.metrics.get_scorer_names) can be used to retrieve the names
of all available scorers.

* **Parameters:**
  **scoring**
  : Scoring method as string. If callable it is returned as is.
    If None, returns None.
* **Returns:**
  **scorer**
  : The scorer.

### Notes

When passed a string, this function always returns a copy of the scorer
object. Calling `get_scorer` twice for the same scorer results in two
separate scorer objects.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.dummy import DummyClassifier
>>> from sklearn.metrics import get_scorer
>>> X = np.reshape([0, 1, -1, -0.5, 2], (-1, 1))
>>> y = np.array([0, 1, 1, 0, 1])
>>> classifier = DummyClassifier(strategy="constant", constant=0).fit(X, y)
>>> accuracy = get_scorer("accuracy")
>>> accuracy(classifier, X, y)
0.4
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<!-- thumbnail-parent-div-close --></div>
