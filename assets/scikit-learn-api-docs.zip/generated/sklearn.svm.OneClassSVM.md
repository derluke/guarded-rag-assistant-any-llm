# OneClassSVM

### *class* sklearn.svm.OneClassSVM(\*, kernel='rbf', degree=3, gamma='scale', coef0=0.0, tol=0.001, nu=0.5, shrinking=True, cache_size=200, verbose=False, max_iter=-1)

Unsupervised Outlier Detection.

Estimate the support of a high-dimensional distribution.

The implementation is based on libsvm.

Read more in the [User Guide](../outlier_detection.md#outlier-detection).

* **Parameters:**
  **kernel**
  : Specifies the kernel type to be used in the algorithm.
    If none is given, ‘rbf’ will be used. If a callable is given it is
    used to precompute the kernel matrix.

  **degree**
  : Degree of the polynomial kernel function (‘poly’).
    Must be non-negative. Ignored by all other kernels.

  **gamma**
  : Kernel coefficient for ‘rbf’, ‘poly’ and ‘sigmoid’.
    - if `gamma='scale'` (default) is passed then it uses
      1 / (n_features \* X.var()) as value of gamma,
    - if ‘auto’, uses 1 / n_features
    - if float, must be non-negative.
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default value of `gamma` changed from ‘auto’ to ‘scale’.

  **coef0**
  : Independent term in kernel function.
    It is only significant in ‘poly’ and ‘sigmoid’.

  **tol**
  : Tolerance for stopping criterion.

  **nu**
  : An upper bound on the fraction of training
    errors and a lower bound of the fraction of support
    vectors. Should be in the interval (0, 1]. By default 0.5
    will be taken.

  **shrinking**
  : Whether to use the shrinking heuristic.
    See the [User Guide](../svm.md#shrinking-svm).

  **cache_size**
  : Specify the size of the kernel cache (in MB).

  **verbose**
  : Enable verbose output. Note that this setting takes advantage of a
    per-process runtime setting in libsvm that, if enabled, may not work
    properly in a multithreaded context.

  **max_iter**
  : Hard limit on iterations within solver, or -1 for no limit.
* **Attributes:**
  [`coef_`](#sklearn.svm.OneClassSVM.coef_)
  : Weights assigned to the features when `kernel="linear"`.

  **dual_coef_**
  : Coefficients of the support vectors in the decision function.

  **fit_status_**
  : 0 if correctly fitted, 1 otherwise (will raise warning)

  **intercept_**
  : Constant in the decision function.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_iter_**
  : Number of iterations run by the optimization routine to fit the model.
    <br/>
    #### Versionadded
    Added in version 1.1.

  [`n_support_`](#sklearn.svm.OneClassSVM.n_support_)
  : Number of support vectors for each class.

  **offset_**
  : Offset used to define the decision function from the raw scores.
    We have the relation: decision_function = score_samples - `offset_`.
    The offset is the opposite of `intercept_` and is provided for
    consistency with other outlier detection algorithms.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **shape_fit_**
  : Array dimensions of training vector `X`.

  **support_**
  : Indices of support vectors.

  **support_vectors_**
  : Support vectors.

#### SEE ALSO
[`sklearn.linear_model.SGDOneClassSVM`](sklearn.linear_model.SGDOneClassSVM.md#sklearn.linear_model.SGDOneClassSVM)
: Solves linear One-Class SVM using Stochastic Gradient Descent.

[`sklearn.neighbors.LocalOutlierFactor`](sklearn.neighbors.LocalOutlierFactor.md#sklearn.neighbors.LocalOutlierFactor)
: Unsupervised Outlier Detection using Local Outlier Factor (LOF).

[`sklearn.ensemble.IsolationForest`](sklearn.ensemble.IsolationForest.md#sklearn.ensemble.IsolationForest)
: Isolation Forest Algorithm.

### Examples

```pycon
>>> from sklearn.svm import OneClassSVM
>>> X = [[0], [0.44], [0.45], [0.46], [1]]
>>> clf = OneClassSVM(gamma='auto').fit(X)
>>> clf.predict(X)
array([-1,  1,  1,  1, -1])
>>> clf.score_samples(X)
array([1.7798..., 2.0547..., 2.0556..., 2.0561..., 1.7332...])
```

For a more extended example,
see [Species distribution modeling](../../auto_examples/applications/plot_species_distribution_modeling.md#sphx-glr-auto-examples-applications-plot-species-distribution-modeling-py)

<!-- !! processed by numpydoc !! -->

#### *property* coef_

Weights assigned to the features when `kernel="linear"`.

* **Returns:**
  ndarray of shape (n_features, n_classes)

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Signed distance to the separating hyperplane.

Signed distance is positive for an inlier and negative for an outlier.

* **Parameters:**
  **X**
  : The data matrix.
* **Returns:**
  **dec**
  : Returns the decision function of the samples.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, sample_weight=None)

Detect the soft boundary of the set of samples X.

* **Parameters:**
  **X**
  : Set of samples, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.

  **sample_weight**
  : Per-sample weights. Rescale C per sample. Higher weights
    force the classifier to put more emphasis on these points.
* **Returns:**
  **self**
  : Fitted estimator.

### Notes

If X is not a C-ordered contiguous array it is copied.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None, \*\*kwargs)

Perform fit on X and returns labels for X.

Returns -1 for outliers and 1 for inliers.

* **Parameters:**
  **X**
  : The input samples.

  **y**
  : Not used, present for API consistency by convention.

  **\*\*kwargs**
  : Arguments to be passed to `fit`.
    <br/>
    #### Versionadded
    Added in version 1.4.
* **Returns:**
  **y**
  : 1 for inliers, -1 for outliers.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_support_

Number of support vectors for each class.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Perform classification on samples in X.

For a one-class model, +1 or -1 is returned.

* **Parameters:**
  **X**
  : For kernel=”precomputed”, the expected shape of X is
    (n_samples_test, n_samples_train).
* **Returns:**
  **y_pred**
  : Class labels for samples in X.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Raw scoring function of the samples.

* **Parameters:**
  **X**
  : The data matrix.
* **Returns:**
  **score_samples**
  : Returns the (unshifted) scoring function of the samples.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [OneClassSVM](#sklearn.svm.OneClassSVM)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the need for robust covariance estimation on a real data set. It is useful both for outlier detection and for a better understanding of the data structure.">  <div class="sphx-glr-thumbnail-title">Outlier detection on a real data set</div>
</div>
* [Outlier detection on a real data set](../../auto_examples/applications/plot_outlier_detection_wine.md#sphx-glr-auto-examples-applications-plot-outlier-detection-wine-py)

<div class="sphx-glr-thumbcontainer" tooltip="Modeling species&#x27; geographic distributions is an important problem in conservation biology. In this example, we model the geographic distribution of two South American mammals given past observations and 14 environmental variables. Since we have only positive examples (there are no unsuccessful observations), we cast this problem as a density estimation problem and use the OneClassSVM as our modeling tool. The dataset is provided by Phillips et. al. (2006). If available, the example uses basemap to plot the coast lines and national boundaries of South America.">  <div class="sphx-glr-thumbnail-title">Species distribution modeling</div>
</div>
* [Species distribution modeling](../../auto_examples/applications/plot_species_distribution_modeling.md#sphx-glr-auto-examples-applications-plot-species-distribution-modeling-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows how to approximate the solution of sklearn.svm.OneClassSVM in the case of an RBF kernel with sklearn.linear_model.SGDOneClassSVM, a Stochastic Gradient Descent (SGD) version of the One-Class SVM. A kernel approximation is first used in order to apply sklearn.linear_model.SGDOneClassSVM which implements a linear One-Class SVM using SGD.">  <div class="sphx-glr-thumbnail-title">One-Class SVM versus One-Class SVM using Stochastic Gradient Descent</div>
</div>
* [One-Class SVM versus One-Class SVM using Stochastic Gradient Descent](../../auto_examples/linear_model/plot_sgdocsvm_vs_ocsvm.md#sphx-glr-auto-examples-linear-model-plot-sgdocsvm-vs-ocsvm-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different anomaly detection algorithms on 2D datasets. Datasets contain one or two modes (regions of high density) to illustrate the ability of algorithms to cope with multimodal data.">  <div class="sphx-glr-thumbnail-title">Comparing anomaly detection algorithms for outlier detection on toy datasets</div>
</div>
* [Comparing anomaly detection algorithms for outlier detection on toy datasets](../../auto_examples/miscellaneous/plot_anomaly_comparison.md#sphx-glr-auto-examples-miscellaneous-plot-anomaly-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example using a one-class SVM for novelty detection.">  <div class="sphx-glr-thumbnail-title">One-class SVM with non-linear kernel (RBF)</div>
</div>
* [One-class SVM with non-linear kernel (RBF)](../../auto_examples/svm/plot_oneclass.md#sphx-glr-auto-examples-svm-plot-oneclass-py)

<!-- thumbnail-parent-div-close --></div>
