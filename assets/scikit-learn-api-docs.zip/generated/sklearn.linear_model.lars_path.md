# lars_path

### sklearn.linear_model.lars_path(X, y, Xy=None, \*, Gram=None, max_iter=500, alpha_min=0, method='lar', copy_X=True, eps=2.220446049250313e-16, copy_Gram=True, verbose=0, return_path=True, return_n_iter=False, positive=False)

Compute Least Angle Regression or Lasso path using the LARS algorithm.

The optimization objective for the case method=’lasso’ is:

```default
(1 / (2 * n_samples)) * ||y - Xw||^2_2 + alpha * ||w||_1
```

in the case of method=’lar’, the objective function is only known in
the form of an implicit equation (see discussion in [[1]](#r2391cff0bbde-1)).

Read more in the [User Guide](../linear_model.md#least-angle-regression).

* **Parameters:**
  **X**
  : Input data. If X is `None`, Gram must also be `None`.
    If only the Gram matrix is available, use `lars_path_gram` instead.

  **y**
  : Input targets.

  **Xy**
  : `Xy = X.T @ y` that can be precomputed. It is useful
    only when the Gram matrix is precomputed.

  **Gram**
  : Precomputed Gram matrix `X.T @ X`, if `'auto'`, the Gram
    matrix is precomputed from the given X, if there are more samples
    than features.

  **max_iter**
  : Maximum number of iterations to perform, set to infinity for no limit.

  **alpha_min**
  : Minimum correlation along the path. It corresponds to the
    regularization parameter `alpha` in the Lasso.

  **method**
  : Specifies the returned model. Select `'lar'` for Least Angle
    Regression, `'lasso'` for the Lasso.

  **copy_X**
  : If `False`, `X` is overwritten.

  **eps**
  : The machine-precision regularization in the computation of the
    Cholesky diagonal factors. Increase this for very ill-conditioned
    systems. Unlike the `tol` parameter in some iterative
    optimization-based algorithms, this parameter does not control
    the tolerance of the optimization.

  **copy_Gram**
  : If `False`, `Gram` is overwritten.

  **verbose**
  : Controls output verbosity.

  **return_path**
  : If `True`, returns the entire path, else returns only the
    last point of the path.

  **return_n_iter**
  : Whether to return the number of iterations.

  **positive**
  : Restrict coefficients to be >= 0.
    This option is only allowed with method ‘lasso’. Note that the model
    coefficients will not converge to the ordinary-least-squares solution
    for small values of alpha. Only coefficients up to the smallest alpha
    value (`alphas_[alphas_ > 0.].min()` when fit_path=True) reached by
    the stepwise Lars-Lasso algorithm are typically in congruence with the
    solution of the coordinate descent `lasso_path` function.
* **Returns:**
  **alphas**
  : Maximum of covariances (in absolute value) at each iteration.
    `n_alphas` is either `max_iter`, `n_features`, or the
    number of nodes in the path with `alpha >= alpha_min`, whichever
    is smaller.

  **active**
  : Indices of active variables at the end of the path.

  **coefs**
  : Coefficients along the path.

  **n_iter**
  : Number of iterations run. Returned only if `return_n_iter` is set
    to True.

#### SEE ALSO
[`lars_path_gram`](sklearn.linear_model.lars_path_gram.md#sklearn.linear_model.lars_path_gram)
: Compute LARS path in the sufficient stats mode.

[`lasso_path`](sklearn.linear_model.lasso_path.md#sklearn.linear_model.lasso_path)
: Compute Lasso path with coordinate descent.

[`LassoLars`](sklearn.linear_model.LassoLars.md#sklearn.linear_model.LassoLars)
: Lasso model fit with Least Angle Regression a.k.a. Lars.

[`Lars`](sklearn.linear_model.Lars.md#sklearn.linear_model.Lars)
: Least Angle Regression model a.k.a. LAR.

[`LassoLarsCV`](sklearn.linear_model.LassoLarsCV.md#sklearn.linear_model.LassoLarsCV)
: Cross-validated Lasso, using the LARS algorithm.

[`LarsCV`](sklearn.linear_model.LarsCV.md#sklearn.linear_model.LarsCV)
: Cross-validated Least Angle Regression model.

[`sklearn.decomposition.sparse_encode`](sklearn.decomposition.sparse_encode.md#sklearn.decomposition.sparse_encode)
: Sparse coding.

### References

### Examples

```pycon
>>> from sklearn.linear_model import lars_path
>>> from sklearn.datasets import make_regression
>>> X, y, true_coef = make_regression(
...    n_samples=100, n_features=5, n_informative=2, coef=True, random_state=0
... )
>>> true_coef
array([ 0.        ,  0.        ,  0.        , 97.9..., 45.7...])
>>> alphas, _, estimated_coef = lars_path(X, y)
>>> alphas.shape
(3,)
>>> estimated_coef
array([[ 0.     ,  0.     ,  0.     ],
       [ 0.     ,  0.     ,  0.     ],
       [ 0.     ,  0.     ,  0.     ],
       [ 0.     , 46.96..., 97.99...],
       [ 0.     ,  0.     , 45.70...]])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows how to compute the &quot;paths&quot; of coefficients along the Lasso, Lasso-LARS, and Elastic Net regularization paths. In other words, it shows the relationship between the regularization parameter (alpha) and the coefficients.">  <div class="sphx-glr-thumbnail-title">Lasso, Lasso-LARS, and Elastic Net paths</div>
</div>
* [Lasso, Lasso-LARS, and Elastic Net paths](../../auto_examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.md#sphx-glr-auto-examples-linear-model-plot-lasso-lasso-lars-elasticnet-path-py)

<!-- thumbnail-parent-div-close --></div>
