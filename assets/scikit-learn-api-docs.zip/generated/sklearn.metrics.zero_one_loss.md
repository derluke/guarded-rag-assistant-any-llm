# zero_one_loss

### sklearn.metrics.zero_one_loss(y_true, y_pred, \*, normalize=True, sample_weight=None)

Zero-one classification loss.

If normalize is `True`, return the fraction of misclassifications
(float), else it returns the number of misclassifications (int). The best
performance is 0.

Read more in the [User Guide](../model_evaluation.md#zero-one-loss).

* **Parameters:**
  **y_true**
  : Ground truth (correct) labels.

  **y_pred**
  : Predicted labels, as returned by a classifier.

  **normalize**
  : If `False`, return the number of misclassifications.
    Otherwise, return the fraction of misclassifications.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **loss**
  : If `normalize == True`, return the fraction of misclassifications
    (float), else it returns the number of misclassifications (int).

#### SEE ALSO
[`accuracy_score`](sklearn.metrics.accuracy_score.md#sklearn.metrics.accuracy_score)
: Compute the accuracy score. By default, the function will return the fraction of correct predictions divided by the total number of predictions.

[`hamming_loss`](sklearn.metrics.hamming_loss.md#sklearn.metrics.hamming_loss)
: Compute the average Hamming loss or Hamming distance between two sets of samples.

[`jaccard_score`](sklearn.metrics.jaccard_score.md#sklearn.metrics.jaccard_score)
: Compute the Jaccard similarity coefficient score.

### Notes

In multilabel classification, the zero_one_loss function corresponds to
the subset zero-one loss: for each sample, the entire set of labels must be
correctly predicted, otherwise the loss for that sample is equal to one.

### Examples

```pycon
>>> from sklearn.metrics import zero_one_loss
>>> y_pred = [1, 2, 3, 4]
>>> y_true = [2, 2, 3, 4]
>>> zero_one_loss(y_true, y_pred)
0.25
>>> zero_one_loss(y_true, y_pred, normalize=False)
1.0
```

In the multilabel case with binary label indicators:

```pycon
>>> import numpy as np
>>> zero_one_loss(np.array([[0, 1], [1, 1]]), np.ones((2, 2)))
0.5
```

<!-- !! processed by numpydoc !! -->
