# MultiOutputClassifier

### *class* sklearn.multioutput.MultiOutputClassifier(estimator, \*, n_jobs=None)

Multi target classification.

This strategy consists of fitting one classifier per target. This is a
simple strategy for extending classifiers that do not natively support
multi-target classification.

* **Parameters:**
  **estimator**
  : An estimator object implementing [fit](../../glossary.md#term-fit) and [predict](../../glossary.md#term-predict).
    A [predict_proba](../../glossary.md#term-predict_proba) method will be exposed only if `estimator` implements
    it.

  **n_jobs**
  : The number of jobs to run in parallel.
    [`fit`](#sklearn.multioutput.MultiOutputClassifier.fit), [`predict`](#sklearn.multioutput.MultiOutputClassifier.predict) and [`partial_fit`](#sklearn.multioutput.MultiOutputClassifier.partial_fit) (if supported
    by the passed estimator) will be parallelized for each target.
    <br/>
    When individual estimators are fast to train or predict,
    using `n_jobs > 1` can result in slower performance due
    to the parallelism overhead.
    <br/>
    `None` means `1` unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all available processes / threads.
    See [Glossary](../../glossary.md#term-n_jobs) for more details.
    <br/>
    #### Versionchanged
    Changed in version 0.20: `n_jobs` default changed from `1` to `None`.
* **Attributes:**
  **classes_**
  : Class labels.

  **estimators_**
  : Estimators used for predictions.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying `estimator` exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimators expose such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`ClassifierChain`](sklearn.multioutput.ClassifierChain.md#sklearn.multioutput.ClassifierChain)
: A multi-label model that arranges binary classifiers into a chain.

[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)
: Fits one regressor per target variable.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.datasets import make_multilabel_classification
>>> from sklearn.multioutput import MultiOutputClassifier
>>> from sklearn.linear_model import LogisticRegression
>>> X, y = make_multilabel_classification(n_classes=3, random_state=0)
>>> clf = MultiOutputClassifier(LogisticRegression()).fit(X, y)
>>> clf.predict(X[-2:])
array([[1, 1, 1],
       [1, 0, 1]])
```

<!-- !! processed by numpydoc !! -->

#### fit(X, Y, sample_weight=None, \*\*fit_params)

Fit the model to data matrix X and targets Y.

* **Parameters:**
  **X**
  : The input data.

  **Y**
  : The target values.

  **sample_weight**
  : Sample weights. If `None`, then samples are equally weighted.
    Only supported if the underlying classifier supports sample
    weights.

  **\*\*fit_params**
  : Parameters passed to the `estimator.fit` method of each step.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **self**
  : Returns a fitted instance.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.3.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### partial_fit(X, y, classes=None, sample_weight=None, \*\*partial_fit_params)

Incrementally fit a separate model for each class output.

* **Parameters:**
  **X**
  : The input data.

  **y**
  : Multi-output targets.

  **classes**
  : Each array is unique classes for one output in str/int.
    Can be obtained via
    `[np.unique(y[:, i]) for i in range(y.shape[1])]`, where `y`
    is the target matrix of the entire dataset.
    This argument is required for the first call to partial_fit
    and can be omitted in the subsequent calls.
    Note that `y` doesn’t need to contain all labels in `classes`.

  **sample_weight**
  : Sample weights. If `None`, then samples are equally weighted.
    Only supported if the underlying regressor supports sample
    weights.

  **\*\*partial_fit_params**
  : Parameters passed to the `estimator.partial_fit` method of each
    sub-estimator.
    <br/>
    Only available if `enable_metadata_routing=True`. See the
    [User Guide](../../metadata_routing.md#metadata-routing).
    <br/>
    #### Versionadded
    Added in version 1.3.
* **Returns:**
  **self**
  : Returns a fitted instance.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict multi-output variable using model for each target variable.

* **Parameters:**
  **X**
  : The input data.
* **Returns:**
  **y**
  : Multi-output targets predicted across multiple predictors.
    Note: Separate models are generated for each predictor.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Return prediction probabilities for each class of each output.

This method will raise a `ValueError` if any of the
estimators do not have `predict_proba`.

* **Parameters:**
  **X**
  : The input data.
* **Returns:**
  **p**
  : The class probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).
    <br/>
    #### Versionchanged
    Changed in version 0.19: This function now returns a list of arrays where the length of
    the list is `n_outputs`, and each array is (`n_samples`,
    `n_classes`) for that particular output.

<!-- !! processed by numpydoc !! -->

#### score(X, y)

Return the mean accuracy on the given test data and labels.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True values for X.
* **Returns:**
  **scores**
  : Mean accuracy of predicted target versus true target.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [MultiOutputClassifier](#sklearn.multioutput.MultiOutputClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_partial_fit_request(\*, classes: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$', sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [MultiOutputClassifier](#sklearn.multioutput.MultiOutputClassifier)

Request metadata passed to the `partial_fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `partial_fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `partial_fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **classes**
  : Metadata routing for `classes` parameter in `partial_fit`.

  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `partial_fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->
