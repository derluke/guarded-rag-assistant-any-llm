# PLSSVD

### *class* sklearn.cross_decomposition.PLSSVD(n_components=2, \*, scale=True, copy=True)

Partial Least Square SVD.

This transformer simply performs a SVD on the cross-covariance matrix
`X'Y`. It is able to project both the training data `X` and the targets
`Y`. The training data `X` is projected on the left singular vectors, while
the targets are projected on the right singular vectors.

Read more in the [User Guide](../cross_decomposition.md#cross-decomposition).

#### Versionadded
Added in version 0.8.

* **Parameters:**
  **n_components**
  : The number of components to keep. Should be in `[1,
    min(n_samples, n_features, n_targets)]`.

  **scale**
  : Whether to scale `X` and `Y`.

  **copy**
  : Whether to copy `X` and `Y` in fit before applying centering, and
    potentially scaling. If `False`, these operations will be done inplace,
    modifying both arrays.
* **Attributes:**
  **x_weights_**
  : The left singular vectors of the SVD of the cross-covariance matrix.
    Used to project `X` in [`transform`](#sklearn.cross_decomposition.PLSSVD.transform).

  **y_weights_**
  : The right singular vectors of the SVD of the cross-covariance matrix.
    Used to project `X` in [`transform`](#sklearn.cross_decomposition.PLSSVD.transform).

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`PLSCanonical`](sklearn.cross_decomposition.PLSCanonical.md#sklearn.cross_decomposition.PLSCanonical)
: Partial Least Squares transformer and regressor.

[`CCA`](sklearn.cross_decomposition.CCA.md#sklearn.cross_decomposition.CCA)
: Canonical Correlation Analysis.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.cross_decomposition import PLSSVD
>>> X = np.array([[0., 0., 1.],
...               [1., 0., 0.],
...               [2., 2., 2.],
...               [2., 5., 4.]])
>>> y = np.array([[0.1, -0.2],
...               [0.9, 1.1],
...               [6.2, 5.9],
...               [11.9, 12.3]])
>>> pls = PLSSVD(n_components=2).fit(X, y)
>>> X_c, y_c = pls.transform(X, y)
>>> X_c.shape, y_c.shape
((4, 2), (4, 2))
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, Y=None)

Fit model to data.

* **Parameters:**
  **X**
  : Training samples.

  **y**
  : Targets.

  **Y**
  : Targets.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Y` is deprecated in 1.5 and will be removed in 1.7. Use `y` instead.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None)

Learn and apply the dimensionality reduction.

* **Parameters:**
  **X**
  : Training samples.

  **y**
  : Targets.
* **Returns:**
  **out**
  : The transformed data `X_transformed` if `Y is not None`,
    `(X_transformed, Y_transformed)` otherwise.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X, y=None, Y=None)

Apply the dimensionality reduction.

* **Parameters:**
  **X**
  : Samples to be transformed.

  **y**
  : Targets.

  **Y**
  : Targets.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Y` is deprecated in 1.5 and will be removed in 1.7. Use `y` instead.
* **Returns:**
  **x_scores**
  : The transformed data `X_transformed` if `Y is not None`,
    `(X_transformed, Y_transformed)` otherwise.

<!-- !! processed by numpydoc !! -->
