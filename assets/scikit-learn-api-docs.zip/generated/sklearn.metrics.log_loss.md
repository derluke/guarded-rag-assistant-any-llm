# log_loss

### sklearn.metrics.log_loss(y_true, y_pred, \*, normalize=True, sample_weight=None, labels=None)

Log loss, aka logistic loss or cross-entropy loss.

This is the loss function used in (multinomial) logistic regression
and extensions of it such as neural networks, defined as the negative
log-likelihood of a logistic model that returns `y_pred` probabilities
for its training data `y_true`.
The log loss is only defined for two or more labels.
For a single sample with true label $y \in \{0,1\}$ and
a probability estimate $p = \operatorname{Pr}(y = 1)$, the log
loss is:

$$
L_{\log}(y, p) = -(y \log (p) + (1 - y) \log (1 - p))

$$

Read more in the [User Guide](../model_evaluation.md#log-loss).

* **Parameters:**
  **y_true**
  : Ground truth (correct) labels for n_samples samples.

  **y_pred**
  : Predicted probabilities, as returned by a classifier’s
    predict_proba method. If `y_pred.shape = (n_samples,)`
    the probabilities provided are assumed to be that of the
    positive class. The labels in `y_pred` are assumed to be
    ordered alphabetically, as done by
    [`LabelBinarizer`](sklearn.preprocessing.LabelBinarizer.md#sklearn.preprocessing.LabelBinarizer).
    <br/>
    `y_pred` values are clipped to `[eps, 1-eps]` where `eps` is the machine
    precision for `y_pred`’s dtype.

  **normalize**
  : If true, return the mean loss per sample.
    Otherwise, return the sum of the per-sample losses.

  **sample_weight**
  : Sample weights.

  **labels**
  : If not provided, labels will be inferred from y_true. If `labels`
    is `None` and `y_pred` has shape (n_samples,) the labels are
    assumed to be binary and are inferred from `y_true`.
    <br/>
    #### Versionadded
    Added in version 0.18.
* **Returns:**
  **loss**
  : Log loss, aka logistic loss or cross-entropy loss.

### Notes

The logarithm used is the natural logarithm (base-e).

### References

C.M. Bishop (2006). Pattern Recognition and Machine Learning. Springer,
p. 209.

### Examples

```pycon
>>> from sklearn.metrics import log_loss
>>> log_loss(["spam", "ham", "ham", "spam"],
...          [[.1, .9], [.9, .1], [.8, .2], [.35, .65]])
0.21616...
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="When performing classification one often wants to predict not only the class label, but also the associated probability. This probability gives some kind of confidence on the prediction. This example demonstrates how to visualize how well calibrated the predicted probabilities are using calibration curves, also known as reliability diagrams. Calibration of an uncalibrated classifier will also be demonstrated.">  <div class="sphx-glr-thumbnail-title">Probability Calibration curves</div>
</div>
* [Probability Calibration curves](../../auto_examples/calibration/plot_calibration_curve.md#sphx-glr-auto-examples-calibration-plot-calibration-curve-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how sigmoid calibration changes predicted probabilities for a 3-class classification problem. Illustrated is the standard 2-simplex, where the three corners correspond to the three classes. Arrows point from the probability vectors predicted by an uncalibrated classifier to the probability vectors predicted by the same classifier after sigmoid calibration on a hold-out validation set. Colors indicate the true class of an instance (red: class 1, green: class 2, blue: class 3).">  <div class="sphx-glr-thumbnail-title">Probability Calibration for 3-class classification</div>
</div>
* [Probability Calibration for 3-class classification](../../auto_examples/calibration/plot_calibration_multiclass.md#sphx-glr-auto-examples-calibration-plot-calibration-multiclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="Gradient Boosting Out-of-Bag estimates">  <div class="sphx-glr-thumbnail-title">Gradient Boosting Out-of-Bag estimates</div>
</div>
* [Gradient Boosting Out-of-Bag estimates](../../auto_examples/ensemble/plot_gradient_boosting_oob.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-oob-py)

<div class="sphx-glr-thumbcontainer" tooltip="Illustration of the effect of different regularization strategies for Gradient Boosting. The example is taken from Hastie et al 2009 [1]_.">  <div class="sphx-glr-thumbnail-title">Gradient Boosting regularization</div>
</div>
* [Gradient Boosting regularization](../../auto_examples/ensemble/plot_gradient_boosting_regularization.md#sphx-glr-auto-examples-ensemble-plot-gradient-boosting-regularization-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates the predicted probability of GPC for an RBF kernel with different choices of the hyperparameters. The first figure shows the predicted probability of GPC with arbitrarily chosen hyperparameters and with the hyperparameters corresponding to the maximum log-marginal-likelihood (LML).">  <div class="sphx-glr-thumbnail-title">Probabilistic predictions with Gaussian process classification (GPC)</div>
</div>
* [Probabilistic predictions with Gaussian process classification (GPC)](../../auto_examples/gaussian_process/plot_gpc.md#sphx-glr-auto-examples-gaussian-process-plot-gpc-py)

<div class="sphx-glr-thumbcontainer" tooltip="Feature scaling through standardization, also called Z-score normalization, is an important preprocessing step for many machine learning algorithms. It involves rescaling each feature such that it has a standard deviation of 1 and a mean of 0.">  <div class="sphx-glr-thumbnail-title">Importance of Feature Scaling</div>
</div>
* [Importance of Feature Scaling](../../auto_examples/preprocessing/plot_scaling_importance.md#sphx-glr-auto-examples-preprocessing-plot-scaling-importance-py)

<!-- thumbnail-parent-div-close --></div>
