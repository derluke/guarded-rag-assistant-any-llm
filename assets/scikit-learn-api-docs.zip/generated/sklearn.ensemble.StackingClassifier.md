# StackingClassifier

### *class* sklearn.ensemble.StackingClassifier(estimators, final_estimator=None, \*, cv=None, stack_method='auto', n_jobs=None, passthrough=False, verbose=0)

Stack of estimators with a final classifier.

Stacked generalization consists in stacking the output of individual
estimator and use a classifier to compute the final prediction. Stacking
allows to use the strength of each individual estimator by using their
output as input of a final estimator.

Note that `estimators_` are fitted on the full `X` while `final_estimator_`
is trained using cross-validated predictions of the base estimators using
`cross_val_predict`.

Read more in the [User Guide](../ensemble.md#stacking).

#### Versionadded
Added in version 0.22.

* **Parameters:**
  **estimators**
  : Base estimators which will be stacked together. Each element of the
    list is defined as a tuple of string (i.e. name) and an estimator
    instance. An estimator can be set to ‘drop’ using `set_params`.
    <br/>
    The type of estimator is generally expected to be a classifier.
    However, one can pass a regressor for some use case (e.g. ordinal
    regression).

  **final_estimator**
  : A classifier which will be used to combine the base estimators.
    The default classifier is a
    [`LogisticRegression`](sklearn.linear_model.LogisticRegression.md#sklearn.linear_model.LogisticRegression).

  **cv**
  : Determines the cross-validation splitting strategy used in
    `cross_val_predict` to train `final_estimator`. Possible inputs for
    cv are:
    * None, to use the default 5-fold cross validation,
    * integer, to specify the number of folds in a (Stratified) KFold,
    * An object to be used as a cross-validation generator,
    * An iterable yielding train, test splits,
    * `"prefit"`, to assume the `estimators` are prefit. In this case, the
      estimators will not be refitted.
    <br/>
    For integer/None inputs, if the estimator is a classifier and y is
    either binary or multiclass,
    [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used.
    In all other cases, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used.
    These splitters are instantiated with `shuffle=False` so the splits
    will be the same across calls.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    If “prefit” is passed, it is assumed that all `estimators` have
    been fitted already. The `final_estimator_` is trained on the `estimators`
    predictions on the full training set and are **not** cross validated
    predictions. Please note that if the models have been trained on the same
    data to train the stacking model, there is a very high risk of overfitting.
    <br/>
    #### Versionadded
    Added in version 1.1: The ‘prefit’ option was added in 1.1
    <br/>
    #### NOTE
    A larger number of split will provide no benefits if the number
    of training samples is large enough. Indeed, the training time
    will increase. `cv` is not used for model evaluation but for
    prediction.

  **stack_method**
  : Methods called for each base estimator. It can be:
    * if ‘auto’, it will try to invoke, for each estimator,
      `'predict_proba'`, `'decision_function'` or `'predict'` in that
      order.
    * otherwise, one of `'predict_proba'`, `'decision_function'` or
      `'predict'`. If the method is not implemented by the estimator, it
      will raise an error.

  **n_jobs**
  : The number of jobs to run in parallel for `fit` of all `estimators`.
    `None` means 1 unless in a `joblib.parallel_backend` context. -1 means
    using all processors. See [Glossary](../../glossary.md#term-n_jobs) for more details.

  **passthrough**
  : When False, only the predictions of estimators will be used as
    training data for `final_estimator`. When True, the
    `final_estimator` is trained on the predictions as well as the
    original training data.

  **verbose**
  : Verbosity level.
* **Attributes:**
  **classes_**
  : Class labels.

  **estimators_**
  : The elements of the `estimators` parameter, having been fitted on the
    training data. If an estimator has been set to `'drop'`, it
    will not appear in `estimators_`. When `cv="prefit"`, `estimators_`
    is set to `estimators` and is not fitted again.

  **named_estimators_**
  : Attribute to access any fitted sub-estimators by name.

  [`n_features_in_`](#sklearn.ensemble.StackingClassifier.n_features_in_)
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimators expose such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **final_estimator_**
  : The classifier fit on the output of `estimators_` and responsible for
    final predictions.

  **stack_method_**
  : The method used by each base estimator.

#### SEE ALSO
[`StackingRegressor`](sklearn.ensemble.StackingRegressor.md#sklearn.ensemble.StackingRegressor)
: Stack of estimators with a final regressor.

### Notes

When `predict_proba` is used by each estimator (i.e. most of the time for
`stack_method='auto'` or specifically for `stack_method='predict_proba'`),
the first column predicted by each estimator will be dropped in the case
of a binary classification problem. Indeed, both feature will be perfectly
collinear.

In some cases (e.g. ordinal regression), one can pass regressors as the
first layer of the [`StackingClassifier`](#sklearn.ensemble.StackingClassifier). However, note that `y` will
be internally encoded in a numerically increasing order or lexicographic
order. If this ordering is not adequate, one should manually numerically
encode the classes in the desired order.

### References

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn.ensemble import RandomForestClassifier
>>> from sklearn.svm import LinearSVC
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.preprocessing import StandardScaler
>>> from sklearn.pipeline import make_pipeline
>>> from sklearn.ensemble import StackingClassifier
>>> X, y = load_iris(return_X_y=True)
>>> estimators = [
...     ('rf', RandomForestClassifier(n_estimators=10, random_state=42)),
...     ('svr', make_pipeline(StandardScaler(),
...                           LinearSVC(random_state=42)))
... ]
>>> clf = StackingClassifier(
...     estimators=estimators, final_estimator=LogisticRegression()
... )
>>> from sklearn.model_selection import train_test_split
>>> X_train, X_test, y_train, y_test = train_test_split(
...     X, y, stratify=y, random_state=42
... )
>>> clf.fit(X_train, y_train).score(X_test, y_test)
0.9...
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Decision function for samples in `X` using the final estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **decisions**
  : The decision function computed the final estimator.

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*, sample_weight=None, \*\*fit_params)

Fit the estimators.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target values. Note that `y` will be internally encoded in
    numerically increasing order or lexicographic order. If the order
    matter (e.g. for ordinal regression), one should numerically encode
    the target `y` before calling [fit](../../glossary.md#term-fit).

  **sample_weight**
  : Sample weights. If None, then samples are equally weighted.
    Note that this is supported only if all underlying estimators
    support sample weights.

  **\*\*fit_params**
  : Parameters to pass to the underlying estimators.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`, which can be
    set by using `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Returns a fitted instance of estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

* **Parameters:**
  **input_features**
  : Input features. The input feature names are only used when `passthrough` is
    `True`.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then names are generated: `[x0, x1, ..., x(n_features_in_ - 1)]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
    <br/>
    If `passthrough` is `False`, then only the names of `estimators` are used
    to generate the output feature names.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.6.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get the parameters of an estimator from the ensemble.

Returns the parameters given in the constructor as well as the
estimators contained within the `estimators` parameter.

* **Parameters:**
  **deep**
  : Setting it to True gets the various estimators and the parameters
    of the estimators as well.
* **Returns:**
  **params**
  : Parameter and estimator names mapped to their values or parameter
    names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *property* n_features_in_

Number of features seen during [fit](../../glossary.md#term-fit).

<!-- !! processed by numpydoc !! -->

#### *property* named_estimators

Dictionary to access any fitted sub-estimators by name.

* **Returns:**
  [`Bunch`](sklearn.utils.Bunch.md#sklearn.utils.Bunch)

<!-- !! processed by numpydoc !! -->

#### predict(X, \*\*predict_params)

Predict target for X.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **\*\*predict_params**
  : Parameters to the `predict` called by the `final_estimator`. Note
    that this may be used to return uncertainties from some estimators
    with `return_std` or `return_cov`. Be aware that it will only
    account for uncertainty in the final estimator.
    - If `enable_metadata_routing=False` (default):
      Parameters directly passed to the `predict` method of the
      `final_estimator`.
    - If `enable_metadata_routing=True`: Parameters safely routed to
      the `predict` method of the `final_estimator`. See [Metadata
      Routing User Guide](../../metadata_routing.md#metadata-routing) for more details.
    <br/>
    #### Versionchanged
    Changed in version 1.6: `**predict_params` can be routed via metadata routing API.
* **Returns:**
  **y_pred**
  : Predicted targets.

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict class probabilities for `X` using the final estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **probabilities**
  : The class probabilities of the input samples.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the mean accuracy on the given test data and labels.

In multi-label classification, this is the subset accuracy
which is a harsh metric since you require for each sample that
each label set be correctly predicted.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : Mean accuracy of `self.predict(X)` w.r.t. `y`.

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [StackingClassifier](#sklearn.ensemble.StackingClassifier)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of an estimator from the ensemble.

Valid parameter keys can be listed with `get_params()`. Note that you
can directly set the parameters of the estimators contained in
`estimators`.

* **Parameters:**
  **\*\*params**
  : Specific parameters using e.g.
    `set_params(parameter_name=new_value)`. In addition, to setting the
    parameters of the estimator, the individual estimator of the
    estimators can also be set, or can be removed by setting them to
    ‘drop’.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [StackingClassifier](#sklearn.ensemble.StackingClassifier)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Return class labels or probabilities for X for each estimator.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features.
* **Returns:**
  **y_preds**
  : Prediction outputs for each estimator.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.22, which comes with many bug fixes and new features! We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_22&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.22</div>
</div>
* [Release Highlights for scikit-learn 0.22](../../auto_examples/release_highlights/plot_release_highlights_0_22_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-22-0-py)

<!-- thumbnail-parent-div-close --></div>
