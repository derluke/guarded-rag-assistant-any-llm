# ElasticNetCV

### *class* sklearn.linear_model.ElasticNetCV(\*, l1_ratio=0.5, eps=0.001, n_alphas=100, alphas=None, fit_intercept=True, precompute='auto', max_iter=1000, tol=0.0001, cv=None, copy_X=True, verbose=0, n_jobs=None, positive=False, random_state=None, selection='cyclic')

Elastic Net model with iterative fitting along a regularization path.

See glossary entry for [cross-validation estimator](../../glossary.md#term-cross-validation-estimator).

Read more in the [User Guide](../linear_model.md#elastic-net).

* **Parameters:**
  **l1_ratio**
  : Float between 0 and 1 passed to ElasticNet (scaling between
    l1 and l2 penalties). For `l1_ratio = 0`
    the penalty is an L2 penalty. For `l1_ratio = 1` it is an L1 penalty.
    For `0 < l1_ratio < 1`, the penalty is a combination of L1 and L2
    This parameter can be a list, in which case the different
    values are tested by cross-validation and the one giving the best
    prediction score is used. Note that a good choice of list of
    values for l1_ratio is often to put more values close to 1
    (i.e. Lasso) and less close to 0 (i.e. Ridge), as in `[.1, .5, .7,
    .9, .95, .99, 1]`.

  **eps**
  : Length of the path. `eps=1e-3` means that
    `alpha_min / alpha_max = 1e-3`.

  **n_alphas**
  : Number of alphas along the regularization path, used for each l1_ratio.

  **alphas**
  : List of alphas where to compute the models.
    If None alphas are set automatically.

  **fit_intercept**
  : Whether to calculate the intercept for this model. If set
    to false, no intercept will be used in calculations
    (i.e. data is expected to be centered).

  **precompute**
  : Whether to use a precomputed Gram matrix to speed up
    calculations. If set to `'auto'` let us decide. The Gram
    matrix can also be passed as argument.

  **max_iter**
  : The maximum number of iterations.

  **tol**
  : The tolerance for the optimization: if the updates are
    smaller than `tol`, the optimization code checks the
    dual gap for optimality and continues until it is smaller
    than `tol`.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross-validation,
    - int, to specify the number of folds.
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For int/None inputs, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value if None changed from 3-fold to 5-fold.

  **copy_X**
  : If `True`, X will be copied; else, it may be overwritten.

  **verbose**
  : Amount of verbosity.

  **n_jobs**
  : Number of CPUs to use during the cross validation.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.

  **positive**
  : When set to `True`, forces the coefficients to be positive.

  **random_state**
  : The seed of the pseudo random number generator that selects a random
    feature to update. Used when `selection` == ‘random’.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **selection**
  : If set to ‘random’, a random coefficient is updated every iteration
    rather than looping over features sequentially by default. This
    (setting to ‘random’) often leads to significantly faster convergence
    especially when tol is higher than 1e-4.
* **Attributes:**
  **alpha_**
  : The amount of penalization chosen by cross validation.

  **l1_ratio_**
  : The compromise between l1 and l2 penalization chosen by
    cross validation.

  **coef_**
  : Parameter vector (w in the cost function formula).

  **intercept_**
  : Independent term in the decision function.

  **mse_path_**
  : Mean square error for the test set on each fold, varying l1_ratio and
    alpha.

  **alphas_**
  : The grid of alphas used for fitting, for each l1_ratio.

  **dual_gap_**
  : The dual gaps at the end of the optimization for the optimal alpha.

  **n_iter_**
  : Number of iterations run by the coordinate descent solver to reach
    the specified tolerance for the optimal alpha.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`enet_path`](sklearn.linear_model.enet_path.md#sklearn.linear_model.enet_path)
: Compute elastic net path with coordinate descent.

[`ElasticNet`](sklearn.linear_model.ElasticNet.md#sklearn.linear_model.ElasticNet)
: Linear regression with combined L1 and L2 priors as regularizer.

### Notes

In `fit`, once the best parameters `l1_ratio` and `alpha` are found through
cross-validation, the model is fit again using the entire training set.

To avoid unnecessary memory duplication the `X` argument of the `fit`
method should be directly passed as a Fortran-contiguous numpy array.

The parameter `l1_ratio` corresponds to alpha in the glmnet R package
while alpha corresponds to the lambda parameter in glmnet.
More specifically, the optimization objective is:

```default
1 / (2 * n_samples) * ||y - Xw||^2_2
+ alpha * l1_ratio * ||w||_1
+ 0.5 * alpha * (1 - l1_ratio) * ||w||^2_2
```

If you are interested in controlling the L1 and L2 penalty
separately, keep in mind that this is equivalent to:

```default
a * L1 + b * L2
```

for:

```default
alpha = a + b and l1_ratio = a / (a + b).
```

For an example, see
[examples/linear_model/plot_lasso_model_selection.py](../../auto_examples/linear_model/plot_lasso_model_selection.md#sphx-glr-auto-examples-linear-model-plot-lasso-model-selection-py).

### Examples

```pycon
>>> from sklearn.linear_model import ElasticNetCV
>>> from sklearn.datasets import make_regression
```

```pycon
>>> X, y = make_regression(n_features=2, random_state=0)
>>> regr = ElasticNetCV(cv=5, random_state=0)
>>> regr.fit(X, y)
ElasticNetCV(cv=5, random_state=0)
>>> print(regr.alpha_)
0.199...
>>> print(regr.intercept_)
0.398...
>>> print(regr.predict([[0, 0]]))
[0.398...]
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y, sample_weight=None, \*\*params)

Fit ElasticNet model with coordinate descent.

Fit is on grid of alphas and best alpha estimated by cross-validation.

* **Parameters:**
  **X**
  : Training data. Pass directly as Fortran-contiguous data
    to avoid unnecessary memory duplication. If y is mono-output,
    X can be sparse. Note that large sparse matrices and arrays
    requiring `int64` indices are not accepted.

  **y**
  : Target values.

  **sample_weight**
  : Sample weights used for fitting and evaluation of the weighted
    mean squared error of each cv-fold. Note that the cross validated
    MSE that is finally used to find the best model is the unweighted
    mean over the (weighted) MSEs of each test fold.

  **\*\*params**
  : Parameters to be passed to the CV splitter.
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Returns an instance of fitted model.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.4.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### *static* path(X, y, \*, l1_ratio=0.5, eps=0.001, n_alphas=100, alphas=None, precompute='auto', Xy=None, copy_X=True, coef_init=None, verbose=False, return_n_iter=False, positive=False, check_input=True, \*\*params)

Compute elastic net path with coordinate descent.

The elastic net optimization function varies for mono and multi-outputs.

For mono-output tasks it is:

```default
1 / (2 * n_samples) * ||y - Xw||^2_2
+ alpha * l1_ratio * ||w||_1
+ 0.5 * alpha * (1 - l1_ratio) * ||w||^2_2
```

For multi-output tasks it is:

```default
(1 / (2 * n_samples)) * ||Y - XW||_Fro^2
+ alpha * l1_ratio * ||W||_21
+ 0.5 * alpha * (1 - l1_ratio) * ||W||_Fro^2
```

Where:

```default
||W||_21 = \sum_i \sqrt{\sum_j w_{ij}^2}
```

i.e. the sum of norm of each row.

Read more in the [User Guide](../linear_model.md#elastic-net).

* **Parameters:**
  **X**
  : Training data. Pass directly as Fortran-contiguous data to avoid
    unnecessary memory duplication. If `y` is mono-output then `X`
    can be sparse.

  **y**
  : Target values.

  **l1_ratio**
  : Number between 0 and 1 passed to elastic net (scaling between
    l1 and l2 penalties). `l1_ratio=1` corresponds to the Lasso.

  **eps**
  : Length of the path. `eps=1e-3` means that
    `alpha_min / alpha_max = 1e-3`.

  **n_alphas**
  : Number of alphas along the regularization path.

  **alphas**
  : List of alphas where to compute the models.
    If None alphas are set automatically.

  **precompute**
  : Whether to use a precomputed Gram matrix to speed up
    calculations. If set to `'auto'` let us decide. The Gram
    matrix can also be passed as argument.

  **Xy**
  : Xy = np.dot(X.T, y) that can be precomputed. It is useful
    only when the Gram matrix is precomputed.

  **copy_X**
  : If `True`, X will be copied; else, it may be overwritten.

  **coef_init**
  : The initial values of the coefficients.

  **verbose**
  : Amount of verbosity.

  **return_n_iter**
  : Whether to return the number of iterations or not.

  **positive**
  : If set to True, forces coefficients to be positive.
    (Only allowed when `y.ndim == 1`).

  **check_input**
  : If set to False, the input validation checks are skipped (including the
    Gram matrix when provided). It is assumed that they are handled
    by the caller.

  **\*\*params**
  : Keyword arguments passed to the coordinate descent solver.
* **Returns:**
  **alphas**
  : The alphas along the path where models are computed.

  **coefs**
  : Coefficients along the path.

  **dual_gaps**
  : The dual gaps at the end of the optimization for each alpha.

  **n_iters**
  : The number of iterations taken by the coordinate descent optimizer to
    reach the specified tolerance for each alpha.
    (Is returned when `return_n_iter` is set to True).

#### SEE ALSO
[`MultiTaskElasticNet`](sklearn.linear_model.MultiTaskElasticNet.md#sklearn.linear_model.MultiTaskElasticNet)
: Multi-task ElasticNet model trained with L1/L2 mixed-norm     as regularizer.

[`MultiTaskElasticNetCV`](sklearn.linear_model.MultiTaskElasticNetCV.md#sklearn.linear_model.MultiTaskElasticNetCV)
: Multi-task L1/L2 ElasticNet with built-in cross-validation.

[`ElasticNet`](sklearn.linear_model.ElasticNet.md#sklearn.linear_model.ElasticNet)
: Linear regression with combined L1 and L2 priors as regularizer.

[`ElasticNetCV`](#sklearn.linear_model.ElasticNetCV)
: Elastic Net model with iterative fitting along a regularization path.

### Notes

For an example, see
[examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.py](../../auto_examples/linear_model/plot_lasso_lasso_lars_elasticnet_path.md#sphx-glr-auto-examples-linear-model-plot-lasso-lasso-lars-elasticnet-path-py).

### Examples

```pycon
>>> from sklearn.linear_model import enet_path
>>> from sklearn.datasets import make_regression
>>> X, y, true_coef = make_regression(
...    n_samples=100, n_features=5, n_informative=2, coef=True, random_state=0
... )
>>> true_coef
array([ 0.        ,  0.        ,  0.        , 97.9..., 45.7...])
>>> alphas, estimated_coef, _ = enet_path(X, y, n_alphas=3)
>>> alphas.shape
(3,)
>>> estimated_coef
 array([[ 0.        ,  0.78...,  0.56...],
        [ 0.        ,  1.12...,  0.61...],
        [-0.        , -2.12..., -1.12...],
        [ 0.        , 23.04..., 88.93...],
        [ 0.        , 10.63..., 41.56...]])
```

<!-- !! processed by numpydoc !! -->

#### predict(X)

Predict using the linear model.

* **Parameters:**
  **X**
  : Samples.
* **Returns:**
  **C**
  : Returns predicted values.

<!-- !! processed by numpydoc !! -->

#### score(X, y, sample_weight=None)

Return the coefficient of determination of the prediction.

The coefficient of determination $R^2$ is defined as
$(1 - \frac{u}{v})$, where $u$ is the residual
sum of squares `((y_true - y_pred)** 2).sum()` and $v$
is the total sum of squares `((y_true - y_true.mean()) ** 2).sum()`.
The best possible score is 1.0 and it can be negative (because the
model can be arbitrarily worse). A constant model that always predicts
the expected value of `y`, disregarding the input features, would get
a $R^2$ score of 0.0.

* **Parameters:**
  **X**
  : Test samples. For some estimators this may be a precomputed
    kernel matrix or a list of generic objects instead with shape
    `(n_samples, n_samples_fitted)`, where `n_samples_fitted`
    is the number of samples used in the fitting for the estimator.

  **y**
  : True values for `X`.

  **sample_weight**
  : Sample weights.
* **Returns:**
  **score**
  : $R^2$ of `self.predict(X)` w.r.t. `y`.

### Notes

The $R^2$ score used when calling `score` on a regressor uses
`multioutput='uniform_average'` from version 0.23 to keep consistent
with default value of [`r2_score`](sklearn.metrics.r2_score.md#sklearn.metrics.r2_score).
This influences the `score` method of all the multioutput
regressors (except for
[`MultiOutputRegressor`](sklearn.multioutput.MultiOutputRegressor.md#sklearn.multioutput.MultiOutputRegressor)).

<!-- !! processed by numpydoc !! -->

#### set_fit_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [ElasticNetCV](#sklearn.linear_model.ElasticNetCV)

Request metadata passed to the `fit` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `fit` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `fit`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `fit`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_score_request(\*, sample_weight: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [ElasticNetCV](#sklearn.linear_model.ElasticNetCV)

Request metadata passed to the `score` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `score` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `score`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **sample_weight**
  : Metadata routing for `sample_weight` parameter in `score`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="The present example compares three l1-based regression models on a synthetic signal obtained from sparse and correlated features that are further corrupted with additive gaussian noise:">  <div class="sphx-glr-thumbnail-title">L1-based models for Sparse Signals</div>
</div>
* [L1-based models for Sparse Signals](../../auto_examples/linear_model/plot_lasso_and_elasticnet.md#sphx-glr-auto-examples-linear-model-plot-lasso-and-elasticnet-py)

<!-- thumbnail-parent-div-close --></div>
