# make_spd_matrix

### sklearn.datasets.make_spd_matrix(n_dim, \*, random_state=None)

Generate a random symmetric, positive-definite matrix.

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **n_dim**
  : The matrix dimension.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Returns:**
  **X**
  : The random symmetric, positive-definite matrix.

#### SEE ALSO
[`make_sparse_spd_matrix`](sklearn.datasets.make_sparse_spd_matrix.md#sklearn.datasets.make_sparse_spd_matrix)
: Generate a sparse symmetric definite positive matrix.

### Examples

```pycon
>>> from sklearn.datasets import make_spd_matrix
>>> make_spd_matrix(n_dim=2, random_state=42)
array([[2.09..., 0.34...],
       [0.34..., 0.21...]])
```

<!-- !! processed by numpydoc !! -->
