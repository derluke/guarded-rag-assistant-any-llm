# make_blobs

### sklearn.datasets.make_blobs(n_samples=100, n_features=2, \*, centers=None, cluster_std=1.0, center_box=(-10.0, 10.0), shuffle=True, random_state=None, return_centers=False)

Generate isotropic Gaussian blobs for clustering.

Read more in the [User Guide](../../datasets/sample_generators.md#sample-generators).

* **Parameters:**
  **n_samples**
  : If int, it is the total number of points equally divided among
    clusters.
    If array-like, each element of the sequence indicates
    the number of samples per cluster.
    <br/>
    #### Versionchanged
    Changed in version v0.20: one can now pass an array-like to the `n_samples` parameter

  **n_features**
  : The number of features for each sample.

  **centers**
  : The number of centers to generate, or the fixed center locations.
    If n_samples is an int and centers is None, 3 centers are generated.
    If n_samples is array-like, centers must be
    either None or an array of length equal to the length of n_samples.

  **cluster_std**
  : The standard deviation of the clusters.

  **center_box**
  : The bounding box for each cluster center when centers are
    generated at random.

  **shuffle**
  : Shuffle the samples.

  **random_state**
  : Determines random number generation for dataset creation. Pass an int
    for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **return_centers**
  : If True, then return the centers of each cluster.
    <br/>
    #### Versionadded
    Added in version 0.23.
* **Returns:**
  **X**
  : The generated samples.

  **y**
  : The integer labels for cluster membership of each sample.

  **centers**
  : The centers of each cluster. Only returned if
    `return_centers=True`.

#### SEE ALSO
[`make_classification`](sklearn.datasets.make_classification.md#sklearn.datasets.make_classification)
: A more intricate variant.

### Examples

```pycon
>>> from sklearn.datasets import make_blobs
>>> X, y = make_blobs(n_samples=10, centers=3, n_features=2,
...                   random_state=0)
>>> print(X.shape)
(10, 2)
>>> y
array([0, 0, 1, 0, 2, 2, 2, 1, 1, 0])
>>> X, y = make_blobs(n_samples=[3, 3, 4], centers=None, n_features=2,
...                   random_state=0)
>>> print(X.shape)
(10, 2)
>>> y
array([0, 1, 2, 0, 2, 2, 2, 1, 1, 0])
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how sigmoid calibration changes predicted probabilities for a 3-class classification problem. Illustrated is the standard 2-simplex, where the three corners correspond to the three classes. Arrows point from the probability vectors predicted by an uncalibrated classifier to the probability vectors predicted by the same classifier after sigmoid calibration on a hold-out validation set. Colors indicate the true class of an instance (red: class 1, green: class 2, blue: class 3).">  <div class="sphx-glr-thumbnail-title">Probability Calibration for 3-class classification</div>
</div>
* [Probability Calibration for 3-class classification](../../auto_examples/calibration/plot_calibration_multiclass.md#sphx-glr-auto-examples-calibration-plot-calibration-multiclass-py)

<div class="sphx-glr-thumbcontainer" tooltip="When performing classification you often want to predict not only the class label, but also the associated probability. This probability gives you some kind of confidence on the prediction. However, not all classifiers provide well-calibrated probabilities, some being over-confident while others being under-confident. Thus, a separate calibration of predicted probabilities is often desirable as a postprocessing. This example illustrates two different methods for this calibration and evaluates the quality of the returned probabilities using Brier&#x27;s score (see https://en.wikipedia.org/wiki/Brier_score).">  <div class="sphx-glr-thumbnail-title">Probability calibration of classifiers</div>
</div>
* [Probability calibration of classifiers](../../auto_examples/calibration/plot_calibration.md#sphx-glr-auto-examples-calibration-plot-calibration-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how the Ledoit-Wolf and Oracle Approximating Shrinkage (OAS) estimators of covariance can improve classification.">  <div class="sphx-glr-thumbnail-title">Normal, Ledoit-Wolf and OAS Linear Discriminant Analysis for classification</div>
</div>
* [Normal, Ledoit-Wolf and OAS Linear Discriminant Analysis for classification](../../auto_examples/classification/plot_lda.md#sphx-glr-auto-examples-classification-plot-lda-py)

<div class="sphx-glr-thumbcontainer" tooltip="Reference:">  <div class="sphx-glr-thumbnail-title">A demo of the mean-shift clustering algorithm</div>
</div>
* [A demo of the mean-shift clustering algorithm](../../auto_examples/cluster/plot_mean_shift.md#sphx-glr-auto-examples-cluster-plot-mean-shift-py)

<div class="sphx-glr-thumbcontainer" tooltip="An example to show the output of the sklearn.cluster.kmeans_plusplus function for generating initial seeds for clustering.">  <div class="sphx-glr-thumbnail-title">An example of K-Means++ initialization</div>
</div>
* [An example of K-Means++ initialization](../../auto_examples/cluster/plot_kmeans_plusplus.md#sphx-glr-auto-examples-cluster-plot-kmeans-plusplus-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows differences between Regular K-Means algorithm and Bisecting K-Means.">  <div class="sphx-glr-thumbnail-title">Bisecting K-Means and Regular K-Means Performance Comparison</div>
</div>
* [Bisecting K-Means and Regular K-Means Performance Comparison](../../auto_examples/cluster/plot_bisect_kmeans.md#sphx-glr-auto-examples-cluster-plot-bisect-kmeans-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares the timing of BIRCH (with and without the global clustering step) and MiniBatchKMeans on a synthetic dataset having 25,000 samples and 2 features generated using make_blobs.">  <div class="sphx-glr-thumbnail-title">Compare BIRCH and MiniBatchKMeans</div>
</div>
* [Compare BIRCH and MiniBatchKMeans](../../auto_examples/cluster/plot_birch_vs_minibatchkmeans.md#sphx-glr-auto-examples-cluster-plot-birch-vs-minibatchkmeans-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different clustering algorithms on datasets that are &quot;interesting&quot; but still in 2D. With the exception of the last dataset, the parameters of each of these dataset-algorithm pairs has been tuned to produce good clustering results. Some algorithms are more sensitive to parameter values than others.">  <div class="sphx-glr-thumbnail-title">Comparing different clustering algorithms on toy datasets</div>
</div>
* [Comparing different clustering algorithms on toy datasets](../../auto_examples/cluster/plot_cluster_comparison.md#sphx-glr-auto-examples-cluster-plot-cluster-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different linkage methods for hierarchical clustering on datasets that are &quot;interesting&quot; but still in 2D.">  <div class="sphx-glr-thumbnail-title">Comparing different hierarchical linkage methods on toy datasets</div>
</div>
* [Comparing different hierarchical linkage methods on toy datasets](../../auto_examples/cluster/plot_linkage_comparison.md#sphx-glr-auto-examples-cluster-plot-linkage-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="We want to compare the performance of the MiniBatchKMeans and KMeans: the MiniBatchKMeans is faster, but gives slightly different results (see mini_batch_kmeans).">  <div class="sphx-glr-thumbnail-title">Comparison of the K-Means and MiniBatchKMeans clustering algorithms</div>
</div>
* [Comparison of the K-Means and MiniBatchKMeans clustering algorithms](../../auto_examples/cluster/plot_mini_batch_kmeans.md#sphx-glr-auto-examples-cluster-plot-mini-batch-kmeans-py)

<div class="sphx-glr-thumbcontainer" tooltip="DBSCAN (Density-Based Spatial Clustering of Applications with Noise) finds core samples in regions of high density and expands clusters from them. This algorithm is good for data which contains clusters of similar density.">  <div class="sphx-glr-thumbnail-title">Demo of DBSCAN clustering algorithm</div>
</div>
* [Demo of DBSCAN clustering algorithm](../../auto_examples/cluster/plot_dbscan.md#sphx-glr-auto-examples-cluster-plot-dbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="In this demo we will take a look at cluster.HDBSCAN from the perspective of generalizing the cluster.DBSCAN algorithm. We&#x27;ll compare both algorithms on specific datasets. Finally we&#x27;ll evaluate HDBSCAN&#x27;s sensitivity to certain hyperparameters.">  <div class="sphx-glr-thumbnail-title">Demo of HDBSCAN clustering algorithm</div>
</div>
* [Demo of HDBSCAN clustering algorithm](../../auto_examples/cluster/plot_hdbscan.md#sphx-glr-auto-examples-cluster-plot-hdbscan-py)

<div class="sphx-glr-thumbcontainer" tooltip="Reference: Brendan J. Frey and Delbert Dueck, &quot;Clustering by Passing Messages Between Data Points&quot;, Science Feb. 2007">  <div class="sphx-glr-thumbnail-title">Demo of affinity propagation clustering algorithm</div>
</div>
* [Demo of affinity propagation clustering algorithm](../../auto_examples/cluster/plot_affinity_propagation.md#sphx-glr-auto-examples-cluster-plot-affinity-propagation-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example is meant to illustrate situations where k-means produces unintuitive and possibly undesirable clusters.">  <div class="sphx-glr-thumbnail-title">Demonstration of k-means assumptions</div>
</div>
* [Demonstration of k-means assumptions](../../auto_examples/cluster/plot_kmeans_assumptions.md#sphx-glr-auto-examples-cluster-plot-kmeans-assumptions-py)

<div class="sphx-glr-thumbcontainer" tooltip="Clustering can be expensive, especially when our dataset contains millions of datapoints. Many clustering algorithms are not inductive and so cannot be directly applied to new data samples without recomputing the clustering, which may be intractable. Instead, we can use clustering to then learn an inductive model with a classifier, which has several benefits:">  <div class="sphx-glr-thumbnail-title">Inductive Clustering</div>
</div>
* [Inductive Clustering](../../auto_examples/cluster/plot_inductive_clustering.md#sphx-glr-auto-examples-cluster-plot-inductive-clustering-py)

<div class="sphx-glr-thumbcontainer" tooltip="Silhouette analysis can be used to study the separation distance between the resulting clusters. The silhouette plot displays a measure of how close each point in one cluster is to points in the neighboring clusters and thus provides a way to assess parameters like number of clusters visually. This measure has a range of [-1, 1].">  <div class="sphx-glr-thumbnail-title">Selecting the number of clusters with silhouette analysis on KMeans clustering</div>
</div>
* [Selecting the number of clusters with silhouette analysis on KMeans clustering](../../auto_examples/cluster/plot_kmeans_silhouette_analysis.md#sphx-glr-auto-examples-cluster-plot-kmeans-silhouette-analysis-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares decision boundaries of multinomial and one-vs-rest logistic regression on a 2D dataset with three classes.">  <div class="sphx-glr-thumbnail-title">Decision Boundaries of Multinomial and One-vs-Rest Logistic Regression</div>
</div>
* [Decision Boundaries of Multinomial and One-vs-Rest Logistic Regression](../../auto_examples/linear_model/plot_logistic_multinomial.md#sphx-glr-auto-examples-linear-model-plot-logistic-multinomial-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the maximum margin separating hyperplane within a two-class separable dataset using a linear Support Vector Machines classifier trained using SGD.">  <div class="sphx-glr-thumbnail-title">SGD: Maximum margin separating hyperplane</div>
</div>
* [SGD: Maximum margin separating hyperplane](../../auto_examples/linear_model/plot_sgd_separating_hyperplane.md#sphx-glr-auto-examples-linear-model-plot-sgd-separating-hyperplane-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different anomaly detection algorithms on 2D datasets. Datasets contain one or two modes (regions of high density) to illustrate the ability of algorithms to cope with multimodal data.">  <div class="sphx-glr-thumbnail-title">Comparing anomaly detection algorithms for outlier detection on toy datasets</div>
</div>
* [Comparing anomaly detection algorithms for outlier detection on toy datasets](../../auto_examples/miscellaneous/plot_anomaly_comparison.md#sphx-glr-auto-examples-miscellaneous-plot-anomaly-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="Examples of the different methods of initialization in Gaussian Mixture Models">  <div class="sphx-glr-thumbnail-title">GMM Initialization Methods</div>
</div>
* [GMM Initialization Methods](../../auto_examples/mixture/plot_gmm_init.md#sphx-glr-auto-examples-mixture-plot-gmm-init-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example presents the different strategies implemented in KBinsDiscretizer:">  <div class="sphx-glr-thumbnail-title">Demonstrating the different strategies of KBinsDiscretizer</div>
</div>
* [Demonstrating the different strategies of KBinsDiscretizer](../../auto_examples/preprocessing/plot_discretization_strategies.md#sphx-glr-auto-examples-preprocessing-plot-discretization-strategies-py)

<div class="sphx-glr-thumbcontainer" tooltip="Unlike SVC (based on LIBSVM), LinearSVC (based on LIBLINEAR) does not provide the support vectors. This example demonstrates how to obtain the support vectors in LinearSVC.">  <div class="sphx-glr-thumbnail-title">Plot the support vectors in LinearSVC</div>
</div>
* [Plot the support vectors in LinearSVC](../../auto_examples/svm/plot_linearsvc_support_vectors.md#sphx-glr-auto-examples-svm-plot-linearsvc-support-vectors-py)

<div class="sphx-glr-thumbcontainer" tooltip="The two plots differ only in the area in the middle where the classes are tied. If break_ties=False, all input in that area would be classified as one class, whereas if break_ties=True, the tie-breaking mechanism will create a non-convex decision boundary in that area.">  <div class="sphx-glr-thumbnail-title">SVM Tie Breaking Example</div>
</div>
* [SVM Tie Breaking Example](../../auto_examples/svm/plot_svm_tie_breaking.md#sphx-glr-auto-examples-svm-plot-svm-tie-breaking-py)

<div class="sphx-glr-thumbcontainer" tooltip="Plot the maximum margin separating hyperplane within a two-class separable dataset using a Support Vector Machine classifier with linear kernel.">  <div class="sphx-glr-thumbnail-title">SVM: Maximum margin separating hyperplane</div>
</div>
* [SVM: Maximum margin separating hyperplane](../../auto_examples/svm/plot_separating_hyperplane.md#sphx-glr-auto-examples-svm-plot-separating-hyperplane-py)

<div class="sphx-glr-thumbcontainer" tooltip="Find the optimal separating hyperplane using an SVC for classes that are unbalanced.">  <div class="sphx-glr-thumbnail-title">SVM: Separating hyperplane for unbalanced classes</div>
</div>
* [SVM: Separating hyperplane for unbalanced classes](../../auto_examples/svm/plot_separating_hyperplane_unbalanced.md#sphx-glr-auto-examples-svm-plot-separating-hyperplane-unbalanced-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.1! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_1&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.1</div>
</div>
* [Release Highlights for scikit-learn 1.1](../../auto_examples/release_highlights/plot_release_highlights_1_1_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-1-0-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.23! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_23&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.23</div>
</div>
* [Release Highlights for scikit-learn 0.23](../../auto_examples/release_highlights/plot_release_highlights_0_23_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-23-0-py)

<!-- thumbnail-parent-div-close --></div>
