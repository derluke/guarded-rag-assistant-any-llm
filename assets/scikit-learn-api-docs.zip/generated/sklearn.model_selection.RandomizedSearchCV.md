# RandomizedSearchCV

### *class* sklearn.model_selection.RandomizedSearchCV(estimator, param_distributions, \*, n_iter=10, scoring=None, n_jobs=None, refit=True, cv=None, verbose=0, pre_dispatch='2\*n_jobs', random_state=None, error_score=nan, return_train_score=False)

Randomized search on hyper parameters.

RandomizedSearchCV implements a “fit” and a “score” method.
It also implements “score_samples”, “predict”, “predict_proba”,
“decision_function”, “transform” and “inverse_transform” if they are
implemented in the estimator used.

The parameters of the estimator used to apply these methods are optimized
by cross-validated search over parameter settings.

In contrast to GridSearchCV, not all parameter values are tried out, but
rather a fixed number of parameter settings is sampled from the specified
distributions. The number of parameter settings that are tried is
given by n_iter.

If all parameters are presented as a list,
sampling without replacement is performed. If at least one parameter
is given as a distribution, sampling with replacement is used.
It is highly recommended to use continuous distributions for continuous
parameters.

Read more in the [User Guide](../grid_search.md#randomized-parameter-search).

#### Versionadded
Added in version 0.14.

* **Parameters:**
  **estimator**
  : An object of that type is instantiated for each grid point.
    This is assumed to implement the scikit-learn estimator interface.
    Either estimator needs to provide a `score` function,
    or `scoring` must be passed.

  **param_distributions**
  : Dictionary with parameters names (`str`) as keys and distributions
    or lists of parameters to try. Distributions must provide a `rvs`
    method for sampling (such as those from scipy.stats.distributions).
    If a list is given, it is sampled uniformly.
    If a list of dicts is given, first a dict is sampled uniformly, and
    then a parameter is sampled using that dict as above.

  **n_iter**
  : Number of parameter settings that are sampled. n_iter trades
    off runtime vs quality of the solution.

  **scoring**
  : Strategy to evaluate the performance of the cross-validated model on
    the test set.
    <br/>
    If `scoring` represents a single score, one can use:
    - a single string (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter));
    - a callable (see [Callable scorers](../model_evaluation.md#scoring-callable)) that returns a single value.
    <br/>
    If `scoring` represents multiple scores, one can use:
    - a list or tuple of unique strings;
    - a callable returning a dictionary where the keys are the metric
      names and the values are the metric scores;
    - a dictionary with metric names as keys and callables as values.
    <br/>
    See [Specifying multiple metrics for evaluation](../grid_search.md#multimetric-grid-search) for an example.
    <br/>
    If None, the estimator’s score method is used.

  **n_jobs**
  : Number of jobs to run in parallel.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionchanged
    Changed in version v0.20: `n_jobs` default changed from 1 to None

  **refit**
  : Refit an estimator using the best found parameters on the whole
    dataset.
    <br/>
    For multiple metric evaluation, this needs to be a `str` denoting the
    scorer that would be used to find the best parameters for refitting
    the estimator at the end.
    <br/>
    Where there are considerations other than maximum score in
    choosing a best estimator, `refit` can be set to a function which
    returns the selected `best_index_` given the `cv_results_`. In that
    case, the `best_estimator_` and `best_params_` will be set
    according to the returned `best_index_` while the `best_score_`
    attribute will not be available.
    <br/>
    The refitted estimator is made available at the `best_estimator_`
    attribute and permits using `predict` directly on this
    `RandomizedSearchCV` instance.
    <br/>
    Also for multiple metric evaluation, the attributes `best_index_`,
    `best_score_` and `best_params_` will only be available if
    `refit` is set and all of them will be determined w.r.t this specific
    scorer.
    <br/>
    See `scoring` parameter to know more about multiple metric
    evaluation.
    <br/>
    #### Versionchanged
    Changed in version 0.20: Support for callable added.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross validation,
    - integer, to specify the number of folds in a `(Stratified)KFold`,
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs, if the estimator is a classifier and `y` is
    either binary or multiclass, [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. In all
    other cases, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used. These splitters are instantiated
    with `shuffle=False` so the splits will be the same across calls.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value if None changed from 3-fold to 5-fold.

  **verbose**
  : Controls the verbosity: the higher, the more messages.
    - >1 : the computation time for each fold and parameter candidate is
      displayed;
    - >2 : the score is also displayed;
    - >3 : the fold and candidate parameter indexes are also displayed
      together with the starting time of the computation.

  **pre_dispatch**
  : Controls the number of jobs that get dispatched during parallel
    execution. Reducing this number can be useful to avoid an
    explosion of memory consumption when more jobs get dispatched
    than CPUs can process. This parameter can be:
    - None, in which case all the jobs are immediately created and spawned. Use
      this for lightweight and fast-running jobs, to avoid delays due to on-demand
      spawning of the jobs
    - An int, giving the exact number of total jobs that are spawned
    - A str, giving an expression as a function of n_jobs, as in ‘2\*n_jobs’

  **random_state**
  : Pseudo random number generator state used for random uniform sampling
    from lists of possible values instead of scipy.stats distributions.
    Pass an int for reproducible output across multiple
    function calls.
    See [Glossary](../../glossary.md#term-random_state).

  **error_score**
  : Value to assign to the score if an error occurs in estimator fitting.
    If set to ‘raise’, the error is raised. If a numeric value is given,
    FitFailedWarning is raised. This parameter does not affect the refit
    step, which will always raise the error.

  **return_train_score**
  : If `False`, the `cv_results_` attribute will not include training
    scores.
    Computing training scores is used to get insights on how different
    parameter settings impact the overfitting/underfitting trade-off.
    However computing the scores on the training set can be computationally
    expensive and is not strictly required to select the parameters that
    yield the best generalization performance.
    <br/>
    #### Versionadded
    Added in version 0.19.
    <br/>
    #### Versionchanged
    Changed in version 0.21: Default value was changed from `True` to `False`
* **Attributes:**
  **cv_results_**
  : A dict with keys as column headers and values as columns, that can be
    imported into a pandas `DataFrame`.
    <br/>
    For instance the below given table
    <br/>
    | param_kernel   |   param_gamma |   split0_test_score | …   |   rank_test_score |
    |----------------|---------------|---------------------|-----|-------------------|
    | ‘rbf’          |           0.1 |                0.8  | …   |                 1 |
    | ‘rbf’          |           0.2 |                0.84 | …   |                 3 |
    | ‘rbf’          |           0.3 |                0.7  | …   |                 2 |
    <br/>
    will be represented by a `cv_results_` dict of:
    ```default
    {
    'param_kernel' : masked_array(data = ['rbf', 'rbf', 'rbf'],
                                  mask = False),
    'param_gamma'  : masked_array(data = [0.1 0.2 0.3], mask = False),
    'split0_test_score'  : [0.80, 0.84, 0.70],
    'split1_test_score'  : [0.82, 0.50, 0.70],
    'mean_test_score'    : [0.81, 0.67, 0.70],
    'std_test_score'     : [0.01, 0.24, 0.00],
    'rank_test_score'    : [1, 3, 2],
    'split0_train_score' : [0.80, 0.92, 0.70],
    'split1_train_score' : [0.82, 0.55, 0.70],
    'mean_train_score'   : [0.81, 0.74, 0.70],
    'std_train_score'    : [0.01, 0.19, 0.00],
    'mean_fit_time'      : [0.73, 0.63, 0.43],
    'std_fit_time'       : [0.01, 0.02, 0.01],
    'mean_score_time'    : [0.01, 0.06, 0.04],
    'std_score_time'     : [0.00, 0.00, 0.00],
    'params'             : [{'kernel' : 'rbf', 'gamma' : 0.1}, ...],
    }
    ```
    <br/>
    NOTE
    <br/>
    The key `'params'` is used to store a list of parameter
    settings dicts for all the parameter candidates.
    <br/>
    The `mean_fit_time`, `std_fit_time`, `mean_score_time` and
    `std_score_time` are all in seconds.
    <br/>
    For multi-metric evaluation, the scores for all the scorers are
    available in the `cv_results_` dict at the keys ending with that
    scorer’s name (`'_<scorer_name>'`) instead of `'_score'` shown
    above. (‘split0_test_precision’, ‘mean_train_precision’ etc.)

  **best_estimator_**
  : Estimator that was chosen by the search, i.e. estimator
    which gave highest score (or smallest loss if specified)
    on the left out data. Not available if `refit=False`.
    <br/>
    For multi-metric evaluation, this attribute is present only if
    `refit` is specified.
    <br/>
    See `refit` parameter for more information on allowed values.

  **best_score_**
  : Mean cross-validated score of the best_estimator.
    <br/>
    For multi-metric evaluation, this is not available if `refit` is
    `False`. See `refit` parameter for more information.
    <br/>
    This attribute is not available if `refit` is a function.

  **best_params_**
  : Parameter setting that gave the best results on the hold out data.
    <br/>
    For multi-metric evaluation, this is not available if `refit` is
    `False`. See `refit` parameter for more information.

  **best_index_**
  : The index (of the `cv_results_` arrays) which corresponds to the best
    candidate parameter setting.
    <br/>
    The dict at `search.cv_results_['params'][search.best_index_]` gives
    the parameter setting for the best model, that gives the highest
    mean score (`search.best_score_`).
    <br/>
    For multi-metric evaluation, this is not available if `refit` is
    `False`. See `refit` parameter for more information.

  **scorer_**
  : Scorer function used on the held out data to choose the best
    parameters for the model.
    <br/>
    For multi-metric evaluation, this attribute holds the validated
    `scoring` dict which maps the scorer key to the scorer callable.

  **n_splits_**
  : The number of cross-validation splits (folds/iterations).

  **refit_time_**
  : Seconds used for refitting the best model on the whole dataset.
    <br/>
    This is present only if `refit` is not False.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **multimetric_**
  : Whether or not the scorers compute several metrics.

  [`classes_`](#sklearn.model_selection.RandomizedSearchCV.classes_)
  : Class labels.

  [`n_features_in_`](#sklearn.model_selection.RandomizedSearchCV.n_features_in_)
  : Number of features seen during [fit](../../glossary.md#term-fit).

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Only defined if
    `best_estimator_` is defined (see the documentation for the `refit`
    parameter for more details) and that `best_estimator_` exposes
    `feature_names_in_` when fit.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`GridSearchCV`](sklearn.model_selection.GridSearchCV.md#sklearn.model_selection.GridSearchCV)
: Does exhaustive search over a grid of parameters.

[`ParameterSampler`](sklearn.model_selection.ParameterSampler.md#sklearn.model_selection.ParameterSampler)
: A generator over parameter settings, constructed from param_distributions.

### Notes

The parameters selected are those that maximize the score of the held-out
data, according to the scoring parameter.

If `n_jobs` was set to a value higher than one, the data is copied for each
parameter setting(and not `n_jobs` times). This is done for efficiency
reasons if individual jobs take very little time, but may raise errors if
the dataset is large and not enough memory is available.  A workaround in
this case is to set `pre_dispatch`. Then, the memory is copied only
`pre_dispatch` many times. A reasonable value for `pre_dispatch` is `2 *
n_jobs`.

### Examples

```pycon
>>> from sklearn.datasets import load_iris
>>> from sklearn.linear_model import LogisticRegression
>>> from sklearn.model_selection import RandomizedSearchCV
>>> from scipy.stats import uniform
>>> iris = load_iris()
>>> logistic = LogisticRegression(solver='saga', tol=1e-2, max_iter=200,
...                               random_state=0)
>>> distributions = dict(C=uniform(loc=0, scale=4),
...                      penalty=['l2', 'l1'])
>>> clf = RandomizedSearchCV(logistic, distributions, random_state=0)
>>> search = clf.fit(iris.data, iris.target)
>>> search.best_params_
{'C': np.float64(2...), 'penalty': 'l1'}
```

<!-- !! processed by numpydoc !! -->

#### *property* classes_

Class labels.

Only available when `refit=True` and the estimator is a classifier.

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Call decision_function on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`decision_function`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_score**
  : Result of the decision function for `X` based on the estimator with
    the best found parameters.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, \*\*params)

Run fit with all sets of parameters.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of features. For precomputed kernel or
    distance matrix, the expected shape of X is (n_samples, n_samples).

  **y**
  : Target relative to X for classification or regression;
    None for unsupervised learning.

  **\*\*params**
  : Parameters passed to the `fit` method of the estimator, the scorer,
    and the CV splitter.
    <br/>
    If a fit parameter is an array-like whose length is equal to
    `num_samples` then it will be split by cross-validation along with
    `X` and `y`. For example, the [sample_weight](../../glossary.md#term-sample_weight) parameter is
    split because `len(sample_weights) = len(X)`. However, this behavior
    does not apply to `groups` which is passed to the splitter configured
    via the `cv` parameter of the constructor. Thus, `groups` is used
    *to perform the split* and determines which samples are
    assigned to the each side of the a split.
* **Returns:**
  **self**
  : Instance of fitted estimator.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.4.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X=None, Xt=None)

Call inverse_transform on the estimator with the best found params.

Only available if the underlying estimator implements
`inverse_transform` and `refit=True`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.

  **Xt**
  : Must fulfill the input assumptions of the
    underlying estimator.
    <br/>
    #### Deprecated
    Deprecated since version 1.5: `Xt` was deprecated in 1.5 and will be removed in 1.7. Use `X` instead.
* **Returns:**
  **X**
  : Result of the `inverse_transform` function for `Xt` based on the
    estimator with the best found parameters.

<!-- !! processed by numpydoc !! -->

#### *property* n_features_in_

Number of features seen during [fit](../../glossary.md#term-fit).

Only available when `refit=True`.

<!-- !! processed by numpydoc !! -->

#### predict(X)

Call predict on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`predict`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_pred**
  : The predicted labels or values for `X` based on the estimator with
    the best found parameters.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Call predict_log_proba on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`predict_log_proba`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_pred**
  : Predicted class log-probabilities for `X` based on the estimator
    with the best found parameters. The order of the classes
    corresponds to that in the fitted attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Call predict_proba on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`predict_proba`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **y_pred**
  : Predicted class probabilities for `X` based on the estimator with
    the best found parameters. The order of the classes corresponds
    to that in the fitted attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y=None, \*\*params)

Return the score on the given data, if the estimator has been refit.

This uses the score defined by `scoring` where provided, and the
`best_estimator_.score` method otherwise.

* **Parameters:**
  **X**
  : Input data, where `n_samples` is the number of samples and
    `n_features` is the number of features.

  **y**
  : Target relative to X for classification or regression;
    None for unsupervised learning.

  **\*\*params**
  : Parameters to be passed to the underlying scorer(s).
    <br/>
    #### Versionadded
    Added in version 1.4: Only available if `enable_metadata_routing=True`. See
    [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for more
    details.
* **Returns:**
  **score**
  : The score defined by `scoring` if provided, and the
    `best_estimator_.score` method otherwise.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Call score_samples on the estimator with the best found parameters.

Only available if `refit=True` and the underlying estimator supports
`score_samples`.

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **X**
  : Data to predict on. Must fulfill input requirements
    of the underlying estimator.
* **Returns:**
  **y_score**
  : The `best_estimator_.score_samples` method.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Call transform on the estimator with the best found parameters.

Only available if the underlying estimator supports `transform` and
`refit=True`.

* **Parameters:**
  **X**
  : Must fulfill the input assumptions of the
    underlying estimator.
* **Returns:**
  **Xt**
  : `X` transformed in the new space based on the estimator with
    the best found parameters.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is a preprocessed excerpt of the &quot;Labeled Faces in the Wild&quot;, aka LFW_: http://vis-www.cs.umass.edu/lfw/lfw-funneled.tgz (233MB)">  <div class="sphx-glr-thumbnail-title">Faces recognition example using eigenfaces and SVMs</div>
</div>
* [Faces recognition example using eigenfaces and SVMs](../../auto_examples/applications/plot_face_recognition.md#sphx-glr-auto-examples-applications-plot-face-recognition-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates how to apply different preprocessing and feature extraction pipelines to different subsets of features, using ColumnTransformer. This is particularly handy for the case of datasets that contain heterogeneous data types, since we may want to scale the numeric features and one-hot encode the categorical ones.">  <div class="sphx-glr-thumbnail-title">Column Transformer with Mixed Types</div>
</div>
* [Column Transformer with Mixed Types](../../auto_examples/compose/plot_column_transformer_mixed_types.md#sphx-glr-auto-examples-compose-plot-column-transformer-mixed-types-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example illustrates differences between a kernel ridge regression and a Gaussian process regression.">  <div class="sphx-glr-thumbnail-title">Comparison of kernel ridge and Gaussian process regression</div>
</div>
* [Comparison of kernel ridge and Gaussian process regression](../../auto_examples/gaussian_process/plot_compare_gpr_krr.md#sphx-glr-auto-examples-gaussian-process-plot-compare-gpr-krr-py)

<div class="sphx-glr-thumbcontainer" tooltip="Compare randomized search and grid search for optimizing hyperparameters of a linear SVM with SGD training. All parameters that influence the learning are searched simultaneously (except for the number of estimators, which poses a time / quality tradeoff).">  <div class="sphx-glr-thumbnail-title">Comparing randomized search and grid search for hyperparameter estimation</div>
</div>
* [Comparing randomized search and grid search for hyperparameter estimation](../../auto_examples/model_selection/plot_randomized_search.md#sphx-glr-auto-examples-model-selection-plot-randomized-search-py)

<div class="sphx-glr-thumbcontainer" tooltip="The dataset used in this example is 20newsgroups_dataset which will be automatically downloaded, cached and reused for the document classification example.">  <div class="sphx-glr-thumbnail-title">Sample pipeline for text feature extraction and evaluation</div>
</div>
* [Sample pipeline for text feature extraction and evaluation](../../auto_examples/model_selection/plot_grid_search_text_feature_extraction.md#sphx-glr-auto-examples-model-selection-plot-grid-search-text-feature-extraction-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
