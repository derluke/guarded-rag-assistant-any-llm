# polynomial_kernel

### sklearn.metrics.pairwise.polynomial_kernel(X, Y=None, degree=3, gamma=None, coef0=1)

Compute the polynomial kernel between X and Y.

```text
K(X, Y) = (gamma <X, Y> + coef0) ^ degree
```

Read more in the [User Guide](../metrics.md#polynomial-kernel).

* **Parameters:**
  **X**
  : A feature array.

  **Y**
  : An optional second feature array. If `None`, uses `Y=X`.

  **degree**
  : Kernel degree.

  **gamma**
  : Coefficient of the vector inner product. If None, defaults to 1.0 / n_features.

  **coef0**
  : Constant offset added to scaled inner product.
* **Returns:**
  **kernel**
  : The polynomial kernel.

### Examples

```pycon
>>> from sklearn.metrics.pairwise import polynomial_kernel
>>> X = [[0, 0, 0], [1, 1, 1]]
>>> Y = [[1, 0, 0], [1, 1, 0]]
>>> polynomial_kernel(X, Y, degree=2)
array([[1.     , 1.     ],
       [1.77..., 2.77...]])
```

<!-- !! processed by numpydoc !! -->
