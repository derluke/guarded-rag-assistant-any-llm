# RBFSampler

### *class* sklearn.kernel_approximation.RBFSampler(\*, gamma=1.0, n_components=100, random_state=None)

Approximate a RBF kernel feature map using random Fourier features.

It implements a variant of Random Kitchen Sinks.[1]

Read more in the [User Guide](../kernel_approximation.md#rbf-kernel-approx).

* **Parameters:**
  **gamma**
  : Parameter of RBF kernel: exp(-gamma \* x^2).
    If `gamma='scale'` is passed then it uses
    1 / (n_features \* X.var()) as value of gamma.
    <br/>
    #### Versionadded
    Added in version 1.2: The option `"scale"` was added in 1.2.

  **n_components**
  : Number of Monte Carlo samples per original feature.
    Equals the dimensionality of the computed feature space.

  **random_state**
  : Pseudo-random number generator to control the generation of the random
    weights and random offset when fitting the training data.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
* **Attributes:**
  **random_offset_**
  : Random offset used to compute the projection in the `n_components`
    dimensions of the feature space.

  **random_weights_**
  : Random projection directions drawn from the Fourier transform
    of the RBF kernel.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`AdditiveChi2Sampler`](sklearn.kernel_approximation.AdditiveChi2Sampler.md#sklearn.kernel_approximation.AdditiveChi2Sampler)
: Approximate feature map for additive chi2 kernel.

[`Nystroem`](sklearn.kernel_approximation.Nystroem.md#sklearn.kernel_approximation.Nystroem)
: Approximate a kernel map using a subset of the training data.

[`PolynomialCountSketch`](sklearn.kernel_approximation.PolynomialCountSketch.md#sklearn.kernel_approximation.PolynomialCountSketch)
: Polynomial kernel approximation via Tensor Sketch.

[`SkewedChi2Sampler`](sklearn.kernel_approximation.SkewedChi2Sampler.md#sklearn.kernel_approximation.SkewedChi2Sampler)
: Approximate feature map for “skewed chi-squared” kernel.

[`sklearn.metrics.pairwise.kernel_metrics`](sklearn.metrics.pairwise.kernel_metrics.md#sklearn.metrics.pairwise.kernel_metrics)
: List of built-in kernels.

### Notes

See “Random Features for Large-Scale Kernel Machines” by A. Rahimi and
Benjamin Recht.

[1] “Weighted Sums of Random Kitchen Sinks: Replacing
minimization with randomization in learning” by A. Rahimi and
Benjamin Recht.
([https://people.eecs.berkeley.edu/~brecht/papers/08.rah.rec.nips.pdf](https://people.eecs.berkeley.edu/~brecht/papers/08.rah.rec.nips.pdf))

### Examples

```pycon
>>> from sklearn.kernel_approximation import RBFSampler
>>> from sklearn.linear_model import SGDClassifier
>>> X = [[0, 0], [1, 1], [1, 0], [0, 1]]
>>> y = [0, 0, 1, 1]
>>> rbf_feature = RBFSampler(gamma=1, random_state=1)
>>> X_features = rbf_feature.fit_transform(X)
>>> clf = SGDClassifier(max_iter=5, tol=1e-3)
>>> clf.fit(X_features, y)
SGDClassifier(max_iter=5)
>>> clf.score(X_features, y)
1.0
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the model with X.

Samples random projection according to n_features.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Target values (None for unsupervised transformations).
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Get output feature names for transformation.

The feature names out will prefixed by the lowercased class name. For
example, if the transformer outputs 3 features, then the feature names
out are: `["class_name0", "class_name1", "class_name2"]`.

* **Parameters:**
  **input_features**
  : Only used to validate feature names with the names seen in `fit`.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Apply the approximate feature map to X.

* **Parameters:**
  **X**
  : New data, where `n_samples` is the number of samples
    and `n_features` is the number of features.
* **Returns:**
  **X_new**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="An example illustrating the approximation of the feature map of an RBF kernel.">  <div class="sphx-glr-thumbnail-title">Explicit feature map approximation for RBF kernels</div>
</div>
* [Explicit feature map approximation for RBF kernels](../../auto_examples/miscellaneous/plot_kernel_approximation.md#sphx-glr-auto-examples-miscellaneous-plot-kernel-approximation-py)

<!-- thumbnail-parent-div-close --></div>
