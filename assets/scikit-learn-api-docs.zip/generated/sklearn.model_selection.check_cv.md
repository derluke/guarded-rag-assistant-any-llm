# check_cv

### sklearn.model_selection.check_cv(cv=5, y=None, \*, classifier=False)

Input checker utility for building a cross-validator.

* **Parameters:**
  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross validation,
    - integer, to specify the number of folds.
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable that generates (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs, if classifier is True and `y` is either
    binary or multiclass, [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. In all other
    cases, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value changed from 3-fold to 5-fold.

  **y**
  : The target variable for supervised learning problems.

  **classifier**
  : Whether the task is a classification task, in which case
    stratified KFold will be used.
* **Returns:**
  **checked_cv**
  : The return value is a cross-validator which generates the train/test
    splits via the `split` method.

### Examples

```pycon
>>> from sklearn.model_selection import check_cv
>>> check_cv(cv=5, y=None, classifier=False)
KFold(...)
>>> check_cv(cv=5, y=[1, 1, 0, 0, 0, 0], classifier=True)
StratifiedKFold(...)
```

<!-- !! processed by numpydoc !! -->
