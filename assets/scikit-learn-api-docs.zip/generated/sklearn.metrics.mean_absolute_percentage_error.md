# mean_absolute_percentage_error

### sklearn.metrics.mean_absolute_percentage_error(y_true, y_pred, \*, sample_weight=None, multioutput='uniform_average')

Mean absolute percentage error (MAPE) regression loss.

Note that we are not using the common “percentage” definition: the percentage
in the range [0, 100] is converted to a relative value in the range [0, 1]
by dividing by 100. Thus, an error of 200% corresponds to a relative error of 2.

Read more in the [User Guide](../model_evaluation.md#mean-absolute-percentage-error).

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **y_true**
  : Ground truth (correct) target values.

  **y_pred**
  : Estimated target values.

  **sample_weight**
  : Sample weights.

  **multioutput**
  : Defines aggregating of multiple output values.
    Array-like value defines weights used to average errors.
    If input is list then the shape must be (n_outputs,).
    <br/>
    ‘raw_values’ :
    : Returns a full set of errors in case of multioutput input.
    <br/>
    ‘uniform_average’ :
    : Errors of all outputs are averaged with uniform weight.
* **Returns:**
  **loss**
  : If multioutput is ‘raw_values’, then mean absolute percentage error
    is returned for each output separately.
    If multioutput is ‘uniform_average’ or an ndarray of weights, then the
    weighted average of all output errors is returned.
    <br/>
    MAPE output is non-negative floating point. The best value is 0.0.
    But note that bad predictions can lead to arbitrarily large
    MAPE values, especially if some `y_true` values are very close to zero.
    Note that we return a large value instead of `inf` when `y_true` is zero.

### Examples

```pycon
>>> from sklearn.metrics import mean_absolute_percentage_error
>>> y_true = [3, -0.5, 2, 7]
>>> y_pred = [2.5, 0.0, 2, 8]
>>> mean_absolute_percentage_error(y_true, y_pred)
0.3273...
>>> y_true = [[0.5, 1], [-1, 1], [7, -6]]
>>> y_pred = [[0, 2], [-1, 2], [8, -5]]
>>> mean_absolute_percentage_error(y_true, y_pred)
0.5515...
>>> mean_absolute_percentage_error(y_true, y_pred, multioutput=[0.3, 0.7])
0.6198...
>>> # the value when some element of the y_true is zero is arbitrarily high because
>>> # of the division by epsilon
>>> y_true = [1., 0., 2.4, 7.]
>>> y_pred = [1.2, 0.1, 2.4, 8.]
>>> mean_absolute_percentage_error(y_true, y_pred)
112589990684262.48
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Polars-engineered lagged features can be used for time series forecasting with HistGradientBoostingRegressor on the Bike Sharing Demand dataset.">  <div class="sphx-glr-thumbnail-title">Lagged features for time series forecasting</div>
</div>
* [Lagged features for time series forecasting](../../auto_examples/applications/plot_time_series_lagged_features.md#sphx-glr-auto-examples-applications-plot-time-series-lagged-features-py)

<!-- thumbnail-parent-div-close --></div>
