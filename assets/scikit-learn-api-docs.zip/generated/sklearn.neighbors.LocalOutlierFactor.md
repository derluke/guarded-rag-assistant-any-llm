# LocalOutlierFactor

### *class* sklearn.neighbors.LocalOutlierFactor(n_neighbors=20, \*, algorithm='auto', leaf_size=30, metric='minkowski', p=2, metric_params=None, contamination='auto', novelty=False, n_jobs=None)

Unsupervised Outlier Detection using the Local Outlier Factor (LOF).

The anomaly score of each sample is called the Local Outlier Factor.
It measures the local deviation of the density of a given sample with respect
to its neighbors.
It is local in that the anomaly score depends on how isolated the object
is with respect to the surrounding neighborhood.
More precisely, locality is given by k-nearest neighbors, whose distance
is used to estimate the local density.
By comparing the local density of a sample to the local densities of its
neighbors, one can identify samples that have a substantially lower density
than their neighbors. These are considered outliers.

#### Versionadded
Added in version 0.19.

* **Parameters:**
  **n_neighbors**
  : Number of neighbors to use by default for [`kneighbors`](#sklearn.neighbors.LocalOutlierFactor.kneighbors) queries.
    If n_neighbors is larger than the number of samples provided,
    all samples will be used.

  **algorithm**
  : Algorithm used to compute the nearest neighbors:
    - ‘ball_tree’ will use [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree)
    - ‘kd_tree’ will use [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree)
    - ‘brute’ will use a brute-force search.
    - ‘auto’ will attempt to decide the most appropriate algorithm
      based on the values passed to [`fit`](#sklearn.neighbors.LocalOutlierFactor.fit) method.
    <br/>
    Note: fitting on sparse input will override the setting of
    this parameter, using brute force.

  **leaf_size**
  : Leaf is size passed to [`BallTree`](sklearn.neighbors.BallTree.md#sklearn.neighbors.BallTree) or [`KDTree`](sklearn.neighbors.KDTree.md#sklearn.neighbors.KDTree). This can
    affect the speed of the construction and query, as well as the memory
    required to store the tree. The optimal value depends on the
    nature of the problem.

  **metric**
  : Metric to use for distance computation. Default is “minkowski”, which
    results in the standard Euclidean distance when p = 2. See the
    documentation of [scipy.spatial.distance](https://docs.scipy.org/doc/scipy/reference/spatial.distance.html) and
    the metrics listed in
    [`distance_metrics`](sklearn.metrics.pairwise.distance_metrics.md#sklearn.metrics.pairwise.distance_metrics) for valid metric
    values.
    <br/>
    If metric is “precomputed”, X is assumed to be a distance matrix and
    must be square during fit. X may be a [sparse graph](../../glossary.md#term-sparse-graph), in which
    case only “nonzero” elements may be considered neighbors.
    <br/>
    If metric is a callable function, it takes two arrays representing 1D
    vectors as inputs and must return one value indicating the distance
    between those vectors. This works for Scipy’s metrics, but is less
    efficient than passing the metric name as a string.

  **p**
  : Parameter for the Minkowski metric from
    [`sklearn.metrics.pairwise_distances`](sklearn.metrics.pairwise_distances.md#sklearn.metrics.pairwise_distances). When p = 1, this
    is equivalent to using manhattan_distance (l1), and euclidean_distance
    (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.

  **metric_params**
  : Additional keyword arguments for the metric function.

  **contamination**
  : The amount of contamination of the data set, i.e. the proportion
    of outliers in the data set. When fitting this is used to define the
    threshold on the scores of the samples.
    - if ‘auto’, the threshold is determined as in the
      original paper,
    - if a float, the contamination should be in the range (0, 0.5].
    <br/>
    #### Versionchanged
    Changed in version 0.22: The default value of `contamination` changed from 0.1
    to `'auto'`.

  **novelty**
  : By default, LocalOutlierFactor is only meant to be used for outlier
    detection (novelty=False). Set novelty to True if you want to use
    LocalOutlierFactor for novelty detection. In this case be aware that
    you should only use predict, decision_function and score_samples
    on new unseen data and not on the training set; and note that the
    results obtained this way may differ from the standard LOF results.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **n_jobs**
  : The number of parallel jobs to run for neighbors search.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **negative_outlier_factor_**
  : The opposite LOF of the training samples. The higher, the more normal.
    Inliers tend to have a LOF score close to 1
    (`negative_outlier_factor_` close to -1), while outliers tend to have
    a larger LOF score.
    <br/>
    The local outlier factor (LOF) of a sample captures its
    supposed ‘degree of abnormality’.
    It is the average of the ratio of the local reachability density of
    a sample and those of its k-nearest neighbors.

  **n_neighbors_**
  : The actual number of neighbors used for [`kneighbors`](#sklearn.neighbors.LocalOutlierFactor.kneighbors) queries.

  **offset_**
  : Offset used to obtain binary labels from the raw scores.
    Observations having a negative_outlier_factor smaller than `offset_`
    are detected as abnormal.
    The offset is set to -1.5 (inliers score around -1), except when a
    contamination parameter different than “auto” is provided. In that
    case, the offset is defined in such a way we obtain the expected
    number of outliers in training.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **effective_metric_**
  : The effective metric used for the distance computation.

  **effective_metric_params_**
  : The effective additional keyword arguments for the metric function.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_samples_fit_**
  : It is the number of samples in the fitted data.

#### SEE ALSO
[`sklearn.svm.OneClassSVM`](sklearn.svm.OneClassSVM.md#sklearn.svm.OneClassSVM)
: Unsupervised Outlier Detection using Support Vector Machine.

### References

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.neighbors import LocalOutlierFactor
>>> X = [[-1.1], [0.2], [101.1], [0.3]]
>>> clf = LocalOutlierFactor(n_neighbors=2)
>>> clf.fit_predict(X)
array([ 1,  1, -1,  1])
>>> clf.negative_outlier_factor_
array([ -0.9821...,  -1.0370..., -73.3697...,  -0.9821...])
```

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Shifted opposite of the Local Outlier Factor of X.

Bigger is better, i.e. large values correspond to inliers.

**Only available for novelty detection (when novelty is set to True).**
The shift offset allows a zero threshold for being an outlier.
The argument X is supposed to contain *new data*: if X contains a
point from training, it considers the later in its own neighborhood.
Also, the samples in X are not considered in the neighborhood of any
point.

* **Parameters:**
  **X**
  : The query sample or samples to compute the Local Outlier Factor
    w.r.t. the training samples.
* **Returns:**
  **shifted_opposite_lof_scores**
  : The shifted opposite of the Local Outlier Factor of each input
    samples. The lower, the more abnormal. Negative scores represent
    outliers, positive scores represent inliers.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the local outlier factor detector from the training dataset.

* **Parameters:**
  **X**
  : Training data.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : The fitted local outlier factor detector.

<!-- !! processed by numpydoc !! -->

#### fit_predict(X, y=None)

Fit the model to the training set X and return the labels.

**Not available for novelty detection (when novelty is set to True).**
Label is 1 for an inlier and -1 for an outlier according to the LOF
score and the contamination parameter.

* **Parameters:**
  **X**
  : The query sample or samples to compute the Local Outlier Factor
    w.r.t. the training samples.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **is_inlier**
  : Returns -1 for anomalies/outliers and 1 for inliers.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### kneighbors(X=None, n_neighbors=None, return_distance=True)

Find the K-neighbors of a point.

Returns indices of and distances to the neighbors of each point.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.

  **n_neighbors**
  : Number of neighbors required for each sample. The default is the
    value passed to the constructor.

  **return_distance**
  : Whether or not to return the distances.
* **Returns:**
  **neigh_dist**
  : Array representing the lengths to points, only present if
    return_distance=True.

  **neigh_ind**
  : Indices of the nearest points in the population matrix.

### Examples

In the following example, we construct a NearestNeighbors
class from an array representing our data set and ask who’s
the closest point to [1,1,1]

```pycon
>>> samples = [[0., 0., 0.], [0., .5, 0.], [1., 1., .5]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(n_neighbors=1)
>>> neigh.fit(samples)
NearestNeighbors(n_neighbors=1)
>>> print(neigh.kneighbors([[1., 1., 1.]]))
(array([[0.5]]), array([[2]]))
```

As you can see, it returns [[0.5]], and [[2]], which means that the
element is at distance 0.5 and is the third element of samples
(indexes start at 0). You can also query for multiple points:

```pycon
>>> X = [[0., 1., 0.], [1., 0., 1.]]
>>> neigh.kneighbors(X, return_distance=False)
array([[1],
       [2]]...)
```

<!-- !! processed by numpydoc !! -->

#### kneighbors_graph(X=None, n_neighbors=None, mode='connectivity')

Compute the (weighted) graph of k-Neighbors for points in X.

* **Parameters:**
  **X**
  : The query point or points.
    If not provided, neighbors of each indexed point are returned.
    In this case, the query point is not considered its own neighbor.
    For `metric='precomputed'` the shape should be
    (n_queries, n_indexed). Otherwise the shape should be
    (n_queries, n_features).

  **n_neighbors**
  : Number of neighbors for each sample. The default is the value
    passed to the constructor.

  **mode**
  : Type of returned matrix: ‘connectivity’ will return the
    connectivity matrix with ones and zeros, in ‘distance’ the
    edges are distances between points, type of distance
    depends on the selected metric parameter in
    NearestNeighbors class.
* **Returns:**
  **A**
  : `n_samples_fit` is the number of samples in the fitted data.
    `A[i, j]` gives the weight of the edge connecting `i` to `j`.
    The matrix is of CSR format.

#### SEE ALSO
[`NearestNeighbors.radius_neighbors_graph`](sklearn.neighbors.NearestNeighbors.md#sklearn.neighbors.NearestNeighbors.radius_neighbors_graph)
: Compute the (weighted) graph of Neighbors for points in X.

### Examples

```pycon
>>> X = [[0], [3], [1]]
>>> from sklearn.neighbors import NearestNeighbors
>>> neigh = NearestNeighbors(n_neighbors=2)
>>> neigh.fit(X)
NearestNeighbors(n_neighbors=2)
>>> A = neigh.kneighbors_graph(X)
>>> A.toarray()
array([[1., 0., 1.],
       [0., 1., 1.],
       [1., 0., 1.]])
```

<!-- !! processed by numpydoc !! -->

#### predict(X=None)

Predict the labels (1 inlier, -1 outlier) of X according to LOF.

**Only available for novelty detection (when novelty is set to True).**
This method allows to generalize prediction to *new observations* (not
in the training set). Note that the result of `clf.fit(X)` then
`clf.predict(X)` with `novelty=True` may differ from the result
obtained by `clf.fit_predict(X)` with `novelty=False`.

* **Parameters:**
  **X**
  : The query sample or samples to compute the Local Outlier Factor
    w.r.t. the training samples.
* **Returns:**
  **is_inlier**
  : Returns -1 for anomalies/outliers and +1 for inliers.

<!-- !! processed by numpydoc !! -->

#### score_samples(X)

Opposite of the Local Outlier Factor of X.

It is the opposite as bigger is better, i.e. large values correspond
to inliers.

**Only available for novelty detection (when novelty is set to True).**
The argument X is supposed to contain *new data*: if X contains a
point from training, it considers the later in its own neighborhood.
Also, the samples in X are not considered in the neighborhood of any
point. Because of this, the scores obtained via `score_samples` may
differ from the standard LOF scores.
The standard LOF scores for the training data is available via the
`negative_outlier_factor_` attribute.

* **Parameters:**
  **X**
  : The query sample or samples to compute the Local Outlier Factor
    w.r.t. the training samples.
* **Returns:**
  **opposite_lof_scores**
  : The opposite of the Local Outlier Factor of each input samples.
    The lower, the more abnormal.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example shows characteristics of different anomaly detection algorithms on 2D datasets. Datasets contain one or two modes (regions of high density) to illustrate the ability of algorithms to cope with multimodal data.">  <div class="sphx-glr-thumbnail-title">Comparing anomaly detection algorithms for outlier detection on toy datasets</div>
</div>
* [Comparing anomaly detection algorithms for outlier detection on toy datasets](../../auto_examples/miscellaneous/plot_anomaly_comparison.md#sphx-glr-auto-examples-miscellaneous-plot-anomaly-comparison-py)

<div class="sphx-glr-thumbcontainer" tooltip="This example compares two outlier detection algorithms, namely local_outlier_factor (LOF) and isolation_forest (IForest), on real-world datasets available in sklearn.datasets. The goal is to show that different algorithms perform well on different datasets and contrast their training speed and sensitivity to hyperparameters.">  <div class="sphx-glr-thumbnail-title">Evaluation of outlier detection estimators</div>
</div>
* [Evaluation of outlier detection estimators](../../auto_examples/miscellaneous/plot_outlier_detection_bench.md#sphx-glr-auto-examples-miscellaneous-plot-outlier-detection-bench-py)

<div class="sphx-glr-thumbcontainer" tooltip="The Local Outlier Factor (LOF) algorithm is an unsupervised anomaly detection method which computes the local density deviation of a given data point with respect to its neighbors. It considers as outliers the samples that have a substantially lower density than their neighbors. This example shows how to use LOF for novelty detection. Note that when LOF is used for novelty detection you MUST not use predict, decision_function and score_samples on the training set as this would lead to wrong results. You must only use these methods on new unseen data (which are not in the training set). See User Guide &lt;outlier_detection&gt;: for details on the difference between outlier detection and novelty detection and how to use LOF for outlier detection.">  <div class="sphx-glr-thumbnail-title">Novelty detection with Local Outlier Factor (LOF)</div>
</div>
* [Novelty detection with Local Outlier Factor (LOF)](../../auto_examples/neighbors/plot_lof_novelty_detection.md#sphx-glr-auto-examples-neighbors-plot-lof-novelty-detection-py)

<div class="sphx-glr-thumbcontainer" tooltip="The Local Outlier Factor (LOF) algorithm is an unsupervised anomaly detection method which computes the local density deviation of a given data point with respect to its neighbors. It considers as outliers the samples that have a substantially lower density than their neighbors. This example shows how to use LOF for outlier detection which is the default use case of this estimator in scikit-learn. Note that when LOF is used for outlier detection it has no predict, decision_function and score_samples methods. See the User Guide &lt;outlier_detection&gt; for details on the difference between outlier detection and novelty detection and how to use LOF for novelty detection.">  <div class="sphx-glr-thumbnail-title">Outlier detection with Local Outlier Factor (LOF)</div>
</div>
* [Outlier detection with Local Outlier Factor (LOF)](../../auto_examples/neighbors/plot_lof_outlier_detection.md#sphx-glr-auto-examples-neighbors-plot-lof-outlier-detection-py)

<!-- thumbnail-parent-div-close --></div>
