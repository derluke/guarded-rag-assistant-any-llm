# RFE

### *class* sklearn.feature_selection.RFE(estimator, \*, n_features_to_select=None, step=1, verbose=0, importance_getter='auto')

Feature ranking with recursive feature elimination.

Given an external estimator that assigns weights to features (e.g., the
coefficients of a linear model), the goal of recursive feature elimination
(RFE) is to select features by recursively considering smaller and smaller
sets of features. First, the estimator is trained on the initial set of
features and the importance of each feature is obtained either through
any specific attribute or callable.
Then, the least important features are pruned from current set of features.
That procedure is recursively repeated on the pruned set until the desired
number of features to select is eventually reached.

Read more in the [User Guide](../feature_selection.md#rfe).

* **Parameters:**
  **estimator**
  : A supervised learning estimator with a `fit` method that provides
    information about feature importance
    (e.g. `coef_`, `feature_importances_`).

  **n_features_to_select**
  : The number of features to select. If `None`, half of the features are
    selected. If integer, the parameter is the absolute number of features
    to select. If float between 0 and 1, it is the fraction of features to
    select.
    <br/>
    #### Versionchanged
    Changed in version 0.24: Added float values for fractions.

  **step**
  : If greater than or equal to 1, then `step` corresponds to the
    (integer) number of features to remove at each iteration.
    If within (0.0, 1.0), then `step` corresponds to the percentage
    (rounded down) of features to remove at each iteration.

  **verbose**
  : Controls verbosity of output.

  **importance_getter**
  : If ‘auto’, uses the feature importance either through a `coef_`
    or `feature_importances_` attributes of estimator.
    <br/>
    Also accepts a string that specifies an attribute name/path
    for extracting feature importance (implemented with `attrgetter`).
    For example, give `regressor_.coef_` in case of
    [`TransformedTargetRegressor`](sklearn.compose.TransformedTargetRegressor.md#sklearn.compose.TransformedTargetRegressor)  or
    `named_steps.clf.feature_importances_` in case of
    class:`~sklearn.pipeline.Pipeline` with its last step named `clf`.
    <br/>
    If `callable`, overrides the default feature importance getter.
    The callable is passed with the fitted estimator and it should
    return importance for each feature.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  [`classes_`](#sklearn.feature_selection.RFE.classes_)
  : Classes labels available when `estimator` is a classifier.

  **estimator_**
  : The fitted estimator used to select features.

  **n_features_**
  : The number of selected features.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **ranking_**
  : The feature ranking, such that `ranking_[i]` corresponds to the
    ranking position of the i-th feature. Selected (i.e., estimated
    best) features are assigned rank 1.

  **support_**
  : The mask of selected features.

#### SEE ALSO
[`RFECV`](sklearn.feature_selection.RFECV.md#sklearn.feature_selection.RFECV)
: Recursive feature elimination with built-in cross-validated selection of the best number of features.

[`SelectFromModel`](sklearn.feature_selection.SelectFromModel.md#sklearn.feature_selection.SelectFromModel)
: Feature selection based on thresholds of importance weights.

[`SequentialFeatureSelector`](sklearn.feature_selection.SequentialFeatureSelector.md#sklearn.feature_selection.SequentialFeatureSelector)
: Sequential cross-validation based feature selection. Does not rely on importance weights.

### Notes

Allows NaN/Inf in the input if the underlying estimator does as well.

### References

### Examples

The following example shows how to retrieve the 5 most informative
features in the Friedman #1 dataset.

```pycon
>>> from sklearn.datasets import make_friedman1
>>> from sklearn.feature_selection import RFE
>>> from sklearn.svm import SVR
>>> X, y = make_friedman1(n_samples=50, n_features=10, random_state=0)
>>> estimator = SVR(kernel="linear")
>>> selector = RFE(estimator, n_features_to_select=5, step=1)
>>> selector = selector.fit(X, y)
>>> selector.support_
array([ True,  True,  True,  True,  True, False, False, False, False,
       False])
>>> selector.ranking_
array([1, 1, 1, 1, 1, 6, 4, 3, 2, 5])
```

<!-- !! processed by numpydoc !! -->

#### *property* classes_

Classes labels available when `estimator` is a classifier.

* **Returns:**
  ndarray of shape (n_classes,)

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Compute the decision function of `X`.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **score**
  : The decision function of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).
    Regression and binary classification produce an array of shape
    [n_samples].

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*\*fit_params)

Fit the RFE model and then the underlying estimator on the selected features.

* **Parameters:**
  **X**
  : The training input samples.

  **y**
  : The target values.

  **\*\*fit_params**
  : - If `enable_metadata_routing=False` (default): Parameters directly passed
      to the `fit` method of the underlying estimator.
    - If `enable_metadata_routing=True`: Parameters safely routed to the `fit`
      method of the underlying estimator.
    <br/>
    #### Versionchanged
    Changed in version 1.6: See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing)
    for more details.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Mask feature names according to selected features.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.6.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_support(indices=False)

Get a mask, or integer index, of the features selected.

* **Parameters:**
  **indices**
  : If True, the return value will be an array of integers, rather
    than a boolean mask.
* **Returns:**
  **support**
  : An index that selects the retained features from a feature vector.
    If `indices` is False, this is a boolean array of shape
    [# input features], in which an element is True iff its
    corresponding feature is selected for retention. If `indices` is
    True, this is an integer array of shape [# output features] whose
    values are indices into the input feature vector.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Reverse the transformation operation.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : `X` with columns of zeros inserted where features would have
    been removed by [`transform`](#sklearn.feature_selection.RFE.transform).

<!-- !! processed by numpydoc !! -->

#### predict(X, \*\*predict_params)

Reduce X to the selected features and predict using the estimator.

* **Parameters:**
  **X**
  : The input samples.

  **\*\*predict_params**
  : Parameters to route to the `predict` method of the
    underlying estimator.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing)
    for more details.
* **Returns:**
  **y**
  : The predicted target values.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Predict class log-probabilities for X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **p**
  : The class log-probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict class probabilities for X.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **p**
  : The class probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y, \*\*score_params)

Reduce X to the selected features and return the score of the estimator.

* **Parameters:**
  **X**
  : The input samples.

  **y**
  : The target values.

  **\*\*score_params**
  : - If `enable_metadata_routing=False` (default): Parameters directly passed
      to the `score` method of the underlying estimator.
    - If `enable_metadata_routing=True`: Parameters safely routed to the `score`
      method of the underlying estimator.
    <br/>
    #### Versionadded
    Added in version 1.0.
    <br/>
    #### Versionchanged
    Changed in version 1.6: See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing)
    for more details.
* **Returns:**
  **score**
  : Score of the underlying base estimator computed with the selected
    features returned by `rfe.transform(X)` and `y`.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Reduce X to the selected features.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : The input samples with only the selected features.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example demonstrates how Recursive Feature Elimination (~sklearn.feature_selection.RFE) can be used to determine the importance of individual pixels for classifying handwritten digits. RFE recursively removes the least significant features, assigning ranks based on their importance, where higher ranking_ values denote lower importance. The ranking is visualized using both shades of blue and pixel annotations for clarity. As expected, pixels positioned at the center of the image tend to be more predictive than those near the edges.">  <div class="sphx-glr-thumbnail-title">Recursive feature elimination</div>
</div>
* [Recursive feature elimination](../../auto_examples/feature_selection/plot_rfe_digits.md#sphx-glr-auto-examples-feature-selection-plot-rfe-digits-py)

<!-- thumbnail-parent-div-close --></div>
