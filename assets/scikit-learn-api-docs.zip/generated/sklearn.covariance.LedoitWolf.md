# LedoitWolf

### *class* sklearn.covariance.LedoitWolf(\*, store_precision=True, assume_centered=False, block_size=1000)

LedoitWolf Estimator.

Ledoit-Wolf is a particular form of shrinkage, where the shrinkage
coefficient is computed using O. Ledoit and M. Wolf’s formula as
described in “A Well-Conditioned Estimator for Large-Dimensional
Covariance Matrices”, Ledoit and Wolf, Journal of Multivariate
Analysis, Volume 88, Issue 2, February 2004, pages 365-411.

Read more in the [User Guide](../covariance.md#shrunk-covariance).

* **Parameters:**
  **store_precision**
  : Specify if the estimated precision is stored.

  **assume_centered**
  : If True, data will not be centered before computation.
    Useful when working with data whose mean is almost, but not exactly
    zero.
    If False (default), data will be centered before computation.

  **block_size**
  : Size of blocks into which the covariance matrix will be split
    during its Ledoit-Wolf estimation. This is purely a memory
    optimization and does not affect results.
* **Attributes:**
  **covariance_**
  : Estimated covariance matrix.

  **location_**
  : Estimated location, i.e. the estimated mean.

  **precision_**
  : Estimated pseudo inverse matrix.
    (stored only if store_precision is True)

  **shrinkage_**
  : Coefficient in the convex combination used for the computation
    of the shrunk estimate. Range is [0, 1].

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit).
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

#### SEE ALSO
[`EllipticEnvelope`](sklearn.covariance.EllipticEnvelope.md#sklearn.covariance.EllipticEnvelope)
: An object for detecting outliers in a Gaussian distributed dataset.

[`EmpiricalCovariance`](sklearn.covariance.EmpiricalCovariance.md#sklearn.covariance.EmpiricalCovariance)
: Maximum likelihood covariance estimator.

[`GraphicalLasso`](sklearn.covariance.GraphicalLasso.md#sklearn.covariance.GraphicalLasso)
: Sparse inverse covariance estimation with an l1-penalized estimator.

[`GraphicalLassoCV`](sklearn.covariance.GraphicalLassoCV.md#sklearn.covariance.GraphicalLassoCV)
: Sparse inverse covariance with cross-validated choice of the l1 penalty.

[`MinCovDet`](sklearn.covariance.MinCovDet.md#sklearn.covariance.MinCovDet)
: Minimum Covariance Determinant (robust estimator of covariance).

[`OAS`](sklearn.covariance.OAS.md#sklearn.covariance.OAS)
: Oracle Approximating Shrinkage Estimator.

[`ShrunkCovariance`](sklearn.covariance.ShrunkCovariance.md#sklearn.covariance.ShrunkCovariance)
: Covariance estimator with shrinkage.

### Notes

The regularised covariance is:

(1 - shrinkage) \* cov + shrinkage \* mu \* np.identity(n_features)

where mu = trace(cov) / n_features
and shrinkage is given by the Ledoit and Wolf formula (see References)

### References

“A Well-Conditioned Estimator for Large-Dimensional Covariance Matrices”,
Ledoit and Wolf, Journal of Multivariate Analysis, Volume 88, Issue 2,
February 2004, pages 365-411.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.covariance import LedoitWolf
>>> real_cov = np.array([[.4, .2],
...                      [.2, .8]])
>>> np.random.seed(0)
>>> X = np.random.multivariate_normal(mean=[0, 0],
...                                   cov=real_cov,
...                                   size=50)
>>> cov = LedoitWolf().fit(X)
>>> cov.covariance_
array([[0.4406..., 0.1616...],
       [0.1616..., 0.8022...]])
>>> cov.location_
array([ 0.0595... , -0.0075...])
```

See also [Shrinkage covariance estimation: LedoitWolf vs OAS and max-likelihood](../../auto_examples/covariance/plot_covariance_estimation.md#sphx-glr-auto-examples-covariance-plot-covariance-estimation-py)
for a more detailed example.

<!-- !! processed by numpydoc !! -->

#### error_norm(comp_cov, norm='frobenius', scaling=True, squared=True)

Compute the Mean Squared Error between two covariance estimators.

* **Parameters:**
  **comp_cov**
  : The covariance to compare with.

  **norm**
  : The type of norm used to compute the error. Available error types:
    - ‘frobenius’ (default): sqrt(tr(A^t.A))
    - ‘spectral’: sqrt(max(eigenvalues(A^t.A))
    where A is the error `(comp_cov - self.covariance_)`.

  **scaling**
  : If True (default), the squared error norm is divided by n_features.
    If False, the squared error norm is not rescaled.

  **squared**
  : Whether to compute the squared error norm or the error norm.
    If True (default), the squared error norm is returned.
    If False, the error norm is returned.
* **Returns:**
  **result**
  : The Mean Squared Error (in the sense of the Frobenius norm) between
    `self` and `comp_cov` covariance estimators.

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None)

Fit the Ledoit-Wolf shrunk covariance model to X.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_precision()

Getter for the precision matrix.

* **Returns:**
  **precision_**
  : The precision matrix associated to the current covariance object.

<!-- !! processed by numpydoc !! -->

#### mahalanobis(X)

Compute the squared Mahalanobis distances of given observations.

* **Parameters:**
  **X**
  : The observations, the Mahalanobis distances of the which we
    compute. Observations are assumed to be drawn from the same
    distribution than the data used in fit.
* **Returns:**
  **dist**
  : Squared Mahalanobis distances of the observations.

<!-- !! processed by numpydoc !! -->

#### score(X_test, y=None)

Compute the log-likelihood of `X_test` under the estimated Gaussian model.

The Gaussian model is defined by its mean and covariance matrix which are
represented respectively by `self.location_` and `self.covariance_`.

* **Parameters:**
  **X_test**
  : Test data of which we compute the likelihood, where `n_samples` is
    the number of samples and `n_features` is the number of features.
    `X_test` is assumed to be drawn from the same distribution than
    the data used in fit (including centering).

  **y**
  : Not used, present for API consistency by convention.
* **Returns:**
  **res**
  : The log-likelihood of `X_test` with `self.location_` and `self.covariance_`
    as estimators of the Gaussian model mean and covariance matrix respectively.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="The usual covariance maximum likelihood estimate can be regularized using shrinkage. Ledoit and Wolf proposed a close formula to compute the asymptotically optimal shrinkage parameter (minimizing a MSE criterion), yielding the Ledoit-Wolf covariance estimate.">  <div class="sphx-glr-thumbnail-title">Ledoit-Wolf vs OAS estimation</div>
</div>
* [Ledoit-Wolf vs OAS estimation](../../auto_examples/covariance/plot_lw_vs_oas.md#sphx-glr-auto-examples-covariance-plot-lw-vs-oas-py)

<div class="sphx-glr-thumbcontainer" tooltip="When working with covariance estimation, the usual approach is to use a maximum likelihood estimator, such as the EmpiricalCovariance. It is unbiased, i.e. it converges to the true (population) covariance when given many observations. However, it can also be beneficial to regularize it, in order to reduce its variance; this, in turn, introduces some bias. This example illustrates the simple regularization used in shrunk_covariance estimators. In particular, it focuses on how to set the amount of regularization, i.e. how to choose the bias-variance trade-off.">  <div class="sphx-glr-thumbnail-title">Shrinkage covariance estimation: LedoitWolf vs OAS and max-likelihood</div>
</div>
* [Shrinkage covariance estimation: LedoitWolf vs OAS and max-likelihood](../../auto_examples/covariance/plot_covariance_estimation.md#sphx-glr-auto-examples-covariance-plot-covariance-estimation-py)

<div class="sphx-glr-thumbcontainer" tooltip="Probabilistic PCA and Factor Analysis are probabilistic models. The consequence is that the likelihood of new data can be used for model selection and covariance estimation. Here we compare PCA and FA with cross-validation on low rank data corrupted with homoscedastic noise (noise variance is the same for each feature) or heteroscedastic noise (noise variance is the different for each feature). In a second step we compare the model likelihood to the likelihoods obtained from shrinkage covariance estimators.">  <div class="sphx-glr-thumbnail-title">Model selection with Probabilistic PCA and Factor Analysis (FA)</div>
</div>
* [Model selection with Probabilistic PCA and Factor Analysis (FA)](../../auto_examples/decomposition/plot_pca_vs_fa_model_selection.md#sphx-glr-auto-examples-decomposition-plot-pca-vs-fa-model-selection-py)

<!-- thumbnail-parent-div-close --></div>
