# GroupKFold

### *class* sklearn.model_selection.GroupKFold(n_splits=5, \*, shuffle=False, random_state=None)

K-fold iterator variant with non-overlapping groups.

Each group will appear exactly once in the test set across all folds (the
number of distinct groups has to be at least equal to the number of folds).

The folds are approximately balanced in the sense that the number of
samples is approximately the same in each test fold when `shuffle` is True.

Read more in the [User Guide](../cross_validation.md#group-k-fold).

For visualisation of cross-validation behaviour and
comparison between common scikit-learn split methods
refer to [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

* **Parameters:**
  **n_splits**
  : Number of folds. Must be at least 2.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `n_splits` default value changed from 3 to 5.

  **shuffle**
  : Whether to shuffle the groups before splitting into batches.
    Note that the samples within each split will not be shuffled.
    <br/>
    #### Versionadded
    Added in version 1.6.

  **random_state**
  : When `shuffle` is True, `random_state` affects the ordering of the
    indices, which controls the randomness of each fold. Otherwise, this
    parameter has no effect.
    Pass an int for reproducible output across multiple function calls.
    See [Glossary](../../glossary.md#term-random_state).
    <br/>
    #### Versionadded
    Added in version 1.6.

#### SEE ALSO
[`LeaveOneGroupOut`](sklearn.model_selection.LeaveOneGroupOut.md#sklearn.model_selection.LeaveOneGroupOut)
: For splitting the data according to explicit domain-specific stratification of the dataset.

[`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold)
: Takes class information into account to avoid building folds with imbalanced class proportions (for binary or multiclass classification tasks).

### Notes

Groups appear in an arbitrary order throughout the folds.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.model_selection import GroupKFold
>>> X = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12]])
>>> y = np.array([1, 2, 3, 4, 5, 6])
>>> groups = np.array([0, 0, 2, 2, 3, 3])
>>> group_kfold = GroupKFold(n_splits=2)
>>> group_kfold.get_n_splits(X, y, groups)
2
>>> print(group_kfold)
GroupKFold(n_splits=2, random_state=None, shuffle=False)
>>> for i, (train_index, test_index) in enumerate(group_kfold.split(X, y, groups)):
...     print(f"Fold {i}:")
...     print(f"  Train: index={train_index}, group={groups[train_index]}")
...     print(f"  Test:  index={test_index}, group={groups[test_index]}")
Fold 0:
  Train: index=[2 3], group=[2 2]
  Test:  index=[0 1 4 5], group=[0 0 3 3]
Fold 1:
  Train: index=[0 1 4 5], group=[0 0 3 3]
  Test:  index=[2 3], group=[2 2]
```

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

* **Returns:**
  **routing**
  : A [`MetadataRequest`](sklearn.utils.metadata_routing.MetadataRequest.md#sklearn.utils.metadata_routing.MetadataRequest) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_n_splits(X=None, y=None, groups=None)

Returns the number of splitting iterations in the cross-validator.

* **Parameters:**
  **X**
  : Always ignored, exists for compatibility.

  **y**
  : Always ignored, exists for compatibility.

  **groups**
  : Always ignored, exists for compatibility.
* **Returns:**
  **n_splits**
  : Returns the number of splitting iterations in the cross-validator.

<!-- !! processed by numpydoc !! -->

#### set_split_request(\*, groups: [bool](https://docs.python.org/3/library/functions.html#bool) | [None](https://docs.python.org/3/library/constants.html#None) | [str](https://docs.python.org/3/library/stdtypes.html#str) = '$UNCHANGED$') → [GroupKFold](#sklearn.model_selection.GroupKFold)

Request metadata passed to the `split` method.

Note that this method is only relevant if
`enable_metadata_routing=True` (see [`sklearn.set_config`](sklearn.set_config.md#sklearn.set_config)).
Please see [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

The options for each parameter are:

- `True`: metadata is requested, and passed to `split` if provided. The request is ignored if metadata is not provided.
- `False`: metadata is not requested and the meta-estimator will not pass it to `split`.
- `None`: metadata is not requested, and the meta-estimator will raise an error if the user provides it.
- `str`: metadata should be passed to the meta-estimator with this given alias instead of the original name.

The default (`sklearn.utils.metadata_routing.UNCHANGED`) retains the
existing request. This allows you to change the request for some
parameters and not others.

#### Versionadded
Added in version 1.3.

#### NOTE
This method is only relevant if this estimator is used as a
sub-estimator of a meta-estimator, e.g. used inside a
[`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline). Otherwise it has no effect.

* **Parameters:**
  **groups**
  : Metadata routing for `groups` parameter in `split`.
* **Returns:**
  **self**
  : The updated object.

<!-- !! processed by numpydoc !! -->

#### split(X, y=None, groups=None)

Generate indices to split data into training and test set.

* **Parameters:**
  **X**
  : Training data, where `n_samples` is the number of samples
    and `n_features` is the number of features.

  **y**
  : The target variable for supervised learning problems.

  **groups**
  : Group labels for the samples used while splitting the dataset into
    train/test set.
* **Yields:**
  **train**
  : The training set indices for that split.

  **test**
  : The testing set indices for that split.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Choosing the right cross-validation object is a crucial part of fitting a model properly. There are many ways to split data into training and test sets in order to avoid model overfitting, to standardize the number of groups in test sets, etc.">  <div class="sphx-glr-thumbnail-title">Visualizing cross-validation behavior in scikit-learn</div>
</div>
* [Visualizing cross-validation behavior in scikit-learn](../../auto_examples/model_selection/plot_cv_indices.md#sphx-glr-auto-examples-model-selection-plot-cv-indices-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 1.4! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_1_4&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 1.4</div>
</div>
* [Release Highlights for scikit-learn 1.4](../../auto_examples/release_highlights/plot_release_highlights_1_4_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-1-4-0-py)

<!-- thumbnail-parent-div-close --></div>
