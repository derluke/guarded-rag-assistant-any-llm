# clear_data_home

### sklearn.datasets.clear_data_home(data_home=None)

Delete all the content of the data home cache.

* **Parameters:**
  **data_home**
  : The path to scikit-learn data directory. If `None`, the default path
    is `~/scikit_learn_data`.

### Examples

```pycon
>>> from sklearn.datasets import clear_data_home
>>> clear_data_home()  
```

<!-- !! processed by numpydoc !! -->
