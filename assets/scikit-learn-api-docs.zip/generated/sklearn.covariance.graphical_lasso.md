# graphical_lasso

### sklearn.covariance.graphical_lasso(emp_cov, alpha, \*, mode='cd', tol=0.0001, enet_tol=0.0001, max_iter=100, verbose=False, return_costs=False, eps=2.220446049250313e-16, return_n_iter=False)

L1-penalized covariance estimator.

Read more in the [User Guide](../covariance.md#sparse-inverse-covariance).

#### Versionchanged
Changed in version v0.20: graph_lasso has been renamed to graphical_lasso

* **Parameters:**
  **emp_cov**
  : Empirical covariance from which to compute the covariance estimate.

  **alpha**
  : The regularization parameter: the higher alpha, the more
    regularization, the sparser the inverse covariance.
    Range is (0, inf].

  **mode**
  : The Lasso solver to use: coordinate descent or LARS. Use LARS for
    very sparse underlying graphs, where p > n. Elsewhere prefer cd
    which is more numerically stable.

  **tol**
  : The tolerance to declare convergence: if the dual gap goes below
    this value, iterations are stopped. Range is (0, inf].

  **enet_tol**
  : The tolerance for the elastic net solver used to calculate the descent
    direction. This parameter controls the accuracy of the search direction
    for a given column update, not of the overall parameter estimate. Only
    used for mode=’cd’. Range is (0, inf].

  **max_iter**
  : The maximum number of iterations.

  **verbose**
  : If verbose is True, the objective function and dual gap are
    printed at each iteration.

  **return_costs**
  : If return_costs is True, the objective function and dual gap
    at each iteration are returned.

  **eps**
  : The machine-precision regularization in the computation of the
    Cholesky diagonal factors. Increase this for very ill-conditioned
    systems. Default is `np.finfo(np.float64).eps`.

  **return_n_iter**
  : Whether or not to return the number of iterations.
* **Returns:**
  **covariance**
  : The estimated covariance matrix.

  **precision**
  : The estimated (sparse) precision matrix.

  **costs**
  : The list of values of the objective function and the dual gap at
    each iteration. Returned only if return_costs is True.

  **n_iter**
  : Number of iterations. Returned only if `return_n_iter` is set to True.

#### SEE ALSO
[`GraphicalLasso`](sklearn.covariance.GraphicalLasso.md#sklearn.covariance.GraphicalLasso)
: Sparse inverse covariance estimation with an l1-penalized estimator.

[`GraphicalLassoCV`](sklearn.covariance.GraphicalLassoCV.md#sklearn.covariance.GraphicalLassoCV)
: Sparse inverse covariance with cross-validated choice of the l1 penalty.

### Notes

The algorithm employed to solve this problem is the GLasso algorithm,
from the Friedman 2008 Biostatistics paper. It is the same algorithm
as in the R `glasso` package.

One possible difference with the `glasso` R package is that the
diagonal coefficients are not penalized.

### Examples

```pycon
>>> import numpy as np
>>> from sklearn.datasets import make_sparse_spd_matrix
>>> from sklearn.covariance import empirical_covariance, graphical_lasso
>>> true_cov = make_sparse_spd_matrix(n_dim=3,random_state=42)
>>> rng = np.random.RandomState(42)
>>> X = rng.multivariate_normal(mean=np.zeros(3), cov=true_cov, size=3)
>>> emp_cov = empirical_covariance(X, assume_centered=True)
>>> emp_cov, _ = graphical_lasso(emp_cov, alpha=0.05)
>>> emp_cov
array([[ 1.68...,  0.21..., -0.20...],
       [ 0.21...,  0.22..., -0.08...],
       [-0.20..., -0.08...,  0.23...]])
```

<!-- !! processed by numpydoc !! -->
