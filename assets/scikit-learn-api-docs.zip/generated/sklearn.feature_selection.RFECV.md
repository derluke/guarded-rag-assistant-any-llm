# RFECV

### *class* sklearn.feature_selection.RFECV(estimator, \*, step=1, min_features_to_select=1, cv=None, scoring=None, verbose=0, n_jobs=None, importance_getter='auto')

Recursive feature elimination with cross-validation to select features.

The number of features selected is tuned automatically by fitting an [`RFE`](sklearn.feature_selection.RFE.md#sklearn.feature_selection.RFE)
selector on the different cross-validation splits (provided by the `cv` parameter).
The performance of the [`RFE`](sklearn.feature_selection.RFE.md#sklearn.feature_selection.RFE) selector are evaluated using `scorer` for
different number of selected features and aggregated together. Finally, the scores
are averaged across folds and the number of features selected is set to the number
of features that maximize the cross-validation score.
See glossary entry for [cross-validation estimator](../../glossary.md#term-cross-validation-estimator).

Read more in the [User Guide](../feature_selection.md#rfe).

* **Parameters:**
  **estimator**
  : A supervised learning estimator with a `fit` method that provides
    information about feature importance either through a `coef_`
    attribute or through a `feature_importances_` attribute.

  **step**
  : If greater than or equal to 1, then `step` corresponds to the
    (integer) number of features to remove at each iteration.
    If within (0.0, 1.0), then `step` corresponds to the percentage
    (rounded down) of features to remove at each iteration.
    Note that the last iteration may remove fewer than `step` features in
    order to reach `min_features_to_select`.

  **min_features_to_select**
  : The minimum number of features to be selected. This number of features
    will always be scored, even if the difference between the original
    feature count and `min_features_to_select` isn’t divisible by
    `step`.
    <br/>
    #### Versionadded
    Added in version 0.20.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross-validation,
    - integer, to specify the number of folds.
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs, if `y` is binary or multiclass,
    [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. If the
    estimator is not a classifier or if `y` is neither binary nor multiclass,
    [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.
    <br/>
    #### Versionchanged
    Changed in version 0.22: `cv` default value of None changed from 3-fold to 5-fold.

  **scoring**
  : A string (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter)) or
    a scorer callable object / function with signature
    `scorer(estimator, X, y)`.

  **verbose**
  : Controls verbosity of output.

  **n_jobs**
  : Number of cores to run in parallel while fitting across folds.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
    <br/>
    #### Versionadded
    Added in version 0.18.

  **importance_getter**
  : If ‘auto’, uses the feature importance either through a `coef_`
    or `feature_importances_` attributes of estimator.
    <br/>
    Also accepts a string that specifies an attribute name/path
    for extracting feature importance.
    For example, give `regressor_.coef_` in case of
    [`TransformedTargetRegressor`](sklearn.compose.TransformedTargetRegressor.md#sklearn.compose.TransformedTargetRegressor)  or
    `named_steps.clf.feature_importances_` in case of
    [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline) with its last step named `clf`.
    <br/>
    If `callable`, overrides the default feature importance getter.
    The callable is passed with the fitted estimator and it should
    return importance for each feature.
    <br/>
    #### Versionadded
    Added in version 0.24.
* **Attributes:**
  [`classes_`](#sklearn.feature_selection.RFECV.classes_)
  : Classes labels available when `estimator` is a classifier.

  **estimator_**
  : The fitted estimator used to select features.

  **cv_results_**
  : All arrays (values of the dictionary) are sorted in ascending order
    by the number of features used (i.e., the first element of the array
    represents the models that used the least number of features, while the
    last element represents the models that used all available features).
    <br/>
    #### Versionadded
    Added in version 1.0.
    <br/>
    This dictionary contains the following keys:
    <br/>
    split(k)_test_score
    : The cross-validation scores across (k)th fold.
    <br/>
    mean_test_score
    : Mean of scores over the folds.
    <br/>
    std_test_score
    : Standard deviation of scores over the folds.
    <br/>
    n_features
    : Number of features used at each step.
      <br/>
      #### Versionadded
      Added in version 1.5.

  **n_features_**
  : The number of selected features with cross-validation.

  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **ranking_**
  : The feature ranking, such that `ranking_[i]`
    corresponds to the ranking
    position of the i-th feature.
    Selected (i.e., estimated best)
    features are assigned rank 1.

  **support_**
  : The mask of selected features.

#### SEE ALSO
[`RFE`](sklearn.feature_selection.RFE.md#sklearn.feature_selection.RFE)
: Recursive feature elimination.

### Notes

The size of all values in `cv_results_` is equal to
`ceil((n_features - min_features_to_select) / step) + 1`,
where step is the number of features removed at each iteration.

Allows NaN/Inf in the input if the underlying estimator does as well.

### References

### Examples

The following example shows how to retrieve the a-priori not known 5
informative features in the Friedman #1 dataset.

```pycon
>>> from sklearn.datasets import make_friedman1
>>> from sklearn.feature_selection import RFECV
>>> from sklearn.svm import SVR
>>> X, y = make_friedman1(n_samples=50, n_features=10, random_state=0)
>>> estimator = SVR(kernel="linear")
>>> selector = RFECV(estimator, step=1, cv=5)
>>> selector = selector.fit(X, y)
>>> selector.support_
array([ True,  True,  True,  True,  True, False, False, False, False,
       False])
>>> selector.ranking_
array([1, 1, 1, 1, 1, 6, 4, 3, 2, 5])
```

<!-- !! processed by numpydoc !! -->

#### *property* classes_

Classes labels available when `estimator` is a classifier.

* **Returns:**
  ndarray of shape (n_classes,)

<!-- !! processed by numpydoc !! -->

#### decision_function(X)

Compute the decision function of `X`.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **score**
  : The decision function of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).
    Regression and binary classification produce an array of shape
    [n_samples].

<!-- !! processed by numpydoc !! -->

#### fit(X, y, \*, groups=None, \*\*params)

Fit the RFE model and automatically tune the number of selected features.

* **Parameters:**
  **X**
  : Training vector, where `n_samples` is the number of samples and
    `n_features` is the total number of features.

  **y**
  : Target values (integers for classification, real numbers for
    regression).

  **groups**
  : Group labels for the samples used while splitting the dataset into
    train/test set. Only used in conjunction with a “Group” [cv](../../glossary.md#term-cv)
    instance (e.g., [`GroupKFold`](sklearn.model_selection.GroupKFold.md#sklearn.model_selection.GroupKFold)).
    <br/>
    #### Versionadded
    Added in version 0.20.

  **\*\*params**
  : Parameters passed to the `fit` method of the estimator,
    the scorer, and the CV splitter.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing)
    for more details.
* **Returns:**
  **self**
  : Fitted estimator.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Mask feature names according to selected features.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.6.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_support(indices=False)

Get a mask, or integer index, of the features selected.

* **Parameters:**
  **indices**
  : If True, the return value will be an array of integers, rather
    than a boolean mask.
* **Returns:**
  **support**
  : An index that selects the retained features from a feature vector.
    If `indices` is False, this is a boolean array of shape
    [# input features], in which an element is True iff its
    corresponding feature is selected for retention. If `indices` is
    True, this is an integer array of shape [# output features] whose
    values are indices into the input feature vector.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Reverse the transformation operation.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : `X` with columns of zeros inserted where features would have
    been removed by [`transform`](#sklearn.feature_selection.RFECV.transform).

<!-- !! processed by numpydoc !! -->

#### predict(X, \*\*predict_params)

Reduce X to the selected features and predict using the estimator.

* **Parameters:**
  **X**
  : The input samples.

  **\*\*predict_params**
  : Parameters to route to the `predict` method of the
    underlying estimator.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing)
    for more details.
* **Returns:**
  **y**
  : The predicted target values.

<!-- !! processed by numpydoc !! -->

#### predict_log_proba(X)

Predict class log-probabilities for X.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **p**
  : The class log-probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### predict_proba(X)

Predict class probabilities for X.

* **Parameters:**
  **X**
  : The input samples. Internally, it will be converted to
    `dtype=np.float32` and if a sparse matrix is provided
    to a sparse `csr_matrix`.
* **Returns:**
  **p**
  : The class probabilities of the input samples. The order of the
    classes corresponds to that in the attribute [classes_](../../glossary.md#term-classes_).

<!-- !! processed by numpydoc !! -->

#### score(X, y, \*\*score_params)

Score using the `scoring` option on the given test data and labels.

* **Parameters:**
  **X**
  : Test samples.

  **y**
  : True labels for X.

  **\*\*score_params**
  : Parameters to pass to the `score` method of the underlying scorer.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing)
    for more details.
* **Returns:**
  **score**
  : Score of self.predict(X) w.r.t. y defined by `scoring`.

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Reduce X to the selected features.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : The input samples with only the selected features.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="A Recursive Feature Elimination (RFE) example with automatic tuning of the number of features selected with cross-validation.">  <div class="sphx-glr-thumbnail-title">Recursive feature elimination with cross-validation</div>
</div>
* [Recursive feature elimination with cross-validation](../../auto_examples/feature_selection/plot_rfe_with_cross_validation.md#sphx-glr-auto-examples-feature-selection-plot-rfe-with-cross-validation-py)

<!-- thumbnail-parent-div-close --></div>
