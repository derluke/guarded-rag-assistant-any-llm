# SequentialFeatureSelector

### *class* sklearn.feature_selection.SequentialFeatureSelector(estimator, \*, n_features_to_select='auto', tol=None, direction='forward', scoring=None, cv=5, n_jobs=None)

Transformer that performs Sequential Feature Selection.

This Sequential Feature Selector adds (forward selection) or
removes (backward selection) features to form a feature subset in a
greedy fashion. At each stage, this estimator chooses the best feature to
add or remove based on the cross-validation score of an estimator. In
the case of unsupervised learning, this Sequential Feature Selector
looks only at the features (X), not the desired outputs (y).

Read more in the [User Guide](../feature_selection.md#sequential-feature-selection).

#### Versionadded
Added in version 0.24.

* **Parameters:**
  **estimator**
  : An unfitted estimator.

  **n_features_to_select**
  : If `"auto"`, the behaviour depends on the `tol` parameter:
    - if `tol` is not `None`, then features are selected while the score
      change does not exceed `tol`.
    - otherwise, half of the features are selected.
    <br/>
    If integer, the parameter is the absolute number of features to select.
    If float between 0 and 1, it is the fraction of features to select.
    <br/>
    #### Versionadded
    Added in version 1.1: The option `"auto"` was added in version 1.1.
    <br/>
    #### Versionchanged
    Changed in version 1.3: The default changed from `"warn"` to `"auto"` in 1.3.

  **tol**
  : If the score is not incremented by at least `tol` between two
    consecutive feature additions or removals, stop adding or removing.
    <br/>
    `tol` can be negative when removing features using `direction="backward"`.
    `tol` is required to be strictly positive when doing forward selection.
    It can be useful to reduce the number of features at the cost of a small
    decrease in the score.
    <br/>
    `tol` is enabled only when `n_features_to_select` is `"auto"`.
    <br/>
    #### Versionadded
    Added in version 1.1.

  **direction**
  : Whether to perform forward selection or backward selection.

  **scoring**
  : A single str (see [The scoring parameter: defining model evaluation rules](../model_evaluation.md#scoring-parameter)) or a callable
    (see [Callable scorers](../model_evaluation.md#scoring-callable)) to evaluate the predictions on the test set.
    <br/>
    NOTE that when using a custom scorer, it should return a single
    value.
    <br/>
    If None, the estimator’s score method is used.

  **cv**
  : Determines the cross-validation splitting strategy.
    Possible inputs for cv are:
    - None, to use the default 5-fold cross validation,
    - integer, to specify the number of folds in a `(Stratified)KFold`,
    - [CV splitter](../../glossary.md#term-CV-splitter),
    - An iterable yielding (train, test) splits as arrays of indices.
    <br/>
    For integer/None inputs, if the estimator is a classifier and `y` is
    either binary or multiclass,
    [`StratifiedKFold`](sklearn.model_selection.StratifiedKFold.md#sklearn.model_selection.StratifiedKFold) is used. In all other
    cases, [`KFold`](sklearn.model_selection.KFold.md#sklearn.model_selection.KFold) is used. These splitters
    are instantiated with `shuffle=False` so the splits will be the same
    across calls.
    <br/>
    Refer [User Guide](../cross_validation.md#cross-validation) for the various
    cross-validation strategies that can be used here.

  **n_jobs**
  : Number of jobs to run in parallel. When evaluating a new feature to
    add or remove, the cross-validation procedure is parallel over the
    folds.
    `None` means 1 unless in a [`joblib.parallel_backend`](https://joblib.readthedocs.io/en/latest/generated/joblib.parallel_backend.html#joblib.parallel_backend) context.
    `-1` means using all processors. See [Glossary](../../glossary.md#term-n_jobs)
    for more details.
* **Attributes:**
  **n_features_in_**
  : Number of features seen during [fit](../../glossary.md#term-fit). Only defined if the
    underlying estimator exposes such an attribute when fit.
    <br/>
    #### Versionadded
    Added in version 0.24.

  **feature_names_in_**
  : Names of features seen during [fit](../../glossary.md#term-fit). Defined only when `X`
    has feature names that are all strings.
    <br/>
    #### Versionadded
    Added in version 1.0.

  **n_features_to_select_**
  : The number of features that were selected.

  **support_**
  : The mask of selected features.

#### SEE ALSO
[`GenericUnivariateSelect`](sklearn.feature_selection.GenericUnivariateSelect.md#sklearn.feature_selection.GenericUnivariateSelect)
: Univariate feature selector with configurable strategy.

[`RFE`](sklearn.feature_selection.RFE.md#sklearn.feature_selection.RFE)
: Recursive feature elimination based on importance weights.

[`RFECV`](sklearn.feature_selection.RFECV.md#sklearn.feature_selection.RFECV)
: Recursive feature elimination based on importance weights, with automatic selection of the number of features.

[`SelectFromModel`](sklearn.feature_selection.SelectFromModel.md#sklearn.feature_selection.SelectFromModel)
: Feature selection based on thresholds of importance weights.

### Examples

```pycon
>>> from sklearn.feature_selection import SequentialFeatureSelector
>>> from sklearn.neighbors import KNeighborsClassifier
>>> from sklearn.datasets import load_iris
>>> X, y = load_iris(return_X_y=True)
>>> knn = KNeighborsClassifier(n_neighbors=3)
>>> sfs = SequentialFeatureSelector(knn, n_features_to_select=3)
>>> sfs.fit(X, y)
SequentialFeatureSelector(estimator=KNeighborsClassifier(n_neighbors=3),
                          n_features_to_select=3)
>>> sfs.get_support()
array([ True, False,  True,  True])
>>> sfs.transform(X).shape
(150, 3)
```

<!-- !! processed by numpydoc !! -->

#### fit(X, y=None, \*\*params)

Learn the features to select from X.

* **Parameters:**
  **X**
  : Training vectors, where `n_samples` is the number of samples and
    `n_features` is the number of predictors.

  **y**
  : Target values. This parameter may be ignored for
    unsupervised learning.

  **\*\*params**
  : Parameters to be passed to the underlying `estimator`, `cv`
    and `scorer` objects.
    <br/>
    #### Versionadded
    Added in version 1.6: Only available if `enable_metadata_routing=True`,
    which can be set by using
    `sklearn.set_config(enable_metadata_routing=True)`.
    See [Metadata Routing User Guide](../../metadata_routing.md#metadata-routing) for
    more details.
* **Returns:**
  **self**
  : Returns the instance itself.

<!-- !! processed by numpydoc !! -->

#### fit_transform(X, y=None, \*\*fit_params)

Fit to data, then transform it.

Fits transformer to `X` and `y` with optional parameters `fit_params`
and returns a transformed version of `X`.

* **Parameters:**
  **X**
  : Input samples.

  **y**
  : Target values (None for unsupervised transformations).

  **\*\*fit_params**
  : Additional fit parameters.
* **Returns:**
  **X_new**
  : Transformed array.

<!-- !! processed by numpydoc !! -->

#### get_feature_names_out(input_features=None)

Mask feature names according to selected features.

* **Parameters:**
  **input_features**
  : Input features.
    - If `input_features` is `None`, then `feature_names_in_` is
      used as feature names in. If `feature_names_in_` is not defined,
      then the following input feature names are generated:
      `["x0", "x1", ..., "x(n_features_in_ - 1)"]`.
    - If `input_features` is an array-like, then `input_features` must
      match `feature_names_in_` if `feature_names_in_` is defined.
* **Returns:**
  **feature_names_out**
  : Transformed feature names.

<!-- !! processed by numpydoc !! -->

#### get_metadata_routing()

Get metadata routing of this object.

Please check [User Guide](../../metadata_routing.md#metadata-routing) on how the routing
mechanism works.

#### Versionadded
Added in version 1.6.

* **Returns:**
  **routing**
  : A [`MetadataRouter`](sklearn.utils.metadata_routing.MetadataRouter.md#sklearn.utils.metadata_routing.MetadataRouter) encapsulating
    routing information.

<!-- !! processed by numpydoc !! -->

#### get_params(deep=True)

Get parameters for this estimator.

* **Parameters:**
  **deep**
  : If True, will return the parameters for this estimator and
    contained subobjects that are estimators.
* **Returns:**
  **params**
  : Parameter names mapped to their values.

<!-- !! processed by numpydoc !! -->

#### get_support(indices=False)

Get a mask, or integer index, of the features selected.

* **Parameters:**
  **indices**
  : If True, the return value will be an array of integers, rather
    than a boolean mask.
* **Returns:**
  **support**
  : An index that selects the retained features from a feature vector.
    If `indices` is False, this is a boolean array of shape
    [# input features], in which an element is True iff its
    corresponding feature is selected for retention. If `indices` is
    True, this is an integer array of shape [# output features] whose
    values are indices into the input feature vector.

<!-- !! processed by numpydoc !! -->

#### inverse_transform(X)

Reverse the transformation operation.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : `X` with columns of zeros inserted where features would have
    been removed by [`transform`](#sklearn.feature_selection.SequentialFeatureSelector.transform).

<!-- !! processed by numpydoc !! -->

#### set_output(\*, transform=None)

Set output container.

See [Introducing the set_output API](../../auto_examples/miscellaneous/plot_set_output.md#sphx-glr-auto-examples-miscellaneous-plot-set-output-py)
for an example on how to use the API.

* **Parameters:**
  **transform**
  : Configure output of `transform` and `fit_transform`.
    - `"default"`: Default output format of a transformer
    - `"pandas"`: DataFrame output
    - `"polars"`: Polars output
    - `None`: Transform configuration is unchanged
    <br/>
    #### Versionadded
    Added in version 1.4: `"polars"` option was added.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### set_params(\*\*params)

Set the parameters of this estimator.

The method works on simple estimators as well as on nested objects
(such as [`Pipeline`](sklearn.pipeline.Pipeline.md#sklearn.pipeline.Pipeline)). The latter have
parameters of the form `<component>__<parameter>` so that it’s
possible to update each component of a nested object.

* **Parameters:**
  **\*\*params**
  : Estimator parameters.
* **Returns:**
  **self**
  : Estimator instance.

<!-- !! processed by numpydoc !! -->

#### transform(X)

Reduce X to the selected features.

* **Parameters:**
  **X**
  : The input samples.
* **Returns:**
  **X_r**
  : The input samples with only the selected features.

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="This example illustrates and compares two approaches for feature selection: SelectFromModel which is based on feature importance, and SequentialFeatureSelector which relies on a greedy approach.">  <div class="sphx-glr-thumbnail-title">Model-based and sequential feature selection</div>
</div>
* [Model-based and sequential feature selection](../../auto_examples/feature_selection/plot_select_from_model_diabetes.md#sphx-glr-auto-examples-feature-selection-plot-select-from-model-diabetes-py)

<div class="sphx-glr-thumbcontainer" tooltip="We are pleased to announce the release of scikit-learn 0.24! Many bug fixes and improvements were added, as well as some new key features. We detail below a few of the major features of this release. For an exhaustive list of all the changes, please refer to the release notes &lt;release_notes_0_24&gt;.">  <div class="sphx-glr-thumbnail-title">Release Highlights for scikit-learn 0.24</div>
</div>
* [Release Highlights for scikit-learn 0.24](../../auto_examples/release_highlights/plot_release_highlights_0_24_0.md#sphx-glr-auto-examples-release-highlights-plot-release-highlights-0-24-0-py)

<!-- thumbnail-parent-div-close --></div>
