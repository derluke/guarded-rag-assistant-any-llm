# hamming_loss

### sklearn.metrics.hamming_loss(y_true, y_pred, \*, sample_weight=None)

Compute the average Hamming loss.

The Hamming loss is the fraction of labels that are incorrectly predicted.

Read more in the [User Guide](../model_evaluation.md#hamming-loss).

* **Parameters:**
  **y_true**
  : Ground truth (correct) labels.

  **y_pred**
  : Predicted labels, as returned by a classifier.

  **sample_weight**
  : Sample weights.
    <br/>
    #### Versionadded
    Added in version 0.18.
* **Returns:**
  **loss**
  : Return the average Hamming loss between element of `y_true` and
    `y_pred`.

#### SEE ALSO
[`accuracy_score`](sklearn.metrics.accuracy_score.md#sklearn.metrics.accuracy_score)
: Compute the accuracy score. By default, the function will return the fraction of correct predictions divided by the total number of predictions.

[`jaccard_score`](sklearn.metrics.jaccard_score.md#sklearn.metrics.jaccard_score)
: Compute the Jaccard similarity coefficient score.

[`zero_one_loss`](sklearn.metrics.zero_one_loss.md#sklearn.metrics.zero_one_loss)
: Compute the Zero-one classification loss. By default, the function will return the percentage of imperfectly predicted subsets.

### Notes

In multiclass classification, the Hamming loss corresponds to the Hamming
distance between `y_true` and `y_pred` which is equivalent to the
subset `zero_one_loss` function, when `normalize` parameter is set to
True.

In multilabel classification, the Hamming loss is different from the
subset zero-one loss. The zero-one loss considers the entire set of labels
for a given sample incorrect if it does not entirely match the true set of
labels. Hamming loss is more forgiving in that it penalizes only the
individual labels.

The Hamming loss is upperbounded by the subset zero-one loss, when
`normalize` parameter is set to True. It is always between 0 and 1,
lower being better.

### References

### Examples

```pycon
>>> from sklearn.metrics import hamming_loss
>>> y_pred = [1, 2, 3, 4]
>>> y_true = [2, 2, 3, 4]
>>> hamming_loss(y_true, y_pred)
0.25
```

In the multilabel case with binary label indicators:

```pycon
>>> import numpy as np
>>> hamming_loss(np.array([[0, 1], [1, 1]]), np.zeros((2, 2)))
0.75
```

<!-- !! processed by numpydoc !! -->

## Gallery examples

<div class="sphx-glr-thumbnails">
<!-- thumbnail-parent-div-open --><div class="sphx-glr-thumbcontainer" tooltip="Demonstrate how model complexity influences both prediction accuracy and computational performance.">  <div class="sphx-glr-thumbnail-title">Model Complexity Influence</div>
</div>
* [Model Complexity Influence](../../auto_examples/applications/plot_model_complexity_influence.md#sphx-glr-auto-examples-applications-plot-model-complexity-influence-py)

<!-- thumbnail-parent-div-close --></div>
